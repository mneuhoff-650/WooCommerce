(()=>{
/**
 * Accept.Blue v2 WooCommerce Blocks Integration
 * Handles card form + tokenization via backend /v2/savedcards
 */

const acceptbluev2_settings = window.wc.wcSettings.getSetting('acceptbluev2_data', {});
const { createElement, useState, useEffect } = window.wp.element;

// ── Apply color scheme on load ────────────────────────────────────────────────
(function() {
	const scheme = acceptbluev2_settings.form_color_scheme || 'auto';
	if ( scheme === 'light' || scheme === 'dark' || scheme === 'custom' ) {
		document.body.setAttribute( 'data-ab-scheme', scheme );
	}
	if ( scheme === 'custom' ) {
		const bg     = acceptbluev2_settings.custom_color_bg     || '#f7f7f7';
		const text   = acceptbluev2_settings.custom_color_text   || '#333333';
		const border = acceptbluev2_settings.custom_color_border || '#cccccc';
		document.documentElement.style.setProperty( '--ab-custom-bg',     bg );
		document.documentElement.style.setProperty( '--ab-custom-text',   text );
		document.documentElement.style.setProperty( '--ab-custom-border', border );
	}
})();


/**
 * Card Input Form
 */
const AcceptBlueV2Form = ({ onCardChange }) => {
	const [card, setCard] = useState({ number: '', expiry: '', cvv: '' });

	const handleChange = (field, value) => {
		const updated = { ...card, [field]: value };
		setCard(updated);
		onCardChange(updated);
	};

	const formatCardNumber = (value) => {
		return value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
	};

	const formatExpiry = (value) => {
		const cleaned = value.replace(/\D/g, '');
		if (cleaned.length >= 2) {
			return `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`;
		}
		return cleaned;
	};

	const formatCVV = (value) => {
		return value.replace(/\D/g, '').slice(0, 4);
	};

	// Build input style based on color scheme
	const scheme    = acceptbluev2_settings.form_color_scheme || 'auto';
	const isDarkInput = scheme === 'dark' ||
	                    ( scheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );
	let inputStyle;
	if ( scheme === 'custom' ) {
		inputStyle = {
			backgroundColor: acceptbluev2_settings.custom_color_bg     || '#f7f7f7',
			color:           acceptbluev2_settings.custom_color_text   || '#333333',
			border:          '2px solid ' + ( acceptbluev2_settings.custom_color_border || '#cccccc' ),
		};
	} else if ( isDarkInput ) {
		inputStyle = {
			backgroundColor: '#2a2a2a',
			color:           '#f0f0f0',
			border:          '2px solid #555555',
		};
	} else {
		inputStyle = {
			backgroundColor: '#f7f7f7',
			color:           '#333333',
			border:          '2px solid #cccccc',
		};
	}


	return createElement(
		'div',
		{ className: 'acceptbluev2-card-form' },
		createElement('label', {}, acceptbluev2_settings.card_number_field_label || 'Card Number'),
		createElement('input', {
			type: 'text',
			placeholder: '•••• •••• •••• ••••',
			value: card.number,
			onChange: (e) => handleChange('number', formatCardNumber(e.target.value)),
			autoComplete: 'cc-number',
			maxLength: 19,
			style: inputStyle,
		}),
		createElement('label', {}, acceptbluev2_settings.card_expiry_field_label || 'Expiry (MM/YY)'),
		createElement('input', {
			type: 'text',
			placeholder: 'MM/YY',
			value: card.expiry,
			onChange: (e) => handleChange('expiry', formatExpiry(e.target.value)),
			autoComplete: 'cc-exp',
			maxLength: 5,
			style: inputStyle,
		}),
		createElement('label', {}, acceptbluev2_settings.card_cvc_field_label || 'CVV'),
		createElement('input', {
			type: 'password',
			placeholder: 'CVV',
			value: card.cvv,
			onChange: (e) => handleChange('cvv', formatCVV(e.target.value)),
			autoComplete: 'cc-csc',
			maxLength: 4,
			style: inputStyle,
		})
	);
};

/**
 * Sandbox Notice
 */
const AcceptBlueV2SandboxNotice = () => {
	if (!acceptbluev2_settings.sandbox) return null;

	const lines = [];
	lines.push('TEST MODE / SANDBOX ENABLED');
	lines.push('');
	lines.push('TEST CARDS');
	lines.push('Visa - 4761530001111118');
	lines.push('Discover - 6011208701117775');

	// Apply background + text inline so it renders correctly regardless of CSS variable support.
	const scheme  = acceptbluev2_settings.form_color_scheme || 'auto';
	const isDark  = scheme === 'dark' ||
	                ( scheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );
	const noticeBg   = isDark ? '#3a2e00' : '#fff3cd';
	const noticeBorder = isDark ? '#665200' : '#ffeeba';
	const textColor  = isDark ? '#f0f0f0' : '#333333';

	return createElement(
		'div',
		{
			className: 'acceptblue-test-cards-notice',
			style: { backgroundColor: noticeBg, border: '1px solid ' + noticeBorder, color: textColor },
		},
		lines.map((line, index) =>
			createElement(
				'div',
				{ key: index, style: { fontWeight: index === 0 ? 'bold' : 'normal' } },
				line
			)
		)
	);
};

/**
 * Saved Payment Token selector
 * Shows stored cards and a "Use a new card" option.
 */
const AcceptBlueV2SavedTokens = ({ selectedToken, onChange }) => {
	const tokens = acceptbluev2_settings.saved_tokens || [];
	if (!tokens.length) return null;

	const cardLabel = (token) => {
		const type = token.card_type
			? token.card_type.charAt(0).toUpperCase() + token.card_type.slice(1)
			: 'Card';
		return `${type} ···· ${token.last4}  exp ${token.expiry_month}/${String(token.expiry_year).slice(-2)}`;
	};

	return createElement(
		'div',
		{ className: 'acceptbluev2-saved-tokens' },
		tokens.map((token) => {
			const isSelected = selectedToken === String(token.id);
			return createElement(
				'div',
				{
					key: token.id,
					className: 'acceptbluev2-token-option' + (isSelected ? ' acceptbluev2-token-option--selected' : ''),
				},
				createElement(
					'label',
					{ className: 'acceptbluev2-token-label' },
					createElement('input', {
						type: 'radio',
						name: 'acceptbluev2-saved-token',
						value: String(token.id),
						checked: isSelected,
						onChange: () => onChange(String(token.id)),
					}),
						createElement('span', null, cardLabel(token))
				)
			);
		}),
		createElement(
			'div',
			{
				className: 'acceptbluev2-token-option acceptbluev2-token-new' + (selectedToken === 'new' ? ' acceptbluev2-token-option--selected' : ''),
			},
			createElement(
				'label',
				{ className: 'acceptbluev2-token-label' },
				createElement('input', {
					type: 'radio',
					name: 'acceptbluev2-saved-token',
					value: 'new',
					checked: selectedToken === 'new',
					onChange: () => onChange('new'),
				}),
					createElement('span', null, 'Use a new card')
			)
		)
	);
};

/**
 * Save to Account Checkbox
 * Only shown to logged-in users when saving is enabled and not forced.
 */
const AcceptBlueV2SaveCard = ({ saveCard, onChange }) => {
	if (!acceptbluev2_settings.is_logged_in) return null;
	if (!acceptbluev2_settings.save_card_enabled) return null;
	if (acceptbluev2_settings.force_save_card) return null;

	return createElement(
		'div',
		{ className: 'acceptbluev2-save-card-row' },
		createElement(
			'label',
			{ className: 'acceptbluev2-save-card-label' },
			createElement('input', {
				type: 'checkbox',
				id: 'acceptbluev2-save-card',
				checked: saveCard,
				onChange: (e) => onChange(e.target.checked),
			}),
			acceptbluev2_settings.save_card_label || 'Save to account'
		)
	);
};

/**
 * Main Checkout Block Payment Component
 */
const AcceptBlueV2Content = (props) => {
	const tokens = acceptbluev2_settings.saved_tokens || [];
	const defaultToken = tokens.length
		? (tokens.find(t => t.is_default) || tokens[0])
		: null;

	const [cardData, setCardData] = useState({});
	const [saveCard, setSaveCard] = useState(!!acceptbluev2_settings.force_save_card);
	const [selectedToken, setSelectedToken] = useState(
		defaultToken ? String(defaultToken.id) : 'new'
	);

	const usingNewCard = selectedToken === 'new';
	const { eventRegistration } = props || {};
	const onPaymentSetup = eventRegistration?.onPaymentSetup;

	useEffect(() => {
		if (!onPaymentSetup) return;

		const unsubscribe = onPaymentSetup(async () => {

			// Using a saved token — pass the WC token ID directly
			if (!usingNewCard) {
				return {
					type: 'success',
					meta: {
						paymentMethodData: {
							'acceptbluev2-block-token-id': selectedToken,
						},
					},
				};
			}

            const ajax_url = acceptblue_hosted_token_params.site_url;

			try {
				const response = await fetch( ajax_url + '/?wc-ajax=acceptbluev2_tokenize', {                
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(cardData),
				});

				const result = await response.json();

				if (!result.success) {
					return {
						type: 'error',
						message: result.data?.message || 'Card tokenization failed.',
					};
				}

				return {
					type: 'success',
					meta: {
						paymentMethodData: {
							token: result.data.token,
							'acceptbluev2-expiry-month': String(result.data.expiry_month || ''),
							'acceptbluev2-expiry-year':  String(result.data.expiry_year  || ''),
							'acceptbluev2-last4':        String(result.data.last4        || ''),
							'acceptbluev2-save-card': (acceptbluev2_settings.force_save_card || saveCard) ? '1' : '0',
						},
					},
				};
			} catch (error) {
				return { type: 'error', message: error.message };
			}
		});

		return () => {
			if (typeof unsubscribe === 'function') unsubscribe();
		};
	}, [cardData, saveCard, selectedToken, usingNewCard, onPaymentSetup]);

	return createElement(
		'div',
		{ className: 'acceptbluev2-wrapper' },
		createElement(AcceptBlueV2SandboxNotice),
		createElement(AcceptBlueV2SavedTokens, { selectedToken, onChange: setSelectedToken }),
		usingNewCard && createElement(AcceptBlueV2Form, { onCardChange: setCardData }),
		usingNewCard && createElement(AcceptBlueV2SaveCard, { saveCard, onChange: setSaveCard })
	);
};

/**
 * Register Payment Method with WooCommerce Blocks
 */
const acceptbluev2_label_text =
	window.wp.htmlEntities.decodeEntities(acceptbluev2_settings.title) ||
	window.wp.i18n.__('Credit Card', 'acceptbluev2');

/**
 * Label component: renders the gateway icon alongside the payment method title.
 * WooCommerce Blocks passes this to the payment method radio button label.
 */
const AcceptBlueV2Label = () => {
	return createElement(
		'span',
		{ style: { display: 'flex', alignItems: 'center', gap: '6px' } },
		acceptbluev2_label_text,
		acceptbluev2_settings.icon_url
			? createElement('img', {
				src: acceptbluev2_settings.icon_url,
				srcSet: acceptbluev2_settings.icon_url_2x
					? `${acceptbluev2_settings.icon_url} 1x, ${acceptbluev2_settings.icon_url_2x} 2x`
					: undefined,
				alt: acceptbluev2_label_text,
				style: { height: '24px', width: 'auto', verticalAlign: 'middle' },
			})
			: null
	);
};

window.wc.wcBlocksRegistry.registerPaymentMethod({
	name: 'acceptbluev2',
	label: createElement(AcceptBlueV2Label),
	content: createElement(AcceptBlueV2Content),
	edit: createElement(AcceptBlueV2Content),
	canMakePayment: () => true,
	ariaLabel: acceptbluev2_label_text,
	supports: {
		features: acceptbluev2_settings.supports,
	},
});
})();
