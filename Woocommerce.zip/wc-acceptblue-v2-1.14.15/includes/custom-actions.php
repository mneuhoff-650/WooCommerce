<?php
/**
 * accept.blue Payment Gateway v2 — Custom Actions
 *
 * All WordPress frontend and WooCommerce custom hooks:
 *
 *   Section 1  — Order status hooks (auto-capture, auto-cancel)
 *   Section 2  — Surcharge: cart fee calculation, block checkout callback,
 *                surcharge script enqueue, surcharge removal on non-AB orders,
 *                Google Pay surcharge filter
 *   Section 3  — Hosted Tokenization SDK: registration + checkout enqueue
 *   Section 4  — Hosted Tokenization AJAX callbacks (standard + addons)
 *   Section 5  — Hosted Tokenization: payment list container (review page)
 *   Section 6  — WooCommerce Blocks tokenize AJAX endpoint
 *   Section 7  — Global frontend script/style params
 *
 * Loaded by wc-acceptblue-v2.php after class files are included.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */

defined( 'ABSPATH' ) || exit;

// =============================================================================
// Singleton gateway accessor
// =============================================================================

/**
 * Retrieve the registered gateway instance from WC's payment gateway registry.
 *
 * NEVER call new WC_Gateway_AcceptBlue_v2() inside a recurring hook callback.
 * Every instantiation re-runs __construct() which calls add_action() again,
 * stacking duplicate listeners until PHP exhausts memory (OOM fatal error).
 * The WC registry holds exactly one instance — always use this helper instead.
 *
 * Returns null when WC is not fully loaded yet; callers must guard for null.
 *
 * @return WC_Gateway_AcceptBlue_v2|null
 */
function acceptblue_v2_gateway() {
    static $instance = null;
    if ( $instance !== null ) {
        return $instance;
    }
    if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways ) {
        return null;
    }
    $gateways = WC()->payment_gateways()->payment_gateways();
    $instance = $gateways['acceptbluev2'] ?? null;
    return $instance;
}

// =============================================================================
// 1. Order status hooks — auto-capture & auto-cancel
// =============================================================================

/**
 * Auto-capture payment when order status changes to on-hold, processing,
 * or completed (e.g. via Shipworks Connector or manual status change).
 */
add_action( 'woocommerce_order_status_on-hold',    array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );
add_action( 'woocommerce_order_status_processing', array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );
add_action( 'woocommerce_order_status_completed',  array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );

/**
 * Auto-void / cancel payment when order status changes to cancelled.
 */
add_action( 'woocommerce_order_status_cancelled', array( 'WC_Gateway_AcceptBlue_v2', 'process_cancelled' ), 10, 2 );

// =============================================================================
// 2. Surcharge
// =============================================================================

/**
 * Enqueue the surcharge JS for WooCommerce Block Checkout.
 * Priority 5 — must load before blocks resolve dependencies.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_surcharge_script', 5 );

function acceptblue_v2_enqueue_surcharge_script() {
    wp_enqueue_script(
        'acceptbluev2-block-surcharge',
        plugins_url( 'assets/js/dist/acceptblue-surcharge.min.js', AB_V2_PLUGIN_FILE ),
        array( 'wc-blocks-registry', 'wp-data', 'wc-blocks' ),
        AB_V2_VERSION,
        true
    );
}

/**
 * Register the surcharge callback for WooCommerce Store API (Block Checkout).
 * Without this, Blocks ignore cart fee changes.
 */
add_filter(
    'woocommerce_store_api_cart_update_callbacks',
    function ( $callbacks ) {
        $callbacks[] = 'acceptblue_v2_surcharge_add_cart_fee';
        return $callbacks;
    }
);

/**
 * Add the surcharge fee to the cart on both classic and block checkout.
 * Also hooked on woocommerce_cart_calculate_fees for classic checkout.
 *
 * @param WC_Cart $cart
 */
function acceptblue_v2_surcharge_add_cart_fee( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }

    // Skip the order-pay page — surcharge is handled per order there
    if ( is_checkout_pay_page() && ! empty( $_GET['order-pay'] ) ) {
        return;
    }

    $client = new WC_AcceptBlue_API_v2();

    $is_enabled = $client->is_surcharge_enabled();
    if ( $is_enabled['code'] === false ) {
        return;
    }

    $surcharge = $client->get_surcharge_info();
    if ( empty( $surcharge['fee']['value'] ) ) {
        return;
    }

    // Prevent duplicate fee
    $fee_slug = str_replace( ' ', '-', strtolower( $surcharge['name'] ) );
    foreach ( $cart->get_fees() as $fee ) {
        if ( $fee->id === $fee_slug ) {
            return;
        }
    }

    $subtotal = $cart->get_cart_contents_total()
              + $cart->get_shipping_total()
              + $cart->get_taxes_total()
              + $cart->get_fee_total();

    if ( $subtotal <= 0 ) {
        return;
    }

    $surcharge_name  = $surcharge['name'];
    $surcharge_value = (float) $surcharge['fee']['value'];
    $surcharge_type  = $surcharge['fee']['type'];

    $fee_amount = ( $surcharge_type === 'percent' )
        ? round( $subtotal * ( $surcharge_value / 100 ), 2 )
        : $surcharge_value;

    if ( $fee_amount <= 0 ) {
        return;
    }

    $cart->add_fee(
        __( sanitize_text_field( $surcharge_name ), 'woocommerce' ),
        $fee_amount,
        false
    );
}

// Classic checkout fee hook
if ( ! has_action( 'woocommerce_cart_calculate_fees', 'acceptblue_v2_surcharge_add_cart_fee' ) ) {
    add_action( 'woocommerce_cart_calculate_fees', 'acceptblue_v2_surcharge_add_cart_fee' );
}

/**
 * After checkout order is created: if the chosen payment method is NOT accept.blue,
 * remove the surcharge fee so it isn't billed to the customer.
 */
add_action( 'woocommerce_checkout_order_processed', 'acceptblue_v2_remove_surcharge_for_non_ab_orders', 10, 3 );

function acceptblue_v2_remove_surcharge_for_non_ab_orders( $order_id, $posted_data, $order ) {
    $order = wc_get_order( $order_id );

    if ( ! $order || $order->get_payment_method() === 'acceptbluev2' ) {
        return;
    }

    $client   = new WC_AcceptBlue_API_v2();
    $surcharge = $client->get_surcharge_info();

    if ( empty( $surcharge['name'] ) ) {
        return;
    }

    $fee_label = $surcharge['name'];

    foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
        if ( $item->get_name() === $fee_label ) {
            $order->remove_item( $item_id );
        }
    }

    $order->calculate_totals();
    $order->save();
}

/**
 * Filter: return the Google Pay surcharge data from the Accept.Blue API.
 * Used by the order review page shortcode to display the surcharge row.
 */
add_filter( 'acceptblue_googlepay_get_surcharge', 'acceptblue_v2_googlepay_surcharge_filter', 10, 1 );

function acceptblue_v2_googlepay_surcharge_filter( $value ) {
    $ab = acceptblue_v2_gateway();
    if ( ! $ab ) return $value;
    return $ab->get_surcharge() ?: $value;
}

// =============================================================================
// 3. Hosted Tokenization SDK — registration & checkout enqueue
// =============================================================================

/**
 * Register the Accept.Blue hosted tokenization CDN script under a single
 * canonical handle so WordPress deduplication prevents double-loading
 * (which caused "window.HostedTokenization is already defined").
 *
 * Priority 1 on wp_enqueue_scripts — registered before anything tries to
 * enqueue it. Also registered on init so WooCommerce Blocks can resolve the
 * dependency (Blocks do NOT run wp_enqueue_scripts).
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_register_hosted_sdk', 1 );
add_action( 'init',               'acceptblue_v2_register_hosted_sdk', 20 );

function acceptblue_v2_register_hosted_sdk() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    $hosted_url = ( isset( $settings['testmode'] ) && $settings['testmode'] === 'yes' )
        ? 'https://tokenization.sandbox.accept.blue/tokenization/v0.3'
        : 'https://tokenization.accept.blue/tokenization/v0.3';

    wp_register_script( 'acceptblue-hosted-sdk', $hosted_url, array(), null, true );
}

/**
 * On the standard (classic) checkout page, enqueue the hosted SDK and the
 * checkout-specific iframe script.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_tokenization_checkout' );

function acceptblue_v2_enqueue_tokenization_checkout() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    // Only on the standard checkout page — not on order-pay
    if ( ! is_checkout() || ( is_checkout_pay_page() && ! empty( $_GET['order-pay'] ) ) ) {
        return;
    }

    // acceptblue-v2-js must be enqueued first so acceptblue_hosted_token_params
    // is defined before acceptblue-hosted-token-iframe-checkout.min.js runs.
    // local_script() registers + localizes + enqueues acceptblue-v2-js.
    $gateway = acceptblue_v2_gateway();
    if ( $gateway ) {
        $gateway->local_script();
        $gateway->style();
    }

    wp_enqueue_script( 'acceptblue-hosted-sdk' );
    wp_enqueue_script(
        'acceptblue-gateway-hosted-token-checkout-iframe',
        plugins_url( 'assets/js/dist/acceptblue-hosted-token-iframe-checkout.min.js', AB_V2_PLUGIN_FILE ),
        array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ),
        AB_V2_VERSION,
        true
    );
}

/**
 * Enqueue the hosted SDK for WooCommerce Block Checkout (3DS path).
 * Priority 5 — before other block scripts.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_hosted_sdk_for_blocks', 5 );

function acceptblue_v2_enqueue_hosted_sdk_for_blocks() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    wp_enqueue_script( 'acceptblue-hosted-sdk' );
}

// =============================================================================
// 4. Hosted Tokenization AJAX callbacks
// =============================================================================

// Standard (non-addons) hosted token place order
add_action( 'wp_ajax_acceptblue_ht_request_place_order_charge',        'acceptblue_v2_ht_place_order_charge' );
add_action( 'wp_ajax_nopriv_acceptblue_ht_request_place_order_charge', 'acceptblue_v2_ht_place_order_charge' );

function acceptblue_v2_ht_place_order_charge() {
    $ab = acceptblue_v2_gateway();
    if ( $ab ) $ab->ht_place_order_charge();
}

// Addons (subscriptions / pre-orders) hosted token place order
add_action( 'wp_ajax_acceptblue_ht_request_place_order_charge_addons',        'acceptblue_v2_ht_place_order_charge_addons' );
add_action( 'wp_ajax_nopriv_acceptblue_ht_request_place_order_charge_addons', 'acceptblue_v2_ht_place_order_charge_addons' );

function acceptblue_v2_ht_place_order_charge_addons() {
    // Addons is instantiated here in a single-shot AJAX callback — not in a
    // recurring hook — so duplicate __construct() accumulation cannot occur.
    $ab = new WC_Gateway_AcceptBlue_v2_Addons();
    $ab->ht_place_order_charge_addons();
}


// =============================================================================
// 6. WooCommerce Blocks — tokenize AJAX endpoint
// =============================================================================

add_action( 'wc_ajax_acceptbluev2_tokenize',        'acceptblue_v2_tokenize_card' );
add_action( 'wc_ajax_nopriv_acceptbluev2_tokenize', 'acceptblue_v2_tokenize_card' );

function acceptblue_v2_tokenize_card() {
    $body = json_decode( file_get_contents( 'php://input' ), true );

    if ( empty( $body['number'] ) || empty( $body['expiry'] ) || empty( $body['cvv'] ) ) {
        wp_send_json_error( array( 'message' => 'Missing card details.' ) );
    }

    $settings  = get_option( 'woocommerce_acceptbluev2_settings' );
    $test_mode = $settings['testmode'] ?? 'no';

    // Parse expiry
    $exp       = explode( '/', $body['expiry'] );
    $exp_month = trim( $exp[0] );
    $exp_year  = isset( $exp[1] ) ? '20' . trim( $exp[1] ) : '';

    $payload = array(
        'card'         => preg_replace( '/\D/', '', $body['number'] ),
        'expiry_month' => (int) $exp_month,
        'expiry_year'  => (int) $exp_year,
        'cvv2'         => $body['cvv'],
    );

    $client   = new WC_AcceptBlue_API_v2();
    $token_id = $client->save_card( $payload );

    if ( $token_id['code'] == 0 ) {
        wp_send_json_error( array( 'message' => $token_id['message'] ) );
    }

    if ( isset( $token_id['token_id'] ) ) {
        wp_send_json_success( array(
            'token'        => $token_id['token_id'],
            'expiry_month' => (int) $exp_month,
            'expiry_year'  => (int) $exp_year,
            'last4'        => substr( preg_replace( '/\D/', '', $body['number'] ), -4 ),
        ) );
    } else {
        wp_send_json_error( array( 'message' => 'Tokenization failed: ' . wp_json_encode( $token_id ) ) );
    }
}

// =============================================================================
// 7. Global frontend script & style params
// =============================================================================

/**
 * Enqueue the global acceptblue_hosted_token_params JS object and base styles
 * on every frontend page except the order-pay page (which has its own flow).
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_global_params' );

function acceptblue_v2_enqueue_global_params() {
    if ( is_checkout_pay_page() && ! empty( $_GET['order-pay'] ) ) {
        return;
    }

    $gateway = acceptblue_v2_gateway();
    if ( ! $gateway ) return;

    // local_script() has a static guard against double-localization.
    // On the classic checkout page acceptblue_v2_enqueue_tokenization_checkout
    // already called local_script(). Calling it again here is safe — the guard
    // skips the localize step and just enqueues the already-registered handle.
    $gateway->local_script();
    $gateway->style();
}
