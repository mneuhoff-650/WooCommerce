# woocommerce-acceptblue-v2

Accept.Blue WooCommerce v2

= 1.14.15 =
26 March 2026

Added:
    - Classic Checkout – New Card:
        - Added support for AVS (Address Verification System)
            avs_address – billing address to improve fraud prevention and transaction approval
            avs_zip – billing ZIP/postal code for accurate AVS matching

= 1.14.14 =
20 March 2026

Added:
    - Major upgrade to Google Pay with better reliability and easier setup
    - Saved cards now work directly on the checkout page

Fixed:    
    - Fixed multiple 3D Secure issues for smoother and more secure payments
    - Fixed issues with amount formatting that caused API errors
    - Fixed customer IP capture for Block Checkout

Improvements:
    - Custom and admin-created orders now process correctly
    - Improved stability, including PHP 8 fixes and better error handling



= 1.14.13 =
17 March 2026

Fixed:

    - Fixed cost: 0 for custom line items — $product->get_price() returns empty for manually added order items (e.g. "Custom" products with no real WooCommerce product object). Cost is now derived from $subtotal / $quantity instead, which is always populated from the order.

    - Fixed cost: 0 for products with a $0 price + order fee — When a product had a $0 price and a fee (e.g. $25.30) was added to the order, the fee was silently ignored and the gateway received cost: 0, causing a validation error (Must be >= 0.0001). Fee line items are now processed separately via $order->get_fees().

    - Fixed integer truncation on unit cost — (int) cast was truncating decimal prices (e.g. $62.50 → 62, $0.99 → 0). Changed to floatval() with round(..., 4) for accurate decimal handling.

Improvements:

    - Zero-cost line item filtering — Any line item with cost < 0.0001 is now stripped before submission to prevent gateway validation errors, matching the gateway's minimum cost requirement.
    
    - Division by zero guard — Quantity is now clamped with max(1, (int) $quantity) before the $subtotal / $quantity calculation.

    - Stricter type checks — Replaced loose if ($order) and if ($product) checks with instanceof WC_Order and instanceof WC_Product for more reliable type safety.

    - Reusable mock object — Duplicated anonymous class definitions for custom items and fees were consolidated into a single $make_mock closure, reducing code duplication.

    - Empty line items early return — If both the cart and order fallback produce no valid line items, the method now returns array() immediately to avoid sending an empty line_items array to the gateway.

    - Float precision consistency — Applied round(..., 4) uniformly across cost, tax_amount, and discount_amount to avoid floating point drift.   

Root Cause Summary:

    All three zero-cost scenarios trace back to the same original assumption — that $product->get_price() is always a reliable source of unit cost. This is false for custom line items, $0-priced products, and fee-only orders. The fix decouples cost calculation from the product object entirely, using order-level financial data ($subtotal / $quantity) as the single source of truth.    


= 1.14.12 =
16 March 2026

Fixed:

    - Fixed issue where the payment gateway with handle wc-acceptblue-hosted-token-blocks-integration was deactivated in Cart and Checkout Blocks because its dependency acceptblue-hosted-sdk was not registered.

    - Resolved the WP Admin Bar display bug.

Improved:

    - Enhanced 3DS data handling for more reliable transactions.

Compatibility:

    - Tested and confirmed compatible with WooCommerce versions 9.4.5 to 10.6.1.

= 1.13.12 =
11 March 2026

Added:

    - Custom Color Scheme option in Appearance settings with three wp-color-picker fields: Background Color, Text Color, and Border Color.
    - Settings reorganized into six tabs: General, API Keys, Tokenization, Google Pay, Card & Payment, and Appearance. All tabs save on a single Save Changes click.
    - Checkout Block setting now displays an inline description noting support for both standard (non-3DS) and 3D Secure (3DS) payments.

Fixed:    

    - Sandbox notice background, border, and text color in block checkout (non-3DS) are now applied as inline styles, resolving inconsistent rendering in themes that did not inherit CSS variables.
    - Sandbox notice in block checkout (3DS) was missing dark mode logic entirely. Background, border, and text color now adjust correctly across all color scheme modes.
    - Card input fields (Card Number, Expiry, CVV) in block checkout (non-3DS) were only styled when the Custom scheme was active. Dark and Auto modes now correctly apply dark input styles.
    - Card field labels in block checkout (non-3DS) were forced to light text in dark mode, making them invisible on light-background themes. Labels now inherit color from the page.
    - Classic WooCommerce checkout form inputs (Card Number, Expiry, CVV) had no color scheme logic. Added acceptblueApplyInputColors() which applies the correct styles on load and re-runs on updated_checkout and payment_method_selected events.

Improved:

    - Custom color scheme CSS variables (--ab-custom-bg, --ab-custom-text, --ab-custom-border) now applied consistently across all five classic iframe JS files, both block checkout JS files, and the classic checkout form JS.
    - Block checkout get_payment_method_data() now passes form_color_scheme and all custom color values to the block JS for both non-3DS and 3DS variants.
    - Custom color picker fields shown and hidden dynamically based on the selected color scheme. wp-color-picker enqueued only on the gateway settings page.
    - Base release. Classic and block checkout with Auto, Light, and Dark scheme support via data-ab-scheme attribute.


= 1.12.11 =
4 March 2026

Added: 
    Block Checkout saved cards (standard + 3DS) with default selection and “Use new card” option.
    Save to Account checkbox for Classic & Block checkout (fully respects force/disable settings).
    Gateway icon toggle setting (hide on frontend checkout).

Fixed:
    Save card flag ignored in Classic checkout.
    Block checkout empty('0') boolean bug.
    Store API token ID retrieval (removed $_REQUEST dependency).
    Incorrect expiry saved to WC tokens.
    Empty "tkn-" tokens causing renewal failures.
    Subscription double-prefix issue.
    JS variable collision (“Identifier already declared”).
    Broken minified JS files.
    PHP 8.2 dynamic property deprecation.

Improved:
    Cleaner Block Checkout UI styling.
    Proper WC token creation after successful charge.
    Removed all console.* logs.
    Rebuilt minified JS files.

= 1.11.11 =
22 Febuary 2026

Added: Setting to enable or disable Level III line item data.
Added: Automatic processor-compliant character limits for Level III fields.
Improved: SKU limited to 12 characters with centralized sanitization.
Improved: Item name limited to 64 characters with HTML stripping and normalization.
Improved: Item description limited to 255 characters with enhanced sanitization.
Improved: Refactored Level III line item builder for cart and order handling.
Dev: Introduced reusable Level III text sanitizer helper.

Tested up to: WooCommerce 10.5.1
Tested up to: WordPress 6.9.1
Compatible with: WooCommerce Subscriptions 8.4.0

= 1.11.10 =
17 February 2026 

Updated: Dynamic capture order status with settings
Improved: level3 data code sanitize html tags. 
Tested: WooCommerce 10.5.1 
Tested: WordPress 6.9.1 
Tested: WooCommerce Subscriptions 8.4.0

= 1.10.10 =
6 February 2026

Refactor:

-Introduced get_cart_total_blocks_safe() as the single source of truth for cart totals.
-Refactored surcharge removal logic to rely on Blocks-safe cart access.

Fix:

-Prevented fatal errors caused by WC()->cart being unavailable in Blocks, Mini Cart, and editor contexts.
-Ensured surcharge removal only executes when surcharge_card setting is enabled.

Compatibility:

-Fully compatible with WooCommerce Blocks API.
-Safe in admin, frontend, and block editor contexts.

= 1.10.9 =

31 January 2026
UPDATE: Improved WooCommerce custom order status logic (Stripe-style handling).Skips payment_complete() when order status is On Hold, Processing, or Completed. Enhanced Force Capture logic to prevent double capture when enabled.
FIXED: Resolved surcharge calculation issue in WooCommerce Subscriptions.
TESTED: Compatible with WooCommerce up to version 10.4.3
TESTED: Compatible with WordPress up to version 6.9

= 1.9.8 =

19 January 2026
UPDATE: WooCommerce checkout block based 3DS iframe implemented
UPDATE: 3DS frictionless settings implemented both checkout block based and classic
FIXED: Surcharge error in 3DS checkout both classic and block based
TESTED: WooCommerce version up to 10.4.3
TESTED: Wordpress version up to 6.9

= 1.8.7 =

07 January 2026
UPDATE: Support 3DS in the classic woocommerce checkout page

= 1.7.7 =

19 November 2025
UPDATE: Support WooCommerce Block Based Checkout card form input fields

= 1.7.6 =

19 October 2025
UPDATE: Remove auto-hold status

= 1.7.5 =

18 September 2025
UPDATE: Credit Card Form UI custom edited labels

= 1.7.4 =

02 September 2025
FIXED: Level3 Bug

= 1.7.3 =

01 September 2025
UPDATE: Level3 data
UPDATE: CVV on save card token checkout
FIXED: Surcharge bug

= 1.6.3 =

06 june 2025
FIXED: Surcharge in checkout, show if accept.blue is selected

= 1.6.2 =

08 May 2025
FIXED: Card Number validation error for existing card token

= 1.6.1 =

07 May 2025
UPDATE: Implement CVV2 parameter

= 1.5.1 =

04 May 2025
FIXED: Surcharge Bugs in the woocommerce admin orders
UPDATE: Name on Card

= 1.4.0 =

05 March 2025
UPDATE: remove update status when trigger capture in order status completed

= 1.3.0 =

27 February 2025
UPDATE: Fix surcharge amount in thank you page

= 1.2.0 =

27 February 2025
UPDATE: Fix double print in tokenization card checkout

= 1.1.0 =

26 February 2025
UPDATE: Fix plugin link docs and support

= 1.0 =

26 February 2025
Initial release version
