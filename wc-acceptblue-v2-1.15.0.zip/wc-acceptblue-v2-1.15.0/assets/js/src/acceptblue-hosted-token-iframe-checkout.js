(function ( $ ) {
"use strict";

/* ============================================================
   accept.blue — Classic Checkout Hosted Tokenization (3DS)

   Key design decisions:
   - All DOM refs are live (queried at use-time) because WooCommerce
     re-renders .payment_box on every update_order_review AJAX call,
     invalidating any refs captured at script load.
   - HostedTokenization is lazy-mounted: only when the payment box
     is visible and "new card" is selected.
   - Saved tokens: when a saved token radio is selected, the
     .ab-ht-new-card-section is hidden and wc-acceptbluev2-payment-token
     is injected on form submit.
   - The charge button listener is registered in syncMount(), not inside
     mountIframe(). This ensures it fires even when a saved token is
     pre-selected on page load and mountIframe() is never called.
   ============================================================ */

// ── Helpers: live DOM queries (never stale) ───────────────────────────────────
function el( id )    { return document.getElementById( id ); }
function q( sel )    { return document.querySelector( sel ); }

// ── Color scheme ──────────────────────────────────────────────────────────────
const abScheme = acceptblue_hosted_token_params.form_color_scheme || 'auto';
const abDark   = abScheme === 'dark' ||
                 ( abScheme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches );

if ( abScheme === 'light' || abScheme === 'dark' || abScheme === 'custom' ) {
    document.body.setAttribute('data-ab-scheme', abScheme);
}
if ( abScheme === 'custom' ) {
    const bg  = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
    const tx  = acceptblue_hosted_token_params.custom_color_text   || '#333333';
    const bd  = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
    document.documentElement.style.setProperty('--ab-custom-bg',     bg);
    document.documentElement.style.setProperty('--ab-custom-text',   tx);
    document.documentElement.style.setProperty('--ab-custom-border', bd);
}

function getIframeStyles() {
    if ( abScheme === 'custom' ) {
        const bg = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
        const tx = acceptblue_hosted_token_params.custom_color_text   || '#333333';
        const bd = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
        return {
            card:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    if ( abDark ) {
        return {
            card:        'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    return {
        card:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;width:48%;border-radius:5px;',
        expiryMonth: 'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        expiryYear:  'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        cvv2:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
    };
}

// ── Lazy HostedTokenization ───────────────────────────────────────────────────
const sandbox         = acceptblue_hosted_token_params.sandbox == 1 ? 'test' : 'prod';
const threeDSApiKey   = acceptblue_hosted_token_params.pk_threeds_key;
const threeDSFriction = acceptblue_hosted_token_params.frictionless == 1;
const threeDS         = { env: sandbox, apiKey: threeDSApiKey, frictionless: threeDSFriction, timeout: 30000 };

let hostedTokenization = null;

function mountIframe() {
    const sourceKey = acceptblue_hosted_token_params.pk_hosted_token;
    if ( ! sourceKey || typeof sourceKey !== 'string' || sourceKey.trim() === '' ) {
        const errEl = el('acceptblue-ht-error-message');
        if ( errEl ) {
            errEl.innerHTML = '<ul class="woocommerce-error" role="alert"><li>' +
                '<strong>Payment configuration error:</strong> ' +
                'The accept.blue Tokenization Source Key is not configured. ' +
                'Please contact the store admin.' +
                '</li></ul>';
        }
        return;
    }

    destroyIframe();

    const opts = { target: '#acceptblue-ht-iframe-container', threeDS };
    hostedTokenization = new window.HostedTokenization( sourceKey, opts );
    hostedTokenization
        .on('input',     _onEvent)
        .on('change',    _onEvent)
        .on('challenge', function(){});
    hostedTokenization.setStyles( getIframeStyles() );
    // NOTE: charge button listener is NOT registered here — it lives in syncMount()
    // so it fires whether or not the iframe was ever mounted.
}

function destroyIframe() {
    if ( ! hostedTokenization ) return;
    try {
        if ( typeof hostedTokenization.unmount === 'function' ) {
            hostedTokenization.unmount();
        } else {
            const c = el('acceptblue-ht-iframe-container');
            if ( c ) c.innerHTML = '';
        }
    } catch(e) {}
    hostedTokenization = null;
}

// ── Saved token helpers ───────────────────────────────────────────────────────
function getSelectedToken() {
    const checked = q('input[name="ab-ht-selected-token"]:checked');
    return checked ? checked.value : null;
}

function updateSelectedTokenHighlight() {
    document.querySelectorAll('.ab-ht-token-item').forEach(function(li) {
        const radio = li.querySelector('.ab-ht-token-radio');
        if (radio) {
            li.classList.toggle('ab-ht-token-item--selected', radio.checked);
        }
    });
}

function syncNewCardSection() {
    updateSelectedTokenHighlight();
    const selected    = getSelectedToken();
    const showNewCard = ( selected === null || selected === 'new' );
    const section     = q('.ab-ht-new-card-section');

    if ( section ) {
        section.style.display = showNewCard ? '' : 'none';
    }

    if ( showNewCard ) {
        mountIframe();
    } else {
        destroyIframe();
    }
}

function bindTokenRadios() {
    document.querySelectorAll('input[name="ab-ht-selected-token"]').forEach(function(radio) {
        radio.removeEventListener('change', syncNewCardSection);
        radio.addEventListener('change', syncNewCardSection);
    });
}

// ── Charge button binding (unconditional — always registers on syncMount) ──────
// Must be separate from mountIframe() so it fires even when a saved token is
// pre-selected on page load and mountIframe() is never called.
function bindChargeButton() {
    const btn = el('acceptblue-ht-charge');
    if ( btn ) {
        btn.removeEventListener('click', onChargeClick);
        btn.addEventListener('click', onChargeClick);
    }
}

// ── Payment method state ──────────────────────────────────────────────────────
function isAcceptBlueSelected() {
    const radio = q('input[name="payment_method"]:checked');
    return radio && radio.value === 'acceptbluev2';
}

function syncMount() {
    if ( isAcceptBlueSelected() ) {
        bindTokenRadios();
        bindChargeButton();    // ← always bind, regardless of saved-token state
        syncNewCardSection();  // mounts iframe only if "new card" is selected
        $( '#place_order' ).hide();
    } else {
        destroyIframe();
        $( '#place_order' ).show();
    }
}

// ── WooCommerce event bindings ────────────────────────────────────────────────
$(document.body).on('payment_method_selected', function() {
    setTimeout( syncMount, 50 );
});

$(document.body).on('updated_checkout', function() {
    hostedTokenization = null;
    setTimeout( syncMount, 100 );
});

$(function() {
    syncMount();
});

// ── Charge button handler ─────────────────────────────────────────────────────
async function onChargeClick() {
    const errEl = el('acceptblue-ht-error-message');
    if ( errEl ) errEl.innerText = '';

    const selectedToken = getSelectedToken();

    // ── Path A: saved token ───────────────────────────────────────────────────
    if ( selectedToken !== null && selectedToken !== 'new' ) {
        const $form      = $('form.checkout, form#order_review, form#add_payment_method');
        const $container = $('#acceptblue-v2-hosted-tokenization-form');
        $container.find('input[name="wc-acceptbluev2-payment-token"]').remove();
        $container.append(
            '<input type="hidden" name="wc-acceptbluev2-payment-token" value="' + selectedToken + '"/>'
        );
        $form.submit();
        return;
    }

    // ── Path B: new card ──────────────────────────────────────────────────────
    if ( ! hostedTokenization ) {
        if ( errEl ) errEl.innerText = 'Card form not ready. Please refresh and try again.';
        return;
    }

    $('#acceptblue-hosted-token-ajax-loader').fadeIn();

    try {
        const result = await hostedTokenization.getNonceToken();

        if ( ! result ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            if ( errEl ) errEl.innerText = 'Card tokenization failed — no response.';
            return;
        }

        if ( acceptblue_hosted_token_params.threeDS == 1 ) {
            loadthreeDS( result );
        } else {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            acceptbluev2_handle_build_token_data( result );
        }

    } catch ( error ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        if ( errEl ) errEl.innerText = 'Card tokenization error: ' + error.message;
    }
}

// ── 3DS flow ──────────────────────────────────────────────────────────────────
async function loadthreeDS( data ) {
    $('html, body').animate({ scrollTop: '0px' }, 0);

    const threeDSData = {
        amount: Number( el('acceptblue-ht-order-amount') ? el('acceptblue-ht-order-amount').value : 0 ),
        email:  q('input[name="billing_email"]') ? q('input[name="billing_email"]').value : '',
    };

    try {
        const threeDSResult = await hostedTokenization.verify3DS( threeDSData );

        if ( threeDSResult ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            acceptbluev2_handle_build_token_data_3ds({
                eci:                 threeDSResult.eci,
                authenticationValue: threeDSResult.authenticationValue,
                dsTransId:           threeDSResult.dsTransId,
                nonce:               data.nonce,
                expiryMonth:         data.expiryMonth,
                expiryYear:          data.expiryYear,
            });
        }

    } catch ( error ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        const errEl = el('acceptblue-ht-error-message');
        if ( errEl ) errEl.innerText = '3DS verification failed: ' + error.message;
        const container = el('acceptblue-ht-iframe-container');
        if ( container ) {
            $('html, body').animate({ scrollTop: $( container ).offset().top - 80 }, 600 );
        }
    }
}

// ── Form submit helpers ───────────────────────────────────────────────────────
function acceptbluev2_handle_build_token_data( data ) {
    const $form      = $('form.checkout, form#order_review, form#add_payment_method');
    const $container = $('#acceptblue-v2-hosted-tokenization-form');
    $container.find('input[name="acceptbluev2-payment-token"]').remove();
    $container.append('<input type="hidden" name="acceptbluev2-payment-token" value="' + data.nonce + '"/>');
    $form.submit();
}

function acceptbluev2_handle_build_token_data_3ds( data ) {
    const $form      = $('form.checkout, form#order_review, form#add_payment_method');
    const $container = $('#acceptblue-v2-hosted-tokenization-form');
    $container.find('input[name^="acceptbluev2-payment-"]').remove();
    $container.append('<input type="hidden" name="acceptbluev2-payment-eci"                value="' + data.eci                 + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-authenticationvalue" value="' + data.authenticationValue + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-dstransid"           value="' + data.dsTransId           + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-token"               value="' + data.nonce               + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_month"        value="' + data.expiryMonth         + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_year"         value="' + data.expiryYear          + '"/>');
    $form.submit();
}

function _onEvent( event ) {
    const errEl = el('acceptblue-ht-error-message');
    if ( ! errEl ) return;
    errEl.innerText = ( event.error && event.error !== '' ) ? event.error : '';
}

}( jQuery ) );
