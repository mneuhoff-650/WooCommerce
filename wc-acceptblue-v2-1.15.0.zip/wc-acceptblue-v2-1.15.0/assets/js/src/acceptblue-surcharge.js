
/**
 * Accept.Blue – WooCommerce Blocks Surcharge Recalculation
 * Safe for Block Checkout, Cart Block, Apple Pay, Google Pay
 */

(function () {

    let lastPaymentMethod = null;
    let subscribed = false;

    /**
     * Wait until WordPress + Woo Store API are ready
     */
    function waitForStores() {

        if (
            typeof window.wp === 'undefined' ||
            !wp.data ||
            !wp.data.select ||
            !wp.data.dispatch
        ) {
            setTimeout(waitForStores, 50);
            return;
        }

        const checkoutStore = wp.data.select('wc/store/checkout');
        const cartStore     = wp.data.select('wc/store/cart');

        // Store API not hydrated yet
        if (!checkoutStore || !cartStore) {
            setTimeout(waitForStores, 50);
            return;
        }

        if (subscribed) {
            return;
        }

        subscribed = true;

        const { subscribe, dispatch } = wp.data;

        /**
         * Subscribe to checkout state changes
         */
        subscribe(() => {
            const method = checkoutStore.getSelectedPaymentMethod
                ? checkoutStore.getSelectedPaymentMethod()
                : null;

            if (!method) {
                return;
            }

            if (method !== lastPaymentMethod) {
                lastPaymentMethod = method;

                // 🔑 Force Store API to recalculate cart + fees
                dispatch('wc/store/cart').invalidateResolutionForStore();
            }
        });
    }

    waitForStores();

})();
