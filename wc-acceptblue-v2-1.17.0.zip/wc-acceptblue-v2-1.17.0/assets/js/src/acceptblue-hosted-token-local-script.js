(function ( $ ) {
"use strict";

$('body').on('change', 'input.input-radio', function(e) {	
			if(acceptblue_hosted_token_params.surcharge_card == 'yes'){
				$('body').trigger('update_checkout');
			}	
			
		});

}( jQuery ) );
