(function ( $ ) {
"use strict";

/* ============================================================
   accept.blue — Classic Checkout Hosted Tokenization (3DS)

   Key design decisions:
   - All DOM refs are live (queried at use-time) because WooCommerce
     re-renders .payment_box on every update_order_review AJAX call,
     invalidating any refs captured at script load.
   - HostedTokenization is lazy-mounted: only when the payment box
     is visible and "new card" is selected.
   - Saved tokens: when a saved token radio is selected, the
     .ab-ht-new-card-section is hidden and wc-acceptbluev2-payment-token
     is injected on form submit.
   - The charge button listener is registered in syncMount(), not inside
     mountIframe(). This ensures it fires even when a saved token is
     pre-selected on page load and mountIframe() is never called.
   ============================================================ */

// ── Global singleton guard ────────────────────────────────────────────────────
// The script should only be executed once per page. If it somehow gets loaded
// twice (e.g. under two different WordPress script handles — the root cause of
// the duplicate-iframe bug), the second IIFE bails out immediately here rather
// than creating a second independent `hostedTokenization` closure that would
// mount a second iframe into the same container, bypassing the per-instance
// `if ( hostedTokenization ) return` guard.
// The PHP fix (same handle name + wp_script_is() early-return) is the real
// prevention; this is belt-and-suspenders in case of future regressions.
if ( window.__acceptblueCheckoutIframeLoaded ) {
    console.warn('[AcceptBlue] acceptblue-hosted-token-iframe-checkout.js loaded TWICE — second instance blocked by global singleton guard. Check wp_enqueue_script() calls for duplicate handles.');
    return;
}
window.__acceptblueCheckoutIframeLoaded = true;
console.log('[AcceptBlue] Singleton guard set. This instance is the active one.');

// ── Guard: bail out on add-payment-method page ───────────────────────────────
// The my-account/add-payment-method/ page uses WC default card fields (not the
// hosted iframe). If this script loads there it would try to mount HostedTokenization
// into a non-existent #acceptblue-ht-iframe-container, fire the `pay` network request,
// and prevent the native form from submitting. Exit immediately.
if ( typeof acceptblue_hosted_token_params !== 'undefined'
     && acceptblue_hosted_token_params.is_add_payment_method == 1 ) {
    return;
}
if ( document.querySelector( 'form#add_payment_method' )
     && ! document.querySelector( 'form.checkout' )
     && ! document.querySelector( 'form#order_review' ) ) {
    return;
}

// ── Helpers: live DOM queries (never stale) ───────────────────────────────────
function el( id )    { return document.getElementById( id ); }
function q( sel )    { return document.querySelector( sel ); }

// ── Color scheme ──────────────────────────────────────────────────────────────
const abScheme = acceptblue_hosted_token_params.form_color_scheme || 'auto';
const abDark   = abScheme === 'dark' ||
                 ( abScheme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches );

if ( abScheme === 'light' || abScheme === 'dark' || abScheme === 'custom' ) {
    document.body.setAttribute('data-ab-scheme', abScheme);
}
if ( abScheme === 'custom' ) {
    const bg  = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
    const tx  = acceptblue_hosted_token_params.custom_color_text   || '#333333';
    const bd  = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
    document.documentElement.style.setProperty('--ab-custom-bg',     bg);
    document.documentElement.style.setProperty('--ab-custom-text',   tx);
    document.documentElement.style.setProperty('--ab-custom-border', bd);
}

function getIframeStyles() {
    if ( abScheme === 'custom' ) {
        const bg = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
        const tx = acceptblue_hosted_token_params.custom_color_text   || '#333333';
        const bd = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
        return {
            card:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    if ( abDark ) {
        return {
            card:        'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:#2a2a2a;border:2px solid #555;color:#f0f0f0;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    return {
        card:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;width:48%;border-radius:5px;',
        expiryMonth: 'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        expiryYear:  'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        cvv2:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
    };
}

// ── Lazy HostedTokenization ───────────────────────────────────────────────────
const sandbox         = acceptblue_hosted_token_params.sandbox == 1 ? 'test' : 'prod';
const threeDSApiKey   = acceptblue_hosted_token_params.pk_threeds_key;
const threeDSFriction = acceptblue_hosted_token_params.frictionless == 1;
const threeDS         = { env: sandbox, apiKey: threeDSApiKey, frictionless: threeDSFriction, timeout: 30000 };

let hostedTokenization = null;

function mountIframe() {
    const sourceKey = acceptblue_hosted_token_params.pk_hosted_token;
    if ( ! sourceKey || typeof sourceKey !== 'string' || sourceKey.trim() === '' ) {
        const errEl = el('acceptblue-ht-error-message');
        if ( errEl ) {
            errEl.innerHTML = '<ul class="woocommerce-error" role="alert"><li>' +
                '<strong>Payment configuration error:</strong> ' +
                'The accept.blue Tokenization Source Key is not configured. ' +
                'Please contact the store admin.' +
                '</li></ul>';
        }
        return;
    }

    destroyIframe();

    const opts = { target: '#acceptblue-ht-iframe-container', threeDS };
    hostedTokenization = new window.HostedTokenization( sourceKey, opts );
    hostedTokenization
        .on('input',     _onEvent)
        .on('change',    _onEvent)
        .on('challenge', function(){});
    hostedTokenization.setStyles( getIframeStyles() );
    // NOTE: charge button listener is NOT registered here — it lives in syncMount()
    // so it fires whether or not the iframe was ever mounted.
}

function destroyIframe() {
    if ( ! hostedTokenization ) return;
    try {
        if ( typeof hostedTokenization.unmount === 'function' ) {
            hostedTokenization.unmount();
        } else {
            const c = el('acceptblue-ht-iframe-container');
            if ( c ) c.innerHTML = '';
        }
    } catch(e) {}
    hostedTokenization = null;
}

// ── Saved token helpers ───────────────────────────────────────────────────────
function getSelectedToken() {
    const checked = q('input[name="ab-ht-selected-token"]:checked');
    return checked ? checked.value : null;
}

function updateSelectedTokenHighlight() {
    document.querySelectorAll('.ab-ht-token-item').forEach(function(li) {
        const radio = li.querySelector('.ab-ht-token-radio');
        if (radio) {
            li.classList.toggle('ab-ht-token-item--selected', radio.checked);
        }
    });
}

function syncNewCardSection() {
    updateSelectedTokenHighlight();
    const selected    = getSelectedToken();
    const showNewCard = ( selected === null || selected === 'new' );
    const section     = q('.ab-ht-new-card-section');

    if ( section ) {
        section.style.display = showNewCard ? '' : 'none';
    }

    if ( showNewCard ) {
        mountIframe();
    } else {
        destroyIframe();
    }
}

function bindTokenRadios() {
    document.querySelectorAll('input[name="ab-ht-selected-token"]').forEach(function(radio) {
        radio.removeEventListener('change', syncNewCardSection);
        radio.addEventListener('change', syncNewCardSection);
    });
}

// ── Charge button binding (unconditional — always registers on syncMount) ──────
// Must be separate from mountIframe() so it fires even when a saved token is
// pre-selected on page load and mountIframe() is never called.
function bindChargeButton() {
    const btn = el('acceptblue-ht-charge');
    if ( btn ) {
        btn.removeEventListener('click', onChargeClick);
        btn.addEventListener('click', onChargeClick);
    }
}

// ── Payment method state ──────────────────────────────────────────────────────
function isAcceptBlueSelected() {
    const radio = q('input[name="payment_method"]:checked');
    return radio && radio.value === 'acceptbluev2';
}

function syncMount() {
    // Only the inline hosted-tokenization iframe mode (block_support_checkout === true)
    // replaces WC's native place-order button with #acceptblue-ht-charge. In all other
    // modes (tokenization-redirect and native CC form) WC's #place_order must remain
    // visible — this function must be a no-op there.
    if ( typeof acceptblue_hosted_token_params === 'undefined'
         || acceptblue_hosted_token_params.block_checkout != 1 ) {
        return;
    }

    if ( isAcceptBlueSelected() ) {
        bindTokenRadios();
        bindChargeButton();    // ← always bind, regardless of saved-token state
        syncNewCardSection();  // mounts iframe only if "new card" is selected
        $( '#place_order' ).hide();
    } else {
        destroyIframe();
        $( '#place_order' ).show();
    }
}

// ── WooCommerce event bindings ────────────────────────────────────────────────
$(document.body).on('payment_method_selected', function() {
    setTimeout( syncMount, 50 );
});

$(document.body).on('updated_checkout', function() {
    destroyIframe();  // unmount SDK and clear DOM before re-mounting
    setTimeout( syncMount, 100 );
});

$(function() {
    syncMount();
});

// ── Charge button handler ─────────────────────────────────────────────────────
async function onChargeClick() {
    const errEl = el('acceptblue-ht-error-message');
    if ( errEl ) errEl.innerText = '';

    const selectedToken = getSelectedToken();

    // ── Path A: saved token ───────────────────────────────────────────────────
    if ( selectedToken !== null && selectedToken !== 'new' ) {
        const $form      = $('form.checkout, form#order_review, form#add_payment_method');
        const $container = $('#acceptblue-v2-hosted-tokenization-form');
        $container.find('input[name="wc-acceptbluev2-payment-token"]').remove();
        $container.append(
            '<input type="hidden" name="wc-acceptbluev2-payment-token" value="' + selectedToken + '"/>'
        );
        $form.submit();
        return;
    }

    // ── Path B: new card ──────────────────────────────────────────────────────
    if ( ! hostedTokenization ) {
        if ( errEl ) errEl.innerText = 'Card form not ready. Please refresh and try again.';
        return;
    }

    $('#acceptblue-hosted-token-ajax-loader').fadeIn();

    try {
        const result = await hostedTokenization.getNonceToken();

        if ( ! result ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            if ( errEl ) errEl.innerText = 'Card tokenization failed — no response.';
            return;
        }

        if ( acceptblue_hosted_token_params.threeDS == 1 ) {
            loadthreeDS( result );
        } else {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            acceptbluev2_handle_build_token_data( result );
        }

    } catch ( error ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        if ( errEl ) errEl.innerText = 'Card tokenization error: ' + error.message;
    }
}

// ── 3DS flow ──────────────────────────────────────────────────────────────────
async function loadthreeDS( data ) {
    $('html, body').animate({ scrollTop: '0px' }, 0);

    // errEl is declared at the top of this function so it is available in ALL
    // branches below — previously it was only declared inside the catch block,
    // causing "errEl is not defined" when the verify3DS promise resolved without
    // ECI data (e.g. frictionless abort).
    const errEl = el('acceptblue-ht-error-message');

    const threeDSData = {
        amount: Number( el('acceptblue-ht-order-amount') ? el('acceptblue-ht-order-amount').value : 0 ),
        email:  q('input[name="billing_email"]') ? q('input[name="billing_email"]').value : '',
    };

    console.log('[AcceptBlue] loadthreeDS() — calling verify3DS()', threeDSData);

    try {
        const threeDSResult = await hostedTokenization.verify3DS( threeDSData );
        console.log('[AcceptBlue] loadthreeDS() — verify3DS() result:', threeDSResult);

        $('#acceptblue-hosted-token-ajax-loader').fadeOut();

        if ( ! threeDSResult ) {
            console.warn('[AcceptBlue] loadthreeDS() — no threeDSResult returned.');
            if ( errEl ) errEl.innerText = '3D Secure verification was not completed. Please try again.';
            return;
        }

        if ( ! threeDSResult.eci ) {
            // ── Frictionless fallback ─────────────────────────────────────────
            // When frictionless mode is enabled and the issuer aborts the
            // challenge (e.g. verify3DS resolves with no ECI), we must NOT
            // block the payment. The nonce token is already valid — submit the
            // form using the nonce alone so the server can process the charge
            // without 3DS data. The server handles the liability shift correctly
            // in this case per the Paay/accept.blue frictionless spec.
            console.warn('[AcceptBlue] loadthreeDS() — no ECI in result. Frictionless fallback: submitting with nonce only.');
            acceptbluev2_handle_build_token_data( data );
            return;
        }

        console.log('[AcceptBlue] loadthreeDS() — 3DS success. ECI:', threeDSResult.eci);
        acceptbluev2_handle_build_token_data_3ds({
            eci:                 threeDSResult.eci,
            authenticationValue: threeDSResult.authenticationValue,
            dsTransId:           threeDSResult.dsTransId,
            nonce:               data.nonce,
            expiryMonth:         data.expiryMonth,
            expiryYear:          data.expiryYear,
        });

    } catch ( error ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        console.error('[AcceptBlue] loadthreeDS() — verify3DS() threw:', error);

        // ── Frictionless catch fallback ───────────────────────────────────────
        // verify3DS can THROW (not just resolve empty) when frictionless mode
        // aborts the challenge: "Challenge request aborted (frictionless)".
        // In that case the nonce is still valid — fall back to nonce-only
        // submission instead of showing an error to the customer.
        const isFrictionlessAbort = threeDSFriction &&
            error && typeof error.message === 'string' &&
            error.message.toLowerCase().includes('frictionless');

        if ( isFrictionlessAbort ) {
            console.warn('[AcceptBlue] loadthreeDS() — frictionless abort caught, falling back to nonce-only submission.');
            acceptbluev2_handle_build_token_data( data );
            return;
        }

        if ( errEl ) errEl.innerText = '3DS verification failed: ' + error.message;
        const container = el('acceptblue-ht-iframe-container');
        if ( container ) {
            $('html, body').animate({ scrollTop: $( container ).offset().top - 80 }, 600 );
        }
    }
}

// ── Form submit helpers ───────────────────────────────────────────────────────
function acceptbluev2_handle_build_token_data( data ) {
    // Nonce-only path (non-3DS, and frictionless 3DS fallback).
    // accept.blue requires expiry even when charging via nonce — the nonce
    // does not carry expiry automatically. getNonceToken() returns expiryMonth
    // and expiryYear alongside the nonce, so we always post them here.
    // PHP reads these as acceptbluev2-payment-expiry_month / expiry_year and
    // includes them in the charge request only when they are valid (>= 1 / >= 2020).
    const $form      = $('form.checkout, form#order_review, form#add_payment_method');
    const $container = $('#acceptblue-v2-hosted-tokenization-form');
    $container.find('input[name="acceptbluev2-payment-token"]').remove();
    $container.find('input[name="acceptbluev2-payment-expiry_month"]').remove();
    $container.find('input[name="acceptbluev2-payment-expiry_year"]').remove();
    $container.append('<input type="hidden" name="acceptbluev2-payment-token"        value="' + data.nonce       + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_month" value="' + (data.expiryMonth || '') + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_year"  value="' + (data.expiryYear  || '') + '"/>');
    console.log('[AcceptBlue] acceptbluev2_handle_build_token_data() — nonce:', data.nonce, 'expiry:', data.expiryMonth, '/', data.expiryYear);
    $form.submit();
}

function acceptbluev2_handle_build_token_data_3ds( data ) {
    const $form      = $('form.checkout, form#order_review, form#add_payment_method');
    const $container = $('#acceptblue-v2-hosted-tokenization-form');
    $container.find('input[name^="acceptbluev2-payment-"]').remove();
    $container.append('<input type="hidden" name="acceptbluev2-payment-eci"                value="' + data.eci                 + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-authenticationvalue" value="' + data.authenticationValue + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-dstransid"           value="' + data.dsTransId           + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-token"               value="' + data.nonce               + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_month"        value="' + data.expiryMonth         + '"/>');
    $container.append('<input type="hidden" name="acceptbluev2-payment-expiry_year"         value="' + data.expiryYear          + '"/>');
    $form.submit();
}

function _onEvent( event ) {
    const errEl = el('acceptblue-ht-error-message');
    if ( ! errEl ) return;
    errEl.innerText = ( event.error && event.error !== '' ) ? event.error : '';
}

}( jQuery ) );
