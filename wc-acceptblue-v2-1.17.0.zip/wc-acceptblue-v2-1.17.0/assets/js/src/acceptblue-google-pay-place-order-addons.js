(function ( $ ) {
"use strict";

// Handle click event for "Proceed to Payment" button
    $('.woocommerce-order-actions .button-goople-pay-place-order').click(function(e) {
        e.preventDefault(); // Prevent the default button action

        var button = $(this); // The clicked button
        var order_key = button.data('order-key'); // Get the order ID (ensure you have this data attribute in your button)

        $('#acceptblue-google-pay-ajax-loader').fadeIn();

        $.ajax({
          type: 'POST',
          url: acceptblue_hosted_token_params.ajax_url,
          data: {
              action: 'acceptblue_request_place_order_charge_addons',                   
              order_key: order_key,
              nonce: acceptblue_hosted_token_params.nonce
          },
          success: function(response) {
            $('#acceptblue-google-pay-ajax-loader').fadeOut();
            if (response.success) {
                window.location.href = response.data;
            } else {
                var errorMessage = '<ul class="woocommerce-error" role="alert">' +
                              '<li><strong>Error:</strong> '+ response.data +'</li>' +
                              '</ul>';                   
                $('.woocommerce-notices-wrapper').html(errorMessage);
                $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 1000);                    
            }
          },
          error: function(xhr, status, error) {
            $('#acceptblue-google-pay-ajax-loader').fadeOut(); 
            var errorMessage = '<ul class="woocommerce-error" role="alert">' +
                               '<li><strong>AJAX request failed:</strong> '+ error +'</li>' +
                               '</ul>';                   
            $('.woocommerce-notices-wrapper').html(errorMessage);
            $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 1000);
        }
      });

    });

}( jQuery ) );
