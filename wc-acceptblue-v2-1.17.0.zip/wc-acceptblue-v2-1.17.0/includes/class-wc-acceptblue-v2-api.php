<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class WC_AcceptBlue_API_v2 {

    protected $host;   
    protected $api_key;
    protected $pin;
    protected $settings;
    

    //public function __construct( $test_mode, $api_key, $pin ) {
    public function __construct() {

        $this->settings = get_option( 'woocommerce_acceptbluev2_settings', array() );

        $test_mode = $this->settings['testmode'] ?? 'yes';

        if($test_mode === 'yes'){        
            $api_key = $this->settings['test_api_key'] ?? '';
            $pin = $this->settings['test_pin'] ?? '';
        } else {        
            $api_key = $this->settings['live_api_key'] ?? '';
            $pin = $this->settings['live_pin'] ?? '';
        }

        $this->host = ($test_mode === 'yes') ? 'https://api.develop.accept.blue/api/v2/' : 'https://api.accept.blue/api/v2/';
        $this->api_key = $api_key;
        $this->pin = $pin;
        
    }  

    public function request( $path, $data = array() ) {
        // Implement the API request logic here 
        
        $username = $this->api_key;
		$password = $this->pin;

        if( isset( $data['method'] ) ) {
            $method = $data['method'];
            unset( $data['method'] );
        } else {
            $method = 'POST';
        }

        //$method = $data['method'] ?? 'POST';

		$response = wp_remote_request( $this->host . $path,
						array(
							'method'    => $method,							
							'headers'   => array( 
													'Content-Type' => 'application/json',
													'Authorization' => 'Basic ' . base64_encode( $username . ':' . $password )
											),
							'body'      => $data ? wp_json_encode( $data, JSON_PRESERVE_ZERO_FRACTION ) : null,
							'timeout'   => 90,
							'sslverify' => true,
							'user-agent' => __( 'accept.blue v2 for WooCommerce ' . AB_V2_VERSION , 'woocommerce') 
						));		


        if ( is_wp_error( $response ) ) {

				$result[ 'code' ] 				= false;
				$result[ 'message' ] 			= $response->get_error_message();

		  } else {
			
				$result[ 'code' ] 				= true;
				$result[ 'response_code' ] 		= $response['response']['code'];
				$result[ 'response_message' ] 	= $response['response']['message'];
				$result[ 'response_body' ] 		= json_decode($response['body']);
		  }                        

        return $result;
        
    }

    // public function save_card( $card_data ) {

    //     $verify = $this->verify( $card_data);

    //     if( $verify['code'] == 1 && $verify['response_code'] == 200 && $verify['response_body']->status == 'Approved' ) {

    //        $result =  $this->request( 'saved-cards', $card_data );

    //        if( $result['code'] == 1 && $result['response_code'] == 200 ) {
    //            $result = array(
    //                'code' => 1,
    //                'message' => 'Card saved successfully',
    //                'token_id' => $result['response_body']->cardRef
    //            );

    //        } else {
    //            $result = array(
    //                'code' => 0,
    //                'message' => 'Payment Error: ' . $result['response_message']
    //            );
    //        } 

    //     } else {
    //         //exit;
    //         $result = array(
    //                'code' => 0,
    //                'message' => 'Payment Error : ' . $verify['response_body']->error_message
    //            );
    //     }
        

    //     return $result;
    // }

    public function save_card( $card_data ) {

        $result = $this->request( 'saved-cards', $card_data );

        if ( $result['code'] == 1 && $result['response_code'] == 200 ) {

            $result = array(
                'code'      => 1,
                'message'   => 'Card saved successfully',
                'token_id'  => $result['response_body']->cardRef
            );

        } else {

            $error_message = isset( $result['response_body']->error_message )
                ? $result['response_body']->error_message
                : $result['response_message'];

            $result = array(
                'code'    => 0,
                'message' => 'Payment Error: ' . $error_message
            );
        }

        return $result;
    }

    public function verify( $card_data ) {
        return $this->request( 'transactions/verify', $card_data );
    }

    public function charge_by_source_token( $charge_data ) {
        return $this->request( 'transactions/charge', $charge_data );
    }

    public function get_surcharge_fee_settings() {
       
        if(($this->settings['surcharge_card'] ?? 'no') !== 'yes' ){
            return false;
        }

        $surcharge_manual = ($this->settings['surcharge_manual'] ?? 'no') === 'yes' ? true : false;
        
        if($surcharge_manual === true ){
			
            return   array(
                            'type' =>  $this->settings['surcharge_type'] ?? 'percentage',
                            'value'=>  $this->settings['surcharge_value'] ?? '0'
                    );			 			

		} else {

			//$response 	= $this->request( 'surcharge', array( 'method' => 'GET' ));

            $method = array( 'method' => 'GET' );
            $response 	= $this->request( 'surcharge', $method );

			$data 		= (array) $response['response_body'];		

			if( !empty($data) && $response[ 'response_code' ] == 200 ){

				return (array) $data['card'];

			}

		}

    }

    public function add_surcharge( $amount_data ) {
       
         $fee = $this->get_surcharge_fee_settings();


        if( $fee[ 'type'] === 'percentage' ) {
            $surcharge_amount = ( $amount_data * $fee['value'] ) / 100;
        } else {
            $surcharge_amount = $fee['value'];
        }

    }

    public function remove_surcharge( $amount_data ) {
       
        $surcharge = $this->get_surcharge_fee_settings();

		$fee_name = str_replace(' ', '-', strtolower( $this->settings['surcharge_label'] ?? 'surcharge' ) ) ;

        $fee_exists = false;
        foreach ( WC()->cart->get_fees() as $fee ) {

            if ( $fee->id === $fee_name ) {
                $surcharge_amount = $fee->amount;
                $fee_exists = true;
                break;
            }
        }

        if ( $fee_exists ) {

             $surcharge_amount = number_format($surcharge_amount, wc_get_price_decimals(), '.', '');
             $total_amount = number_format(  $amount_data - $surcharge_amount, wc_get_price_decimals(), '.', '');
             return $total_amount;

        } else {

            return $amount_data;

        }   
        

    }

    public function get_surcharge_info() {

        $surcharge = $this->get_surcharge_fee_settings();

        // get_surcharge_fee_settings() returns false when surcharge is disabled
        $type  = ( is_array( $surcharge ) && isset( $surcharge['type']  ) ) ? $surcharge['type']  : 'percentage';
        $value = ( is_array( $surcharge ) && isset( $surcharge['value'] ) ) ? $surcharge['value'] : '0';
        
        return array(
            'name' => esc_html__($this->settings['surcharge_label'] ?? 'Surcharge', 'woocommerce'),
            'fee' => array(
                'type'  => $type,
                'value' => $value,
            ),
        );
        

    }

    public function is_surcharge_enabled() {
        
        if(($this->settings['surcharge_card'] ?? 'no') !== 'yes' ){
            return array('code' => false);
        } else {
            return array('code' => true);
        }   

    }   
    
}