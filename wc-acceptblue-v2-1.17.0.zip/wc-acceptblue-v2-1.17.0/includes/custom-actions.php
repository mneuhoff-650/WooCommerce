<?php
/**
 * accept.blue Payment Gateway v2 — Custom Actions
 *
 * All WordPress frontend and WooCommerce custom hooks:
 *
 *   Section 1  — Order status hooks (auto-capture, auto-cancel)
 *   Section 2  — Surcharge: cart fee calculation, block checkout callback,
 *                surcharge script enqueue, surcharge removal on non-AB orders,
 *                Google Pay surcharge filter
 *   Section 3  — Hosted Tokenization SDK: registration + checkout enqueue
 *   Section 4  — Hosted Tokenization AJAX callbacks (standard + addons)
 *   Section 5  — Hosted Tokenization: payment list container (review page)
 *   Section 6  — WooCommerce Blocks tokenize AJAX endpoint
 *   Section 7  — Global frontend script/style params
 *
 * Loaded by wc-acceptblue-v2.php after class files are included.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */

defined( 'ABSPATH' ) || exit;

// =============================================================================
// Singleton gateway accessor
// =============================================================================

/**
 * Retrieve the registered gateway instance from WC's payment gateway registry.
 *
 * NEVER call new WC_Gateway_AcceptBlue_v2() inside a recurring hook callback.
 * Every instantiation re-runs __construct() which calls add_action() again,
 * stacking duplicate listeners until PHP exhausts memory (OOM fatal error).
 * The WC registry holds exactly one instance — always use this helper instead.
 *
 * Returns null when WC is not fully loaded yet; callers must guard for null.
 *
 * @return WC_Gateway_AcceptBlue_v2|null
 */
function acceptblue_v2_gateway() {
    static $instance = null;
    if ( $instance !== null ) {
        return $instance;
    }
    if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways ) {
        return null;
    }
    $gateways = WC()->payment_gateways()->payment_gateways();
    $instance = $gateways['acceptbluev2'] ?? null;
    return $instance;
}

// =============================================================================
// 1. Order status hooks — auto-capture & auto-cancel
// =============================================================================

/**
 * Auto-capture payment when order status changes to on-hold, processing,
 * or completed (e.g. via Shipworks Connector or manual status change).
 */
add_action( 'woocommerce_order_status_on-hold',    array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );
add_action( 'woocommerce_order_status_processing', array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );
add_action( 'woocommerce_order_status_completed',  array( 'WC_Gateway_AcceptBlue_v2', 'process_capture' ), 10, 2 );

/**
 * Auto-void / cancel payment when order status changes to cancelled.
 */
add_action( 'woocommerce_order_status_cancelled', array( 'WC_Gateway_AcceptBlue_v2', 'process_cancelled' ), 10, 2 );

// =============================================================================
// 2. Surcharge
// =============================================================================

/**
 * Enqueue the surcharge JS for WooCommerce Block Checkout.
 * Priority 5 — must load before blocks resolve dependencies.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_surcharge_script', 5 );

function acceptblue_v2_enqueue_surcharge_script() {
    wp_enqueue_script(
        'acceptbluev2-block-surcharge',
        plugins_url( 'assets/js/dist/acceptblue-surcharge.min.js', AB_V2_PLUGIN_FILE ),
        array( 'wc-blocks-registry', 'wp-data', 'wc-blocks' ),
        AB_V2_VERSION,
        true
    );
}

/**
 * Register the surcharge callback for WooCommerce Store API (Block Checkout).
 * Without this, Blocks ignore cart fee changes.
 */
add_filter(
    'woocommerce_store_api_cart_update_callbacks',
    function ( $callbacks ) {
        $callbacks[] = 'acceptblue_v2_surcharge_add_cart_fee';
        return $callbacks;
    }
);

/**
 * Add the surcharge fee to the cart on both classic and block checkout.
 * Also hooked on woocommerce_cart_calculate_fees for classic checkout.
 *
 * @param WC_Cart $cart
 */
function acceptblue_v2_surcharge_add_cart_fee( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }

    // Skip the order-pay page — surcharge is handled per order there.
    // Use is_checkout_pay_page() directly; $_GET['order-pay'] is empty on pretty-permalink sites.
    if ( is_checkout_pay_page() ) {
        return;
    }

    // Respect the "Show Surcharge in Checkout" setting
    $settings = get_option( 'woocommerce_acceptbluev2_settings', [] );
    if ( empty( $settings['surcharge_card'] ) || $settings['surcharge_card'] !== 'yes' ) {
        return;
    }
    if ( empty( $settings['surcharge_checkout'] ) || $settings['surcharge_checkout'] !== 'yes' ) {
        return;
    }

    // Only add the surcharge fee when accept.blue is the chosen payment method.
    // On classic checkout WC stores the chosen method in the session; on block
    // checkout the surcharge JS triggers a cart recalculation on method change
    // so this check fires with the correct method each time.
    $chosen = WC()->session ? WC()->session->get( 'chosen_payment_method' ) : '';
    if ( $chosen && $chosen !== 'acceptbluev2' ) {
        return;
    }

    $client = new WC_AcceptBlue_API_v2();

    $is_enabled = $client->is_surcharge_enabled();
    if ( $is_enabled['code'] === false ) {
        return;
    }

    $surcharge = $client->get_surcharge_info();
    if ( empty( $surcharge['fee']['value'] ) ) {
        return;
    }

    // Prevent duplicate fee
    $fee_slug = str_replace( ' ', '-', strtolower( $surcharge['name'] ) );
    foreach ( $cart->get_fees() as $fee ) {
        if ( $fee->id === $fee_slug ) {
            return;
        }
    }

    $subtotal = $cart->get_cart_contents_total()
              + $cart->get_shipping_total()
              + $cart->get_taxes_total()
              + $cart->get_fee_total();

    if ( $subtotal <= 0 ) {
        return;
    }

    $surcharge_name  = $surcharge['name'];
    $surcharge_value = (float) $surcharge['fee']['value'];
    $surcharge_type  = $surcharge['fee']['type'];

    $fee_amount = ( $surcharge_type === 'percent' )
        ? round( $subtotal * ( $surcharge_value / 100 ), 2 )
        : $surcharge_value;

    if ( $fee_amount <= 0 ) {
        return;
    }

    $cart->add_fee(
        __( sanitize_text_field( $surcharge_name ), 'woocommerce' ),
        $fee_amount,
        false
    );
}

// Classic checkout fee hook
if ( ! has_action( 'woocommerce_cart_calculate_fees', 'acceptblue_v2_surcharge_add_cart_fee' ) ) {
    add_action( 'woocommerce_cart_calculate_fees', 'acceptblue_v2_surcharge_add_cart_fee' );
}

/**
 * After checkout order is created: if the chosen payment method is NOT accept.blue,
 * remove the surcharge fee so it isn't billed to the customer.
 */
add_action( 'woocommerce_checkout_order_processed', 'acceptblue_v2_remove_surcharge_for_non_ab_orders', 10, 3 );

function acceptblue_v2_remove_surcharge_for_non_ab_orders( $order_id, $posted_data, $order ) {
    $order = wc_get_order( $order_id );

    if ( ! $order || $order->get_payment_method() === 'acceptbluev2' ) {
        return;
    }

    $client   = new WC_AcceptBlue_API_v2();
    $surcharge = $client->get_surcharge_info();

    if ( empty( $surcharge['name'] ) ) {
        return;
    }

    $fee_label = $surcharge['name'];

    foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
        if ( $item->get_name() === $fee_label ) {
            $order->remove_item( $item_id );
        }
    }

    $order->calculate_totals();
    $order->save();
}

/**
 * Filter: return the Google Pay surcharge data from the Accept.Blue API.
 * Used by the order review page shortcode to display the surcharge row.
 */
add_filter( 'acceptblue_googlepay_get_surcharge', 'acceptblue_v2_googlepay_surcharge_filter', 10, 1 );

function acceptblue_v2_googlepay_surcharge_filter( $value ) {
    $ab = acceptblue_v2_gateway();
    if ( ! $ab ) return $value;
    return $ab->get_surcharge() ?: $value;
}

// =============================================================================
// 3. Hosted Tokenization SDK — registration & checkout enqueue
// =============================================================================

/**
 * Register the Accept.Blue hosted tokenization CDN script under a single
 * canonical handle so WordPress deduplication prevents double-loading
 * (which caused "window.HostedTokenization is already defined").
 *
 * Priority 1 on wp_enqueue_scripts — registered before anything tries to
 * enqueue it. Also registered on init so WooCommerce Blocks can resolve the
 * dependency (Blocks do NOT run wp_enqueue_scripts).
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_register_hosted_sdk', 1 );
add_action( 'init',               'acceptblue_v2_register_hosted_sdk', 20 );

function acceptblue_v2_register_hosted_sdk() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    $hosted_url = ( isset( $settings['testmode'] ) && $settings['testmode'] === 'yes' )
        ? 'https://tokenization.sandbox.accept.blue/tokenization/v0.3'
        : 'https://tokenization.accept.blue/tokenization/v0.3';

    wp_register_script( 'acceptblue-hosted-sdk', $hosted_url, array(), null, true );
}

/**
 * On the standard (classic) checkout page, enqueue the hosted SDK and the
 * checkout-specific iframe script.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_tokenization_checkout' );

function acceptblue_v2_enqueue_tokenization_checkout() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    // Only on the standard checkout page — not on order-pay.
    // Use is_checkout_pay_page() directly; $_GET['order-pay'] is empty on
    // pretty-permalink installs where the order ID is part of the URL path.
    if ( ! is_checkout() || is_checkout_pay_page() ) {
        return;
    }

    // FIX: The gateway class (class-wc-acceptblue-v2.php) may already have
    // enqueued the same JS file under the handle 'acceptblue-gateway-hosted-token'
    // via threeds_classic_checkout_script() or tokenization_script(). If either
    // of those handles is already queued/registered we must not load a second
    // copy — that is what caused the duplicate iframe (two independent IIFEs,
    // each with their own `hostedTokenization` variable, both mounting into the
    // same container). Bail out; the class handle already covers this page.
    if (
        wp_script_is( 'acceptblue-gateway-hosted-token', 'enqueued' ) ||
        wp_script_is( 'acceptblue-gateway-hosted-token', 'registered' ) ||
        wp_script_is( 'acceptblue-gateway-hosted-token-checkout-iframe', 'enqueued' )
    ) {
        return;
    }

    // acceptblue-v2-js must be enqueued first so acceptblue_hosted_token_params
    // is defined before acceptblue-hosted-token-iframe-checkout.min.js runs.
    // local_script() registers + localizes + enqueues acceptblue-v2-js.
    $gateway = acceptblue_v2_gateway();
    if ( $gateway ) {
        $gateway->local_script();
        $gateway->style();
    }

    wp_enqueue_script( 'acceptblue-hosted-sdk' );
    wp_enqueue_script(
        // FIX: Use the same handle as the class so WordPress deduplicates
        // automatically if both code paths ever run. Previously this used
        // a different handle ('acceptblue-gateway-hosted-token-checkout-iframe')
        // which meant WordPress had no way to know it was the same file.
        'acceptblue-gateway-hosted-token',
        plugins_url( 'assets/js/dist/acceptblue-hosted-token-iframe-checkout.min.js', AB_V2_PLUGIN_FILE ),
        array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ),
        AB_V2_VERSION,
        true
    );
}

/**
 * Enqueue the hosted SDK for WooCommerce Block Checkout (3DS path).
 * Priority 5 — before other block scripts.
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_hosted_sdk_for_blocks', 5 );

function acceptblue_v2_enqueue_hosted_sdk_for_blocks() {
    $settings = get_option( 'woocommerce_acceptbluev2_settings' );
    if ( empty( $settings ) || $settings['enabled'] === 'no' ) {
        return;
    }

    // Skip the order-pay page: when block_support_checkout=true and tokenization=false,
    // the order-pay page uses classic card fields (no hosted iframe container exists).
    // Loading the SDK there causes 'Target element not found' errors.
    // The tokenization=true path loads the SDK via tokenization_script() instead.
    if ( is_checkout_pay_page() ) {
        return;
    }

    wp_enqueue_script( 'acceptblue-hosted-sdk' );
}

// =============================================================================
// 4. Hosted Tokenization AJAX callbacks
// =============================================================================

// Standard (non-addons) hosted token place order
add_action( 'wp_ajax_acceptblue_ht_request_place_order_charge',        'acceptblue_v2_ht_place_order_charge' );
add_action( 'wp_ajax_nopriv_acceptblue_ht_request_place_order_charge', 'acceptblue_v2_ht_place_order_charge' );

function acceptblue_v2_ht_place_order_charge() {
    $ab = acceptblue_v2_gateway();
    if ( $ab ) $ab->ht_place_order_charge();
}

// Addons (subscriptions / pre-orders) hosted token place order
add_action( 'wp_ajax_acceptblue_ht_request_place_order_charge_addons',        'acceptblue_v2_ht_place_order_charge_addons' );
add_action( 'wp_ajax_nopriv_acceptblue_ht_request_place_order_charge_addons', 'acceptblue_v2_ht_place_order_charge_addons' );

function acceptblue_v2_ht_place_order_charge_addons() {
    // Addons is instantiated here in a single-shot AJAX callback — not in a
    // recurring hook — so duplicate __construct() accumulation cannot occur.
    $ab = new WC_Gateway_AcceptBlue_v2_Addons();
    $ab->ht_place_order_charge_addons();
}

// Add Payment Method via hosted tokenization iframe
// Called from both iframe-3ds.js and iframe-addons-3ds.js when is_add_payment_method = 1.
add_action( 'wp_ajax_acceptblue_ht_add_payment_method', 'acceptblue_v2_ht_add_payment_method' );

function acceptblue_v2_ht_add_payment_method() {
    if ( ! check_ajax_referer( 'acceptblue-ajax-nonce', 'nonce', false ) ) {
        wp_send_json_error( array( 'message' => esc_html__( 'Invalid nonce.', 'woocommerce' ) ) );
    }
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( array( 'message' => esc_html__( 'You must be logged in to add a payment method.', 'woocommerce' ) ) );
    }

    $ab = acceptblue_v2_gateway();
    if ( ! $ab ) {
        wp_send_json_error( array( 'message' => esc_html__( 'Gateway not available.', 'woocommerce' ) ) );
    }

    $saved_token_id     = ! empty( $_POST['saved_token_id'] )     ? absint( $_POST['saved_token_id'] )             : 0;
    $hosted_token_nonce = ! empty( $_POST['hosted_token_nonce'] ) ? sanitize_text_field( $_POST['hosted_token_nonce'] ) : '';

    if ( empty( $saved_token_id ) && empty( $hosted_token_nonce ) ) {
        wp_send_json_error( array( 'message' => esc_html__( 'No payment token provided.', 'woocommerce' ) ) );
    }

    // ── Path A: saved token re-use — just verify it belongs to the user ──────
    if ( $saved_token_id > 0 && empty( $hosted_token_nonce ) ) {
        $wc_token = WC_Payment_Tokens::get( $saved_token_id );
        if (
            ! $wc_token ||
            $wc_token->get_gateway_id() !== $ab->id ||
            $wc_token->get_user_id() !== get_current_user_id()
        ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Invalid payment token.', 'woocommerce' ) ) );
        }
        // Token already saved — nothing to do, redirect to payment methods
        wp_send_json_success( array( 'redirect' => wc_get_endpoint_url( 'payment-methods', '', wc_get_page_permalink( 'myaccount' ) ) ) );
    }

    // ── Path B: new card — $0.01 auth-and-void to capture card_ref ──────────
    $expiry_month = ! empty( $_POST['expiry_month'] ) ? (int) $_POST['expiry_month'] : 0;
    $expiry_year  = ! empty( $_POST['expiry_year'] )  ? (int) $_POST['expiry_year']  : 0;
    // Auto-generate valid expiry when missing (frictionless fallback sends no expiry)
    if ( $expiry_month < 1 || $expiry_month > 12 ) { $expiry_month = (int) date('n'); }
    if ( $expiry_year  < 2020 )                    { $expiry_year  = (int) date('Y') + 2; }
    $card_name    = ! empty( $_POST['card_name'] )    ? sanitize_text_field( $_POST['card_name'] ) : '';

    $current_user = wp_get_current_user();
    // Get client IP directly — we have no order object here, so bypass get_client_ip()
    // which requires a WC_Order argument.
    $client_ip = class_exists( 'WC_Geolocation' ) ? WC_Geolocation::get_ip_address() : '';

    $params = array(
        'amount'      => 0.01,
        'source'      => 'nonce-' . $hosted_token_nonce,
        'capture'     => false,
        'save_card'   => true,
        'billing_info' => array(
            'first_name' => $current_user->first_name ?: $current_user->display_name,
            'last_name'  => $current_user->last_name,
        ),
        'transaction_details' => array(
            'description' => sprintf( '%s - Add Payment Method', ucwords( get_bloginfo( 'name' ) ) ),
            'client_ip'   => sanitize_text_field( (string) $client_ip ),
        ),
        'amount_details' => array( 'tax' => 0.0, 'shipping' => 0.0, 'discount' => 0.0 ),
    );
    if ( $expiry_month ) $params['expiry_month'] = $expiry_month;
    if ( $expiry_year )  $params['expiry_year']  = $expiry_year;
    if ( $card_name )    $params['name']          = $card_name;

    // 3DS data if present
    $raw_eci      = ! empty( $_POST['threed_secure']['eci'] )        ? wp_unslash( $_POST['threed_secure']['eci'] )        : '';
    $raw_cavv     = ! empty( $_POST['threed_secure']['cavv'] )       ? wp_unslash( $_POST['threed_secure']['cavv'] )       : '';
    $raw_trans_id = ! empty( $_POST['threed_secure']['ds_trans_id'] )? wp_unslash( $_POST['threed_secure']['ds_trans_id'] ): '';
    if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {
        $params['3d_secure'] = array(
            'eci'        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
            'cavv'       => (string) $raw_cavv,
            'ds_trans_id'=> (string) $raw_trans_id,
        );
    }

    $result = $ab->request_api( $params, 'transactions/charge', 'POST' );

    if (
        isset( $result['response_code'], $result['response_message'], $result['response_body'] ) &&
        (int) $result['response_code'] === 200 &&
        $result['response_message'] === 'OK'
    ) {
        $data     = wp_parse_args( (array) $result['response_body'], array() );
        $card_ref = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );

        if ( ! empty( $card_ref ) && ( $data['status'] ?? '' ) === 'Approved' ) {
            // Immediately void the $0.01 auth
            $ref_num = sanitize_text_field( $data['reference_number'] ?? '' );
            if ( $ref_num ) {
                $ab->request_api( array( 'reference_number' => (int) $ref_num ), 'transactions/reversal', 'POST' );
            }

            // Save the token
            $card_token = array(
                'token'            => 'tkn-' . $card_ref,
                'card_type'        => sanitize_text_field( $data['card_type'] ?? '' ),
                'set_last4'        => sanitize_text_field( $data['last_4'] ?? '' ),
                'set_expiry_month' => (int) ( $data['expiry_month'] ?? $expiry_month ),
                'set_expiry_year'  => (int) ( $data['expiry_year']  ?? $expiry_year ),
            );
            $ab->save_token( $card_token );

            wp_send_json_success( array(
                'redirect' => wc_get_endpoint_url( 'payment-methods', '', wc_get_page_permalink( 'myaccount' ) ),
            ) );
        }
    }

    wp_send_json_error( array( 'message' => esc_html__( 'There was a problem adding this card. Please try again.', 'woocommerce' ) ) );
}


// =============================================================================
// 6. WooCommerce Blocks — tokenize AJAX endpoint
// =============================================================================

add_action( 'wc_ajax_acceptbluev2_tokenize',        'acceptblue_v2_tokenize_card' );
add_action( 'wc_ajax_nopriv_acceptbluev2_tokenize', 'acceptblue_v2_tokenize_card' );

function acceptblue_v2_tokenize_card() {
    $body = json_decode( file_get_contents( 'php://input' ), true );

    if ( empty( $body['number'] ) || empty( $body['expiry'] ) || empty( $body['cvv'] ) ) {
        wp_send_json_error( array( 'message' => 'Missing card details.' ) );
    }

    $settings  = get_option( 'woocommerce_acceptbluev2_settings' );
    $test_mode = $settings['testmode'] ?? 'no';

    // Parse expiry
    $exp       = explode( '/', $body['expiry'] );
    $exp_month = trim( $exp[0] );
    $exp_year  = isset( $exp[1] ) ? '20' . trim( $exp[1] ) : '';

    $payload = array(
        'card'         => preg_replace( '/\D/', '', $body['number'] ),
        'expiry_month' => (int) $exp_month,
        'expiry_year'  => (int) $exp_year,
        'cvv2'         => $body['cvv'],
    );

    // AVS fields — billing address and zip for fraud prevention and best E-commerce rate.
    // Sent by the block checkout JS from the WooCommerce billing fields.
    // Trimmed and capped to API limits: address ≤ 255 chars, zip ≤ 50 chars.
    if ( ! empty( $body['avs_address'] ) ) {
        $payload['avs_address'] = substr( sanitize_text_field( wp_unslash( $body['avs_address'] ) ), 0, 255 );
    }
    if ( ! empty( $body['avs_zip'] ) ) {
        $payload['avs_zip'] = substr( sanitize_text_field( wp_unslash( $body['avs_zip'] ) ), 0, 50 );
    }

    $client   = new WC_AcceptBlue_API_v2();
    $token_id = $client->save_card( $payload );

    if ( $token_id['code'] == 0 ) {
        wp_send_json_error( array( 'message' => $token_id['message'] ) );
    }

    if ( isset( $token_id['token_id'] ) ) {
        wp_send_json_success( array(
            'token'        => $token_id['token_id'],
            'expiry_month' => (int) $exp_month,
            'expiry_year'  => (int) $exp_year,
            'last4'        => substr( preg_replace( '/\D/', '', $body['number'] ), -4 ),
        ) );
    } else {
        wp_send_json_error( array( 'message' => 'Tokenization failed: ' . wp_json_encode( $token_id ) ) );
    }
}

// =============================================================================
// 7. Global frontend script & style params
// =============================================================================

/**
 * Enqueue the global acceptblue_hosted_token_params JS object and base styles
 * on every frontend page except the order-pay page (which has its own flow).
 */
add_action( 'wp_enqueue_scripts', 'acceptblue_v2_enqueue_global_params' );

function acceptblue_v2_enqueue_global_params() {
    // Skip the order-pay page entirely — local_script_for_pay_order_page() handles it
    // there with block_checkout:false so the classic card form JS submits correctly.
    // The old guard used $_GET['order-pay'] which is empty on pretty-permalink sites.
    if ( is_checkout_pay_page() ) {
        return;
    }

    $gateway = acceptblue_v2_gateway();
    if ( ! $gateway ) return;

    // local_script() has a static guard against double-localization.
    // On the classic checkout page acceptblue_v2_enqueue_tokenization_checkout
    // already called local_script(). Calling it again here is safe — the guard
    // skips the localize step and just enqueues the already-registered handle.
    $gateway->local_script();
    $gateway->style();
}

// =============================================================================
// 8. Adjust and Capture — admin warning, order action, AJAX handler, UI button
// =============================================================================

/**
 * Resolve the current order on the admin order edit screen.
 * Works for both legacy post-based orders and HPOS (custom_order_tables).
 * Returns null if not on an order screen or order can't be loaded.
 *
 * @return WC_Order|null
 */
function acceptblue_v2_get_current_admin_order() {
    // HPOS: order ID is in $_GET['id']
    if ( ! empty( $_GET['id'] ) && function_exists( 'wc_get_order' ) ) {
        $order = wc_get_order( absint( $_GET['id'] ) );
        if ( $order instanceof WC_Order ) return $order;
    }

    // Legacy post editor: order ID is in $_GET['post'] or $_POST['post_ID']
    $post_id = absint( $_GET['post'] ?? $_POST['post_ID'] ?? 0 );
    if ( $post_id && function_exists( 'wc_get_order' ) ) {
        $order = wc_get_order( $post_id );
        if ( $order instanceof WC_Order ) return $order;
    }

    // Last resort: use $theorder global (set by WC legacy meta box)
    global $theorder;
    if ( $theorder instanceof WC_Order ) return $theorder;

    return null;
}

/**
 * Helper: is the order eligible for Adjust & Capture?
 * Returns false if already captured, not acceptbluev2, or force_capture is on.
 *
 * @param WC_Order $order
 * @return bool
 */
function acceptblue_v2_order_is_adjustable( WC_Order $order ) {
    if ( $order->get_payment_method() !== 'acceptbluev2' ) return false;
    if ( $order->get_meta( '_acceptblue_capture_done' ) ) return false;

    // Do not show the capture button for terminal/non-capturable order statuses.
    $non_capturable = array( 'cancelled', 'refunded', 'failed', 'trash' );
    if ( in_array( $order->get_status(), $non_capturable, true ) ) return false;

    // Respect force_capture setting — no manual capture needed when it's on
    $settings = get_option( 'woocommerce_acceptbluev2_settings', array() );
    if ( ! empty( $settings['force_capture'] ) && $settings['force_capture'] === 'yes' ) return false;

    // Must have a transaction ID to capture against.
    // _transaction_id is a WC internal key — use the proper getter to avoid notices.
    $txn = $order->get_transaction_id();
    if ( empty( $txn ) ) {
        $txn = $order->get_meta( '_acceptbluev2_refnum' );
    }
    if ( empty( $txn ) ) return false;

    return true;
}

/**
 * Register "Adjust and Capture" in the WooCommerce order actions dropdown.
 *
 * The filter receives $theorder as a second arg in WC 7.9+ (HPOS), but in
 * older WC it only passes the $actions array. We use our own resolver to
 * handle both cases reliably.
 */
add_filter( 'woocommerce_order_actions', 'acceptblue_v2_register_adjust_capture_action', 10, 2 );

function acceptblue_v2_register_adjust_capture_action( $actions, $order = null ) {
    // WC 7.9+ HPOS passes $order as second arg; older WC does not.
    if ( ! $order instanceof WC_Order ) {
        $order = acceptblue_v2_get_current_admin_order();
    }
    if ( ! $order instanceof WC_Order ) return $actions;
    if ( ! acceptblue_v2_order_is_adjustable( $order ) ) return $actions;

    $actions['acceptblue_adjust_and_capture'] = __( 'accept.blue: Adjust and Capture Payment', 'woocommerce' );
    return $actions;
}

/**
 * Handle the order-action dropdown trigger.
 * WooCommerce fires: woocommerce_order_action_{action_key}
 */
add_action( 'woocommerce_order_action_acceptblue_adjust_and_capture', 'acceptblue_v2_handle_adjust_capture_action', 10, 1 );

function acceptblue_v2_handle_adjust_capture_action( $order ) {
    if ( ! $order instanceof WC_Order ) return;
    WC_Gateway_AcceptBlue_v2::adjust_and_capture( $order->get_id(), $order );
}

/**
 * Register the "Adjust and Capture" meta box.
 *
 * Using add_meta_box is the most reliable way to inject a button into the
 * order edit screen for both legacy (shop_order) and HPOS (woocommerce_page_wc-orders).
 * woocommerce_order_item_add_action_button fires inside the order ITEMS table
 * and is not suited for payment action buttons.
 */
add_action( 'add_meta_boxes', 'acceptblue_v2_register_adjust_capture_meta_box' );

function acceptblue_v2_register_adjust_capture_meta_box() {
    // Legacy CPT screen
    add_meta_box(
        'acceptblue-adjust-capture',
        'accept.blue Payment',
        'acceptblue_v2_render_adjust_capture_meta_box',
        'shop_order',
        'side',
        'high'
    );

    // HPOS screen (WC 7.1+)
    add_meta_box(
        'acceptblue-adjust-capture',
        'accept.blue Payment',
        'acceptblue_v2_render_adjust_capture_meta_box',
        'woocommerce_page_wc-orders',
        'side',
        'high'
    );
}

// =============================================================================
// 8b. Inline warning inside the order items box (Save / Recalculate trigger)
// =============================================================================

/**
 * Enqueue inline JS on the admin order edit screen (both legacy CPT and HPOS).
 *
 * The JS injects a warning banner into the DOM just before the Recalculate
 * button and shows it whenever the live order total differs from the stored
 * authorized amount. Triggered by: Recalculate, Save, Add item/fee/shipping.
 *
 * woocommerce_order_item_add_action_button is NOT used here because it does
 * not fire on the HPOS wc-orders screen — admin_enqueue_scripts works on both.
 */
add_action( 'admin_enqueue_scripts', 'acceptblue_v2_enqueue_items_box_warning' );

function acceptblue_v2_enqueue_items_box_warning() {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    $is_order_screen = ( $screen->id === 'shop_order' )
        || ( $screen->id === 'woocommerce_page_wc-orders' && ! empty( $_GET['id'] ) );
    if ( ! $is_order_screen ) return;

    $order_id = absint( $_GET['id'] ?? $_GET['post'] ?? 0 );
    if ( ! $order_id ) return;

    $order = wc_get_order( $order_id );
    if ( ! $order instanceof WC_Order ) return;
    if ( $order->get_payment_method() !== 'acceptbluev2' ) return;
    if ( $order->get_meta( '_acceptblue_capture_done' ) ) return;

    $settings = get_option( 'woocommerce_acceptbluev2_settings', array() );
    if ( ! empty( $settings['force_capture'] ) && $settings['force_capture'] === 'yes' ) return;

    $authorized = (float) $order->get_meta( '_acceptblue_authorized_amount' );
    if ( $authorized <= 0 ) return;

    $currency   = $order->get_currency();
    $auth_price = wp_strip_all_tags( wc_price( $authorized, array( 'currency' => $currency ) ) );

    // Pass data to inline JS via wp_add_inline_script on a guaranteed handle
    $data = array(
        'authorizedAmt' => $authorized,
        'authFormatted'  => $auth_price,
        'orderId'        => $order_id,
        'nonce'          => wp_create_nonce( 'acceptblue_v2_check_total_' . $order_id ),
    );

    // jquery is always enqueued on admin order screens
    wp_add_inline_script(
        'jquery',
        'window.acceptblueItemsWarning = ' . wp_json_encode( $data ) . ';'
            . acceptblue_v2_items_warning_js(),
        'after'
    );
}

/**
 * Returns the inline JS string for the items-box warning.
 * Kept as a function so it is only defined once (not duplicated per enqueue).
 */
function acceptblue_v2_items_warning_js() {
    return <<<'JS'
(function($) {
    'use strict';

    var cfg = window.acceptblueItemsWarning;
    if ( ! cfg ) return;

    var authorizedAmt = parseFloat( cfg.authorizedAmt );
    var authFormatted = cfg.authFormatted;

    // Guard: only show the banner after a real user action — never on page load.
    var userTriggered = false;

    // -------------------------------------------------------------------------
    // Build the warning banner (hidden, not yet in DOM)
    // -------------------------------------------------------------------------
    var banner = document.createElement('div');
    banner.id  = 'acceptblue-items-warning';
    banner.style.cssText = [
        'display:none',
        'margin:0 0 8px',
        'padding:10px 14px',
        'background:#fff8e5',
        'border-left:4px solid #dba617',
        'border-radius:2px',
        'font-size:12px',
        'line-height:1.6',
        'color:#3c3c3c',
        'clear:both'
    ].join(';');

    banner.innerHTML =
        '<strong>accept.blue \u2014 Order Total Changed</strong><br>' +
        'Authorized amount was <strong>' + authFormatted + '</strong> ' +
        'but the order total has changed. ' +
        'Use <strong>Adjust and Capture Payment</strong> in the sidebar to capture the updated amount.';

    // -------------------------------------------------------------------------
    // Insert banner just before the button row (once, lazily)
    // -------------------------------------------------------------------------
    function insertBanner() {
        if ( document.getElementById('acceptblue-items-warning') ) return;

        var anchor = document.querySelector('.wc-order-bulk-actions')
                  || document.querySelector('.wc-order-item-bulk-edit')
                  || document.querySelector('button.calc_totals')
                  || document.querySelector('button.recalculate');

        if ( ! anchor ) return;

        var target = ( anchor.tagName === 'BUTTON' )
            ? ( anchor.closest('.wc-order-bulk-actions, .wc-order-item-bulk-edit, tr') || anchor.parentNode )
            : anchor;

        target.parentNode.insertBefore( banner, target );
    }

    // -------------------------------------------------------------------------
    // Read the live order total from WC's DOM after AJAX updates it
    // -------------------------------------------------------------------------
    function getLiveTotal() {
        // Hidden input — WC keeps this in sync on both legacy and HPOS screens
        var input = document.getElementById('order_total')
                 || document.querySelector('input[name="order_total"]');
        if ( input ) {
            var v = parseFloat( input.value.replace( /[^0-9.\-]/g, '' ) );
            if ( ! isNaN(v) && v > 0 ) return v;
        }
        // HPOS data attribute fallback
        var dataEl = document.querySelector('[data-order_total]');
        if ( dataEl ) {
            var v2 = parseFloat( dataEl.dataset.order_total );
            if ( ! isNaN(v2) && v2 > 0 ) return v2;
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Compare totals and show/hide — ONLY if userTriggered
    // -------------------------------------------------------------------------
    function checkAndShow() {
        if ( ! userTriggered ) return;   // <-- hard gate: never fires on page load

        var warning = document.getElementById('acceptblue-items-warning');
        if ( ! warning ) return;

        var live = getLiveTotal();
        if ( live === null ) return;

        warning.style.display = ( Math.abs( live - authorizedAmt ) >= 0.01 ) ? 'block' : 'none';
    }

    // -------------------------------------------------------------------------
    // Trigger on button clicks in the order items area
    // -------------------------------------------------------------------------
    document.addEventListener('click', function( e ) {
        var t = e.target;
        if ( ! t ) return;

        var cl = t.classList;

        var isRecalc = cl.contains('calc_totals') || cl.contains('recalculate')
                    || ( t.dataset && t.dataset.action === 'calc_totals' );
        var isSave   = cl.contains('save_order') || cl.contains('save-order')
                    || t.id === 'save-action';
        var isAdd    = cl.contains('add_order_fee') || cl.contains('add_order_item')
                    || cl.contains('add_order_shipping') || cl.contains('add-line-item');

        if ( isRecalc || isSave || isAdd ) {
            userTriggered = true;
            // Wait for WC's AJAX to finish updating the DOM
            setTimeout( checkAndShow, 700 );
        }
    }, true );

    // -------------------------------------------------------------------------
    // Trigger on WC AJAX events — only when userTriggered is already true
    // -------------------------------------------------------------------------
    $(function() {
        // Insert the banner placeholder on load (hidden) so it is ready
        setTimeout( insertBanner, 500 );

        // init_totals fires on page load AND after recalc — gate with userTriggered
        $( document.body ).on( 'init_totals', function() {
            if ( userTriggered ) setTimeout( checkAndShow, 300 );
        });

        $( document ).on(
            'woocommerce_order_items_saved woocommerce_order_item_added woocommerce_tax_row_updated',
            function() {
                if ( userTriggered ) setTimeout( checkAndShow, 400 );
            }
        );

        // Catch HPOS AJAX save/recalculate responses
        $( document ).on( 'ajaxComplete', function( e, xhr, settings ) {
            if ( ! userTriggered ) return;
            var action = ( settings.data || '' ).toString();
            if ( action.indexOf('woocommerce_save_order_items') !== -1
              || action.indexOf('woocommerce_calc_line_taxes')  !== -1 ) {
                setTimeout( checkAndShow, 500 );
            }
        });
    });

})(jQuery);
JS;
}

/**
 * Admin notice: warn when the current order total differs from the authorized amount.
 * Shows on the single-order edit screen.
 */
add_action( 'admin_notices', 'acceptblue_v2_admin_notice_total_changed' );

function acceptblue_v2_admin_notice_total_changed() {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    // Support both legacy post editor and HPOS order edit screen
    $is_order_screen = ( $screen->id === 'shop_order' )
        || ( $screen->id === 'woocommerce_page_wc-orders' && ! empty( $_GET['id'] ) );

    if ( ! $is_order_screen ) return;

    // Suppress during Save / Recalculate — the totals are mid-update and
    // the notice would fire on every save even when nothing has changed.
    $post_action = sanitize_text_field( wp_unslash( $_POST['action'] ?? '' ) );
    $suppressed_actions = array(
        'editpost',                          // legacy CPT save
        'woocommerce_save_order_items',      // recalculate / save items AJAX
        'woocommerce_calc_line_taxes',       // recalculate taxes AJAX
    );
    if ( in_array( $post_action, $suppressed_actions, true ) ) return;

    $order_id = absint( $_GET['id'] ?? $_GET['post'] ?? 0 );
    if ( ! $order_id ) return;

    $order = wc_get_order( $order_id );
    if ( ! $order || $order->get_payment_method() !== 'acceptbluev2' ) return;

    // Never show when capture is already done
    if ( $order->get_meta( '_acceptblue_capture_done' ) ) return;

    // Never show when force_capture is on — payment was captured immediately at checkout,
    // there is no pending auth to adjust.
    $settings = get_option( 'woocommerce_acceptbluev2_settings', array() );
    if ( ! empty( $settings['force_capture'] ) && $settings['force_capture'] === 'yes' ) return;

    // Only show when we actually stored an authorized amount from the API response.
    // A missing or zero meta means this order was placed via a path that doesn't
    // support adjust-and-capture (e.g. hosted tokenization redirect), so stay silent.
    $authorized = (float) $order->get_meta( '_acceptblue_authorized_amount' );
    if ( $authorized <= 0 ) return;

    // Compare full order total (including surcharge) against the API-reported auth amount.
    $current = round( (float) $order->get_total(), 2 );
    if ( abs( $current - $authorized ) < 0.01 ) return; // no meaningful change

    $currency = $order->get_currency();
    $diff     = $current - $authorized;
    $sign     = $diff > 0 ? '+' : '';

    printf(
        '<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
        esc_html__( 'accept.blue — Order Total Changed', 'woocommerce' ),
        wp_kses(
            sprintf(
                /* translators: 1: authorized amount, 2: current total, 3: signed difference */
                __( 'The authorized amount was <strong>%1$s</strong> but the order total is now <strong>%2$s</strong> (%3$s). Use <strong>Adjust and Capture Payment</strong> in the sidebar to capture the updated amount now, or it will be captured automatically at the current total when the order status changes.', 'woocommerce' ),
                wc_price( $authorized, array( 'currency' => $currency ) ),
                wc_price( $current,    array( 'currency' => $currency ) ),
                $sign . wc_price( abs( $diff ), array( 'currency' => $currency ) )
            ),
            array( 'strong' => array() )
        )
    );
}

/**
 * Render the "Adjust and Capture Payment" meta box content.
 *
 * Called by the meta box registered in acceptblue_v2_register_adjust_capture_meta_box().
 * The $post_or_order_object argument is either a WP_Post (legacy) or a WC_Order (HPOS).
 *
 * @param WP_Post|WC_Order $post_or_order_object
 */
function acceptblue_v2_render_adjust_capture_meta_box( $post_or_order_object ) {

    // Resolve order from either a WP_Post (legacy CPT) or WC_Order (HPOS)
    if ( $post_or_order_object instanceof WC_Order ) {
        $order = $post_or_order_object;
    } elseif ( $post_or_order_object instanceof WP_Post ) {
        $order = wc_get_order( $post_or_order_object->ID );
    } else {
        $order = acceptblue_v2_get_current_admin_order();
    }

    if ( ! $order instanceof WC_Order ) return;

    // Only show for eligible orders
    if ( ! acceptblue_v2_order_is_adjustable( $order ) ) {
        echo '<p style="color:#666;font-size:12px;">' . esc_html__( 'No pending capture for this order.', 'woocommerce' ) . '</p>';
        return;
    }

    $authorized    = (float) $order->get_meta( '_acceptblue_authorized_amount' );
    $current       = round( (float) $order->get_total(), 2 );
    $total_changed = $authorized && abs( $current - $authorized ) >= 0.01;
    $currency      = $order->get_currency();

    $label = $total_changed
        ? __( 'Adjust and Capture Payment', 'woocommerce' )
        : __( 'Capture Payment', 'woocommerce' );

    $nonce = wp_create_nonce( 'acceptblue_adjust_capture_' . $order->get_id() );
    ?>
    <div style="padding:4px 0 8px;">

        <?php if ( $authorized ) : ?>
        <p style="margin:0 0 6px;font-size:12px;color:#555;">
            <?php printf(
                esc_html__( 'Authorized: %s', 'woocommerce' ),
                wp_kses_post( wc_price( $authorized, array( 'currency' => $currency ) ) )
            ); ?>
        </p>
        <p style="margin:0 0 8px;font-size:12px;color:#555;">
            <?php printf(
                esc_html__( 'Capture amount: %s', 'woocommerce' ),
                wp_kses_post( wc_price( $current, array( 'currency' => $currency ) ) )
            ); ?>
            <?php if ( $total_changed ) : ?>
                <span style="color:#d63638;font-weight:600;">(<?php esc_html_e( 'changed', 'woocommerce' ); ?>)</span>
            <?php endif; ?>
        </p>
        <?php endif; ?>

        <button type="button"
                id="acceptblue-adjust-capture-btn"
                class="button button-primary"
                data-order-id="<?php echo esc_attr( $order->get_id() ); ?>"
                data-nonce="<?php echo esc_attr( $nonce ); ?>"
                style="width:100%;background:#135e96;border-color:#135e96;">
            <?php echo esc_html( $label ); ?>
        </button>

        <div id="acceptblue-capture-msg" style="display:none;margin-top:6px;font-size:12px;padding:4px 6px;border-radius:3px;"></div>
    </div>

    <script type="text/javascript">
    (function() {
        var btn = document.getElementById('acceptblue-adjust-capture-btn');
        var msg = document.getElementById('acceptblue-capture-msg');
        if ( ! btn ) return;

        btn.addEventListener('click', function() {
            if ( ! confirm('<?php echo esc_js( __( 'Capture the current order total with accept.blue? This cannot be undone.', 'woocommerce' ) ); ?>') ) return;

            btn.disabled    = true;
            btn.textContent = '<?php echo esc_js( __( 'Processing…', 'woocommerce' ) ); ?>';
            msg.style.display = 'none';

            var formData = new FormData();
            formData.append('action',   'acceptblue_v2_ajax_adjust_capture');
            formData.append('order_id', btn.dataset.orderId);
            formData.append('nonce',    btn.dataset.nonce);

            fetch(ajaxurl, { method: 'POST', credentials: 'same-origin', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    if ( res.success ) {
                        msg.style.background = '#d1e7dd';
                        msg.style.color      = '#0a3622';
                        msg.textContent      = res.data.message || '<?php echo esc_js( __( 'Capture successful.', 'woocommerce' ) ); ?>';
                        msg.style.display    = 'block';
                        // Reload after short delay so order notes update
                        setTimeout(function() { location.reload(); }, 1200 );
                    } else {
                        msg.style.background = '#f8d7da';
                        msg.style.color      = '#58151c';
                        msg.textContent      = res.data.message || '<?php echo esc_js( __( 'Capture failed. Check order notes.', 'woocommerce' ) ); ?>';
                        msg.style.display    = 'block';
                        btn.disabled         = false;
                        btn.textContent      = '<?php echo esc_js( $label ); ?>';
                    }
                })
                .catch(function() {
                    msg.style.background = '#f8d7da';
                    msg.style.color      = '#58151c';
                    msg.textContent      = '<?php echo esc_js( __( 'Network error. Please reload and try again.', 'woocommerce' ) ); ?>';
                    msg.style.display    = 'block';
                    btn.disabled         = false;
                    btn.textContent      = '<?php echo esc_js( $label ); ?>';
                });
        });
    })();
    </script>
    <?php
}

/**
 * AJAX handler for the "Adjust and Capture" button.
 */
add_action( 'wp_ajax_acceptblue_v2_ajax_adjust_capture', 'acceptblue_v2_ajax_adjust_capture' );

function acceptblue_v2_ajax_adjust_capture() {
    $order_id = absint( $_POST['order_id'] ?? 0 );
    $nonce    = sanitize_text_field( $_POST['nonce'] ?? '' );

    if ( ! $order_id || ! wp_verify_nonce( $nonce, 'acceptblue_adjust_capture_' . $order_id ) ) {
        wp_send_json_error( array( 'message' => __( 'Security check failed.', 'woocommerce' ) ) );
    }

    if ( ! current_user_can( 'edit_shop_orders' ) ) {
        wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'woocommerce' ) ) );
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        wp_send_json_error( array( 'message' => __( 'Order not found.', 'woocommerce' ) ) );
    }

    $result = WC_Gateway_AcceptBlue_v2::adjust_and_capture( $order_id, $order );

    if ( $result ) {
        wp_send_json_success( array( 'message' => __( 'Payment captured successfully.', 'woocommerce' ) ) );
    } else {
        wp_send_json_error( array( 'message' => __( 'Capture failed. Please check the order notes for details.', 'woocommerce' ) ) );
    }
}

