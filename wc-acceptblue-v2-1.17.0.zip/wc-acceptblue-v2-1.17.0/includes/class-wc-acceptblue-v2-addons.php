<?php
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce accept.blue v2 Addons - Payment Gateway
 * 
 * @author RyanPlugins
 * @version since 1.1
 */

class WC_Gateway_AcceptBlue_v2_Addons extends WC_Gateway_AcceptBlue_v2 {
	
	function __construct(){
		 parent::__construct();

		 if ( class_exists( 'WC_Subscriptions_Order' ) ) {
			

	      add_action( 'woocommerce_scheduled_subscription_payment_' . $this->id, array( $this, 'scheduled_subscription_payment' ), 10, 2 );
	      add_action( 'woocommerce_subscription_failing_payment_method_updated_'.$this->id, array( $this, 'update_failing_payment_method' ), 10, 2 );

	      add_action( 'wcs_resubscribe_order_created', array( $this, 'delete_resubscribe_meta' ), 10 );

	      add_filter( 'woocommerce_subscription_payment_meta', array( $this, 'add_subscription_payment_meta' ), 10, 2 );
	      add_filter( 'woocommerce_subscription_validate_payment_meta', array( $this, 'validate_subscription_payment_meta' ), 10, 2 );
		
		}
	    
	}

  	//* AcceptBlue Payments process addon payment

	public function process_payment( $order_id ){
	
		global $woocommerce;

		$order = wc_get_order( $order_id );

        if($this->tokenization === true ){   
			
			$this->surcharge_fee_to_order($order, "");

			// Store a trial indicator meta so ht_place_order_charge can detect it
			// reliably without depending on WCS subscription-linking.
			if ( (float) $order->get_total() < 0.01 ) {
				$order->update_meta_data( '_acceptblue_ht_trial', '1' );
				$order->save();
			}
		
            $checkout_url_args 	= array( 'order-pay' => $order_id, 'key' => $order->get_order_key() );
            $checkout_url 		= add_query_arg( $checkout_url_args, wc_get_checkout_url() );

            if(  $order_id > 0 ){
                return array(
                    'result'    => 'success',
                    'redirect'  => esc_url_raw( $checkout_url )
                );
            } 

            else {
                wc_add_notice( 
                    __( sprintf( "Error when processing payment: '%s'", "Invalid Order ID!" ) , 'woocommerce' ), "error" );
                return false;

            }

        } else {


			// Detect order-pay context reliably during wc-ajax=checkout (page context is reset).
			// WooCommerce order-pay form sends all three signals; any one is sufficient.
			$is_pay_order_page = (
				( ! empty( $_POST['pay_for_order'] ) && $_POST['pay_for_order'] === 'true' ) ||
				( ! empty( $_POST['order_id'] ) && is_numeric( $_POST['order_id'] ) ) ||
				! empty( $_POST['woocommerce-pay-nonce'] )
			);

			// Block checkout saved token: read directly from POST to avoid $_REQUEST unreliability
			// in the Store API context. On order-pay page fall through to classic token reading.
			if ( $this->block_support_checkout && ! $is_pay_order_page && ! empty( $_POST['acceptbluev2-block-token-id'] ) ) {
				$token_id = sanitize_text_field( $_POST['acceptbluev2-block-token-id'] );
			} else {
				$token_id = ! empty( $_REQUEST['wc-acceptbluev2-payment-token'] ) ? sanitize_text_field( $_REQUEST['wc-acceptbluev2-payment-token'] ) : '';
			}

			if( empty($token_id)){
				// Allow classic card_verification on order-pay page even when block_support_checkout=true.
				if( $this->block_support_checkout === false || $is_pay_order_page ){
					if($this->card_verification($_POST) === false ) return;
				}
				
			}    

			// Remove surcharge from the order!
			$this->custom_remove_specific_fee_from_order( $order_id );
			
			$order  = wc_get_order( $order_id );		

			
			$woo_currency 					= $order->get_currency();

            if ( $woo_currency !== 'USD' ) {
                wc_add_notice( esc_html__( 'Invalid, Transaction amount should be in USD.', 'woocommerce' ), 'error' );
                return false;
            }

            
            $woo_get_total 					= $order->get_total();
            $avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
            $avs_zip  						= $order->get_billing_postcode();
            
            //* Amount Details            

            $amount_details[ "tax" ] 		= (double) "0";
            $amount_details[ "shipping" ] 	= (double) "0";
            $amount_details[ "discount" ] 	= (double) "0";

            //* Transaction details

            $transaction_details = array();
            $transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
            $transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
            $transaction_details[ "order_number" ] 	= $order->get_order_number();
            $transaction_details[ "invoice_number" ] = $order->get_order_number();
            $transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

            //* Billing Address Fields

            $billing_info = array();

            $billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
            $billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
            $billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
            $billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
            $billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
            $billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
            $billing_info[ "zip" ] 			= $order->get_billing_postcode();
            $billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
            $billing_info[ "phone" ] 		= $order->get_billing_phone();						
            
            //* Shipping Address Fields

            $shipping_info = array();

            $shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
            $shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
            $shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
            $shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
            $shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
            $shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
            $shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
            $shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
            $shipping_info[ "phone" ] 		= $order->get_billing_phone();         
           

            if($this->force_save_card_token === true ){

                $save_card = (bool) true;

            } else {

				// WooCommerce posts 'wc-{id}-new-payment-method' as the string 'true' (not '1').
				$save_card_classic = isset($_REQUEST['wc-acceptbluev2-new-payment-method']) && sanitize_text_field($_REQUEST['wc-acceptbluev2-new-payment-method']) === 'true';
				// Block checkout sends '1'/'0' via paymentMethodData.
				$save_card_block = isset($_POST['acceptbluev2-save-card']) && sanitize_text_field($_POST['acceptbluev2-save-card']) === '1';
				// Hosted tokenization iframe on classic checkout (render_hosted_tokenization_form).
				$save_card_ht    = isset($_POST['acceptbluev2-ht-save-card']) && sanitize_text_field($_POST['acceptbluev2-ht-save-card']) === '1';
				$save_card = (bool) (($save_card_classic || $save_card_block || $save_card_ht) && !is_numeric($token_id));

				// Force saved to token for subscription

				if(  ( $this->order_contains_subscription( $order_id ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) ){
    		
						$save_card = (bool) true;						
						
				}

            }
			

            if( is_numeric($token_id) && $token_id > 0 ){
                
                $token = $this->use_card_token($token_id);

                if( !empty($token) && is_array($token)){

                    $card           = wc_clean($token[ "token" ]);
                    $expiry_month   = wc_clean($token[ "expiry_month" ]);		
                    $expiry_year    = wc_clean($token[ "expiry_year" ]);	

                    $card_info = array(                        
                        'source' => $card,
                        'expiry_month' => (int) $expiry_month,
                        'expiry_year' => (int) $expiry_year
                    );
				
			    }

            } else {

				// On order-pay page with block_support_checkout=true, use classic card fields.
				// $is_pay_order_page was set above from $_POST['pay_for_order'].
				if( $this->block_support_checkout === true && ! $is_pay_order_page ){

					// ── Block checkout token source resolution ───────────────────────────────
					// Same logic as parent process_payment:
					// 3DS path  → $_POST['acceptbluev2-payment-token'] is a HostedTokenization nonce → "nonce-"
					// non-3DS   → $_POST['token'] is an integer token_id from save_card          → "tkn-"
					if ( $this->threeds === true ) {
						$nonce_value = isset( $_POST['acceptbluev2-payment-token'] )
							? sanitize_text_field( $_POST['acceptbluev2-payment-token'] )
							: '';
						$card_token = ! empty( $nonce_value ) ? 'nonce-' . $nonce_value : '';
					} else {
						$raw_token_id = isset( $_POST['token'] )
							? sanitize_text_field( $_POST['token'] )
							: '';
						if ( empty( $raw_token_id ) ) {
							$raw_token_id = isset( $_POST['acceptbluev2-payment-token'] )
								? sanitize_text_field( $_POST['acceptbluev2-payment-token'] )
								: '';
						}
						$card_token = ! empty( $raw_token_id ) ? 'tkn-' . $raw_token_id : '';
					}

					if ( empty( $card_token ) ) {
						wc_add_notice( __( 'Payment token missing. Please try again.', 'woocommerce' ), 'error' );
						self::log( 'Block checkout (addons): payment token missing from POST data.', 'error' );
						return false;
					}

					// Use real expiry from tokenize AJAX response; fall back to current month + next year
					$expiry_month = ! empty( $_POST['acceptbluev2-expiry-month'] )
						? (int) sanitize_text_field( $_POST['acceptbluev2-expiry-month'] )
						: (int) date('n');
					$expiry_year = ! empty( $_POST['acceptbluev2-expiry-year'] )
						? (int) sanitize_text_field( $_POST['acceptbluev2-expiry-year'] )
						: (int) date('Y') + 1;

					$card_info = array(
						'source' 		=> $card_token,
						'expiry_month' 	=> (int) $expiry_month,
						'expiry_year' 	=> (int) $expiry_year,
						//'cvv2'			=> (string) $cvv2
					);

					if($this->threeds === true ){

						$expiry_month = isset($_POST['acceptbluev2-payment-expiry_month']) ? sanitize_text_field($_POST['acceptbluev2-payment-expiry_month']) : "";
							$expiry_year = isset($_POST['acceptbluev2-payment-expiry_year']) ? sanitize_text_field($_POST['acceptbluev2-payment-expiry_year']) : "";

							$card_info = array(
								'source' 		=> $card_token,
								'expiry_month' 	=> (int) $expiry_month,
								'expiry_year' 	=> (int) $expiry_year,
								//'cvv2'			=> (string) $cvv2
							);


						if ( $this->frictionless === false ) {

							$raw_eci      = isset( $_POST['acceptbluev2-payment-eci'] )
											? wp_unslash( $_POST['acceptbluev2-payment-eci'] )
											: '';
							$raw_cavv     = isset( $_POST['acceptbluev2-payment-authenticationvalue'] )
											? wp_unslash( $_POST['acceptbluev2-payment-authenticationvalue'] )
											: '';
							$raw_trans_id = isset( $_POST['acceptbluev2-payment-dstransid'] )
											? wp_unslash( $_POST['acceptbluev2-payment-dstransid'] )
											: '';

							if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {

								$threeds_params = array(
									'3d_secure' => array(
										'eci'        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
										'cavv'       => (string) $raw_cavv,
										'ds_trans_id'=> (string) $raw_trans_id,
									),
								);

								$card_info = array_merge( $card_info, $threeds_params );

							} else {

								self::log(
									'Block 3DS (addons): missing 3d_secure fields — eci=' . var_export( $raw_eci, true )
									. ' cavv=' . ( empty( $raw_cavv ) ? 'EMPTY' : 'present' )
									. ' ds_trans_id=' . var_export( $raw_trans_id, true ),
									'error'
								);

								wc_add_notice( esc_html__( '3D Secure verification did not complete. Please try again.', 'woocommerce' ), 'error' );
								return array( 'result' => 'fail' );

							}

						}

						

					}

				} else {

					$card = wc_clean( $_POST['acceptbluev2-cardnumber'] );
					$expiry_month = wc_clean( $_POST['acceptbluev2-expiry_m'] );	
					$expiry_year = wc_clean( $_POST['acceptbluev2-expiry_y'] );
					$cvv2		 = 	wc_clean( $_POST['acceptbluev2-card_cvc'] );

					$card_info = array(
						'card' 			=> $card,
						'expiry_month' 	=> (int) $expiry_month,
						'expiry_year' 	=> (int) $expiry_year,
						'cvv2'			=> (string) $cvv2
					);

				}


            }


            // -----------------------------------------------------------------------
            // $0 TRIAL PERIOD HANDLING
            // When a subscription order has a $0 initial total (free trial period),
            // the accept.blue API cannot process a $0 charge. Instead we:
            //   1. Run a $0.01 auth (capture=false) to verify the card is valid and
            //      get a card_ref / token for future renewals. The API requires
            //      amount >= 0.01 — sending 0.00 returns a 400 Validation error.
            //   2. Immediately void the $0.01 auth so nothing settles.
            //   3. Save the token and complete the order normally.
            //   4. Level 3 data is skipped — no real items in a $0 trial order.
            // -----------------------------------------------------------------------
            $is_subscription_order = (
                $this->order_contains_subscription( $order->get_id() )
                || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) )
            );

            if ( $is_subscription_order && (float) $woo_get_total < 0.01 ) {

                $zero_auth_params = array(
                    'amount'              => 0.01, // API minimum; auth is voided immediately after
                    'billing_info'        => $billing_info,
                    'shipping_info'       => $shipping_info,
                    'avs_zip'             => $avs_zip,
                    'avs_address'         => $avs_address,
                    'transaction_details' => $transaction_details,
                    'amount_details'      => array( 'tax' => 0.0, 'shipping' => 0.0, 'discount' => 0.0 ),
                    'capture'             => false,
                    'save_card'           => true,
                );
                $zero_auth_params = array_merge( $zero_auth_params, $card_info );

                $zero_result = parent::request_api( $zero_auth_params, 'transactions/charge', 'POST' );

                if (
                    isset( $zero_result['response_code'], $zero_result['response_message'], $zero_result['response_body'] ) &&
                    (int) $zero_result['response_code'] === 200 &&
                    $zero_result['response_message'] === 'OK'
                ) {
                    $zero_data = wp_parse_args( (array) $zero_result['response_body'], array() );

                    if ( ! empty( $zero_data['status'] ) && $zero_data['status'] === 'Approved' ) {

                        $ref_num  = sanitize_text_field( $zero_data['reference_number'] ?? '' );
                        $card_ref = sanitize_text_field( $zero_data['card_ref'] ?? $zero_data['cardRef'] ?? '' );

                        // Immediately void the $0 auth so nothing settles.
                        if ( $ref_num ) {
                            parent::request_api(
                                array( 'reference_number' => (int) $ref_num ),
                                'transactions/reversal',
                                'POST'
                            );
                        }

                        // Save the card token for future scheduled renewals.
                        if ( ! empty( $card_ref ) ) {
                            $full_token    = 'tkn-' . $card_ref;
                            $expiry_month_t = absint( $card_info['expiry_month'] ?? 0 );
                            $expiry_year_t  = absint( $card_info['expiry_year']  ?? 0 );
                            $api_card_type  = sanitize_text_field( $zero_data['card_type'] ?? $zero_data['cardType'] ?? '' );
                            $api_last4      = sanitize_text_field( $zero_data['last_4']    ?? $zero_data['last4']    ?? '' );

                            $order->update_meta_data( '_' . $this->id . '_customer_token', $full_token );
                            $order->save();

                            if ( $expiry_year_t >= 2000 && ! empty( $api_last4 ) ) {
                                $this->save_token( array(
                                    'token'            => $full_token,
                                    'card_type'        => $api_card_type,
                                    'set_last4'        => $api_last4,
                                    'set_expiry_month' => $expiry_month_t,
                                    'set_expiry_year'  => $expiry_year_t,
                                ) );
                            }

                            // Activate the subscription so future renewals are scheduled.
                            $this->process_subscription( $order, $full_token );
                        }

                        $order->payment_complete();
                        $order->add_order_note( sprintf(
                            __( '%s Trial period — card verified via $0.01 auth (Ref: %s, Auth voided). Future renewals will be charged normally.', 'woocommerce' ),
                            $this->method_title,
                            $ref_num ?: 'N/A'
                        ) );

                        WC()->cart->empty_cart();
                        WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );

                        return array(
                            'result'   => 'success',
                            'redirect' => $this->get_return_url( $order ),
                        );

                    } else {
                        $err = sanitize_text_field( $zero_data['error_message'] ?? $zero_data['status'] ?? 'Card verification failed.' );
                        wc_add_notice( sprintf( __( 'Payment failed: %s', 'woocommerce' ), $err ), 'error' );
                        $order->update_status( 'failed' );
                        $order->add_order_note( sprintf( '%s Trial: card verification failed — %s', $this->method_title, $err ) );
                        return false;
                    }

                } else {
                    wc_add_notice( __( 'Payment failed: unable to verify card. Please try again.', 'woocommerce' ), 'error' );
                    $order->update_status( 'failed' );
                    $order->add_order_note( sprintf( '%s Trial: API error during card verification.', $this->method_title ) );
                    return false;
                }
            }
            // -----------------------------------------------------------------------
            // END $0 TRIAL HANDLING — normal (non-zero) charge continues below
            // -----------------------------------------------------------------------

            $params = array(
                "amount" 		=> (double) $woo_get_total,                
                "billing_info" 	=> $billing_info,
                "shipping_info" => $shipping_info,						
                "avs_zip" 		=> $avs_zip,
                "avs_address" 	=> $avs_address,
                "transaction_details" => $transaction_details,
                "amount_details" => $amount_details,                
                "capture"        => (bool) $this->force_capture,
                "save_card"      => (bool) $save_card
            ); 
            		

            $params = array_merge($params, $card_info);

			$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );
			$params = array_merge($params, $level3_line_items);

	    // Change payment method for order pay page


		$change_payment_method = !empty($_REQUEST['change_payment_method']) ? $_REQUEST['change_payment_method'] : '';
	    $pay_for_order = ! empty( $_REQUEST['pay_for_order'] ) && $_REQUEST['pay_for_order'] === 'true';
		$new_payment_token = !empty($_REQUEST['wc-acceptbluev2-payment-token']) ? $_REQUEST['wc-acceptbluev2-payment-token'] : '';
		$update_all_subscription = !empty($_REQUEST['update_all_subscriptions_payment_method']) ? $_REQUEST['update_all_subscriptions_payment_method'] : '';

		
		// validate the card of payment token not allowed!
		if( !empty($change_payment_method) && $pay_for_order === true && empty($params['card']) && is_numeric($new_payment_token) ){
			wc_add_notice( esc_html__( "Invalid, Payment method not allowed.", "woocommerce" ) );
			return;

		}		

		if( !empty($change_payment_method) && $pay_for_order === true && !empty($params['card']) ){			
			

			if( !is_numeric($new_payment_token)){

				$data = array(
					'change_payment_method' => $change_payment_method,
					'pay_for_order' => $pay_for_order,
					'new_payment_token' => $new_payment_token,
					'update_all_subscription' => $update_all_subscription,
					'save_card' => $save_card
				);
				
	
				$card_token = $this->customer_change_payment_method_new( $data );	
	
				//update_post_meta( $order->get_id(), '_'.$this->id.'_customer_token', $card_token );
				$order->update_meta_data( '_'.$this->id.'_customer_token', $card_token );
				$order->save();
	
					$redirect_url = $this->get_return_url( $order );
					$pay_for_order = ! empty($_REQUEST[ 'pay_for_order' ]) ? $_REQUEST[ 'pay_for_order' ] : '';
	
						if( $pay_for_order == 'true' ){
								ob_start();
								?>
								<script type="text/javascript">
									window.location.replace("<?php echo esc_url($redirect_url); ?>");	
								</script>
								<?php
								exit;
	
						}

											

			} else {

				//wc_add_notice( esc_html__( "Invalid, Existing Saved card not allowed.", "woocommerce" ) );                

			} 	

	    } 

		    

		//Surcharge add into order details
		$this->surcharge_fee_to_order($order, '' );

	    //* Fire payment
		$result = parent::request_api( $params, 'transactions/charge', 'POST');		
	
		if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){

			$defaults = array();
			$data 		= wp_parse_args( (array) $result['response_body'], $defaults );					

			if($data[ 'status' ] == 'Approved' ){

					//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
                    //$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );					

                    if( $this->default_status == 'default' ){
                        // Mark as complete or processing based on virtual order or not
						$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );						
                    } else {
						$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
                        $order->update_status( $this->default_status );
                    }
                    
				

				$card_token = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );							
			
				if(  ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) && empty($card_token) ){
					wc_add_notice( 'Invalid accept.blue Payment Token, Subscriptions is not Activated' , 'woocommerce');
				}
				
				 // Processing subscription
			    if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) ) {
			    	// Set the subscriptions — card_ref from API is bare; prefix once.
					// Guard: skip if card_ref was empty (would produce "tkn-" sentinel).
					if ( ! empty( $card_token ) ) {
						$card_token = "tkn-" . $card_token;
						$this->process_subscription( $order, $card_token );
					}
			    } 

				$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );

				// Store the API's auth_amount as the authorized amount for Adjust & Capture.
				// auth_amount is the ground truth — inclusive of surcharge and all fees.
				if ( ! (bool) $this->force_capture ) {
					$auth_amount = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) $woo_get_total;
					$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount );
				}

				$order->save();

				$order->add_order_note(
					esc_html__( sprintf(
						"%s Payment Completed with Transaction Id of '%s'",
						$this->method_title,
						sanitize_text_field($data[ 'reference_number' ])
					), 'woocommerce' )
				);

		       

		        $card_token = array();

		         //* Save token
				 if( $save_card === true && !is_numeric($token_id) ){

					// accept.blue does not return card_ref when charging an already-saved tkn- source.
					// Fall back to extracting the ref from the source that was sent.
					$card_ref = sanitize_text_field( $data[ 'card_ref' ] ?? '' );
					if ( empty( $card_ref ) && ! empty( $card_info['source'] ) ) {
						if ( strpos( $card_info['source'], 'tkn-' ) === 0 ) {
							$card_ref = substr( $card_info['source'], 4 );
						}
					}

					if ( ! empty( $card_ref ) ) {
						// API may use camelCase (cardType/last4) or snake_case (card_type/last_4)
						$api_card_type = $data['card_type'] ?? $data['cardType'] ?? '';
						$api_last4     = $data['last_4']    ?? $data['last4']    ?? '';
						if ( empty( $api_last4 ) ) {
							$api_last4 = sanitize_text_field( $_POST['acceptbluev2-last4'] ?? '' );
						}

						$card_token['token']            = 'tkn-' . $card_ref;
						$card_token['card_type']        = sanitize_text_field( $api_card_type );
						$card_token['set_last4']        = sanitize_text_field( $api_last4 );
						$card_token['set_expiry_month'] = absint( $card_info['expiry_month'] ?? 0 );
						$card_token['set_expiry_year']  = absint( $card_info['expiry_year']  ?? 0 );

						if (
							$card_token['set_expiry_year'] >= 2000 &&
							! empty( $card_token['set_last4'] )
						) {
							$this->save_token( $card_token );
						} else {
							self::log( 'save_token skipped (addons): missing year or last4. year='
								. $card_token['set_expiry_year'] . ' last4=' . $card_token['set_last4'], 'warning' );
						}
					}

				}

		        WC()->cart->empty_cart();
				WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
				$redirect_url = $this->get_return_url( $order );

				$pay_for_order = ! empty($_REQUEST[ 'pay_for_order' ]) ? $_REQUEST[ 'pay_for_order' ] : '';

				if( $pay_for_order == 'true' ){
						ob_start();
						?>
						<script type="text/javascript">
							window.location.replace("<?php echo esc_url($redirect_url); ?>");	
						</script>
						<?php
						exit;

				} else {

				return array(
						'result' => 'success',
						'redirect' => $redirect_url
					);

				}

			} else {

				// Use error_message from response body, not status (which is just "Declined")
				$e = ! empty( $data['error_message'] )
					? esc_html( $data['error_message'] )
					: esc_html( $data['status'] ?? 'Payment declined.' );

				$order->update_status( 'failed' );
				$order->add_order_note(
					esc_html( sprintf( "%s Payment Failed: '%s'", $this->method_title, $e ) )
				);

				wc_add_notice( esc_html( sprintf( "Payment Failed: '%s'", $e ) ), 'error' );

				if ( $this->block_support_checkout === true ) {
					return array(
						'result'  => 'failure',
						'message' => esc_html( sprintf( "Payment Failed: '%s'", $e ) ),
					);
				}

				return false;

			} 


		} else {			

			return parent::handle_payment_failure( $order, $result );			

		}

		}        
		

	}

	
	//* process subscription

	public function process_subscription( $order,  $customer_token = ''   ){

		  WC_Subscriptions_Manager::activate_subscriptions_for_order( $order );

		  if ( $customer_token )
		    $this->save_subscription_meta( $order->get_id(), $customer_token );

		    $redirect = $this->get_return_url($order);

		    return array(
		        'result' => 'success',
		        'redirect' => $redirect
		    );
	}
	
	//* accept.blue v2 scheduled subscription payment

	public function scheduled_subscription_payment( $amount_to_charge, $renewal_order ){
		$result = $this->process_subscription_payment( $renewal_order, $amount_to_charge );
		if ( is_wp_error( $result ) ) {
		  $renewal_order->update_status(
		    'failed',
		    sprintf( esc_html__( 'accept.blue Transaction Failed (%s)', 'woocommerce' ),
		    $result->get_error_message() )
		  );
		}
	}

	
	//* accept.blue v2 Process Subscription

	public function process_subscription_payment( $order = '', $amount = 0 ){
		global $woocommerce;

		if ( 0 == $amount ) {
		  // Payment complete
		  $order->payment_complete();
		  return true;
		}

		// Remove surcharge from the order!
		$this->custom_remove_specific_fee_from_order( $order->get_id() );
		$order->calculate_totals();
		$order->save();

		$ip_address = ! empty( $_SERVER['HTTP_X_FORWARD_FOR'] ) ? $_SERVER['HTTP_X_FORWARD_FOR'] : $_SERVER['REMOTE_ADDR'];
		
		//$customer_token = get_post_meta( $order->get_id(), '_' . $this->id . '_customer_token', true );
		//$customer_token = $order->get_meta( '_' . $this->id . '_customer_token');


		// Try order based  token
		$customer_token = $order->get_meta( '_' . $this->id . '_customer_token' );
		
		// 2. Fallback to customer's default saved card
		if ( empty( $customer_token ) ) {
			$customer_id = $order->get_customer_id();
			$tokens = WC_Payment_Tokens::get_customer_tokens( $customer_id, $this->id );
			if ( ! empty( $tokens ) ) {
				$token = reset( $tokens );
				$customer_token = $token->get_token();
			}

			self::log( 'accept.blue v2 save card fallback token used: ' . WC_AcceptBlue_Log_Masker::mask_token( $customer_token ) );
		}

		if ( ! $customer_token )
		  return new WP_Error( 'error', __( 'Customer token is missing.', 'woocommerce' ) );

		//$currency = get_post_meta( $order->get_id(),'_order_currency',true);
		$currency = $order->get_meta('_order_currency');
		self::log( 'currency: ' . $currency );

		if (!$currency || empty($currency)) $currency = get_woocommerce_currency();

			$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
			$avs_zip  						= $order->get_billing_postcode();
			
			//* Amount Details            

			$amount_details[ "tax" ] 		= (double) "0";
			$amount_details[ "shipping" ] 	= (double) "0";
			$amount_details[ "discount" ] 	= (double) "0";

			//* Transaction details

			$transaction_details = array();
			$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
			$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
			$transaction_details[ "order_number" ] 	= $order->get_order_number();
			$transaction_details[ "invoice_number" ] = $order->get_order_number();
			$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

			//* Billing Address Fields

			$billing_info = array();

			$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
			$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
			$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
			$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
			$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
			$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
			$billing_info[ "zip" ] 			= $order->get_billing_postcode();
			$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
			$billing_info[ "phone" ] 		= $order->get_billing_phone();						
			
			//* Shipping Address Fields

			$shipping_info = array();

			$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
			$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
			$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
			$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
			$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
			$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
			$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
			$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
			$shipping_info[ "phone" ] 		= $order->get_billing_phone();

			// //Subscription payment here 

			$params = array();

			$card           = wc_clean($customer_token);
			$expiry_month = (new DateTime())->modify('+1 month')->format('m');		
			$expiry_year =  (new DateTime())->modify('+1 year')->format('Y');	

			$card_info = array(                        
				'source' => $card,
				'expiry_month' => (int) $expiry_month,
				'expiry_year' => (int) $expiry_year
			);

			// ── MIT: Merchant-Initiated Transaction indicators ───────────────────────────
			// Retrieve the reference_number saved from the initial customer-present charge
			// so Accept Blue can link this renewal back to the original CIT.
			$initial_ref = (string) $order->get_meta( '_' . $this->id . '_refnum' );

			// If not on the renewal order, walk up to the parent subscription order.
			if ( empty( $initial_ref ) && function_exists( 'wcs_get_subscriptions_for_renewal_order' ) ) {
				$subscriptions = wcs_get_subscriptions_for_renewal_order( $order );
				foreach ( $subscriptions as $subscription ) {
					$parent_order = $subscription->get_parent();
					if ( $parent_order ) {
						$initial_ref = (string) $parent_order->get_meta( '_' . $this->id . '_refnum' );
						if ( ! empty( $initial_ref ) ) {
							break;
						}
					}
				}
			}

			$mit_params = array(
				'initiated_by'       => 'merchant',
				'stored_credential'  => array(
					'sequence'               => 'subsequent',
					'initiator'              => 'merchant',
					'is_scheduled'           => true,
				),
			);

			// Include the original transaction ID when available — strongly recommended
			// by Visa/Mastercard stored-credential framework so the issuer can trace
			// the chain back to the original customer-authorised (CIT) transaction.
			if ( ! empty( $initial_ref ) ) {
				$mit_params['stored_credential']['initial_transaction_id'] = (int) $initial_ref;
			}
			// ── end MIT block ────────────────────────────────────────────────────────────

			$params = array(
                "amount" 		=> (double) $order->get_total(),                
                "billing_info" 	=> $billing_info,
                "shipping_info" => $shipping_info,						
                "avs_zip" 		=> $avs_zip,
                "avs_address" 	=> $avs_address,
                "transaction_details" => $transaction_details,
                "amount_details" => $amount_details,                
                "capture"        => (bool) $this->force_capture,
                "save_card"      => (bool) false
            ); 

			$params = array_merge($params, $card_info);
			$params = array_merge($params, $mit_params); // MIT indicators

			$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

			$params = array_merge($params, $level3_line_items);

			//Surcharge add into order details
			$this->surcharge_fee_to_order($order, '' );

			self::log( 'accept.blue v2 MIT renewal — initiated_by=merchant, sequence=subsequent, initial_ref=' . ( $initial_ref ?: '(not found)' ) );

			$result = parent::request_api($params, 'transactions/charge', 'POST');

			if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){

				$defaults  = array();
				$data 		= wp_parse_args( (array) $result['response_body'], $defaults );					

				if($data[ 'status' ] == 'Approved'){

					//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
					//$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );

					//$order_status = parent::virtual_order_payment_complete_order_status( $order->get_id() );

					if( $this->default_status == 'default' ){
						// Mark as complete or processing based on virtual order or not
						$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
                        
                    } else {
						$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
                        $order->update_status( $this->default_status );
                    }

					$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );
					$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );					
					$order->save();

					$order->add_order_note(sprintf(esc_html__('accept.blue subscription payment completed (Reference Number: %s)','woocommerce'),sanitize_text_field($data[ 'reference_number' ])  ));

					return true;

				} else {

					$order->update_status( 'failed' );
					$order->add_order_note(
			            esc_html__( sprintf(
			                "%s Payment Failed with message: '%s'",
			                $this->method_title,
			                sanitize_text_field($data['status']) 
			            ), 'woocommerce' )
			        );

			        return new WP_Error( 'error', sprintf(esc_html__('accept.blue error: %s','woocommerce'), $data['status'] ) );
				} 

			} else {

				$order->update_status( 'failed' );
				$body      = $result['response_body'] ?? null;
				$err_code  = is_object( $body ) ? ( $body->error_code ?? '' ) : '';
				$err_msg   = is_object( $body ) ? ( $body->error ?? 'Gateway error' ) : 'Gateway error';
				return new WP_Error( 'error', sprintf( esc_html__( 'accept.blue error: %s', 'woocommerce' ), esc_html( $err_code . ( $err_code ? ' - ' : '' ) . $err_msg ) ) );
			}
		
	}

	
	//* add customer to order     

	public function add_customer_to_order( $order, $customer_token = false ){
		if ( $customer_token ) {
		  $this->save_subscription_meta( $order->get_id(), $customer_token );
		  return $result[ 'code' ] == true;
		} else {
		  return $result[ 'code' ] == false;
		}
	}

	
	//* save subscription meta 

	protected function save_subscription_meta( $order_id, $customer_token ){
		$customer_token = wc_clean( $customer_token );

		//update_post_meta( $order_id, '_' . $this->id . '_customer_token', $customer_token );
		$order = wc_get_order( $order_id );
		$order->update_meta_data( '_' . $this->id . '_customer_token', $customer_token );
		$order->save();

		foreach( wcs_get_subscriptions_for_order( $order_id ) as $subscription ) {
		  //update_post_meta( $subscription->id, '_' . $this->id . '_customer_token', $customer_token );
		  $order = wc_get_order( $subscription->get_id() );
		  $order->update_meta_data( '_' . $this->id . '_customer_token', $customer_token );
		  $order->save();
		}
	}

	
	//* add subscription payment meta

	public function add_subscription_payment_meta( $payment_meta, $subscription ){

		//$order = wc_get_order( $subscription->id );
		$order = wcs_get_subscription( $subscription->get_id() );

		$payment_meta[ $this->id ] = array(
		  'post_meta' => array(
		    '_' . $this->id . '_customer_token' => array(
		      //'value' => get_post_meta( $subscription->id, '_'.$this->id.'_customer_token', true ),
			  'value' => $order->get_meta( '_'.$this->id.'_customer_token' ),
			  
		      'label' => 'accept.blue Customer Token',
		    ),
		  ),
		);
		return $payment_meta;
	}

	
	//* validate subscription payment meta

	public function validate_subscription_payment_meta( $payment_method_id, $payment_meta ) {
		if ( $this->id === $payment_method_id ) {
		  if ( ! isset( $payment_meta['post_meta']['_'.$this->id.'_customer_token']['value'] ) || empty( $payment_meta['post_meta']['_'.$this->id.'_customer_token']['value'] ) ) {
		    throw new Exception( 'A "_'.$this->id.'_customer_token" value is required.' );
		  }
		}
	}

	
	//* delete subscriber meta

	public function delete_resubscribe_meta( $resubscribe_order ){
		$order = wc_get_order( $resubscribe_order->get_id() );
		if ( $order ) {
			$order->delete_meta_data( '_'.$this->id.'_customer_token' );
			$order->save();
		}
	}
	
	//* update failing payment method

	public function update_failing_payment_method( $subscription, $new_renewal_order ){
		// update_post_meta(
		//     $subscription->id, '_'.$this->id.'_customer_token',
		//     get_post_meta( $new_renewal_order->id,
		//     '_'.$this->id.'_customer_token', true )
		// );

		$order = wc_get_order( $subscription->get_id() );
		$renewal_order = wc_get_order( $new_renewal_order->get_id() );
		$order->update_meta_data( '_'.$this->id.'_customer_token', $renewal_order->get_meta(  '_'.$this->id.'_customer_token' ) );
		$order->save();
	}

	
	//* Check if order contains subscriptions.
	
	protected function order_contains_subscription( $order_id ) {
		return function_exists( 'wcs_order_contains_subscription' ) && ( wcs_order_contains_subscription( $order_id ) || wcs_order_contains_renewal( $order_id ) );
	}
	

	public function unset_gateway_by_product( $available_gateways ){

	 	foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
	        $prod_variable = $prod_simple = $prod_subscription = false;
	        // Get the WC_Product object
	        $product = wc_get_product($cart_item['product_id']);
	        if($product->is_type('subscription')) $prod_subscription = true;
	    }

	    if( $prod_subscription === false ) {
	    	unset( $available_gateways[ $this->id . '_subscriptions'] ); 
	    }

	    return $available_gateways;
	 } 

	 public function customer_change_payment_method_new( $data ) {

		if( is_numeric($data['new_payment_token'])) return;

		$order = wc_get_order( $data['change_payment_method'] );
		$save_card = $data['save_card'];


        $params[ "card" ] 	 	        = sanitize_text_field($_REQUEST[ 'acceptbluev2-cardnumber' ]); //'4761530001111118';
        $params[ "expiry_month" ] 		= (int) wc_clean($_REQUEST[ 'acceptbluev2-expiry_m' ]);
        $params[ "expiry_year" ] 		= (int) wc_clean($_REQUEST[ 'acceptbluev2-expiry_y' ]);
    
        $result = $this->request_api($params, 'saved-cards', 'POST');	

			if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){

				$defaults  = array();
				$data 		= wp_parse_args( (array) $result['response_body'], $defaults );		

                if( !empty($data[ 'cardRef' ]) ){

					$card_token = array();

					//* Save token
					//$card_token[ 'token' ] 				= sanitize_text_field($data[ 'cardRef' ]);
                    $card_token[ 'token' ] 				= "tkn-" . sanitize_text_field($data[ 'cardRef' ]);
					$card_token[ 'card_type' ] 			= sanitize_text_field($this->get_card_type($params[ 'card' ]));
					$card_token[ 'set_last4' ]			= substr(sanitize_text_field($params[ 'card' ]), -4 );
					$card_token[ 'set_expiry_month' ]	= absint($params['expiry_month']);
					$card_token[ 'set_expiry_year' ]	= absint($params[ 'expiry_year' ]);					

					//* Fire save card token
					parent::save_token($card_token);
				
				}					

				return $card_token[ 'token' ];	

			} else {

				wc_add_notice( esc_html__( 'There was a problem adding this card.', 'woocommerce' ), 'error' );
				return;

			}
	    
	}

	public function ht_place_order_charge_addons(){
        
        if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {

            $order_key = !empty($_POST['order_key']) ? wc_clean($_POST['order_key']) : '';

			if (!empty($order_key)) {
				$order_id = wc_get_order_id_by_order_key($order_key);
			} 

			if (empty($order_id)) {
				wp_send_json_error( esc_html__( 'No order found.', 'woocommerce' ) );
			}

            $saved_token_id     = ! empty( $_POST['saved_token_id'] ) ? absint( $_POST['saved_token_id'] ) : 0;
            $hosted_token_nonce = ! empty( $_POST['hosted_token_nonce'] ) ? wc_clean( $_POST['hosted_token_nonce'] ) : '';

            if ( empty( $hosted_token_nonce ) && empty( $saved_token_id ) ) {
				wp_send_json_error( esc_html__( 'No payment token found.', 'woocommerce' ) );
			}

			// ── Saved token fast path ─────────────────────────────────────────
			if ( $saved_token_id > 0 && empty( $hosted_token_nonce ) ) {
				$wc_token = WC_Payment_Tokens::get( $saved_token_id );

				if (
					! $wc_token ||
					$wc_token->get_gateway_id() !== $this->id ||
					( is_user_logged_in() && $wc_token->get_user_id() !== get_current_user_id() )
				) {
					wp_send_json_error( esc_html__( 'Invalid payment token.', 'woocommerce' ) );
				}

				$raw_token = $wc_token->get_token();
				if ( empty( $raw_token ) || $raw_token === 'tkn-' ) {
					wp_send_json_error( esc_html__( 'Saved card reference is invalid.', 'woocommerce' ) );
				}

				$name_on_card = ! empty( $_POST['card_name'] ) ? wc_clean( $_POST['card_name'] ) : '';
				if ( $this->name_on_card_required && empty( $name_on_card ) && $this->name_on_card ) {
					wp_send_json_error( esc_html__( 'Name on card is required.', 'woocommerce' ) );
				}

				$this->custom_remove_specific_fee_from_order( $order_id );
				$order = wc_get_order( $order_id );
				if ( ! $order ) wp_send_json_error( esc_html__( 'Invalid order.', 'woocommerce' ) );
				if ( ! empty( $order->get_transaction_id() ) ) wp_send_json_error( esc_html__( 'The order has been processed.', 'woocommerce' ) );
				if ( $order->get_currency() !== 'USD' ) wp_send_json_error( esc_html__( 'Transaction amount should be in USD.', 'woocommerce' ) );

				$billing_info  = array( 'first_name' => $order->get_billing_first_name(), 'last_name' => $order->get_billing_last_name(), 'street' => $order->get_billing_address_1(), 'street2' => $order->get_billing_address_2(), 'city' => $order->get_billing_city(), 'state' => $order->get_billing_state(), 'zip' => $order->get_billing_postcode(), 'country' => $order->get_billing_country(), 'phone' => $order->get_billing_phone() );
				$shipping_info = array( 'first_name' => $order->get_shipping_first_name(), 'last_name' => $order->get_shipping_last_name(), 'street' => $order->get_shipping_address_1(), 'street2' => $order->get_shipping_address_2(), 'city' => $order->get_shipping_city(), 'state' => $order->get_shipping_state(), 'zip' => $order->get_shipping_postcode(), 'country' => $order->get_shipping_country(), 'phone' => $order->get_billing_phone() );
				$transaction_details = array( 'description' => sprintf( '%s - ORDER No. #%s', ucwords( get_bloginfo('name') ), $order->get_order_number() ), 'client_ip' => $this->get_client_ip( $order ), 'order_number' => $order->get_order_number(), 'invoice_number' => $order->get_order_number(), 'terminal' => $order->get_payment_method_title() );

				$this->surcharge_fee_to_order( $order, '' );

				// Trial detection: use the _acceptblue_ht_trial meta flag stored at process_payment time.
				// This is 100% reliable — no WCS function dependency needed.
				$_ht_sc_is_trial = ( $order->get_meta( '_acceptblue_ht_trial' ) === '1' );
				$_ht_sc_amount   = $_ht_sc_is_trial ? 0.01 : (float) $order->get_total();

				$params = array(
					'amount'              => $_ht_sc_amount,
					'source'              => $raw_token,
					'expiry_month'        => (int) $wc_token->get_expiry_month(),
					'expiry_year'         => (int) $wc_token->get_expiry_year(),
					'billing_info'        => $billing_info,
					'shipping_info'       => $shipping_info,
					'avs_zip'             => $order->get_billing_postcode(),
					'avs_address'         => trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() ),
					'transaction_details' => $transaction_details,
					'amount_details'      => array( 'tax' => 0.0, 'shipping' => 0.0, 'discount' => 0.0 ),
					'capture'             => $_ht_sc_is_trial ? false : (bool) $this->force_capture,
					'save_card'           => true,
					'name'                => $name_on_card,
				);

				$level3 = (array) parent::level3_data_line_items( $order->get_id() );
				$params = array_merge( $params, $level3 );

				$result = parent::request_api( $params, 'transactions/charge', 'POST' );

				if ( $result['response_code'] == 200 && $result['response_message'] === 'OK' && ! empty( $result['response_body'] ) ) {
					$defaults = array();
					$data     = wp_parse_args( (array) $result['response_body'], $defaults );

					if ( $data['status'] === 'Approved' ) {

						// Trial: void the $0.01 auth immediately, save token for renewals
						if ( $_ht_sc_is_trial ) {
							$ref_num      = sanitize_text_field( $data['reference_number'] ?? '' );
							$card_ref_trial = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );
							if ( $ref_num ) {
								parent::request_api(
									array( 'reference_number' => (int) $ref_num ),
									'transactions/reversal',
									'POST'
								);
							}
							if ( ! empty( $card_ref_trial ) ) {
								$this->process_subscription( $order, 'tkn-' . $card_ref_trial );
							}
							$order->payment_complete( $ref_num );
							$order->update_meta_data( '_' . $this->id . '_refnum', $ref_num );
							$order->add_order_note( sprintf(
								__( '%s Trial — card verified via $0.01 auth (Ref: %s, auth voided). Future renewals charged normally.', 'woocommerce' ),
								$this->method_title, $ref_num
							) );
							$order->save();
							WC()->cart->empty_cart();
							WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
							wp_send_json_success( $order->get_checkout_order_received_url() );
							wp_die();
						}

						if ( $this->default_status === 'default' ) {
							$order->payment_complete( sanitize_text_field( $data['reference_number'] ) );
						} else {
							$order->set_transaction_id( sanitize_text_field( $data['reference_number'] ) );
							$order->update_status( $this->default_status );
						}
						$card_token_ref = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );
						if ( ! empty( $card_token_ref ) && ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order->get_id() ) ) ) ) {
							$this->process_subscription( $order, 'tkn-' . $card_token_ref );
						}
						$order->update_meta_data( '_' . $this->id . '_refnum', sanitize_text_field( $data['reference_number'] ) );

						// Store authorized amount for Adjust & Capture total-change detection.
						if ( ! (bool) $this->force_capture ) {
							$auth_amount_addons_sc = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : 0;
							if ( $auth_amount_addons_sc > 0 ) {
								$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_addons_sc );
							}
						}

						$order->add_order_note( sprintf( "%s Payment Completed (saved card) — Txn ID '%s'", $this->method_title, sanitize_text_field( $data['reference_number'] ) ) );
						$order->save();
						WC()->cart->empty_cart();
						WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
						wp_send_json_success( $order->get_checkout_order_received_url() );
					} else {
						$err = ! empty( $data['error_message'] ) ? $data['error_message'] : ( $data['status'] ?? 'Declined' );
						$order->update_status( 'failed' );
						$order->add_order_note( sprintf( "%s Payment Failed (saved card): '%s'", $this->method_title, esc_html( $err ) ) );
						$order->save();
						wp_send_json_error( esc_html( $err ) );
					}
				} else {
					$msg = ! empty( $result['response_message'] ) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'ht_place_order_charge_addons (saved token) API error: ' . $msg, 'error' );
					wp_send_json_error( esc_html( wc_clean( $msg ) ) );
				}
				wp_die();
			} // end saved token path

            $expiry_month = !empty($_POST[ 'expiry_month' ]) ? wc_clean($_POST[ 'expiry_month' ]) : '';
            $expiry_year = !empty($_POST[ 'expiry_year' ]) ? wc_clean($_POST[ 'expiry_year' ]) : '';
			$name_on_card = !empty($_POST[ 'card_name' ]) ? wc_clean($_POST[ 'card_name' ]) : '';

			if( $this->name_on_card_required === true && empty($name_on_card) && $this->name_on_card === true ){
				wp_send_json_error( esc_html__( 'Name on card is required.', 'woocommerce' ) );
			}

            // Remove surcharge from the order!
		    $this->custom_remove_specific_fee_from_order( $order_id );

			// Get the order object
			$order = wc_get_order($order_id);

			if (!$order) {				
				wp_send_json_error( esc_html__( 'Invalid order ID or key', 'woocommerce' ) );
			} else {

				$status 		= $order->get_status();
				$transaction_id = $order->get_transaction_id();

				//* validate the if transaction id is already exist
				if(!empty($transaction_id)){
					//wp_send_json_success($order->get_checkout_order_received_url());
					wp_send_json_error( esc_html__( "The order has been processed.", "woocommerce" ) );
				}
				
				$woo_currency 					= $order->get_currency();

				if($woo_currency != "USD" ) {
					wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD.", "woocommerce" ) );
				}

				//$currency_code 					= self::get_currency_code($woo_currency);
				$woo_get_total 					= $order->get_total();
				$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
				$avs_zip  						= $order->get_billing_postcode();

				// For trial subscription orders ($0 total), the API requires amount >= 0.01.
				// Trial detection: use the _acceptblue_ht_trial meta flag stored at process_payment time.
				// This is 100% reliable — no WCS function dependency needed.
				$_ht_is_trial_order = ( $order->get_meta( '_acceptblue_ht_trial' ) === '1' );
				$charge_amount      = $_ht_is_trial_order ? 0.01 : (double) $woo_get_total;

				//$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
				//$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
				//$amount_details[ "discount" ] 	= (double) $order->get_discount_total();

                $amount_details[ "tax" ] 		= (double) "0";
				$amount_details[ "shipping" ] 	= (double) "0";
				$amount_details[ "discount" ] 	= (double) "0";

				//* Transaction details

				$transaction_details = array();
				$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
				$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
				$transaction_details[ "order_number" ] 	= $order->get_order_number();
				$transaction_details[ "invoice_number" ] = $order->get_order_number();
				$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

				//* Billing Address Fields

				$billing_info = array();

				$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
				$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
				$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
				$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
				$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
				$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
				$billing_info[ "zip" ] 			= $order->get_billing_postcode();
				$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
				$billing_info[ "phone" ] 		= $order->get_billing_phone();						
				
				//* Shipping Address Fields

				$shipping_info = array();

				$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
				$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
				$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
				$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
				$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
				$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
				$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
				$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
				$shipping_info[ "phone" ] 		= $order->get_billing_phone();


                if($this->is_enabled() === false){ 
                    wp_send_json_error( esc_html__( 'Payment Gateway is Disabled!', 'woocommerce' ) );
                }

                $threed_secure = ! empty( $_POST['threed_secure'] ) ? wp_unslash( $_POST['threed_secure'] ) : '';

				if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) ) {
					$force_save_card_token = true; // Always save for subscriptions
				} elseif ( $this->force_save_card_token ) {
					$force_save_card_token = true;
				} else {
					// Honour save card checkbox sent by iframe JS
					$force_save_card_token = isset( $_POST['save_card'] ) && $_POST['save_card'] === '1';
				}

				if($threed_secure){

					if( $this->frictionless === true ){

						$params = array(
							"amount" 		=> $charge_amount,
							"source" 		=> "nonce-" . $hosted_token_nonce,
							"billing_info" 	=> $billing_info,
							"shipping_info" => $shipping_info,						
							"avs_zip" 		=> $avs_zip,
							"avs_address" 	=> $avs_address,
							"transaction_details" => $transaction_details,
							"amount_details" => $amount_details,
							"expiry_month"   => (int) $expiry_month,
							"expiry_year"    => (int) $expiry_year,
							"capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
							"save_card"      => (bool) $force_save_card_token,						
							"name"			=> $name_on_card
						);

					} else {

						$raw_eci      = isset( $threed_secure['eci'] )      ? wp_unslash( $threed_secure['eci'] )      : '';
						$raw_cavv     = isset( $threed_secure['cavv'] )     ? wp_unslash( $threed_secure['cavv'] )     : '';
						$raw_trans_id = isset( $threed_secure['ds_trans_id'] ) ? wp_unslash( $threed_secure['ds_trans_id'] ) : '';

						if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {

							$params = array(
								"amount" 		=> $charge_amount,
								"source" 		=> "nonce-" . $hosted_token_nonce,
								"billing_info" 	=> $billing_info,
								"shipping_info" => $shipping_info,						
								"avs_zip" 		=> $avs_zip,
								"avs_address" 	=> $avs_address,
								"transaction_details" => $transaction_details,
								"amount_details" => $amount_details,
								"expiry_month"   => (int) $expiry_month,
								"expiry_year"    => (int) $expiry_year,
								"capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
								"save_card"      => (bool) $force_save_card_token,
								"3d_secure" => array(
									"eci"        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
									"cavv"       => (string) $raw_cavv,
									"ds_trans_id"=> (string) $raw_trans_id,
								),
								"name" => $name_on_card
							);

						} else {

							self::log(
								'Classic 3DS (addons): missing 3d_secure fields — eci=' . var_export( $raw_eci, true )
								. ' cavv=' . ( empty( $raw_cavv ) ? 'EMPTY' : 'present' )
								. ' ds_trans_id=' . var_export( $raw_trans_id, true ),
								'error'
							);

							wp_send_json_error( esc_html__( '3D Secure data missing. Please try again.', 'woocommerce' ) );
							return;

						}

					}
					

				} else {

                    $params = array(
                        "amount" 		=> $charge_amount,
                        "source" 		=> "nonce-" . $hosted_token_nonce,
                        "billing_info" 	=> $billing_info,
                        "shipping_info" => $shipping_info,						
                        "avs_zip" 		=> $avs_zip,
                        "avs_address" 	=> $avs_address,
                        "transaction_details" => $transaction_details,
                        "amount_details" => $amount_details,
                        "expiry_month"   => (int) $expiry_month,
                        "expiry_year"    => (int) $expiry_year,
                        "capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
                        "save_card"      => (bool) $force_save_card_token,
						"name"			=> $name_on_card
                        
                    );

                }

				$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

				$params = array_merge($params, $level3_line_items);				

                //Surcharge add into order details
		    	$this->surcharge_fee_to_order($order, '' );
				
				//* Execute the payments					
                $result = $this->request_api($params, 'transactions/charge', 'POST');

				if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
					$data 		= wp_parse_args( (array) $result['response_body'], $defaults );
					
					if( $data[ 'status' ] == 'Approved' ){

						// Trial subscription: immediately void the $0.01 auth so nothing settles.
						if ( $_ht_is_trial_order ) {
							$ref_num  = sanitize_text_field( $data['reference_number'] ?? '' );
							$card_ref = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );
							if ( $ref_num ) {
								parent::request_api(
									array( 'reference_number' => (int) $ref_num ),
									'transactions/reversal',
									'POST'
								);
							}
							if ( ! empty( $card_ref ) ) {
								$full_token = 'tkn-' . $card_ref;
								$this->process_subscription( $order, $full_token );
							}
							$order->payment_complete( $ref_num );
							$order->update_meta_data( '_' . $this->id . '_refnum', $ref_num );
							$order->add_order_note( sprintf(
								__( '%s Trial — card verified via $0.01 auth (Ref: %s, auth voided). Future renewals charged normally.', 'woocommerce' ),
								$this->method_title, $ref_num
							) );
							$order->save();
							wp_send_json_success( $order->get_checkout_order_received_url() );
							return;
						}

						if( $this->default_status == 'default' ){
							// Mark as complete or processing based on virtual order or not
							$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
						} else {
							$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
							$order->update_status( $this->default_status );
						}
						
						$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );

						// Store authorized amount for Adjust & Capture total-change detection.
						if ( ! (bool) $this->force_capture ) {
							$auth_amount_addons_ht = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) $woo_get_total;
							if ( $auth_amount_addons_ht > 0 ) {
								$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_addons_ht );
							}
						}

						$order->save();

						$card_token = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );							
			
						if(  ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) && empty($card_token) ){
							wc_add_notice( 'Invalid accept.blue Payment Token, Subscriptions is not Activated' , 'woocommerce');
						}
						
						// Processing subscription
						if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) ) {
							// Guard: skip if card_ref was empty (would produce "tkn-" sentinel).
							if ( ! empty( $card_token ) ) {
								$card_token = "tkn-" . $card_token;
								$this->process_subscription( $order, $card_token );
							}
						} 

						$order->add_order_note(
							esc_html__( sprintf(
								"%s Payment Completed with Transaction Id of '%s'",
								$this->method_title,
								sanitize_text_field($data[ 'reference_number' ])
							), 'woocommerce' )
						);

						// Save WC payment token when user opted in (or force/subscription save is on)
						if ( $force_save_card_token && is_user_logged_in() ) {
							$card_ref_ht = sanitize_text_field( $data['card_ref'] ?? '' );
							if ( ! empty( $card_ref_ht ) ) {
								$wc_token_arr = array(
									'token'            => 'tkn-' . $card_ref_ht,
									'card_type'        => sanitize_text_field( $data['card_type'] ?? $data['cardType'] ?? '' ),
									'set_last4'        => sanitize_text_field( $data['last_4'] ?? $data['last4'] ?? '' ),
									'set_expiry_month' => absint( $expiry_month ),
									'set_expiry_year'  => absint( $expiry_year ),
								);
								parent::save_token( $wc_token_arr );
							}
						}

						WC()->cart->empty_cart();
						WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
							wp_send_json_success($order->get_checkout_order_received_url());
					} else {

						wp_send_json_error( esc_html__( $data[ 'error_message' ], 'woocommerce' ) );
					}
				
				} else{

					$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
					wp_send_json_error( esc_html__( wc_clean($message), 'woocommerce' ) );
				}


			} 
                

        }

        wp_die();

    }

	public function acceptblue_woocommerce_ajax_script_process_charge_addons(){
    
		if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {
	
			$order_key 		= !empty($_POST['order_key']) ? wc_clean($_POST['order_key']) : '';	
			$payment_token = !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';
	
	
			if(!empty($order_key) && !empty($payment_token)){
					
					$payment_token = base64_decode($payment_token);
					
					$order_id = wc_get_order_id_by_order_key( $order_key );				
	
					if($order_id){
						
						$order = wc_get_order($order_id);
	
						$woo_currency 					= $order->get_currency();
	
						if($woo_currency != "USD" ) {
							wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD!", "woocommerce" ) );
						}
	
						//$currency_code 					= $this->get_currency_code($woo_currency);
						$woo_get_total 					= $order->get_total();
						$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
						$avs_zip  						= $order->get_billing_postcode();
						
						//* Amount Details
	
						$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
						$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
						$amount_details[ "discount" ] 	= (double) $order->get_discount_total();
	
						//* Transaction details
	
						$transaction_details = array();
						$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
						$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
						$transaction_details[ "order_number" ] 	= $order->get_order_number();
						$transaction_details[ "invoice_number" ] = $order->get_order_number();
						$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();
	
						//* Billing Address Fields
	
						$billing_info = array();
	
						$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
						$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
						$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
						$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
						$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
						$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
						$billing_info[ "zip" ] 			= $order->get_billing_postcode();
						$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
						$billing_info[ "phone" ] 		= $order->get_billing_phone();						
						
						//* Shipping Address Fields
	
						$shipping_info = array();
	
						$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
						$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
						$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
						$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
						$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
						$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
						$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
						$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
						$shipping_info[ "phone" ] 		= $order->get_billing_phone();
	
						$params = array(
							"amount" 		=> (double) $woo_get_total,
							"source" 		=> $this->source,
							"token" 		=> $payment_token,	
							"billing_info" 	=> $billing_info,
							"shipping_info" => $shipping_info,						
							"avs_zip" 		=> $avs_zip,
							"avs_address" 	=> $avs_address,
							"transaction_details" => $transaction_details,
							"amount_details" => $amount_details,
							"capture"        => (bool) $this->force_capture,
							"save_card"      => true
						);

						$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

						$params = array_merge($params, $level3_line_items);
						
						//* Execute the payments	
						$result = parent::request_api($params,'transactions/charge');
	
						if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
							$data 		= wp_parse_args( (array) $result['response_body'], $defaults );
	
							if( $data[ 'status' ] == 'Approved' ){
								//$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );	
								if( $this->default_status == 'default' ){	
									// Mark as complete or processing based on virtual order or not
									$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );									
								} else {
									$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
									$order->update_status( $this->default_status );
								}
								
								$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );
								$order->delete_meta_data( 'payment_token' );

								// Store authorized amount for Adjust & Capture total-change detection.
								if ( ! (bool) $this->force_capture ) {
									$auth_amount_gp_block = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) ( $params['amount'] ?? 0 );
									if ( $auth_amount_gp_block > 0 ) {
										$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_gp_block );
									}
								}

								$order->save();
	
								$card_token = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );	
											   
								if(  ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) && empty($card_token) ){
									wc_add_notice( 'Invalid accept.blue Google Pay Payment Token, Subscriptions is not Activated' , 'woocommerce');
								}
								
								// Processing subscription
								if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order_id ) ) ) ) {
									// Set the subscriptions
									$card_token = "tkn-" . $card_token;
									$this->process_subscription( $order, $card_token  );
								} 
	
								$order->add_order_note(
									esc_html__( sprintf(
										"%s Payment Completed with Transaction Id of '%s'",
										$this->method_title,
										sanitize_text_field($data[ 'reference_number' ])
									), 'woocommerce' )
								);
	
								WC()->cart->empty_cart();
								WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
								 wp_send_json_success($order->get_checkout_order_received_url());
							} else {
	
								wp_send_json_error( esc_html__( $data[ 'error_message' ], 'woocommerce' ) );
							}
						
						} else{
	
							$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
							wp_send_json_error( esc_html__( wc_clean($message), 'woocommerce' ) );
						}
	
	
					} else {
						wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
					}
	
	
			} else {
				wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
			}
	
		}
			
		wp_die();
	  }
	
	  //* process cart page ajax request
	
		public function acceptblue_woocommerce_ajax_script_process_cart_page_charge_addons(){			
			
			if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
				wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
			} else {
	
				$payment_token = !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
				$product_id = !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
				$billing_address = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
				$email_address = !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
				$googlepay_amount = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';		
				
				$customer_id = get_current_user_id();
	
				// Check if a customer is logged in
				if (!$customer_id) {
					// Handle the case where no customer is logged in
					wp_send_json_error( esc_html__( 'No customer is logged in.', 'woocommerce' ) );
					return;
				}
	
				if(!empty($payment_token)){
						
						$payment_token = base64_decode($payment_token);
						
						if(!WC()->cart->is_empty()){
	
							$woo_get_total = (float) WC()->cart->get_total( 'edit' );						
	
							$order_id = WC()->session->get('order_awaiting_payment');
	
							if ($order_id) {	
								
								// if ($product->is_type('subscription') || $product->is_type('variable-subscription')) {
								// 	$this->set_order_subscription( $order, $product_id, $customer_id);
								// }
								
				
								$this->process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount );
	
								
							} else {
	
								if ( !is_user_logged_in() ) {
									wp_send_json_error( esc_html__( 'Please login!', 'woocommerce' ) );
								}
	
								
								$order = wc_create_order();
								$order_id = $order->get_id();
	
								// Optionally, add items to the order
								foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
									
									$order->add_product( $cart_item['data'], $cart_item['quantity'] ); // Add product to order
	
									// Get product and quantity
									$product_id = $cart_item['product_id'];
									$quantity   = $cart_item['quantity'];
									$product 	= wc_get_product( $product_id ); 
	
									if ($product->is_type('subscription') || $product->is_type('variable-subscription')) {
										
										$this->set_order_subscription( $order, $product_id, $customer_id);
									}
								}
	
								// Calculate totals and save
								$order->calculate_totals();
								$order->save();
				
								
								
				
								$this->process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount );
	
									
								
							}
	
						} else {
							wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
						}
	
	
				} else {
					wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
				}
	
			}
				
			wp_die();
	
		}
	
	  //* Process product page ajax request
	
		public function acceptblue_woocommerce_ajax_script_process_product_page_charge_addons(){
	
			if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
				wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
			} else {
	
				$payment_token      = !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
				$product_id         = !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
				$billing_address    = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
				$email_address      = !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
				$googlepay_amount   = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';			
	
				if(!empty($payment_token) && !empty($product_id)){
	
					$customer_id = get_current_user_id();
	
					// Check if a customer is logged in
					if (!$customer_id) {
						// Handle the case where no customer is logged in
						wp_send_json_error( esc_html__( 'No customer is logged in.', 'woocommerce' ) );
						return;
					}
						
					$payment_token = base64_decode($payment_token);	
					
					$order = wc_create_order();
					$order_id = $order->get_id();
	
					// Add products to the order
					$product = wc_get_product($product_id);
	
					if (!$product) {
						wp_send_json_error( esc_html__( 'Invalid product ID.', 'woocommerce' ) );
						return;
					}
	
					$quantity = 1; // Set the quantity of the product
					$order->add_product( $product, $quantity );
	
					// Set customer data
					$order->set_customer_id($customer_id);
	
					// Calculate totals for the order
					$order->calculate_totals();
	
					// Set the order status (e.g., 'pending', 'processing')
					
					$order->update_status('pending');
					$order->save();
	
					if ( !is_user_logged_in() ) {
						wp_send_json_error( esc_html__( 'Please login!', 'woocommerce' ) );
					}
	
					if ($product->is_type('subscription') || $product->is_type('variable-subscription')) {
						$this->set_order_subscription( $order, $product_id, $customer_id);
					}
					
	
					$this->process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount );
	
	
				} else {
					wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
				}
	
			}
				
			wp_die();
	
		}
	
		//* Create Subscription 
		
		public function set_order_subscription( $order, $product_id, $customer_id ){
	
			$product = wc_get_product($product_id);
	
			// Get the product's billing period and interval
			$billing_period = get_post_meta($product_id, '_subscription_period', true); // e.g., 'day', 'week', 'month', 'year'
			$billing_interval = get_post_meta($product_id, '_subscription_period_interval', true); // e.g., 1, 2, 3
		
			// Validate billing period and interval
			if (!$billing_period || !$billing_interval) {
				wp_send_json_error( esc_html__( 'Invalid billing period or interval for the product.', 'woocommerce' ) );
				return;
			}
	
			// Create a subscription for the order
			$subscription = wcs_create_subscription(array(
				'order_id' => $order->get_id(),
				'customer_id' => $customer_id,
				'billing_period' => $billing_period, // Dynamic billing period from product
				'billing_interval' => $billing_interval, // Dynamic billing interval from product
			));
	
			// Check if the subscription creation was successful
			if (is_wp_error($subscription)) {
				wp_send_json_error( esc_html__( 'Failed to create subscription: ' . $subscription->get_error_message(), 'woocommerce' ) );
				return;
			}
	
			// Add product to the subscription
			$subscription->add_product($product, 1); // Quantity set to 1
	
			// Set the payment method for the subscription to Google Pay
			$subscription->set_payment_method($this->id);
	
			// Set the subscription status to active
			$subscription->update_status('active');
	
			// Add order to the subscription
			//  $subscription->add_order($order->get_id());
			// Associate the order with the subscription
			// $subscription->add_related_order($order->get_id(), 'parent');
			//$subscription->attach_order($order->get_id());
	
			//* Billing Address Fields
	
			$billing_info = array();
	
			$billing_first_name 	= !empty($order->get_billing_first_name()) ? $order->get_billing_first_name() : WC()->cart->get_customer()->get_billing_first_name();
			$billing_last_name 		= !empty($order->get_billing_last_name()) ? $order->get_billing_last_name() : WC()->cart->get_customer()->get_billing_last_name();
			$billing_address_1 		= !empty($order->get_billing_address_1()) ? $order->get_billing_address_1() : WC()->cart->get_customer()->get_billing_address();
			$billing_address_2 		= !empty($order->get_billing_address_2()) ? $order->get_billing_address_2() : WC()->cart->get_customer()->get_billing_address_2();
			$billing_city 			= !empty($order->get_billing_city()) ? $order->get_billing_city() : WC()->cart->get_customer()->get_billing_city();
			$billing_state 			= !empty($order->get_billing_state()) ? $order->get_billing_state() : WC()->cart->get_customer()->get_billing_state();
			$billing_postcode 		= !empty($order->get_billing_postcode()) ? $order->get_billing_postcode() : WC()->cart->get_customer()->get_billing_postcode();
			$billing_country 		= !empty($order->get_billing_country()) ? $order->get_billing_country() : WC()->cart->get_customer()->get_billing_country();
			$billing_phone 			= !empty($order->get_billing_phone()) ? $order->get_billing_phone() : WC()->cart->get_customer()->get_billing_phone();
			$billing_email 			= !empty($order->get_billing_email()) ? $order->get_billing_email() : WC()->cart->get_customer()->get_billing_email();
			
			//* Shipping Address Fields
	
			$shipping_info = array();
	
			$shipping_first_name 			= !empty($order->get_shipping_first_name()) ? $order->get_shipping_first_name() : WC()->cart->get_customer()->get_shipping_first_name();
			$shipping_last_name 			= !empty($order->get_shipping_last_name()) ? $order->get_shipping_last_name() : WC()->cart->get_customer()->get_shipping_last_name();
			$shipping_address_1 			= !empty($order->get_shipping_address_1()) ? $order->get_shipping_address_1() : WC()->cart->get_customer()->get_shipping_address();
			$shipping_address_2 			= !empty($order->get_shipping_address_2()) ? $order->get_shipping_address_2() : WC()->cart->get_customer()->get_shipping_address_2();
			$shipping_city 					= !empty($order->get_shipping_city()) ? $order->get_shipping_city() : WC()->cart->get_customer()->get_shipping_city();
			$shipping_state 				= !empty($order->get_shipping_state()) ? $order->get_shipping_state() : WC()->cart->get_customer()->get_shipping_state();
			$shipping_postcode 				= !empty($order->get_shipping_postcode()) ? $order->get_shipping_postcode() : WC()->cart->get_customer()->get_shipping_postcode();
			$shipping_country 				= !empty($order->get_shipping_country()) ? $order->get_shipping_country() : WC()->cart->get_customer()->get_shipping_country();
			
	
			// Update Billing Information
			$subscription->set_billing_first_name( $billing_first_name );
			$subscription->set_billing_last_name( $billing_last_name );		
			$subscription->set_billing_address_1( $billing_address_1 );
			$subscription->set_billing_address_2( $billing_address_2  );
			$subscription->set_billing_city( $billing_city );
			$subscription->set_billing_state( $billing_state );
			$subscription->set_billing_postcode( $billing_postcode );
			$subscription->set_billing_country( $billing_country );
			$subscription->set_billing_email( $billing_email );
			$subscription->set_billing_phone( $billing_phone );
	
			// Update Shipping Information
			$subscription->set_shipping_first_name( $billing_first_name );
			$subscription->set_shipping_last_name( $billing_last_name );		
			$subscription->set_shipping_address_1( $billing_address_1 );
			$subscription->set_shipping_address_2( $billing_address_2 );
			$subscription->set_shipping_city( $billing_city );
			$subscription->set_shipping_state( $billing_state );
			$subscription->set_shipping_postcode( $billing_postcode );
			$subscription->set_shipping_country( $billing_country );
	
	
			// Set Coupons
			$applied_coupons = WC()->cart->get_applied_coupons();
	
			if ( ! empty( $applied_coupons ) ) {
	
				// Loop through each applied coupon
				foreach ( $applied_coupons as $coupon_code ) {
					
					// Get the coupon object
					$coupon = new WC_Coupon( $coupon_code );
			
					// Ensure the coupon is valid
					if ( ! $coupon->get_id() ) {
						continue; // Skip invalid coupon codes
					}
					
					$subscription->apply_coupon($coupon_code);
					
				}
	
				// Calculate totals
				//$order->calculate_totals(true);
				// Save the order after updating the details
				$subscription->calculate_totals();
				$subscription->save();
	
			}
	
	
			//* Check if has physical product
			$has_physical_product = false;
	
			foreach ($order->get_items() as $item_id => $item) {
				$product_id = $item->get_product_id();
				$product = wc_get_product($product_id);
				
				if ($product && $product->is_virtual() === false) {
					// If the product is not virtual, it is considered a physical product
					$has_physical_product = true;
					break;
				}
			}
			
			if ($has_physical_product) {
	
				// Create a shipping package
				$packages = [
					[
						'contents'        => [],
						'contents_cost'   => 0,
						'applied_coupons' => $order->get_used_coupons(),
						'user'            => [
							'ID' => get_current_user_id(),
						],
						'destination'     => [
							'country'   => $shipping_country,
							'state'     => $shipping_state,
							'postcode'  => $shipping_postcode,
							'city'      => $shipping_city,
							'address'   => $shipping_address_1,
							'address_2' => $shipping_address_2,
						],
					],
				];
			
				// Calculate the shipping rates
				WC()->shipping()->calculate_shipping( $packages );
			
				// Get available shipping rates for the package
				$available_methods = WC()->shipping->get_packages()[0]['rates'];
	
				// Retrieve the chosen shipping method IDs
				$chosen_methods = WC()->session->get('chosen_shipping_methods');
			
				// Add the first available shipping method (default method) to the order
				if ( ! empty( $available_methods ) ) {
	
					if( ! empty($chosen_methods) && !empty($chosen_methods[0])){
						$shipping_rate = $available_methods[$chosen_methods[0]]; 
	
					} else {
						$shipping_rate = reset( $available_methods ); // Get the first available method	
					}
	
					$subscription->add_shipping( $shipping_rate );			
					
				}
			}
			
	
	
			// Manually associate the order with the subscription
			update_post_meta($subscription->get_id(), '_subscription_order_id', $order->get_id());
			$order->add_meta_data('_subscription_id', $subscription->get_id(), true);
			$order->calculate_totals();
			$order->save();
	
			// Calculate totals and save the subscription
			$subscription->calculate_totals();
			$subscription->save();
	
		}
	
		//* Process payment by order id Callback from Google Pay
	
		public function process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount ){
	
			if(!$order_id) return;
	
			// Remove surcharge from the order!
			parent::custom_remove_specific_fee_from_order( $order_id );	
							
			$order                          = wc_get_order($order_id);
			$woo_currency 					= $order->get_currency();
	
			if($woo_currency != "USD" ) {
				wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD!", "woocommerce" ) );			
			}
	
			//$currency_code 					= $this->get_currency_code($woo_currency);
			$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
			$avs_zip  						= $order->get_billing_postcode();
			
			//* Amount Details
	
			$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
			$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
			$amount_details[ "discount" ] 	= (double) $order->get_discount_total();
	
			//* Transaction details		
	
			$transaction_details = array();
			$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
			$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
			$transaction_details[ "order_number" ] 	= $order->get_order_number();
			$transaction_details[ "invoice_number" ] = $order->get_order_number();
			$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();
			
	
			//* Billing Address Fields
	
			$billing_info = array();
	
			$billing_first_name 	= !empty($order->get_billing_first_name()) ? $order->get_billing_first_name() : WC()->cart->get_customer()->get_billing_first_name();
			$billing_last_name 		= !empty($order->get_billing_last_name()) ? $order->get_billing_last_name() : WC()->cart->get_customer()->get_billing_last_name();
			$billing_address_1 		= !empty($order->get_billing_address_1()) ? $order->get_billing_address_1() : WC()->cart->get_customer()->get_billing_address();
			$billing_address_2 		= !empty($order->get_billing_address_2()) ? $order->get_billing_address_2() : WC()->cart->get_customer()->get_billing_address_2();
			$billing_city 			= !empty($order->get_billing_city()) ? $order->get_billing_city() : WC()->cart->get_customer()->get_billing_city();
			$billing_state 			= !empty($order->get_billing_state()) ? $order->get_billing_state() : WC()->cart->get_customer()->get_billing_state();
			$billing_postcode 		= !empty($order->get_billing_postcode()) ? $order->get_billing_postcode() : WC()->cart->get_customer()->get_billing_postcode();
			$billing_country 		= !empty($order->get_billing_country()) ? $order->get_billing_country() : WC()->cart->get_customer()->get_billing_country();
			$billing_phone 			= !empty($order->get_billing_phone()) ? $order->get_billing_phone() : WC()->cart->get_customer()->get_billing_phone();
			$billing_email 			= !empty($order->get_billing_email()) ? $order->get_billing_email() : WC()->cart->get_customer()->get_billing_email();
	
	
			$billing_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
			$billing_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
			$billing_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
			$billing_info[ "street2" ] 		= esc_html__( $billing_address_2, 'woocommerce' );
			$billing_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
			$billing_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
			$billing_info[ "zip" ] 			= $billing_postcode;
			$billing_info[ "country" ] 		= esc_html__( $billing_country, 'woocommerce');
			$billing_info[ "phone" ] 		= $billing_phone;						
			
			//* Shipping Address Fields
	
			$shipping_info = array();
	
			$shipping_first_name 			= !empty($order->get_shipping_first_name()) ? $order->get_shipping_first_name() : WC()->cart->get_customer()->get_shipping_first_name();
			$shipping_last_name 			= !empty($order->get_shipping_last_name()) ? $order->get_shipping_last_name() : WC()->cart->get_customer()->get_shipping_last_name();
			$shipping_address_1 			= !empty($order->get_shipping_address_1()) ? $order->get_shipping_address_1() : WC()->cart->get_customer()->get_shipping_address();
			$shipping_address_2 			= !empty($order->get_shipping_address_2()) ? $order->get_shipping_address_2() : WC()->cart->get_customer()->get_shipping_address_2();
			$shipping_city 					= !empty($order->get_shipping_city()) ? $order->get_shipping_city() : WC()->cart->get_customer()->get_shipping_city();
			$shipping_state 				= !empty($order->get_shipping_state()) ? $order->get_shipping_state() : WC()->cart->get_customer()->get_shipping_state();
			$shipping_postcode 				= !empty($order->get_shipping_postcode()) ? $order->get_shipping_postcode() : WC()->cart->get_customer()->get_shipping_postcode();
			$shipping_country 				= !empty($order->get_shipping_country()) ? $order->get_shipping_country() : WC()->cart->get_customer()->get_shipping_country();
					
			$shipping_info[ "first_name" ] 	= esc_html__( $shipping_first_name, 'woocommerce' );
			$shipping_info[ "last_name" ] 	= esc_html__( $shipping_last_name, 'woocommerce' );
			$shipping_info[ "street" ] 		= esc_html__( $shipping_address_1, 'woocommerce' );
			$shipping_info[ "street2" ] 	= esc_html__( $shipping_address_2 , 'woocommerce' );
			$shipping_info[ "city" ] 		= esc_html__( $shipping_city, 'woocommerce' );
			$shipping_info[ "state" ] 		= esc_html__( $shipping_state, 'woocommerce' );
			$shipping_info[ "zip" ] 		= $shipping_postcode;
			$shipping_info[ "country" ] 	= esc_html__( $shipping_country , 'woocommerce' );
			$shipping_info[ "phone" ] 		= $billing_phone;
	
			// Update Billing Information
			$order->set_billing_first_name( $billing_first_name );
			$order->set_billing_last_name( $billing_last_name );		
			$order->set_billing_address_1( $billing_address_1 );
			$order->set_billing_address_2( $billing_address_2  );
			$order->set_billing_city( $billing_city );
			$order->set_billing_state( $billing_state );
			$order->set_billing_postcode( $billing_postcode );
			$order->set_billing_country( $billing_country );
			$order->set_billing_email( $billing_email );
			$order->set_billing_phone( $billing_phone );
	
			// Update Shipping Information
			$order->set_shipping_first_name( $shipping_first_name );
			$order->set_shipping_last_name( $shipping_last_name );		
			$order->set_shipping_address_1( $shipping_address_1 );
			$order->set_shipping_address_2( $shipping_address_2 );
			$order->set_shipping_city( $shipping_city );
			$order->set_shipping_state( $shipping_state );
			$order->set_shipping_postcode( $shipping_postcode );
			$order->set_shipping_country( $shipping_country );
	
			// Set Payment gateway 
			$order->set_payment_method( $this->id );
	
			// Set Customer id 
			$current_user = wp_get_current_user();
			$order->set_customer_id($current_user->ID);
	
			// Set Coupons
			$applied_coupons = WC()->cart->get_applied_coupons();
	
			if ( ! empty( $applied_coupons ) ) {
	
				// Loop through each applied coupon
				foreach ( $applied_coupons as $coupon_code ) {
					
					// Get the coupon object
					$coupon = new WC_Coupon( $coupon_code );
			
					// Ensure the coupon is valid
					if ( ! $coupon->get_id() ) {
						continue; // Skip invalid coupon codes
					}
					
					$order->apply_coupon($coupon_code);
					
				}
	
				// Calculate totals
				//$order->calculate_totals(true);
				// Save the order after updating the details
				$order->save();
	
			}
	
	
			//* Check if has physical product
			$has_physical_product = false;
	
			foreach ($order->get_items() as $item_id => $item) {
				$product_id = $item->get_product_id();
				$product = wc_get_product($product_id);
				
				if ($product && $product->is_virtual() === false) {
					// If the product is not virtual, it is considered a physical product
					$has_physical_product = true;
					break;
				}
			}
			
			if ($has_physical_product) {
	
				// Create a shipping package
				$packages = [
					[
						'contents'        => [],
						'contents_cost'   => 0,
						'applied_coupons' => $order->get_used_coupons(),
						'user'            => [
							'ID' => get_current_user_id(),
						],
						'destination'     => [
							'country'   => $shipping_country,
							'state'     => $shipping_state,
							'postcode'  => $shipping_postcode,
							'city'      => $shipping_city,
							'address'   => $shipping_address_1,
							'address_2' => $shipping_address_2,
						],
					],
				];
			
				// Calculate the shipping rates
				WC()->shipping()->calculate_shipping( $packages );
			
				// Get available shipping rates for the package
				$available_methods = WC()->shipping->get_packages()[0]['rates'];
	
				// Retrieve the chosen shipping method IDs
				$chosen_methods = WC()->session->get('chosen_shipping_methods');
			
				// Add the first available shipping method (default method) to the order
				if ( ! empty( $available_methods ) ) {
	
					if( ! empty($chosen_methods) && !empty($chosen_methods[0])){
						$shipping_rate = $available_methods[$chosen_methods[0]]; 
	
					} else {
						$shipping_rate = reset( $available_methods ); // Get the first available method	
					}
	
					$order->add_shipping( $shipping_rate );			
					
				}
			}
			
	
			// Calculate totals
			$order->calculate_totals();
	
			$order->update_meta_data( 'payment_token', $payment_token );
	
			// Save the order after updating the details
			$order->save();
	
			$woo_get_total 	= $order->get_total();
	
			// exit;
	
			//* Google Pay Order Review Page
	
			if($this->order_review_enable === true ){
	
				$page_id = $this->order_review_page;
	
				if( !empty($page_id) ){
	
					$args 	= array( 'key' => $order->get_order_key() );
					$url 	= add_query_arg( $args, get_permalink( $page_id ) );
	
					wp_send_json_success( esc_url( $url  ) );
	
				} else {
	
					wp_send_json_error( esc_html__( "Invalid Google Pay Order Review Page!" , "woocommerce" ));
	
				}
	
				
	
			} else {
	
				$params = array(
					"amount" 		=> (double) $woo_get_total,
					"source" 		=> $this->source,
					"token" 		=> $payment_token,	
					"billing_info" 	=> $billing_info,
					"shipping_info" => $shipping_info,						
					"avs_zip" 		=> $avs_zip,
					"avs_address" 	=> $avs_address,
					"transaction_details" => $transaction_details,
					"amount_details" => $amount_details,
					"capture"        => (bool) $this->force_capture,
					"save_card"      => (bool) true
				);

				$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

				$params = array_merge($params, $level3_line_items);
	
				//Surcharge add into order details
				parent::surcharge_fee_to_order($order, '' );
	
				$this->execute_payment_addons( $order, $params, 'transactions/charge' );
	
			}
				
				
	
			
		}
	
		public function execute_payment_addons( $order, $params, $action ){
	
			//* Execute the payments	
			$result = parent::request_api($params, $action );		 
		
			if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
				$data 		= wp_parse_args( (array) $result['response_body'], $defaults );
							
				if( $data[ 'status' ] == 'Approved' ){
	
					//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
					//$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
	
					//$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );
	
					if( $this->default_status == 'default' ){	
						// Mark as complete or processing based on virtual order or not
						$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );						
					} else {
						$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );	
						$order->update_status( $this->default_status );
					}
	
	
					$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );
					$order->delete_meta_data( 'payment_token' );

					// Store authorized amount for Adjust & Capture total-change detection.
					if ( ! (bool) $this->force_capture ) {
						$auth_amount_ep_addons = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) ( $params['amount'] ?? 0 );
						if ( $auth_amount_ep_addons > 0 ) {
							$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_ep_addons );
						}
					}

					$order->save();
	
					$card_token = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );						
									
					if(  ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order->get_id() ) ) ) && empty($card_token) ){
						wc_add_notice( 'Invalid accept.blue Google Pay Payment Token, Subscriptions is not Activated' , 'woocommerce');
					}
					
					// Processing subscription
					if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order->get_id() ) ) ) ) {
						// Set the subscriptions
						$card_token = "tkn-" . $card_token;
						$this->process_subscription( $order, $card_token  );
					} 
					
					$order->add_order_note(
						esc_html__( sprintf(
							"%s Payment Completed with Transaction Id of '%s'",
							$this->method_title,
							sanitize_text_field($data[ 'reference_number' ])
						), 'woocommerce' )
					);
	
					//$order->get_checkout_order_received_url();
					 WC()->cart->empty_cart();
					 WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
					 wp_send_json_success($order->get_checkout_order_received_url());				
				} else {
					wp_send_json_error( esc_html__( $data[ 'error_message' ], "woocommerce" ) );
				}
			
			} else{
	
				$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
				wp_send_json_error( esc_html__( $message, "woocommerce" ));
			}
	
		}
	
		//* Non Member Process payment by order id Callback from Google Pay
	
		public function non_member_process_payment_by_order_id_addons( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount ){
	
			if(!$order_id) return;
	
			// Remove surcharge from the order!
			parent::custom_remove_specific_fee_from_order( $order_id );	
							
			$order = wc_get_order($order_id);
	
			$woo_currency 					= $order->get_currency();
	
			if($woo_currency != "USD" ) {
				wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD!", "woocommerce"  ) );
			}
	
			//$currency_code 					= $this->get_currency_code($woo_currency);	
			
			//* Amount Details
	
			$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
			$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
			$amount_details[ "discount" ] 	= (double) $order->get_discount_total();
	
			//* Transaction details		
	
			$transaction_details = array();
			$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
			$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
			$transaction_details[ "order_number" ] 	= $order->get_order_number();
			$transaction_details[ "invoice_number" ] = $order->get_order_number();
			$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();
	
			$email_address = base64_decode($email_address);
			
			//* Billing Address Fields
	
			$billing_info = array();
	
			$name_parts = explode( ' ', $billing_address['name'], 2 );
	
			$billing_first_name 	= !empty($name_parts[0]) ? $name_parts[0] : '';
			$billing_last_name 		= !empty($name_parts[1]) ? $name_parts[1] : '';
			$billing_address_1 		= !empty($billing_address['address1']) ? $billing_address['address1'] : '';
			$billing_address_2 		= !empty($billing_address['address2']) ? $billing_address['address2'] : '';
			$billing_city 			= !empty($billing_address['locality']) ? $billing_address['locality'] : '';
			$billing_state 			= !empty($billing_address['administrativeArea']) ? $billing_address['administrativeArea'] : '';
			$billing_postcode 		= !empty($billing_address['postalCode']) ? $billing_address['postalCode'] : '';
			$billing_country 		= !empty($billing_address['countryCode']) ? $billing_address['countryCode'] : '';
			$billing_phone 			= !empty($billing_address['phoneNumber']) ? $billing_address['phoneNumber'] : '';
			$billing_email 			= !empty($email_address) ? $email_address : '';
	
	
			$billing_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
			$billing_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
			$billing_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
			$billing_info[ "street2" ] 		= esc_html__( $billing_address_2, 'woocommerce' );
			$billing_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
			$billing_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
			$billing_info[ "zip" ] 			= $billing_postcode;
			$billing_info[ "country" ] 		= esc_html__( $billing_country, 'woocommerce');
			$billing_info[ "phone" ] 		= $billing_phone;						
			
			//* Shipping Address Fields
	
			$shipping_info = array();
	
					
			$shipping_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
			$shipping_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
			$shipping_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
			$shipping_info[ "street2" ] 	= esc_html__( $billing_address_2 , 'woocommerce' );
			$shipping_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
			$shipping_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
			$shipping_info[ "zip" ] 		= $billing_postcode;
			$shipping_info[ "country" ] 	= esc_html__( $billing_country , 'woocommerce' );
			$shipping_info[ "phone" ] 		= $billing_phone;
	
			// Update Billing Information
			$order->set_billing_first_name( $billing_first_name );
			$order->set_billing_last_name( $billing_last_name );		
			$order->set_billing_address_1( $billing_address_1 );
			$order->set_billing_address_2( $billing_address_2  );
			$order->set_billing_city( $billing_city );
			$order->set_billing_state( $billing_state );
			$order->set_billing_postcode( $billing_postcode );
			$order->set_billing_country( $billing_country );
			$order->set_billing_email( $billing_email );
			$order->set_billing_phone( $billing_phone );
	
			// Update Shipping Information
			$order->set_shipping_first_name( $billing_first_name );
			$order->set_shipping_last_name( $billing_last_name );		
			$order->set_shipping_address_1( $billing_address_1 );
			$order->set_shipping_address_2( $billing_address_2 );
			$order->set_shipping_city( $billing_city );
			$order->set_shipping_state( $billing_state );
			$order->set_shipping_postcode( $billing_postcode );
			$order->set_shipping_country( $billing_country );
	
			// Set Payment gateway 
			$order->set_payment_method( $this->id );
	
			// Set Customer id 
			$current_user = wp_get_current_user();
			$order->set_customer_id($current_user->ID);
	
			// Set Coupons
			$applied_coupons = WC()->cart->get_applied_coupons();
	
			if ( ! empty( $applied_coupons ) ) {
	
				// Loop through each applied coupon
				foreach ( $applied_coupons as $coupon_code ) {
					
					// Get the coupon object
					$coupon = new WC_Coupon( $coupon_code );
			
					// Ensure the coupon is valid
					if ( ! $coupon->get_id() ) {
						continue; // Skip invalid coupon codes
					}
					
					$order->apply_coupon($coupon_code);
					
				}
	
				// Calculate totals
				//$order->calculate_totals(true);
				// Save the order after updating the details
				$order->save();
	
			}
	
			//* Check if has physical product
			$has_physical_product = false;
	
			foreach ($order->get_items() as $item_id => $item) {
				$product_id = $item->get_product_id();
				$product = wc_get_product($product_id);
				
				if ($product && $product->is_virtual() === false) {
					// If the product is not virtual, it is considered a physical product
					$has_physical_product = true;
					break;
				}
			}
			
			if ($has_physical_product) {
	
				// Create a shipping package
				$packages = [
					[
						'contents'        => [],
						'contents_cost'   => 0,
						'applied_coupons' => $order->get_used_coupons(),
						'user'            => [
							'ID' => get_current_user_id(),
						],
						'destination'     => [
							'country'   => $shipping_info[ "country" ],
							'state'     => $shipping_info[ "state" ],
							'postcode'  => $shipping_info[ "zip" ] ,
							'city'      => $shipping_info[ "city" ],
							'address'   => $shipping_info[ "street" ],
							'address_2' => $shipping_info[ "street2" ],
						],
					],
				];
			
				// Calculate the shipping rates
				WC()->shipping()->calculate_shipping( $packages );
			
				// Get available shipping rates for the package
				$available_methods = WC()->shipping->get_packages()[0]['rates'];
			
				// Retrieve the chosen shipping method IDs
				$chosen_methods = WC()->session->get('chosen_shipping_methods');
			
				// Add the first available shipping method (default method) to the order
				if ( ! empty( $available_methods ) ) {
	
					if( ! empty($chosen_methods) && !empty($chosen_methods[0])){
						$shipping_rate = $available_methods[$chosen_methods[0]]; 					
					} else {
						$shipping_rate = reset( $available_methods ); // Get the first available method				
					}
					
					$order->add_shipping( $shipping_rate );		
					
				}
	
			}
	
			
	
			// Calculate totals
			$order->calculate_totals();
	
			$order->update_meta_data( 'payment_token', $payment_token );
	
			// Save the order after updating the details
			$order->save();
	
			$woo_get_total 					= $order->get_total();
			$avs_address					= esc_html__( $billing_address_1 .' '. $billing_address_2, 'woocommerce' );
			$avs_zip  						= $billing_postcode;	
	
			if($this->order_review_enable === true ){
	
				$page_id = $this->order_review_page;
	
				if( !empty($page_id) ){
	
					$args 	= array( 'key' => $order->get_order_key() );
					$url 	= add_query_arg( $args, get_permalink( $page_id ) );
	
					wp_send_json_success( esc_url( $url  ) );
	
				} else {
	
					wp_send_json_error( esc_html__( "Invalid Google Pay Order Review Page!" , "woocommerce" ));
	
				}
	
				
	
			} else {
	
				$params = array(
					"amount" 		=> (double) $woo_get_total,
					"source" 		=> $this->source,
					"token" 		=> $payment_token,	
					"billing_info" 	=> $billing_info,
					"shipping_info" => $shipping_info,						
					"avs_zip" 		=> $avs_zip,
					"avs_address" 	=> $avs_address,
					"transaction_details" => $transaction_details,
					"amount_details" => $amount_details,
					"capture"        => (bool) $this->force_capture,
					"save_card"      => (bool) true 
				);

				$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

				$params = array_merge($params, $level3_line_items);
	
				//Surcharge add into order details
				parent::surcharge_fee_to_order($order, '' );
	
				$this->execute_payment_addons( $order, $params, 'transactions/charge' );
	
			}
			
		}
	
		//* Process product page ajax request
	
		public function acceptblue_woocommerce_ajax_script_place_order_charge_addons(){
	
			if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
				wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
			} else {
	
				$order_key = !empty($_POST['order_key']) ? wc_clean($_POST['order_key']) : '';
	
				if (!empty($order_key)) {
					$order_id = wc_get_order_id_by_order_key($order_key);
				} 
	
				if (empty($order_id)) {
					wp_send_json_error( esc_html__( 'No order found.', 'woocommerce' ) );
				}
	
				// Remove surcharge from the order!
				parent::custom_remove_specific_fee_from_order( $order_id );	
	
				// Get the order object
				$order = wc_get_order($order_id);
	
				if (!$order) {				
					wp_send_json_error( esc_html__( 'Invalid order ID or key', 'woocommerce' ) );
				} else {
	
					$status 		= $order->get_status();
					$transaction_id = $order->get_transaction_id();
	
					//* validate the if transaction id is already exist
					if(!empty($transaction_id)){
						//wp_send_json_success($order->get_checkout_order_received_url());
						wp_send_json_error( esc_html__( "The order has been processed.", "woocommerce" ) );
					}
	
					$payment_token 					= $order->get_meta( 'payment_token' );
	
					if(empty($payment_token)) {
						wp_send_json_error( esc_html__( "Invalid, Payment Token.", "woocommerce" ) );
					}
	
					$woo_currency 					= $order->get_currency();
	
					if($woo_currency != "USD" ) {
						wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD.", "woocommerce" ) );
					}
	
					//$currency_code 					= $this->get_currency_code($woo_currency);
					$woo_get_total 					= $order->get_total();
					$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
					$avs_zip  						= $order->get_billing_postcode();
					
					//* Amount Details
	
					$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
					$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
					$amount_details[ "discount" ] 	= (double) $order->get_discount_total();
	
					//* Transaction details
	
					$transaction_details = array();
					$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
					$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
					$transaction_details[ "order_number" ] 	= $order->get_order_number();
					$transaction_details[ "invoice_number" ] = $order->get_order_number();
					$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();
	
					//* Billing Address Fields
	
					$billing_info = array();
	
					$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
					$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
					$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
					$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
					$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
					$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
					$billing_info[ "zip" ] 			= $order->get_billing_postcode();
					$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
					$billing_info[ "phone" ] 		= $order->get_billing_phone();						
					
					//* Shipping Address Fields
	
					$shipping_info = array();
	
					$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
					$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
					$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
					$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
					$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
					$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
					$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
					$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
					$shipping_info[ "phone" ] 		= $order->get_billing_phone();
	
					$params = array(
						"amount" 		=> (double) $woo_get_total,
						"source" 		=> $this->source,
						"token" 		=> $payment_token,	
						"billing_info" 	=> $billing_info,
						"shipping_info" => $shipping_info,						
						"avs_zip" 		=> $avs_zip,
						"avs_address" 	=> $avs_address,
						"transaction_details" => $transaction_details,
						"amount_details" => $amount_details,
						"capture"        => (bool) $this->force_capture,
						"save_card"      => (bool) true 
					);

					$level3_line_items = (array) parent::level3_data_line_items( $order->get_id() );

					$params = array_merge($params, $level3_line_items);
	
					//Surcharge add into order details
					parent::surcharge_fee_to_order($order, '' );
					
					//* Execute the payments	
					$result = $this->request_api($params,'transactions/charge');
					 
					if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
						$data 		= wp_parse_args( (array) $result['response_body'], $defaults );
						
						if( $data[ 'status' ] == 'Approved' ){
	
							//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
							//$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );	
							//$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );
	
							if( $this->default_status == 'default' ){	
								// Mark as complete or processing based on virtual order or not
								$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
								
							} else {
								$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
								$order->update_status( $this->default_status );
							}
							
							$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );
							//* removed the Google Pay payment token
							$order->delete_meta_data( 'payment_token' );

							// Store authorized amount for Adjust & Capture total-change detection.
							if ( ! (bool) $this->force_capture ) {
								$auth_amount_gp_addons = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) ( $params['amount'] ?? 0 );
								if ( $auth_amount_gp_addons > 0 ) {
									$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_gp_addons );
								}
							}

							$order->save();
	
							$card_token = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );
	
							if(  ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order->get_id() ) ) ) && empty($card_token) ){
								wc_add_notice( 'Invalid accept.blue Google Pay Payment Token, Subscriptions is not Activated' , 'woocommerce');
							}
							
							// Processing subscription
							if ( ( $this->order_contains_subscription( $order->get_id() ) || ( function_exists( 'wcs_is_subscription' ) && wcs_is_subscription( $order->get_id() ) ) ) ) {
								// Set the subscriptions
								$card_token = "tkn-" . $card_token;
								$this->process_subscription( $order, $card_token  );
							} 
	
							$order->add_order_note(
								esc_html__( sprintf(
									"%s Payment Completed with Transaction Id of '%s'",
									$this->method_title,
									sanitize_text_field($data[ 'reference_number' ])
								), 'woocommerce' )
							);
	
							WC()->cart->empty_cart();
							WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
								wp_send_json_success($order->get_checkout_order_received_url());
						} else {
	
							wp_send_json_error( esc_html__( $data[ 'error_message' ], 'woocommerce' ) );
						}
					
					} else{
	
						$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
						wp_send_json_error( esc_html__( wc_clean($message), 'woocommerce' ) );
					}
	
	
				} 
	
			}
				
			wp_die();
	
		}
	
		//* process checkout page ajax request
	
		public function acceptblue_woocommerce_ajax_script_process_checkout_page_charge_addons(){
				
			
			if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
				wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
			} else {
	
				$payment_token 	= !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
				$product_id 	= !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
				$billing_address = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
				$email_address 	= !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
				$googlepay_amount = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';
	
				$customer_id = get_current_user_id();
	
				// Check if a customer is logged in
				if (!$customer_id) {
					// Handle the case where no customer is logged in
					wp_send_json_error( esc_html__( 'No customer is logged in.', 'woocommerce' ) );
					return;
				}
				
	
				if(!empty($payment_token)){
						
						$payment_token = base64_decode($payment_token);
						
						if(!WC()->cart->is_empty()){
	
							$woo_get_total = (float) WC()->cart->get_total( 'edit' );						
	
							$order_id = WC()->session->get('order_awaiting_payment');
	
							if ($order_id) {
	
								if ( !is_user_logged_in() ) {
									wp_send_json_error( esc_html__( 'Please login!', 'woocommerce' ) );
								}
				
								$this->process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount );
							
	
							} else {
	
								if ( !is_user_logged_in() ) {
									wp_send_json_error( esc_html__( 'Please login!', 'woocommerce' ) );
								}
	
								
								$order = wc_create_order();
								$order_id = $order->get_id();
	
								// Optionally, add items to the order
								foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
									
									$order->add_product( $cart_item['data'], $cart_item['quantity'] ); // Add product to order
	
									// Get product and quantity
									$product_id = $cart_item['product_id'];
									$quantity   = $cart_item['quantity'];
									$product 	= wc_get_product( $product_id ); 
	
									if ($product->is_type('subscription') || $product->is_type('variable-subscription')) {
										
										$this->set_order_subscription( $order, $product_id, $customer_id);
									}
								}
	
								// Calculate totals and save
								$order->calculate_totals();
								$order->save();
				
								$this->process_payment_by_order_id_addons( $order_id, $payment_token, $googlepay_amount );
								
								
							}
	
						} else {
							wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
						}
	
	
				} else {
					wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
				}
	
			}
				
			wp_die();
	
		}

	
	
}


//* WooCommerce AJAX AcceptBlue Google Pay Addons Integration 
add_action('wp_ajax_acceptblue_request_charge_addons', 'acceptblue_request_charge_addons' );
add_action('wp_ajax_nopriv_acceptblue_request_charge_addons', 'acceptblue_request_charge_addons');

function acceptblue_request_charge_addons(){

	if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0) return;
	
	$accept_blue = new WC_Gateway_AcceptBlue_v2_Addons();
	$accept_blue->acceptblue_woocommerce_ajax_script_process_charge_addons();
}

//* Google Pay Callback Product Page Ajax
add_action('wp_ajax_acceptblue_request_product_page_charge_addons', 'acceptblue_request_product_page_charge_addons' );
add_action('wp_ajax_nopriv_acceptblue_request_product_page_charge_addons', 'acceptblue_request_product_page_charge_addons');

function acceptblue_request_product_page_charge_addons(){

	if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0) return;

	$accept_blue = new WC_Gateway_AcceptBlue_v2_Addons();
	$accept_blue->acceptblue_woocommerce_ajax_script_process_product_page_charge_addons();
}

//* Google Pay Callback Cart Page Ajax
add_action('wp_ajax_acceptblue_request_cart_page_charge_addons', 'acceptblue_request_cart_page_charge_addons' );
add_action('wp_ajax_nopriv_acceptblue_request_cart_page_charge_addons', 'acceptblue_request_cart_page_charge_addons');

function acceptblue_request_cart_page_charge_addons(){

	if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0) return;

	$accept_blue = new WC_Gateway_AcceptBlue_v2_Addons();
	$accept_blue->acceptblue_woocommerce_ajax_script_process_cart_page_charge_addons();
}

//* Google Pay Callback Checkout Page Ajax
add_action('wp_ajax_acceptblue_request_checkout_page_charge_addons', 'acceptblue_request_checkout_page_charge_addons' );
add_action('wp_ajax_nopriv_acceptblue_request_checkout_page_charge_addons', 'acceptblue_request_checkout_page_charge_addons');

function acceptblue_request_checkout_page_charge_addons(){

	if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0) return;

	$accept_blue = new WC_Gateway_AcceptBlue_v2_Addons();
	$accept_blue->acceptblue_woocommerce_ajax_script_process_checkout_page_charge_addons();
}

//* Google Pay Callback Place Order Ajax
add_action('wp_ajax_acceptblue_request_place_order_charge_addons', 'acceptblue_request_place_order_charge_addons' );
add_action('wp_ajax_nopriv_acceptblue_request_place_order_charge_addons', 'acceptblue_request_place_order_charge_addons');

function acceptblue_request_place_order_charge_addons(){

	if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0) return;

	$accept_blue = new WC_Gateway_AcceptBlue_v2_Addons();
	$accept_blue->acceptblue_woocommerce_ajax_script_place_order_charge_addons();
}