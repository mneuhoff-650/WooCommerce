<?php
/**
 * RyanPlugins License SDK v1.0
 * ─────────────────────────────────────────────────────────────────────────────
 * Drop this single file into any RyanPlugins plugin and wire it up in 3 lines.
 *
 * QUICK START
 * ───────────
 * In your main plugin file, after your plugin header:
 *
 *   require_once plugin_dir_path( __FILE__ ) . 'includes/class-ryanplugins-license.php';
 *
 *   add_action( 'plugins_loaded', function() {
 *       if ( class_exists( 'RyanPlugins_License' ) ) {
 *           $license = new RyanPlugins_License(
 *               'your-plugin-slug',   // e.g. 'my-awesome-plugin'
 *               'Your Plugin Name',   // e.g. 'My Awesome Plugin'
 *               __FILE__              // path to your main plugin file
 *           );
 *           $license->init();
 *
 *           // (Optional) Store globally so other classes can reach it
 *           $GLOBALS['my_plugin_license'] = $license;
 *       }
 *   } );
 *
 * RENDERING THE LICENSE TAB
 * ─────────────────────────
 * Inside your settings page callback, when the "license" tab is active:
 *
 *   $GLOBALS['my_plugin_license']->render_settings_tab();
 *
 * CHECKING LICENSE STATUS IN YOUR PLUGIN CODE
 * ────────────────────────────────────────────
 *   if ( $GLOBALS['my_plugin_license']->is_licensed() ) {
 *       // user has an activated key
 *   }
 *
 *   if ( $GLOBALS['my_plugin_license']->should_show_notice() ) {
 *       // notice logic is already handled automatically via init(),
 *       // but you can call this to make manual decisions too
 *   }
 *
 * CONFIGURATION
 * ─────────────
 * Edit the four constants at the top of the class below to match your setup.
 *
 * @package RyanPlugins
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct file access.
}

if ( ! class_exists( 'RyanPlugins_License' ) ) :

class RyanPlugins_License {

    // =========================================================================
    // ── CONFIGURATION — edit these to match your setup ───────────────────────
    // =========================================================================

    /** Base URL of your license server (no trailing slash). */
    const SERVER_URL = 'https://license.ryanplugins.net';

    /** Days after a patron cancels before the admin notice appears. */
    const GRACE_DAYS = 30;

    /**
     * How often (in seconds) to re-validate an activated license.
     * Default: 604800 = 7 days.
     */
    const RECHECK_INTERVAL = 604800;

    /**
     * If the license server is unreachable, keep treating the license as valid
     * for this many days before showing a notice.
     */
    const OFFLINE_GRACE_DAYS = 14;

    // =========================================================================
    // ── INSTANCE PROPERTIES ──────────────────────────────────────────────────
    // =========================================================================

    /** @var string Plugin slug used for option keys and AJAX actions. */
    private $plugin_slug;

    /** @var string Human-readable plugin name shown in admin notices. */
    private $plugin_name;

    /** @var string Absolute path to the main plugin file (__FILE__). */
    private $plugin_file;

    /** @var string wp_options key that stores all license data. */
    private $option_key;

    /** @var string wp_options key that stores the notice-dismissed timestamp. */
    private $notice_dismissed_key;

    // =========================================================================
    // ── CONSTRUCTOR ───────────────────────────────────────────────────────────
    // =========================================================================

    /**
     * @param string $plugin_slug  Unique slug for this plugin (e.g. 'my-plugin').
     * @param string $plugin_name  Human-readable name shown in notices/UI.
     * @param string $plugin_file  Pass __FILE__ from your main plugin file.
     */
    public function __construct( $plugin_slug, $plugin_name, $plugin_file ) {
        $this->plugin_slug          = $plugin_slug;
        $this->plugin_name          = $plugin_name;
        $this->plugin_file          = $plugin_file;
        $this->option_key           = 'rp_license_' . sanitize_key( $plugin_slug );
        $this->notice_dismissed_key = 'rp_notice_dismissed_' . sanitize_key( $plugin_slug );
    }

    // =========================================================================
    // ── BOOT — call this once, e.g. inside plugins_loaded ────────────────────
    // =========================================================================

    public function init() {
        // Periodic re-validation on admin page loads.
        add_action( 'init', [ $this, 'maybe_recheck' ] );

        // Admin banner notice.
        add_action( 'admin_notices', [ $this, 'maybe_show_notice' ] );

        // AJAX: dismiss the notice for 7 days.
        add_action(
            'wp_ajax_rp_dismiss_notice_' . sanitize_key( $this->plugin_slug ),
            [ $this, 'ajax_dismiss_notice' ]
        );

        // AJAX: activate a license key.
        add_action(
            'wp_ajax_rp_activate_license_' . sanitize_key( $this->plugin_slug ),
            [ $this, 'ajax_activate' ]
        );

        // AJAX: deactivate / remove the current license key.
        add_action(
            'wp_ajax_rp_deactivate_license_' . sanitize_key( $this->plugin_slug ),
            [ $this, 'ajax_deactivate' ]
        );
    }

    // =========================================================================
    // ── PUBLIC STATUS CHECKS ──────────────────────────────────────────────────
    // =========================================================================

    /**
     * Returns true if a license key has been entered and activated.
     *
     * @return bool
     */
    public function is_licensed() {
        $data = $this->get_license_data();
        return ! empty( $data['license_key'] ) && ! empty( $data['activated'] );
    }

    /**
     * Returns true when the admin notice should be displayed.
     *
     * The plugin always works regardless of license status — this only
     * controls whether the "please activate / resubscribe" banner is shown.
     *
     * @return bool
     */
    public function should_show_notice() {
        // Not activated at all → show notice (unless dismissed).
        if ( ! $this->is_licensed() ) {
            return ! $this->is_notice_dismissed();
        }

        $data = $this->get_license_data();

        // Active patron → no notice.
        if ( isset( $data['patron_status'] ) && $data['patron_status'] === 'active' ) {
            return false;
        }

        // Server was unreachable → respect offline grace period.
        if ( ! isset( $data['patron_status'] ) || $data['patron_status'] === 'unknown' ) {
            $days_offline = ( time() - ( $data['last_check'] ?? 0 ) ) / 86400;
            return $days_offline > self::OFFLINE_GRACE_DAYS
                ? ! $this->is_notice_dismissed()
                : false;
        }

        // Cancelled membership → show if within notice window and not dismissed.
        if ( $data['patron_status'] === 'cancelled' ) {
            $show = $data['show_notice'] ?? true;
            return $show && ! $this->is_notice_dismissed();
        }

        return false;
    }

    // =========================================================================
    // ── DATA STORAGE ──────────────────────────────────────────────────────────
    // =========================================================================

    /**
     * Returns the stored license data array, or an empty array if none.
     *
     * Keys present after activation:
     *   license_key   (string)  — the entered key
     *   activated     (bool)    — true after a successful activation call
     *   patron_name   (string)  — name returned by the server
     *   patron_status (string)  — 'active' | 'cancelled' | 'revoked' | 'unknown'
     *   show_notice   (bool)    — server hint: show the cancelled notice?
     *   activated_at  (int)     — Unix timestamp of first activation
     *   last_check    (int)     — Unix timestamp of last server validation
     *
     * @return array
     */
    public function get_license_data() {
        return get_option( $this->option_key, [] );
    }

    /**
     * Persist license data.
     *
     * @param array $data
     */
    private function save_license_data( $data ) {
        update_option( $this->option_key, $data );
    }

    /**
     * Returns true if the admin clicked "Dismiss" and the timeout has not yet expired.
     *
     * @return bool
     */
    private function is_notice_dismissed() {
        $dismissed_until = get_option( $this->notice_dismissed_key, 0 );
        return $dismissed_until > time();
    }

    /**
     * Snooze the notice for the given number of days.
     *
     * @param int $days
     */
    private function dismiss_notice_for_days( $days = 7 ) {
        update_option( $this->notice_dismissed_key, time() + ( $days * 86400 ) );
    }

    // =========================================================================
    // ── PERIODIC RE-VALIDATION ────────────────────────────────────────────────
    // =========================================================================

    /**
     * Hooked to 'init'. Fires a validation request if the recheck interval
     * has elapsed since the last successful check.
     */
    public function maybe_recheck() {
        if ( ! $this->is_licensed() ) {
            return;
        }
        if ( ! is_admin() ) {
            return;
        }

        $data       = $this->get_license_data();
        $last_check = $data['last_check'] ?? 0;

        if ( time() - $last_check < self::RECHECK_INTERVAL ) {
            return;
        }

        $this->validate_with_server( $data['license_key'] );
    }

    /**
     * Send a validate request to the license server and update stored data.
     *
     * @param  string     $key License key to validate.
     * @return array|null      Decoded response body, or null on failure.
     */
    private function validate_with_server( $key ) {
        $response = wp_remote_post( self::SERVER_URL . '/api/license', [
            'timeout' => 12,
            'body'    => [
                'action'      => 'validate',
                'license_key' => $key,
                'site_url'    => home_url(),
                'plugin_slug' => $this->plugin_slug,
            ],
        ] );

        // Server unreachable — leave last_check unchanged so we retry next time.
        if ( is_wp_error( $response ) ) {
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body ) ) {
            return null;
        }

        $data               = $this->get_license_data();
        $data['last_check'] = time();

        if ( $body['success'] ) {
            $data['patron_status'] = $body['patron_status'] ?? 'unknown';
            $data['show_notice']   = $body['show_notice']   ?? false;
            $data['within_grace']  = $body['within_grace']  ?? true;
        } elseif ( isset( $body['code'] ) && $body['code'] === 'revoked' ) {
            // Key was revoked server-side.
            $data['activated']     = false;
            $data['patron_status'] = 'revoked';
            $data['show_notice']   = true;
        }

        $this->save_license_data( $data );
        return $body;
    }

    // =========================================================================
    // ── AJAX: ACTIVATE ────────────────────────────────────────────────────────
    // =========================================================================

    /** Handles wp_ajax_rp_activate_license_{slug}. */
    public function ajax_activate() {
        check_ajax_referer( 'rp_license_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $key = sanitize_text_field( trim( $_POST['license_key'] ?? '' ) );

        if ( empty( $key ) ) {
            wp_send_json_error( [ 'message' => 'Please enter a license key.' ] );
        }

        $response = wp_remote_post( self::SERVER_URL . '/api/license', [
            'timeout' => 15,
            'body'    => [
                'action'      => 'activate',
                'license_key' => $key,
                'site_url'    => home_url(),
                'plugin_slug' => $this->plugin_slug,
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [
                'message' => 'Could not connect to the license server. Please check your internet connection and try again.',
            ] );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body ) ) {
            wp_send_json_error( [ 'message' => 'Invalid response from license server.' ] );
        }

        if ( ! $body['success'] ) {
            wp_send_json_error( [
                'message' => $body['message'] ?? 'Activation failed. Please check your key.',
            ] );
        }

        $this->save_license_data( [
            'license_key'   => $key,
            'activated'     => true,
            'patron_name'   => $body['patron_name']   ?? '',
            'patron_status' => $body['patron_status'] ?? 'active',
            'show_notice'   => $body['show_notice']   ?? false,
            'activated_at'  => time(),
            'last_check'    => time(),
        ] );

        wp_send_json_success( [
            'message'       => $body['message'],
            'patron_name'   => $body['patron_name']   ?? '',
            'patron_status' => $body['patron_status'] ?? 'active',
        ] );
    }

    // =========================================================================
    // ── AJAX: DEACTIVATE ──────────────────────────────────────────────────────
    // =========================================================================

    /** Handles wp_ajax_rp_deactivate_license_{slug}. */
    public function ajax_deactivate() {
        check_ajax_referer( 'rp_license_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $data = $this->get_license_data();
        $key  = $data['license_key'] ?? '';

        // Notify the server so it can free the activation slot.
        if ( $key ) {
            wp_remote_post( self::SERVER_URL . '/api/license', [
                'timeout' => 8,
                'body'    => [
                    'action'      => 'deactivate',
                    'license_key' => $key,
                    'site_url'    => home_url(),
                ],
            ] );
        }

        $this->save_license_data( [] );
        wp_send_json_success( [ 'message' => 'License deactivated.' ] );
    }

    // =========================================================================
    // ── AJAX: DISMISS NOTICE ──────────────────────────────────────────────────
    // =========================================================================

    /** Handles wp_ajax_rp_dismiss_notice_{slug}. */
    public function ajax_dismiss_notice() {
        check_ajax_referer( 'rp_license_nonce', 'nonce' );
        $this->dismiss_notice_for_days( 7 );
        wp_send_json_success();
    }

    // =========================================================================
    // ── ADMIN NOTICE ──────────────────────────────────────────────────────────
    // =========================================================================

    /** Hooked to 'admin_notices'. Renders the banner when needed. */
    public function maybe_show_notice() {
        if ( ! $this->should_show_notice() ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data          = $this->get_license_data();
        $is_activated  = $this->is_licensed();
        $patron_status = $data['patron_status'] ?? '';
        $slug_safe     = sanitize_key( $this->plugin_slug );
        $nonce         = wp_create_nonce( 'rp_license_nonce' );
        $portal_url    = self::SERVER_URL;
        $patreon_url   = 'https://www.patreon.com/RyanPlugins';

        // ── Determine notice type & content ──────────────────────────────────
        // expired/cancelled membership: activated key but patron no longer active
        $is_expired = $is_activated && in_array( $patron_status, [ 'cancelled', 'revoked' ], true );

        if ( $is_expired ) {
            // Red error notice — membership has lapsed
            $notice_class  = 'notice notice-error rp-license-notice';
            $icon          = '⚠️';
            $dismiss_label = 'Snooze – 7 days';
            $message = sprintf(
                '<strong>%s — Membership Expired</strong> Your Patreon membership has ended. '.
                'The plugin continues to work, but <strong>updates and new features are paused</strong>. '.
                '<a href="%s" target="_blank" style="font-weight:600">Resubscribe on Patreon →</a>',
                esc_html( $this->plugin_name ),
                esc_url( $patreon_url )
            );
        } else {
            // Yellow warning notice — never activated
            $notice_class  = 'notice notice-warning rp-license-notice';
            $icon          = '🔑';
            $dismiss_label = 'Dismiss – 7 days';
            $message = sprintf(
                '<strong>%s</strong> is unlicensed. '.
                '<a href="%s" target="_blank">Activate your license</a> to stay up to date and get support when you need it.',
                esc_html( $this->plugin_name ),
                esc_url( $portal_url )
            );
        }

        printf(
            '<div class="%s" style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;gap:16px" data-plugin="%s">'.
            '<p style="margin:0">%s %s</p>'.
            '<button type="button" class="rp-dismiss-notice button button-secondary" '.
                'data-plugin="%s" data-nonce="%s" '.
                'style="flex-shrink:0;white-space:nowrap;min-width:130px">%s</button>'.
            '</div>',
            esc_attr( $notice_class ),
            esc_attr( $slug_safe ),
            $icon,
            $message,
            esc_attr( $slug_safe ),
            esc_attr( $nonce ),
            esc_html( $dismiss_label )
        );

        // Inline dismiss script — printed only once even if multiple plugins use this SDK.
        static $js_printed = false;
        if ( ! $js_printed ) {
            $js_printed = true;
            echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                document.querySelectorAll(".rp-dismiss-notice").forEach(function(btn) {
                    var notice = btn.closest(".rp-license-notice");
                    btn.addEventListener("click", function() {
                        var plugin = btn.dataset.plugin;
                        var nonce  = btn.dataset.nonce;
                        btn.disabled = true;
                        btn.textContent = "Dismissed…";
                        notice.style.transition = "opacity 0.3s ease";
                        notice.style.opacity = "0.4";
                        fetch(ajaxurl, {
                            method: "POST",
                            headers: {"Content-Type":"application/x-www-form-urlencoded"},
                            body: "action=rp_dismiss_notice_" + plugin + "&nonce=" + nonce
                        }).then(function() {
                            notice.remove();
                        }).catch(function() {
                            notice.remove(); // remove anyway on network error
                        });
                    });
                });
            });
            </script>';
        }
    }

    // =========================================================================
    // ── SETTINGS TAB UI ───────────────────────────────────────────────────────
    // =========================================================================

    /**
     * Render the full License settings tab HTML.
     *
     * Call this inside your plugin's settings page when the "license" tab
     * (or section) is active. The method outputs HTML directly.
     *
     * Example:
     *   public function render_settings_page() {
     *       $tab = $_GET['tab'] ?? 'general';
     *       // … render your tab nav …
     *       if ( $tab === 'license' ) {
     *           $GLOBALS['my_plugin_license']->render_settings_tab();
     *       }
     *   }
     */
    public function render_settings_tab() {
        $data          = $this->get_license_data();
        $is_licensed   = $this->is_licensed();
        $slug_safe     = sanitize_key( $this->plugin_slug );
        $nonce         = wp_create_nonce( 'rp_license_nonce' );
        $portal_url    = self::SERVER_URL;
        $patron_status = $data['patron_status'] ?? '';
        $patron_name   = $data['patron_name']   ?? '';
        $key_display   = $is_licensed ? $this->mask_key( $data['license_key'] ) : '';
        $last_check    = isset( $data['last_check'] )
            ? date_i18n( get_option('date_format') . ' ' . get_option('time_format'), $data['last_check'] )
            : 'Never';
        ?>
        <div class="fraud-settings-card">
            <div class="fraud-card-header">
                <h2>🔑 License</h2>
                <p>Activate your license to receive plugin updates and support.</p>
            </div>

            <?php if ( $is_licensed ) : ?>
            <!-- ── Activated state ─────────────────────────────────────── -->

            <div class="fraud-field-group">
                <label class="fraud-label">Status</label>
                <div class="fraud-input-wrap">
                    <?php if ( $patron_status === 'active' ) : ?>
                        <div style="display:flex;align-items:center;gap:10px">
                            <span style="display:inline-flex;align-items:center;gap:6px;background:var(--os-low-bg);color:var(--os-low);border:1px solid var(--os-low-border);border-radius:3px;padding:5px 12px;font-size:13px;font-weight:500">
                                ✓ Active License
                            </span>
                            <?php if ( $patron_name ) : ?>
                                <span style="font-size:13px;color:var(--os-text-muted)">Welcome, <?php echo esc_html( $patron_name ); ?>!</span>
                            <?php endif; ?>
                        </div>

                    <?php elseif ( $patron_status === 'cancelled' ) : ?>
                        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                            <span style="display:inline-flex;align-items:center;gap:6px;background:var(--os-medium-bg);color:var(--os-medium);border:1px solid var(--os-medium-border);border-radius:3px;padding:5px 12px;font-size:13px;font-weight:500">
                                ⚠ Membership Cancelled
                            </span>
                            <a href="https://www.patreon.com/RyanPlugins" target="_blank" class="fraud-btn" style="font-size:12px;padding:0 12px;line-height:2">Resubscribe on Patreon</a>
                        </div>
                        <span class="fraud-hint">Plugin continues to work. Resubscribe to receive updates and new features.</span>

                    <?php else : ?>
                        <span style="display:inline-flex;align-items:center;gap:6px;background:var(--os-accent-light);color:var(--os-accent);border:1px solid var(--os-accent-border);border-radius:3px;padding:5px 12px;font-size:13px;font-weight:500">
                            ● Activated
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="fraud-field-group">
                <label class="fraud-label">License Key</label>
                <div class="fraud-input-wrap">
                    <code style="font-family:Consolas,monospace;font-size:13px;background:var(--os-bg);padding:6px 10px;border-radius:3px;border:1px solid var(--os-border);color:var(--os-text-muted)">
                        <?php echo esc_html( $key_display ); ?>
                    </code>
                </div>
            </div>

            <div class="fraud-field-group">
                <label class="fraud-label">Last Validated</label>
                <div class="fraud-input-wrap">
                    <span style="font-size:13px;color:var(--os-text-muted)"><?php echo esc_html( $last_check ); ?></span>
                    <span class="fraud-hint">Plugin re-validates automatically every 7 days.</span>
                </div>
            </div>

            <div class="fraud-field-group">
                <label class="fraud-label">Actions</label>
                <div class="fraud-input-wrap" style="flex-direction:row;gap:10px;flex-wrap:wrap">
                    <button type="button" id="rp-recheck-btn" class="fraud-btn-outline"
                        data-plugin="<?php echo esc_attr( $slug_safe ); ?>"
                        data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        ↺ Re-validate Now
                    </button>
                    <button type="button" id="rp-deactivate-btn" class="fraud-btn-outline fraud-reset-btn"
                        data-plugin="<?php echo esc_attr( $slug_safe ); ?>"
                        data-nonce="<?php echo esc_attr( $nonce ); ?>"
                        onclick="return confirm('Deactivate this license key? The plugin will continue to work but updates will stop.')">
                        Deactivate License
                    </button>
                </div>
                <div id="rp-license-msg" style="margin-top:8px;font-size:13px"></div>
            </div>

            <?php else : ?>
            <!-- ── Not activated state ────────────────────────────────── -->

            <div class="fraud-field-group">
                <label class="fraud-label">Activate Your License</label>
                <div class="fraud-input-wrap">
                    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                        <input type="text" id="rp-license-key-input" class="fraud-input fraud-input-mono"
                            placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX"
                            style="max-width:420px;text-transform:uppercase">
                        <button type="button" id="rp-activate-btn" class="fraud-btn"
                            data-plugin="<?php echo esc_attr( $slug_safe ); ?>"
                            data-nonce="<?php echo esc_attr( $nonce ); ?>">
                            Activate License
                        </button>
                    </div>
                    <div id="rp-license-msg" style="margin-top:8px;font-size:13px"></div>
                    <span class="fraud-hint">
                        Don't have a key?
                        <a href="<?php echo esc_url( $portal_url ); ?>" target="_blank">Generate one on the RyanPlugins License Portal →</a>
                    </span>
                </div>
            </div>

            <?php endif; ?>

            <div class="fraud-info-box" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
                <span>Your license key works across <strong>all</strong> RyanPlugins on this site.</span>
                <a href="<?php echo esc_url( $portal_url ); ?>" target="_blank" class="fraud-btn-outline" style="font-size:12px;padding:0 12px;line-height:2">
                    🔑 License Portal
                </a>
            </div>
        </div><!-- /.fraud-settings-card -->

        <script>
        (function($) {
            'use strict';

            var plugin  = '<?php echo esc_js( $slug_safe ); ?>';
            var ajaxUrl = typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php';

            /**
             * Show a success or error message inside the given element.
             */
            function showMsg( $el, msg, type ) {
                $el.css( 'color', type === 'success' ? 'var(--os-low)' : 'var(--os-high)' ).text( msg );
            }

            // ── Activate ──────────────────────────────────────────────────
            $( '#rp-activate-btn' ).on( 'click', function() {
                var $btn = $( this ).prop( 'disabled', true ).text( 'Activating…' );
                var key  = $( '#rp-license-key-input' ).val().trim();
                var $msg = $( '#rp-license-msg' );

                if ( ! key ) {
                    showMsg( $msg, 'Please enter your license key.', 'error' );
                    $btn.prop( 'disabled', false ).text( 'Activate License' );
                    return;
                }

                $.post( ajaxUrl, {
                    action:      'rp_activate_license_' + plugin,
                    nonce:       $btn.data( 'nonce' ),
                    license_key: key,
                }, function( res ) {
                    if ( res.success ) {
                        showMsg( $msg, '✓ ' + res.data.message, 'success' );
                        setTimeout( function() { location.reload(); }, 1200 );
                    } else {
                        showMsg( $msg, '✗ ' + res.data.message, 'error' );
                        $btn.prop( 'disabled', false ).text( 'Activate License' );
                    }
                } ).fail( function() {
                    showMsg( $msg, '✗ Network error. Please try again.', 'error' );
                    $btn.prop( 'disabled', false ).text( 'Activate License' );
                } );
            } );

            // ── Deactivate ────────────────────────────────────────────────
            $( '#rp-deactivate-btn' ).on( 'click', function() {
                var $btn = $( this ).prop( 'disabled', true ).text( 'Deactivating…' );
                var $msg = $( '#rp-license-msg' );

                $.post( ajaxUrl, {
                    action: 'rp_deactivate_license_' + plugin,
                    nonce:  $btn.data( 'nonce' ),
                }, function( res ) {
                    if ( res.success ) {
                        showMsg( $msg, '✓ License deactivated.', 'success' );
                        setTimeout( function() { location.reload(); }, 800 );
                    } else {
                        $btn.prop( 'disabled', false ).text( 'Deactivate License' );
                    }
                } );
            } );

            // ── Re-validate ───────────────────────────────────────────────
            $( '#rp-recheck-btn' ).on( 'click', function() {
                var $btn = $( this ).prop( 'disabled', true ).text( 'Checking…' );
                var $msg = $( '#rp-license-msg' );

                $.post( ajaxUrl, {
                    action:      'rp_activate_license_' + plugin,
                    nonce:       $btn.data( 'nonce' ),
                    license_key: '<?php echo esc_js( $data['license_key'] ?? '' ); ?>',
                }, function( res ) {
                    $btn.prop( 'disabled', false ).text( '↺ Re-validate Now' );
                    if ( res.success ) {
                        showMsg( $msg, '✓ License is valid. Status: ' + res.data.patron_status, 'success' );
                        setTimeout( function() { location.reload(); }, 1500 );
                    } else {
                        showMsg( $msg, '✗ ' + res.data.message, 'error' );
                    }
                } );
            } );

        })(jQuery);
        </script>
        <?php
    }

    // =========================================================================
    // ── HELPERS ───────────────────────────────────────────────────────────────
    // =========================================================================

    /**
     * Mask all but the first segment of a license key.
     * e.g. "ABCD1234-EFGH5678-IJKL9012" → "ABCD1234-********-********"
     *
     * @param  string $key
     * @return string
     */
    private function mask_key( $key ) {
        $parts = explode( '-', $key );

        if ( count( $parts ) < 2 ) {
            return substr( $key, 0, 8 ) . '…';
        }

        return $parts[0] . '-' . implode(
            '-',
            array_map(
                fn( $p ) => str_repeat( '*', strlen( $p ) ),
                array_slice( $parts, 1 )
            )
        );
    }

} // class RyanPlugins_License

endif; // class_exists check — safe to include in multiple plugins.
