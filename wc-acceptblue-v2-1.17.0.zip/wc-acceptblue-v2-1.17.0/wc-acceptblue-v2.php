<?php
/**
 * Plugin Name: accept.blue Payment Gateway v2
 * Description: accept.blue Payment Gateway v2 for WooCommerce (Tokenization, Google Pay and Surcharge)
 * Version: 1.17.0
 * Author: RyanPlugins
 * Author URI: https://ryanplugins.net/
 * Plugin URI: https://www.patreon.com/RyanPlugins
 *
 * WC requires at least: 3.0
 * WC tested up to: 9.7.0
 * WC Subscription tested up to: 7.1.0
 */

defined( 'ABSPATH' ) || exit;

// =============================================================================
// Constants
// =============================================================================

$plugin_data    = get_file_data( __FILE__, array( 'Version' => 'Version' ), false );
$plugin_version = $plugin_data['Version'];

define( 'AB_V2_VERSION', $plugin_version );

if ( ! defined( 'AB_V2_PLUGIN_FILE' ) ) {
    define( 'AB_V2_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'AB_V2_PLUGIN_DIR' ) ) {
    define( 'AB_V2_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

// =============================================================================
// Bootstrap — only when WooCommerce is active
// =============================================================================

if ( in_array(
    'woocommerce/woocommerce.php',
    apply_filters( 'active_plugins', get_option( 'active_plugins' ) )
) ) {
    add_action( 'plugins_loaded', 'wc_acceptblue_v2_init' );
}

function wc_acceptblue_v2_init() {
    // ── Core classes ─────────────────────────────────────────────────────────
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-log-masker.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-api.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-addons.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-google-pay-actions.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-google-pay-checkout.php';

    // ── License SDK ───────────────────────────────────────────────────────────
    require_once AB_V2_PLUGIN_DIR . 'includes/class-ryanplugins-license.php';
    if ( class_exists( 'RyanPlugins_License' ) ) {
        $GLOBALS['wc_acceptblue_v2_license'] = new RyanPlugins_License(
            'wc-acceptblue-v2',
            'accept.blue Payment Gateway v2',
            AB_V2_PLUGIN_FILE
        );
        $GLOBALS['wc_acceptblue_v2_license']->init();
    }

    // ── One-time migration: copy Google Pay settings from the main gateway ───
    // Runs once when upgrading from < 1.15.3 where those keys lived in
    // woocommerce_acceptbluev2_settings. Safe to call on every load because
    // it exits immediately once the migration flag is set.
    wc_acceptblue_v2_migrate_googlepay_settings();

    // ── Hook files ───────────────────────────────────────────────────────────
    require_once AB_V2_PLUGIN_DIR . 'includes/admin-actions.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/custom-actions.php';

    // ── Google Pay actions (needs gateway instance — defer to woocommerce_init)
    add_action( 'woocommerce_init', 'wc_acceptblue_v2_init_google_pay', 20 );
}

/**
 * Bootstrap WC_AcceptBlue_Google_Pay_Actions once WooCommerce is fully loaded.
 * Deferred to priority 20 so the gateway settings are available.
 *
 * Express buttons (product / cart / checkout page) work as long as the
 * Google Pay gateway is enabled — even when the main credit-card gateway
 * (acceptbluev2) is disabled. When the main gateway IS enabled it is used as
 * the gateway object because it carries all the enqueue / AJAX wiring.
 * When it is disabled we synthesise a minimal stand-in from the Google Pay
 * gateway's own settings so express buttons still render correctly.
 */
function wc_acceptblue_v2_init_google_pay() {
    if ( ! function_exists( 'WC' ) ) return;

    $wc = WC();
    if ( ! $wc || ! is_callable( array( $wc, 'payment_gateways' ) ) ) return;

    $registry = $wc->payment_gateways();
    if ( ! $registry || ! is_callable( array( $registry, 'payment_gateways' ) ) ) return;

    $gateways     = $registry->payment_gateways();
    $main_gateway = $gateways['acceptbluev2']                    ?? null;
    $gpay_gateway = $gateways['acceptbluev2_googlepay_checkout'] ?? null;

    // Google Pay express buttons need the Google Pay gateway to be enabled
    // and have a gateway_merchant_id configured (empty ID causes OR_BIBED_11).
    $gpay_settings     = get_option( 'woocommerce_acceptbluev2_googlepay_checkout_settings', array() );
    $gpay_enabled      = ( $gpay_settings['enabled']            ?? 'no' ) === 'yes';
    $gateway_merch_id  = trim( $gpay_settings['gateway_merchant_id'] ?? '' );

    if ( ! $gpay_enabled || empty( $gateway_merch_id ) ) {
        // Google Pay not configured — no express buttons.
        return;
    }

    // Prefer the live main gateway instance (it carries AJAX action registrations).
    // Fall back to a minimal proxy that returns the right property values from
    // the Google Pay option so WC_AcceptBlue_Google_Pay_Actions works standalone.
    if ( $main_gateway && $main_gateway->is_enabled() ) {
        $gateway_for_actions = $main_gateway;
    } elseif ( $main_gateway ) {
        // Main gateway exists but is disabled — patch its Google Pay properties
        // from the dedicated option so express buttons still work.
        $main_gateway->googlepay                           = $gpay_enabled;
        $main_gateway->gateway_merchant_id                = $gpay_settings['gateway_merchant_id']  ?? '';
        $main_gateway->google_merchant_id                 = $gpay_settings['google_merchant_id']   ?? '';
        $main_gateway->google_merchant_name               = $gpay_settings['google_merchant_name'] ?? '';
        $main_gateway->card_networks                      = $gpay_settings['card_networks']        ?? array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' );
        $main_gateway->card_auth_methods                  = $gpay_settings['card_auth_methods']    ?? array( 'PAN_ONLY' );
        $main_gateway->button_color                       = $gpay_settings['button_color']         ?? 'default';
        $main_gateway->button_type                        = $gpay_settings['button_type']          ?? 'buy';
        $main_gateway->button_locale                      = $gpay_settings['button_locale']        ?? 'en';
        $main_gateway->google_pay_billing_address_required = ( ( $gpay_settings['google_pay_billing_address_required'] ?? 'no' ) === 'yes' );
        $main_gateway->google_pay_phone_number_required    = ( ( $gpay_settings['google_pay_phone_number_required']    ?? 'no' ) === 'yes' );
        $main_gateway->google_pay_button_product_enable    = ( ( $gpay_settings['google_pay_button_product_enable']  ?? 'yes' ) === 'yes' );
        $main_gateway->google_pay_button_cart_enable       = ( ( $gpay_settings['google_pay_button_cart_enable']     ?? 'yes' ) === 'yes' );
        $main_gateway->google_pay_button_checkout_enable   = ( ( $gpay_settings['google_pay_button_checkout_enable'] ?? 'yes' ) === 'yes' );
        $main_gateway->order_review_enable                 = ( ( $gpay_settings['order_review_enable'] ?? 'no' ) === 'yes' );
        $main_gateway->order_review_page                   = $gpay_settings['order_review_page'] ?? '';
        $gateway_for_actions = $main_gateway;
    } elseif ( $gpay_gateway ) {
        // Main gateway not registered at all — use the Google Pay gateway itself.
        $gateway_for_actions = $gpay_gateway;
    } else {
        return;
    }

    $gpay = new WC_AcceptBlue_Google_Pay_Actions( $gateway_for_actions );
    $gpay->register_hooks();
}

// =============================================================================
// Settings migration  (v1.15.2 -> v1.15.3)
// =============================================================================

/**
 * One-time migration: move all Google Pay keys from the main gateway's
 * option (woocommerce_acceptbluev2_settings) into the new dedicated option
 * (woocommerce_acceptbluev2_googlepay_checkout_settings).
 *
 * The function is idempotent — a migration flag prevents repeat runs.
 * Existing values in the new option are preserved so re-activation never
 * overwrites changes made directly in the new settings page.
 */
function wc_acceptblue_v2_migrate_googlepay_settings() {
    if ( get_option( 'ab_v2_gpay_settings_migrated_115' ) ) {
        return; // Already done
    }

    $main_settings = get_option( 'woocommerce_acceptbluev2_settings', array() );
    if ( empty( $main_settings ) ) {
        update_option( 'ab_v2_gpay_settings_migrated_115', '1' );
        return;
    }

    // Keys to move across, with safe defaults for any missing values
    $gpay_keys = array(
        'googlepay'                          => 'no',
        // API credentials — copied from main gateway as starting point
        'testmode'                            => 'yes',
        'test_api_key'                        => '',
        'live_api_key'                        => '',
        'test_pin'                            => '',
        'live_pin'                            => '',
        // Google Pay settings
        'google_merchant_id'                 => '',
        'google_merchant_name'               => '',
        'gateway_merchant_id'                => '',
        'google_pay_button_product_enable'   => 'yes',
        'google_pay_button_cart_enable'      => 'yes',
        'google_pay_button_checkout_enable'  => 'yes',
        'button_color'                        => 'default',
        'button_type'                         => 'buy',
        'button_locale'                       => 'en',
        'card_networks'                       => array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' ),
        'card_auth_methods'                   => array( 'PAN_ONLY' ),
        'google_pay_billing_address_required' => 'no',
        'google_pay_phone_number_required'    => 'no',
        'order_review_enable'                 => 'no',
        'order_review_page'                   => '',
    );

    $new_settings = get_option( 'woocommerce_acceptbluev2_googlepay_checkout_settings', array() );

    foreach ( $gpay_keys as $key => $default ) {
        // Only copy if the new settings page has not already saved a value
        if ( ! array_key_exists( $key, $new_settings ) ) {
            $new_settings[ $key ] = $main_settings[ $key ] ?? $default;
        }
    }

    // Map the old 'googlepay' enable flag to the new gateway 'enabled' key
    if ( ! array_key_exists( 'enabled', $new_settings ) ) {
        $new_settings['enabled'] = ( ( $main_settings['googlepay'] ?? 'no' ) === 'yes' ) ? 'yes' : 'no';
    }

    // Preserve existing title / description if already set
    if ( ! array_key_exists( 'title', $new_settings ) ) {
        $new_settings['title'] = __( 'Google Pay', 'woocommerce' );
    }
    if ( ! array_key_exists( 'description', $new_settings ) ) {
        $new_settings['description'] = __( 'Pay quickly and securely using Google Pay.', 'woocommerce' );
    }

    update_option( 'woocommerce_acceptbluev2_googlepay_checkout_settings', $new_settings );

    // Remove migrated keys from the main settings to keep things clean
    $keys_to_remove = array_keys( $gpay_keys );
    $keys_to_remove[] = 'googlepay'; // the old enable flag
    foreach ( $keys_to_remove as $key ) {
        unset( $main_settings[ $key ] );
    }
    update_option( 'woocommerce_acceptbluev2_settings', $main_settings );

    // Mark migration complete
    update_option( 'ab_v2_gpay_settings_migrated_115', '1' );
}

// =============================================================================
// WooCommerce gateway registration
// =============================================================================

add_filter( 'woocommerce_payment_gateways', 'wc_acceptblue_v2_add_gateway' );

/**
 * Register the correct gateway class:
 *   - WC_Gateway_AcceptBlue_v2_Addons when WooCommerce Subscriptions or
 *     WooCommerce Pre-Orders is active (extends the base gateway).
 *   - WC_Gateway_AcceptBlue_v2 otherwise.
 *
 * @param array $methods
 * @return array
 */
function wc_acceptblue_v2_add_gateway( $methods ) {
    if (
        class_exists( 'WC_Subscriptions_Order' ) ||
        class_exists( 'WC_Pre_Orders_Order' )
    ) {
        $methods[] = 'WC_Gateway_AcceptBlue_v2_Addons';
    } else {
        $methods[] = 'WC_Gateway_AcceptBlue_v2';
    }
    // Google Pay as a dedicated checkout payment method option
    $methods[] = 'WC_Gateway_AcceptBlue_v2_GooglePay_Checkout';
    return $methods;
}
