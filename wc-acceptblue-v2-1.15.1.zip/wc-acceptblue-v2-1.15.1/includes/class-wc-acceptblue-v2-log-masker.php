<?php
/**
 * accept.blue Payment Gateway v2 — Log Masker
 *
 * Scrubs sensitive fields from request params and API responses before
 * they are written to the WooCommerce debug log.
 *
 * Masked field categories
 * ───────────────────────
 * Payment data      : card number, cvv2, payment token/source, card_ref
 * Auth credentials  : Authorization header, api_key, api_pin, password
 * Cardholder PII    : full name, street address, phone number, email
 * Tokenization data : nonce values, hosted-token references
 *
 * Safe fields (kept intact)
 * ─────────────────────────
 * amount, currency, order number, transaction ID, last4 digits, card type,
 * expiry month/year, status, error messages, response codes, description.
 *
 * Masking rules
 * ─────────────
 * Card numbers   → first 6 + ******* + last 4    e.g. 476153*******1118
 * Tokens/sources → first 4 + *** + last 4         e.g. nonce***1234
 * CVV            → ***
 * Names          → first initial + ***            e.g. J***
 * Address        → first token + ***              e.g. 123 ***
 * Phone          → first 3 digits + *******       e.g. 555*******
 * Email          → user[0] + *** @ domain         e.g. j***@example.com
 * Auth header    → Basic [REDACTED]
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */

defined( 'ABSPATH' ) || exit;

class WC_AcceptBlue_Log_Masker {

    // ── Field name maps ──────────────────────────────────────────────────────

    /** Fields whose entire value is a payment card number or raw PAN. */
    const CARD_NUMBER_FIELDS = array( 'card', 'number', 'card_number' );

    /** Fields containing a CVV / CVC / security code. */
    const CVV_FIELDS = array( 'cvv2', 'cvv', 'cvc', 'card_code' );

    /**
     * Fields containing a payment token, source ref, or card reference.
     * These are partially masked (first 4 + *** + last 4).
     */
    const TOKEN_FIELDS = array( 'token', 'source', 'card_ref', 'cardRef', 'card_token', 'payment_token' );

    /** Credential fields — fully redacted. */
    const CREDENTIAL_FIELDS = array( 'api_key', 'api_pin', 'password', 'Authorization', 'threeds_key', 'public_key' );

    /** Name fields — show first initial only. */
    const NAME_FIELDS = array( 'first_name', 'last_name', 'name', 'card_name', 'name_on_card' );

    /** Address / street fields. */
    const ADDRESS_FIELDS = array( 'street', 'street2', 'address', 'address_1', 'address_2' );

    /** Phone fields. */
    const PHONE_FIELDS = array( 'phone', 'phoneNumber', 'phone_number' );

    /** Email fields. */
    const EMAIL_FIELDS = array( 'email', 'emailAddress', 'billing_email' );

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Mask sensitive fields in a request params array or JSON string.
     *
     * @param  array|string $params  Raw params (array or JSON string).
     * @return string                JSON string safe for logging.
     */
    public static function mask_request( $params ) {
        if ( is_string( $params ) ) {
            $decoded = json_decode( $params, true );
            // If it isn't valid JSON just treat as plain string
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                return self::mask_string( $params );
            }
            $params = $decoded;
        }

        if ( ! is_array( $params ) ) {
            return (string) $params;
        }

        return wp_json_encode( self::mask_array( $params ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
    }

    /**
     * Mask sensitive fields in an API response object/array.
     *
     * @param  mixed $response  Decoded response body (object, array, or string).
     * @return string           JSON string safe for logging.
     */
    public static function mask_response( $response ) {
        if ( is_object( $response ) ) {
            $response = json_decode( wp_json_encode( $response ), true );
        }

        if ( is_array( $response ) ) {
            return wp_json_encode( self::mask_array( $response ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
        }

        return (string) $response;
    }

    // ── Core masking logic ───────────────────────────────────────────────────

    /**
     * Recursively walk an array and mask sensitive keys.
     *
     * @param  array $data
     * @return array
     */
    private static function mask_array( array $data ) {
        $masked = array();

        foreach ( $data as $key => $value ) {
            // Recurse into nested arrays/objects
            if ( is_array( $value ) ) {
                $masked[ $key ] = self::mask_array( $value );
                continue;
            }
            if ( is_object( $value ) ) {
                $masked[ $key ] = self::mask_array( (array) $value );
                continue;
            }

            $masked[ $key ] = self::mask_value( $key, $value );
        }

        return $masked;
    }

    /**
     * Return the masked version of a single key/value pair.
     *
     * @param  string $key
     * @param  mixed  $value
     * @return mixed
     */
    private static function mask_value( $key, $value ) {
        if ( empty( $value ) && $value !== 0 ) {
            return $value;
        }

        $key_lower = strtolower( $key );

        // Credentials — fully redacted
        if ( in_array( $key, self::CREDENTIAL_FIELDS, true ) ||
             in_array( $key_lower, array_map( 'strtolower', self::CREDENTIAL_FIELDS ), true ) ) {
            return '[REDACTED]';
        }

        // Card number (PAN)
        if ( in_array( $key_lower, self::CARD_NUMBER_FIELDS, true ) ) {
            return self::mask_pan( (string) $value );
        }

        // CVV
        if ( in_array( $key_lower, self::CVV_FIELDS, true ) ) {
            return '***';
        }

        // Payment tokens / sources
        if ( in_array( $key, self::TOKEN_FIELDS, true ) ||
             in_array( $key_lower, array_map( 'strtolower', self::TOKEN_FIELDS ), true ) ) {
            return self::mask_token( (string) $value );
        }

        // Cardholder name
        if ( in_array( $key_lower, self::NAME_FIELDS, true ) ) {
            return self::mask_name( (string) $value );
        }

        // Address / street
        if ( in_array( $key_lower, self::ADDRESS_FIELDS, true ) ) {
            return self::mask_address( (string) $value );
        }

        // Phone
        if ( in_array( $key_lower, self::PHONE_FIELDS, true ) ) {
            return self::mask_phone( (string) $value );
        }

        // Email
        if ( in_array( $key_lower, self::EMAIL_FIELDS, true ) ) {
            return self::mask_email( (string) $value );
        }

        // Heuristic: value looks like a raw card number (13–19 digits, no dashes/spaces handled)
        if ( is_string( $value ) && preg_match( '/^\d{13,19}$/', preg_replace( '/[\s\-]/', '', $value ) ) ) {
            return self::mask_pan( $value );
        }

        return $value;
    }

    // ── Masking helpers ──────────────────────────────────────────────────────

    /**
     * Mask a Primary Account Number (PAN / card number).
     * Keeps BIN (first 6) and last 4, masks the rest.
     *
     * 4761530001111118  →  476153*******1118
     *
     * @param  string $pan
     * @return string
     */
    public static function mask_pan( $pan ) {
        $digits = preg_replace( '/\D/', '', $pan );
        $len    = strlen( $digits );

        if ( $len < 13 ) {
            // Too short to be a real PAN — mask entirely
            return str_repeat( '*', $len );
        }

        $visible_start = 6;
        $visible_end   = 4;
        $mask_len      = $len - $visible_start - $visible_end;

        return substr( $digits, 0, $visible_start )
             . str_repeat( '*', max( $mask_len, 1 ) )
             . substr( $digits, -$visible_end );
    }

    /**
     * Mask a payment token or source reference.
     * Keeps prefix type indicator + last 4.
     *
     * nonce-abc123xyz789  →  nonc***789
     * tkn-00112233445566  →  tkn-***5566
     *
     * @param  string $token
     * @return string
     */
    public static function mask_token( $token ) {
        if ( strlen( $token ) <= 8 ) {
            return str_repeat( '*', strlen( $token ) );
        }
        return substr( $token, 0, 4 ) . '***' . substr( $token, -4 );
    }

    /**
     * Mask a person's name — keep first initial only.
     *
     * John Smith  →  J***
     *
     * @param  string $name
     * @return string
     */
    public static function mask_name( $name ) {
        $name = trim( $name );
        if ( empty( $name ) ) {
            return '';
        }
        return mb_substr( $name, 0, 1 ) . '***';
    }

    /**
     * Mask a street address — keep street number, mask the rest.
     *
     * 123 Main Street  →  123 ***
     *
     * @param  string $address
     * @return string
     */
    public static function mask_address( $address ) {
        $address = trim( $address );
        if ( empty( $address ) ) {
            return '';
        }
        // Keep the first space-separated token (usually the house number)
        $parts = preg_split( '/\s+/', $address, 2 );
        return $parts[0] . ' ***';
    }

    /**
     * Mask a phone number — keep country/area code (first 3 digits), mask the rest.
     *
     * 5551234567  →  555*******
     *
     * @param  string $phone
     * @return string
     */
    public static function mask_phone( $phone ) {
        $digits = preg_replace( '/\D/', '', $phone );
        if ( strlen( $digits ) <= 3 ) {
            return str_repeat( '*', strlen( $digits ) );
        }
        return substr( $digits, 0, 3 ) . str_repeat( '*', strlen( $digits ) - 3 );
    }

    /**
     * Mask an email address — keep first char of local part and full domain.
     *
     * john.smith@example.com  →  j***@example.com
     *
     * @param  string $email
     * @return string
     */
    public static function mask_email( $email ) {
        $email = trim( $email );
        if ( ! strpos( $email, '@' ) ) {
            return '***';
        }
        list( $local, $domain ) = explode( '@', $email, 2 );
        return mb_substr( $local, 0, 1 ) . '***@' . $domain;
    }

    /**
     * Mask an Authorization header value.
     * Strips the credential entirely, keeps the scheme.
     *
     * Basic dXNlcjpwYXNz  →  Basic [REDACTED]
     *
     * @param  string $header
     * @return string
     */
    public static function mask_auth_header( $header ) {
        return preg_replace( '/^(Basic|Bearer|Digest)\s+.+$/i', '$1 [REDACTED]', $header );
    }

    /**
     * Heuristic scan of a plain string for card number patterns and redact them.
     * Used as a last-resort sanitiser on unstructured log strings.
     *
     * @param  string $text
     * @return string
     */
    public static function mask_string( $text ) {
        // 13-19 digit sequences (possible PANs)
        return preg_replace_callback(
            '/\b(\d[\d \-]{11,17}\d)\b/',
            function ( $matches ) {
                $digits = preg_replace( '/\D/', '', $matches[1] );
                return self::mask_pan( $digits );
            },
            $text
        );
    }
}
