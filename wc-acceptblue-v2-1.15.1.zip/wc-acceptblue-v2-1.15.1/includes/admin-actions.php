<?php
/**
 * accept.blue Payment Gateway v2 — Admin Actions
 *
 * All WordPress admin-side hooks:
 *   - Plugin action links (Docs / Support)
 *   - Gateway method title icon in WooCommerce → Payments list
 *   - WooCommerce HPOS (custom_order_tables) compatibility declaration
 *   - WooCommerce Blocks (cart_checkout_blocks) compatibility declaration
 *   - WooCommerce Blocks payment method type registration
 *
 * Loaded by wc-acceptblue-v2.php after class files are included.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */

defined( 'ABSPATH' ) || exit;

// =============================================================================
// 1. WooCommerce feature compatibility declarations
// =============================================================================

/**
 * Declare HPOS (High-Performance Order Storage) compatibility.
 * Must run on before_woocommerce_init — fires very early, before WC loads.
 */
add_action( 'before_woocommerce_init', 'acceptblue_v2_declare_hpos_compatibility' );

function acceptblue_v2_declare_hpos_compatibility() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            AB_V2_PLUGIN_FILE,
            true
        );
    }
}

/**
 * Declare Cart & Checkout Blocks compatibility.
 */
add_action( 'before_woocommerce_init', 'acceptblue_v2_declare_blocks_compatibility' );

function acceptblue_v2_declare_blocks_compatibility() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'cart_checkout_blocks',
            AB_V2_PLUGIN_FILE,
            true
        );
    }
}

// =============================================================================
// 2. WooCommerce Blocks — payment method type registration
// =============================================================================

add_action( 'woocommerce_blocks_loaded', 'acceptblue_v2_register_blocks_payment_method' );

function acceptblue_v2_register_blocks_payment_method() {
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    require_once plugin_dir_path( AB_V2_PLUGIN_FILE ) . 'includes/class-wc-acceptblue-v2-block-checkout.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function ( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            $payment_method_registry->register( new WC_AcceptBlue_V2_Gateway_Blocks() );
        }
    );
}

// =============================================================================
// 3. Plugin action links — Docs & Support
// =============================================================================

add_filter( 'plugin_action_links_' . plugin_basename( AB_V2_PLUGIN_FILE ), 'acceptblue_v2_plugin_action_links' );

function acceptblue_v2_plugin_action_links( $links ) {
    $plugin_links = array(
        '<a href="' . esc_url( 'https://acceptblue.ryanplugins.net/blog/docs/accept-blue-version-2/' ) . '" target="_blank">'
            . esc_html__( 'Docs', 'woocommerce' ) . '</a>',
        '<a href="' . esc_url( 'https://www.patreon.com/c/RyanPlugins' ) . '" target="_blank">'
            . esc_html__( 'Support', 'woocommerce' ) . '</a>',
    );
    return array_merge( $plugin_links, $links );
}

// =============================================================================
// 4. Gateway method title — logo icon in WooCommerce → Payments list
// =============================================================================

/**
 * Append the accept.blue logo next to the gateway title in the admin
 * WooCommerce → Payments screen, regardless of the frontend icon toggle.
 */
add_filter( 'woocommerce_gateway_method_title', 'acceptblue_v2_admin_gateway_method_title', 10, 2 );

function acceptblue_v2_admin_gateway_method_title( $title, $gateway ) {
    if ( ! isset( $gateway->id ) || $gateway->id !== 'acceptbluev2' ) {
        return $title;
    }

    $logo_url = plugins_url( 'assets/images/icons/logo.png', AB_V2_PLUGIN_FILE );
    $title   .= ' <img src="' . esc_url( $logo_url ) . '"'
              . ' alt="accept.blue"'
              . ' style="height:20px;vertical-align:middle;margin-left:6px;" />';

    return $title;
}

// =============================================================================
// 5. Configuration notices — missing Tokenization Source Key
// =============================================================================

add_action( 'admin_notices', 'acceptblue_v2_admin_notice_missing_pk_key' );

function acceptblue_v2_admin_notice_missing_pk_key() {
    // Only on WooCommerce pages
    $screen = get_current_screen();
    if ( ! $screen || strpos( $screen->id, 'woocommerce' ) === false ) {
        return;
    }

    $settings = get_option( 'woocommerce_acceptbluev2_settings', array() );

    if ( empty( $settings ) || ( $settings['enabled'] ?? 'no' ) === 'no' ) {
        return;
    }

    // Only warn when block checkout (classic checkout iframe) or 3DS is on
    $block_checkout = ( $settings['block_support_checkout'] ?? 'no' ) === 'yes';
    $threeds        = ( $settings['threeds'] ?? 'no' ) === 'yes';

    if ( ! $block_checkout && ! $threeds ) {
        return;
    }

    $testmode = ( $settings['testmode'] ?? 'no' ) === 'yes';
    $pk_key   = $testmode
        ? ( $settings['pk_key_test'] ?? '' )
        : ( $settings['pk_key_live'] ?? '' );

    if ( ! empty( $pk_key ) ) {
        return; // Key is set — no notice needed
    }

    $mode_label = $testmode ? __( 'Test', 'woocommerce' ) : __( 'Live', 'woocommerce' );
    $settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=acceptbluev2' );

    echo '<div class="notice notice-error">';
    echo '<p><strong>' . esc_html__( 'accept.blue Payment Gateway', 'woocommerce' ) . ':</strong> ';
    printf(
        /* translators: 1: mode label (Test/Live), 2: settings URL */
        wp_kses(
            __( 'The <strong>%1$s Tokenization Source Key</strong> is not set. The hosted card input will not render on the checkout page until this key is configured. <a href="%2$s">Go to settings</a>.', 'woocommerce' ),
            array( 'strong' => array(), 'a' => array( 'href' => array() ) )
        ),
        esc_html( $mode_label ),
        esc_url( $settings_url )
    );
    echo '</p></div>';
}
