# accept.blue Payment Gateway v2 for WooCommerce

Accept credit cards securely on your WooCommerce store using the [accept.blue](https://accept.blue) payment platform. Supports classic checkout, block-based checkout, Google Pay, 3D Secure, WooCommerce Subscriptions, surcharge, Level III data, and more.

---

## Requirements

| Requirement | Minimum |
|---|---|
| WordPress | 5.8+ |
| WooCommerce | 3.0+ |
| PHP | 7.4+ |
| SSL | Required for live mode |
| WooCommerce Subscriptions | 4.0+ *(optional)* |

---

## Installation

1. Download the plugin ZIP file.
2. In your WordPress admin go to **Plugins → Add New → Upload Plugin**.
3. Upload the ZIP, click **Install Now**, then **Activate**.
4. Go to **WooCommerce → Settings → Payments** and click **accept.blue v2** to configure.

---

## Configuration

### API Keys

| Setting | Description |
|---|---|
| **Enable / Disable** | Turn the gateway on or off. |
| **Test Mode** | Use sandbox credentials for testing. Disable before going live. |
| **Live API Key** | Your accept.blue live source key. |
| **Test API Key** | Your accept.blue sandbox source key. |
| **Live Tokenization Key** | Public key for the Hosted Tokenization iframe (live). |
| **Test Tokenization Key** | Public key for the Hosted Tokenization iframe (sandbox). |

> **Where to find your keys:** Log in to [accept.blue](https://accept.blue), go to **Sources**, and copy your source key and tokenization key.

---

### General Settings

| Setting | Description |
|---|---|
| **Title** | Payment method label shown to customers at checkout. |
| **Description** | Short description shown below the payment method title. |
| **Default Order Status** | Order status after a successful payment. Use *Default* for WooCommerce automatic handling. |
| **Show Gateway Icon** | Display the accept.blue logo next to the payment method title. |

---

### Card & Payment

| Setting | Description |
|---|---|
| **Force Capture** | Automatically capture the payment immediately after authorization. Disable to use auth-only (capture later). |
| **Capture on Status** | When Force Capture is off, choose which order status triggers automatic capture. |
| **Save Card / Tokenization** | Allow customers to save cards for future purchases. |
| **Force Save Card** | Always save the card without prompting the customer. |

---

### Adjust and Capture

When **Force Capture is disabled**, the gateway authorizes the card at checkout without settling. You can later capture a different amount if the order total changes.

**How it works:**

- An **"accept.blue Payment"** panel appears in the right sidebar of the order edit screen showing the authorized amount and the current capture amount.
- If the order total has changed since authorization, a **yellow warning banner** appears at the top of the screen.
- Click **Adjust and Capture Payment** to capture the current order total (including surcharge) against the original authorization.
- The order is automatically set to **Completed** after a successful capture.
- The **Order Actions** dropdown also includes *accept.blue: Adjust and Capture Payment* as an alternative trigger.

> **API permissions required:** Your accept.blue source key needs both **Capture** and **Adjust** permissions when capturing a different amount. A transaction can only be adjusted once. International (non-US/CA) cards may not support adjustment — use a refund instead.

---

### Surcharge

| Setting | Description |
|---|---|
| **Enable Surcharge** | Apply a surcharge fee to card payments. |
| **Show Surcharge in Checkout** | Display the surcharge amount on the checkout page before payment. |
| **Manual Surcharge** | Enter a fixed surcharge value instead of pulling from the API. |
| **Surcharge Type** | Percentage or flat amount — must match your accept.blue merchant setting. |
| **Surcharge Value** | The surcharge amount or percentage. |
| **Surcharge Label** | The label shown to customers for the surcharge line item. |

---

### Level III Data

Level III line item data can qualify transactions for lower interchange rates on B2B/corporate cards.

| Setting | Description |
|---|---|
| **Enable Level III** | Send itemized line item data with each transaction. |
| **Truncate Fields** | Automatically trim field values to processor limits. |
| **Unit of Measure** | Default unit of measure for line items (e.g. "EA"). |
| **Commodity Code** | Default 8-character commodity code. |

---

### 3D Secure (3DS)

| Setting | Description |
|---|---|
| **Enable 3DS** | Enable 3D Secure authentication for extra fraud protection. |
| **Frictionless 3DS** | Attempt frictionless authentication when the issuer supports it. |

> 3DS requires the **Tokenization Source Key** to be configured.

---

### Google Pay

| Setting | Description |
|---|---|
| **Enable Google Pay** | Show the Google Pay button at checkout, product pages, and cart. |
| **Merchant ID** | Your Google Pay merchant ID (required for live mode). |
| **Environment** | Test or Production. |
| **Button Style** | Choose the Google Pay button color and style. |

> Google Pay requires HTTPS.

---

### Appearance

| Setting | Description |
|---|---|
| **Color Scheme** | **Auto** (follows system preference), **Light**, **Dark**, or **Custom**. |
| **Custom Background** | Background color for the card input area (Custom scheme only). |
| **Custom Text Color** | Text/label color (Custom scheme only). |
| **Custom Border Color** | Border color for card input fields (Custom scheme only). |

---

### Block Checkout

Enable this setting to use the gateway inside the WooCommerce Block-based Checkout page. Saved cards, 3DS, and surcharge are all supported in block checkout.

---

## WooCommerce Subscriptions

The gateway fully supports [WooCommerce Subscriptions](https://woocommerce.com/products/woocommerce-subscriptions/).

- Cards are tokenized at initial checkout and stored securely for renewals.
- Renewal payments are charged automatically using the saved token.
- **Free trial ($0) orders** are handled automatically: the card is verified with a $0 auth (immediately voided) and tokenized for future renewals — no charge is made to the customer.
- Customers can update their saved payment method from their account page.

---

## Checkout Setup Guide

The gateway supports four checkout modes. Use the table below to pick the right combination of settings for your store, then follow the matching setup steps.

| Mode | Hosted Tokenization | Tokenization Keys | 3DS | Block Checkout |
|---|---|---|---|---|
| Non-3DS Classic | Disabled | Not required | Disabled | Disabled |
| Non-3DS Block | Disabled | Not required | Disabled | Enabled |
| 3DS Classic | Disabled | **Required** | **Enabled** | ✅ Enabled |
| 3DS Block | Disabled | **Required** | **Enabled** | Enabled |
| Pay Order Redirect – Non-3DS | **Enabled** | **Required** | Disabled | Disabled |
| Pay Order Redirect – 3DS | **Enabled** | **Required** | **Enabled** | Disabled |

---

### Non-3DS Setup

Standard card entry without 3D Secure authentication. Suitable for most stores.

#### 1. Classic Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ❌ Disabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ❌ Disabled |
| **Tokenization** | Hosted Tokenization Keys | Not required |
| **Tokenization** | Paay 3D Secure | ❌ Disabled |

#### 2. Block-Based Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ✅ Enabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ❌ Disabled |
| **Tokenization** | Hosted Tokenization Keys | Not required |
| **Tokenization** | Paay 3D Secure | ❌ Disabled |

---

### 3DS Setup

Adds 3D Secure (Paay) authentication for enhanced fraud protection. Requires Tokenization Keys.

#### 1. Classic Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ✅ Enabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ❌ Disabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ✅ Enabled |

#### 2. Block-Based Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ✅ Enabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ❌ Disabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ✅ Enabled |

---

### Pay Order (Redirect) – Non-3DS Setup

The customer is redirected to a hosted payment page to enter their card. Both Classic and Block-based checkout use the **same settings** for this mode — Block Checkout must be **Disabled**.

#### 1. Classic Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ❌ Disabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ✅ Enabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ❌ Disabled |

#### 2. Block-Based Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ❌ Disabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ✅ Enabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ❌ Disabled |

> **Note:** When Hosted Tokenization is enabled, Block Checkout must be **Disabled** regardless of which checkout page style your theme uses.

---

### Pay Order (Redirect) – 3DS Setup

Hosted payment page with 3D Secure authentication.

#### 1. Classic Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ❌ Disabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ✅ Enabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ✅ Enabled |

#### 2. Block-Based Checkout

| Tab | Setting | Value |
|---|---|---|
| **General** | Checkout Block | ❌ Disabled |
| **API Keys** | All fields | ✅ Required |
| **Tokenization** | Hosted Tokenization | ✅ Enabled |
| **Tokenization** | Hosted Tokenization Keys | ✅ Required |
| **Tokenization** | Paay 3D Secure | ✅ Enabled |

---

> **Still having issues?** Please share screenshots of your accept.blue gateway settings and your WooCommerce checkout page when contacting support — this helps us troubleshoot much faster.

---

## Testing

Enable **Test Mode** and use these card numbers:

| Network | Number |
|---|---|
| Visa | `4761530001111118` |
| Discover | `6011208701117775` |

Use any future expiry (e.g. `12/26`) and any 3-digit CVV.

---

## Frequently Asked Questions

**Why is the order showing "on hold" instead of "processing"?**
Your *Default Order Status* setting may be set to On Hold. Change it to *Default* in the gateway settings.

**The surcharge is not showing at checkout.**
Make sure both *Enable Surcharge* and *Show Surcharge in Checkout* are enabled, and that the Surcharge Type and Value match your accept.blue merchant account settings exactly.

**The Adjust and Capture button is not visible.**
The button only appears when: (1) Force Capture is disabled, (2) the order was paid via accept.blue, and (3) the payment has not already been captured. Check the order notes for previous capture activity.

**Google Pay is not showing.**
Ensure your site runs over HTTPS, Google Pay is enabled in settings, and the Merchant ID is correctly set for live mode.

**I see a WooCommerce notice about `is_internal_meta_key`.**
Update to v1.15.0 or later — this was resolved by using the proper `get_transaction_id()` getter instead of `get_meta('_transaction_id')`.

---

## Changelog

See [changelog.txt](changelog.txt) for the full version history.

---

## Support

- **Documentation:** https://acceptblue.ryanplugins.net/blog/docs/accept-blue-version-2/
- **Support / Patreon:** https://www.patreon.com/c/RyanPlugins

---

## License

This plugin is proprietary software. All rights reserved.
