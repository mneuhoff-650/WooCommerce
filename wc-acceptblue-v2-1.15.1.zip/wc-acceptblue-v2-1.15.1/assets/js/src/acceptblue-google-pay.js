/**
 * accept.blue Google Pay — unified module
 *
 * Replaces the six near-identical per-page scripts:
 *   acceptblue-google-pay-product.js
 *   acceptblue-google-pay-product-addons.js
 *   acceptblue-google-pay-cart.js
 *   acceptblue-google-pay-cart-addons.js
 *   acceptblue-google-pay-checkout-page.js
 *   acceptblue-google-pay-checkout-page-addons.js
 *
 * Fixes applied:
 *   - All code wrapped in an IIFE to prevent top-level const re-declaration errors
 *     when multiple scripts share the same page.
 *   - billingAddressParameters is omitted when billingAddressRequired is false.
 *   - countryCode added to transactionInfo (required by Google Pay for production).
 *   - Silent .catch({}) blocks replaced with console.warn logging.
 *   - AJAX action driven by data attribute on the button container so a single
 *     file handles product / cart / checkout / addons variants.
 *   - addGooglePayButton() reads the container ID from a data attribute, so it
 *     works on product, cart, and checkout pages without hardcoding the wrong ID.
 *   - Ajax loader element is expected in the footer (rendered by accept_blue_google_pay_footer).
 */

(function ($) {

    'use strict';

    /* ------------------------------------------------------------------ */
    /* 1. Config — populated server-side via wp_localize_script            */
    /* ------------------------------------------------------------------ */

    // Guard: if params aren't defined (script load order issue), bail silently
    // instead of throwing "acceptblue_hosted_token_params is not defined" and
    // preventing every other script on the page from running.
    if ( typeof acceptblue_hosted_token_params === 'undefined' ) {
        console.warn('[accept.blue] Google Pay: acceptblue_hosted_token_params not defined. Check script load order.');
        return;
    }

    var p = acceptblue_hosted_token_params;

    var environment         = p.google_pay_environment;       // 'TEST' or 'PRODUCTION'
    var allowedCardNetworks = p.allowed_card_networks;
    var allowedCardAuthMethods = p.allowed_card_auth_methods;
    var merchantId          = p.google_pay_merchant_id;
    var gatewayMerchantId   = p.gateway_merchant_id;
    var merchantName        = p.google_pay_merchant_name;
    var countryCode         = p.google_pay_country_code || 'US'; // FIX: countryCode required by Google Pay
    var isUserLoggedIn      = p.is_user_logged_in;

    var billingAddressRequired = (p.google_pay_billing_address_required == 1);
    var phoneNumberRequired    = (p.google_pay_phone_number_required == 1);

    /* ------------------------------------------------------------------ */
    /* 2. Google Pay API objects                                           */
    /* ------------------------------------------------------------------ */

    var baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0
    };

    var tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: 'acceptblue',
            gatewayMerchantId: gatewayMerchantId
        }
    };

    /**
     * Build the card payment method object.
     * FIX: billingAddressParameters is only included when billingAddressRequired
     * is true, preventing a Google Pay API console warning.
     */
    function buildBaseCardPaymentMethod() {
        var params = {
            allowedAuthMethods: allowedCardAuthMethods,
            allowedCardNetworks: allowedCardNetworks,
            billingAddressRequired: billingAddressRequired
        };

        if (billingAddressRequired) {
            params.billingAddressParameters = {
                format: 'FULL',
                phoneNumberRequired: phoneNumberRequired
            };
        }

        return { type: 'CARD', parameters: params };
    }

    var baseCardPaymentMethod = buildBaseCardPaymentMethod();

    var cardPaymentMethod = Object.assign({}, baseCardPaymentMethod, {
        tokenizationSpecification: tokenizationSpecification
    });

    /* ------------------------------------------------------------------ */
    /* 3. Payments client (singleton)                                      */
    /* ------------------------------------------------------------------ */

    var paymentsClient = null;

    function getGooglePaymentsClient() {
        if (paymentsClient === null) {
            paymentsClient = new google.payments.api.PaymentsClient({ environment: environment });
        }
        return paymentsClient;
    }

    /* ------------------------------------------------------------------ */
    /* 4. isReadyToPay request                                             */
    /* ------------------------------------------------------------------ */

    function getGoogleIsReadyToPayRequest() {
        return Object.assign({}, baseRequest, {
            allowedPaymentMethods: [baseCardPaymentMethod],
            // FIX: Without this, Google Pay hides the button for logged-in users
            // who have no payment method saved in their Google account on this browser.
            // false = show the button to anyone with Google Pay enabled on their device.
            existingPaymentMethodRequired: false
        });
    }

    /* ------------------------------------------------------------------ */
    /* 5. Payment data request                                             */
    /* ------------------------------------------------------------------ */

    function getGooglePaymentDataRequest(finalPrice, currencyCode) {
        var request = Object.assign({}, baseRequest);
        request.allowedPaymentMethods = [cardPaymentMethod];
        request.transactionInfo = getGoogleTransactionInfo(finalPrice, currencyCode);
        request.merchantInfo = {
            merchantId: merchantId,
            merchantName: merchantName
        };
        request.emailRequired = (isUserLoggedIn != 1);
        return request;
    }

    /**
     * FIX: countryCode is now included — it is required by Google Pay for
     * production and triggers a console warning when missing.
     */
    function getGoogleTransactionInfo(totalPrice, currencyCode) {
        return {
            countryCode: countryCode,
            currencyCode: currencyCode,
            totalPriceStatus: 'FINAL',
            totalPrice: totalPrice
        };
    }

    /* ------------------------------------------------------------------ */
    /* 6. Button rendering                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * FIX: The container element ID is read from a data-button-container
     * attribute on the script tag so product / cart / checkout pages can each
     * use a distinct DOM ID without duplicating this file.
     */
    function getButtonContainerId() {
        var scripts = document.querySelectorAll('script[data-ab-gpay-container]');
        if (scripts.length > 0) {
            return scripts[scripts.length - 1].getAttribute('data-ab-gpay-container');
        }
        // Fallback: the footer script sets window.acceptblue_gpay_container
        return window.acceptblue_gpay_container || 'acceptblue-google-pay-button';
    }

    function addGooglePayButton(containerId, action) {
        var client = getGooglePaymentsClient();
        var button = client.createButton({
            buttonColor: p.button_color,
            buttonType: p.button_type,
            buttonRadius: 4,
            buttonLocale: p.button_locale,
            buttonSizeMode: 'fill',
            onClick: function () { onGooglePaymentButtonClicked(action); },
            allowedPaymentMethods: [baseCardPaymentMethod]
        });

        var container = document.getElementById(containerId);
        if (!container) {
            // FIX: log instead of silently failing when the container is missing
            console.warn('[accept.blue] Google Pay button container not found: #' + containerId);
            return;
        }
        container.appendChild(button);
    }

    /* ------------------------------------------------------------------ */
    /* 7. Click handler → loadPaymentData                                  */
    /* ------------------------------------------------------------------ */

    function onGooglePaymentButtonClicked(action) {
        var finalPrice = (typeof acceptblue_final_price !== 'undefined') ? acceptblue_final_price : '0.00';
        var currencyCode = (typeof acceptblue_currency_code !== 'undefined') ? acceptblue_currency_code : 'USD';

        var paymentDataRequest = getGooglePaymentDataRequest(finalPrice, currencyCode);

        getGooglePaymentsClient()
            .loadPaymentData(paymentDataRequest)
            .then(function (paymentData) {
                processPayment(paymentData, action, finalPrice);
            })
            .catch(function (err) {
                // FIX: was an empty catch {} — errors are now logged and surfaced to the user
                if (err.statusCode === 'CANCELED') {
                    // User dismissed the sheet — do nothing
                    return;
                }
                console.warn('[accept.blue] Google Pay loadPaymentData error:', err.statusCode, err.statusMessage);
                showError(err.statusMessage || 'Google Pay payment failed. Please try again.');
            });
    }

    /* ------------------------------------------------------------------ */
    /* 8. Process payment — AJAX post                                      */
    /* ------------------------------------------------------------------ */

    function processPayment(paymentData, action, finalPrice) {

        var paymentToken    = btoa(paymentData.paymentMethodData.tokenizationData.token);
        var billingAddress  = paymentData.paymentMethodData.info.billingAddress;
        var emailAddress    = (isUserLoggedIn == 1) ? '' : btoa(paymentData.email || '');
        var productId       = (typeof acceptblue_product_id !== 'undefined') ? acceptblue_product_id : '';

        showLoader(true);

        $.ajax({
            type: 'POST',
            url: p.ajax_url,
            data: {
                action:          action,
                payment_token:   paymentToken,
                googlepay_amount: finalPrice,
                email_address:   emailAddress,
                billing_address: billingAddress,
                product_id:      productId,
                nonce:           p.nonce
            },
            success: function (response) {
                showLoader(false);
                if (response.success) {
                    window.location.href = response.data;
                } else {
                    showError(response.data);
                }
            },
            error: function (xhr, status, error) {
                showLoader(false);
                showError('AJAX request failed: ' + error);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* 9. UI helpers                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * FIX: The ajax loader div was commented out in PHP render functions and
     * only rendered in the footer by accept_blue_google_pay_footer().
     * All show/hide calls now target that single footer element.
     */
    function showLoader(visible) {
        var $loader = $('#acceptblue-google-pay-ajax-loader');
        if (!$loader.length) return; // graceful — element may not exist on every page
        if (visible) { $loader.fadeIn(); } else { $loader.fadeOut(); }
    }

    function showError(message) {
        var html = '<ul class="woocommerce-error" role="alert"><li><strong>Error:</strong> ' + message + '</li></ul>';
        $('.woocommerce-notices-wrapper').html(html);
        $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 600);
    }

    /* ------------------------------------------------------------------ */
    /* 10. Initialise — called after Google Pay JS is loaded               */
    /* ------------------------------------------------------------------ */

    function onGooglePayLoaded(containerId, action) {
        getGooglePaymentsClient()
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then(function (response) {
                if (response.result) {
                    addGooglePayButton(containerId, action);
                }
            })
            .catch(function (err) {
                // FIX: was empty — now logged for debugging
                console.warn('[accept.blue] Google Pay isReadyToPay error:', err.statusCode, err.statusMessage);
            });
    }

    /* ------------------------------------------------------------------ */
    /* 11. Bootstrap on DOMContentLoaded                                   */
    /* ------------------------------------------------------------------ */

    document.addEventListener('DOMContentLoaded', function () {

        if (!window.google || !window.google.payments || !window.google.payments.api) {
            console.warn('[accept.blue] Google Pay API not loaded.');
            return;
        }

        // containerId and ajaxAction are injected by PHP via the inline script
        // that immediately precedes this file on each page.
        var containerId = window.acceptblue_gpay_container || 'acceptblue-google-pay-button';
        var ajaxAction  = window.acceptblue_gpay_action  || '';

        if (!ajaxAction) {
            console.warn('[accept.blue] Google Pay ajax action not set.');
            return;
        }

        onGooglePayLoaded(containerId, ajaxAction);
    });

})(jQuery);
