/**
 * accept.blue Google Pay — Place Order page
 *
 * Fixes applied:
 *   - Typo fixed: was '.button-goople-pay-place-order' (goople) — now 'button-google-pay-place-order'
 *   - Ajax loader now targets the shared footer element rendered by accept_blue_google_pay_footer()
 *   - Error handling surfaced on AJAX failure
 *   - Wrapped in IIFE to prevent global namespace pollution
 */

(function ($) {
    'use strict';

    function showLoader(visible) {
        var $loader = $('#acceptblue-google-pay-ajax-loader');
        if (!$loader.length) return;
        if (visible) { $loader.fadeIn(); } else { $loader.fadeOut(); }
    }

    function showError(message) {
        var html = '<ul class="woocommerce-error" role="alert"><li><strong>Error:</strong> ' + message + '</li></ul>';
        $('.woocommerce-notices-wrapper').html(html);
        $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 600);
    }

    $(document).ready(function () {

        // FIX: Corrected CSS class — was 'button-goople-pay-place-order' (typo "goople")
        // Selector covers both the new .ab-actions wrapper and the legacy .woocommerce-order-actions wrapper
        $(document).on('click', '.ab-btn-place-order, .woocommerce-order-actions .button-google-pay-place-order', function (e) {
            e.preventDefault();

            var orderKey = $(this).data('order-key');

            if (!orderKey) {
                showError('Order key is missing. Please refresh and try again.');
                return;
            }

            // Action is injected by PHP via window.acceptblue_gpay_place_order_action
            var action = window.acceptblue_gpay_place_order_action || 'acceptblue_request_place_order_charge';

            showLoader(true);

            $.ajax({
                type:    'POST',
                url:     acceptblue_hosted_token_params.ajax_url,
                data: {
                    action:    action,
                    order_key: orderKey,
                    nonce:     acceptblue_hosted_token_params.nonce
                },
                success: function (response) {
                    showLoader(false);
                    if (response.success) {
                        window.location.href = response.data;
                    } else {
                        showError(response.data || 'Payment failed. Please try again.');
                    }
                },
                error: function (xhr, status, error) {
                    showLoader(false);
                    showError('AJAX request failed: ' + error);
                }
            });
        });

    });

})(jQuery);
