(function ( $ ) {
	"use strict";
	function acceptbluev2_event_handler(event){

		event.preventDefault();

		var $checkout_form 		= $( 'form.checkout, form#order_review, form#add_payment_method' ),
			$prefix_ 			= 'acceptbluev2',
	    	$cardnumber    		= $( '#'+ $prefix_ +'-card-number' ).val(),
	        $card_expiry   		= $.payment.cardExpiryVal( $( '#'+ $prefix_ +'-card-expiry' ).val() ),
	        $card_cvc 			= $("#" + $prefix_ + '-card-cvc').val(),
	        $card_expiry_month 	= $card_expiry.month,
	        $card_expiry_year 	= $card_expiry.year;

	        $cardnumber 		= $cardnumber.replace( /\s/g, '' );
	        $card_cvc 			= $card_cvc.replace( /\s/g, '' );

	    var $data = {
	    		'cardnumber' : $cardnumber,
	    		'card_cvc'   : $card_cvc,
	    		'expiry_m'   : $card_expiry_month,
	    		'expiry_y'   : $card_expiry_year
	     };   

		 acceptbluev2_handle_build_card($data);

	     return false;

	}

	function acceptbluev2_handle_build_card( params ) {
   
	   var	$form  			= $( 'form.checkout, form#order_review, form#add_payment_method' ),
	       	$acceptbluev2  	= $( "#wc-acceptbluev2-cc-form" );

			$acceptbluev2.append( '<input type="hidden" class="acceptbluev2-cardnumber" name="acceptbluev2-cardnumber" value="' + params.cardnumber + '"/>' );
			$acceptbluev2.append( '<input type="hidden" class="acceptbluev2-card_cvc" name="acceptbluev2-card_cvc" value="' + params.card_cvc + '"/>' );
			$acceptbluev2.append( '<input type="hidden" class="acceptbluev2-expiry_m" name="acceptbluev2-expiry_m" value="' + params.expiry_m + '"/>' );
			$acceptbluev2.append( '<input type="hidden" class="acceptbluev2-expiry_y" name="acceptbluev2-expiry_y" value="' + params.expiry_y + '"/>' );
	    
	    $form.submit();

	 }

	jQuery( document ).ready( function( $ ) {

	// ── Apply color scheme to classic CC form inputs ─────────────────────────
	function acceptblueApplyInputColors() {
		var scheme = (acceptblue_hosted_token_params && acceptblue_hosted_token_params.form_color_scheme) || 'auto';
		var isDark = scheme === 'dark' ||
		             ( scheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );

		var inputStyle, labelColor;
		if ( scheme === 'custom' ) {
			inputStyle = {
				'background-color': acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7',
				'color':            acceptblue_hosted_token_params.custom_color_text   || '#333333',
				'border-color':     acceptblue_hosted_token_params.custom_color_border || '#cccccc',
			};
			labelColor = acceptblue_hosted_token_params.custom_color_text || '#333333';
		} else if ( isDark ) {
			inputStyle = { 'background-color': '#2a2a2a', 'color': '#f0f0f0', 'border-color': '#555555' };
			labelColor = null; // inherit
		} else {
			return; // light — let theme handle it
		}

		var inputs = $( '#wc-acceptbluev2-cc-form input[type="text"], #wc-acceptbluev2-cc-form input[type="password"], #wc-acceptbluev2-cc-form input[type="tel"]' );
		inputs.css( inputStyle );
	}

	acceptblueApplyInputColors();
	$( document.body ).on( 'updated_checkout payment_method_selected', acceptblueApplyInputColors );


		$( document.body ).on( 'checkout_error', function () {
	       $( '.acceptbluev2-cardnumber' ).remove();
	       $( '.acceptbluev2-card_cvc' ).remove();
	       $( '.acceptbluev2-expiry_m' ).remove();
	       $( '.acceptbluev2-expiry_y' ).remove();
	    });

	    $( "body" ).on( 'click', '#place_order', function( e ){
	        if ( $( '#payment_method_acceptbluev2' ).is( ':checked' ) ) {

				// When block_support_checkout=true the iframe handles tokenization via
				// #acceptblue-ht-charge. Clicking #place_order must do nothing —
				// the user must click our custom button to complete payment.
				if ( acceptblue_hosted_token_params.block_checkout == 1 ) {
					e.preventDefault();
					// Scroll to our charge button so the user sees it
					var $btn = $( '#acceptblue-ht-charge' );
					if ( $btn.length ) {
						$( 'html, body' ).animate({ scrollTop: $btn.offset().top - 80 }, 400 );
						$btn.trigger( 'focus' );
					}
					return false;
				}

				// Classic card form path
				acceptbluev2_event_handler(e);
				return false;
	        }
	    });

		$( "body" ).on( 'click', '.woocommerce-SavedPaymentMethods-tokenInput', function( e ){
			

			if("wc-acceptbluev2-payment-token-new" === $(this).attr('id')){

				$("#wc-acceptbluev2-cc-form").show();
				$(".woocommerce-SavedPaymentMethods-saveNew").show();		
				$(".acceptbluev2-card-code-custom").hide();		

			} else {

				$("#wc-acceptbluev2-cc-form").hide();
				$(".woocommerce-SavedPaymentMethods-saveNew").hide();
				$(".acceptbluev2-card-code-custom").show();
				
			}
			

			if("wc-acceptbluev2-payment-token-" + $(this).val() === $(this).attr('id')) {
			} 

			//return false; 

	    });

	    $( 'form.checkout, form#order_review, form#add_payment_method' ).on( 'change', '#wc-acceptbluev2-cc-form input', function() {
	      	$( '.acceptbluev2-cardnumber' ).remove();
	       	$( '.acceptbluev2-card_cvc' ).remove();
	       	$( '.acceptbluev2-expiry_m' ).remove();
	       	$( '.acceptbluev2-expiry_y' ).remove();
	    });

	});

	// #acceptblue-v2-hosted-tokenization-form is now rendered inside payment_fields()
	// so it lives inside .payment_method_acceptbluev2 .payment_box.
	// WooCommerce natively shows/hides .payment_box when the payment method radio
	// changes — no manual show/hide JS needed.

	


}( jQuery ) );