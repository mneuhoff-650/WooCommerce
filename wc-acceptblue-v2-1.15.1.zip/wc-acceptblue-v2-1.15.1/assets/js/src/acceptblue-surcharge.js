
/**
 * Accept.Blue – WooCommerce Blocks Surcharge Recalculation
 * Safe for Block Checkout, Cart Block, Apple Pay, Google Pay
 */

(function () {

    // ── Classic checkout: show/hide notice + recalculate on payment method change ──
    (function classicSurcharge() {
        if ( typeof jQuery === 'undefined' ) {
            return;
        }

        jQuery( function( $ ) {
            var GATEWAY_ID   = 'acceptbluev2';
            var updateTimer  = null;
            var lastMethod   = null;
            var isUpdating   = false;

            function getChosenMethod() {
                return $( 'input[name="payment_method"]:checked' ).val() || '';
            }

            function updateNoticeVisibility( chosen ) {
                var $notice = $( '.payment_method_' + GATEWAY_ID + ' .ab-surcharge-notice' );
                if ( chosen === GATEWAY_ID ) {
                    $notice.show();
                } else {
                    $notice.hide();
                }
            }

            function onPaymentMethodSelected() {
                var chosen = getChosenMethod();

                // Update notice visibility immediately (no AJAX needed)
                updateNoticeVisibility( chosen );

                // Only trigger cart recalculation when the method actually changed
                // Use a debounce and guard against re-entry to prevent loops
                if ( chosen === lastMethod ) {
                    return;
                }
                lastMethod = chosen;

                if ( isUpdating ) {
                    return;
                }

                clearTimeout( updateTimer );
                updateTimer = setTimeout( function() {
                    isUpdating = true;
                    $( document.body ).trigger( 'update_checkout' );
                    // Reset flag after WC finishes recalculating
                    $( document.body ).one( 'updated_checkout', function() {
                        isUpdating = false;
                    });
                }, 250 );
            }

            // Only fire on deliberate payment method selection — NOT on updated_checkout
            // (listening to updated_checkout would cause an infinite loop)
            $( document.body ).on( 'payment_method_selected', onPaymentMethodSelected );

            // Set correct initial visibility once WC renders payment methods
            $( document ).ready( function() {
                setTimeout( function() {
                    updateNoticeVisibility( getChosenMethod() );
                }, 300 );
            });
        });
    })();

    // ── Block checkout: recalculate cart when payment method changes ──────────────

    let lastPaymentMethod = null;
    let subscribed = false;

    /**
     * Wait until WordPress + Woo Store API are ready
     */
    function waitForStores() {

        if (
            typeof window.wp === 'undefined' ||
            !wp.data ||
            !wp.data.select ||
            !wp.data.dispatch
        ) {
            setTimeout(waitForStores, 50);
            return;
        }

        const checkoutStore = wp.data.select('wc/store/checkout');
        const cartStore     = wp.data.select('wc/store/cart');

        // Store API not hydrated yet
        if (!checkoutStore || !cartStore) {
            setTimeout(waitForStores, 50);
            return;
        }

        if (subscribed) {
            return;
        }

        subscribed = true;

        const { subscribe, dispatch } = wp.data;

        /**
         * Subscribe to checkout state changes
         */
        subscribe(() => {
            const method = checkoutStore.getSelectedPaymentMethod
                ? checkoutStore.getSelectedPaymentMethod()
                : null;

            if (!method) {
                return;
            }

            if (method !== lastPaymentMethod) {
                lastPaymentMethod = method;

                // 🔑 Force Store API to recalculate cart + fees
                dispatch('wc/store/cart').invalidateResolutionForStore();
            }
        });
    }

    waitForStores();

})();
