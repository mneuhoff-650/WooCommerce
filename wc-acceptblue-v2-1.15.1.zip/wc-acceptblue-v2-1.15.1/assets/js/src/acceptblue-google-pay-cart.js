const baseRequest = {
    apiVersion: 2,
    apiVersionMinor: 0
  };
  
  const environment             = acceptblue_hosted_token_params.google_pay_environment;
  const allowedCardNetworks     = acceptblue_hosted_token_params.allowed_card_networks;
  const allowedCardAuthMethods  = acceptblue_hosted_token_params.allowed_card_auth_methods;
  const merchantId              = acceptblue_hosted_token_params.google_pay_merchant_id;
  const gatewayMerchantId       = acceptblue_hosted_token_params.gateway_merchant_id;
  const merchantName            = acceptblue_hosted_token_params.google_pay_merchant_name;
  var billingAddressRequired  = acceptblue_hosted_token_params.google_pay_billing_address_required;
  var phoneNumberRequired     = acceptblue_hosted_token_params.google_pay_phone_number_required;
  var is_user_logged_in         = acceptblue_hosted_token_params.is_user_logged_in;
  
  if(billingAddressRequired == 1 ){
    billingAddressRequired = true;
  } else {
    billingAddressRequired = false;
  }

  if(phoneNumberRequired == 1 ){
    phoneNumberRequired = true;
  } else {
    phoneNumberRequired = false;
  }
  
  const tokenizationSpecification = {
    type: 'PAYMENT_GATEWAY',
    parameters: {
      'gateway': 'acceptblue',
      'gatewayMerchantId': gatewayMerchantId    
    }
  };
  
  const baseCardPaymentMethod = {
    type: 'CARD',
    parameters: {
      allowedAuthMethods: allowedCardAuthMethods,
      allowedCardNetworks: allowedCardNetworks,
      'billingAddressRequired' : billingAddressRequired,
      'billingAddressParameters': {
        'format': 'FULL',
        'phoneNumberRequired': phoneNumberRequired
      }
    }
  };

  
  
  const cardPaymentMethod = Object.assign(
    {},
    baseCardPaymentMethod,
    {
      tokenizationSpecification: tokenizationSpecification
    }
  );
  
  let paymentsClient = null;
  
  function getGoogleIsReadyToPayRequest() {
    return Object.assign(
        {},
        baseRequest,
        {
          allowedPaymentMethods: [baseCardPaymentMethod]
        }
    );
  }
  
  function getGooglePaymentDataRequest() {
    const paymentDataRequest = Object.assign({}, baseRequest);
    paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
    paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
    paymentDataRequest.merchantInfo = {
      // @todo a merchant ID is available for a production environment after approval by Google
      // See {@link https://developers.google.com/pay/api/web/guides/test-and-deploy/integration-checklist|Integration checklist}
      merchantId: merchantId,
      merchantName: merchantName
    };

    if(is_user_logged_in == 1 ){
      paymentDataRequest.emailRequired = false; 
    } else {
      paymentDataRequest.emailRequired = true; 
    }
  
    //paymentDataRequest.callbackIntents = ["SHIPPING_ADDRESS",  "SHIPPING_OPTION", "PAYMENT_AUTHORIZATION"];
    //paymentDataRequest.callbackIntents = ["SHIPPING_ADDRESS",  "SHIPPING_OPTION"];
  
    //paymentDataRequest.shippingAddressRequired = true;
    //paymentDataRequest.shippingAddressParameters = getGoogleShippingAddressParameters();
    //paymentDataRequest.shippingOptionRequired = true;
  
    return paymentDataRequest;
  }
  
  function getGooglePaymentsClient() {
    if ( paymentsClient === null ) {
      paymentsClient = new google.payments.api.PaymentsClient({environment: environment });
    }
    return paymentsClient;
  }
  
  function onGooglePayLoaded() {
    const paymentsClient = getGooglePaymentsClient();
    paymentsClient.isReadyToPay(getGoogleIsReadyToPayRequest())
        .then(function(response) {
          if (response.result) {
            addGooglePayButton();
            // @todo prefetch payment data to improve performance after confirming site functionality
            // prefetchGooglePaymentData();
          }
        })
        .catch(function(err) {
          // show error in developer console for debugging
        });
  }
  
  function addGooglePayButton() {
    const paymentsClient = getGooglePaymentsClient();
    const button =
        paymentsClient.createButton({
          buttonColor: acceptblue_hosted_token_params.button_color,
          buttonType: acceptblue_hosted_token_params.button_type,
          buttonRadius: 4,
          buttonLocale: acceptblue_hosted_token_params.button_locale,
          onClick: onGooglePaymentButtonClicked,
          allowedPaymentMethods: [baseCardPaymentMethod]
        });
    document.getElementById('acceptblue-google-pay-product-button').appendChild(button);
  }
  
  function getGoogleTransactionInfo() {    
    return {     
      currencyCode: acceptblue_currency_code,
      totalPriceStatus: 'FINAL',
      // set to cart total
      totalPrice: acceptblue_final_price
    };
  }
  
  function prefetchGooglePaymentData() {
    const paymentDataRequest = getGooglePaymentDataRequest();
    // transactionInfo must be set but does not affect cache
    paymentDataRequest.transactionInfo = {
      totalPriceStatus: 'NOT_CURRENTLY_KNOWN',
      currencyCode: acceptblue_currency_code
    };
    const paymentsClient = getGooglePaymentsClient();
    paymentsClient.prefetchPaymentData(paymentDataRequest);
  }
  
  function onGooglePaymentButtonClicked() {
    const paymentDataRequest = getGooglePaymentDataRequest();
    paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
  
    const paymentsClient = getGooglePaymentsClient();
    paymentsClient.loadPaymentData(paymentDataRequest)
        .then(function(paymentData) {
          // handle the response
          processPayment(paymentData);
        })
        .catch(function(err) {
          // show error in developer console for debugging
        });
  }
  
  function processPayment(paymentData) {
    jQuery(document).ready(function($) {
      var paymentToken = btoa(paymentData.paymentMethodData.tokenizationData.token);  
      var billingAddress = paymentData.paymentMethodData.info.billingAddress;
  
      if(is_user_logged_in == 1 ) {      
        var emailAddress = '';
      } else {     
        var emailAddress = btoa(paymentData.email);
      }

    $('#acceptblue-google-pay-ajax-loader').fadeIn();
    
      $.ajax({
        type: 'POST',
        url: acceptblue_hosted_token_params.ajax_url,
        data: {
            action: 'acceptblue_request_cart_page_charge',                   
            payment_token: paymentToken,
            email_address: emailAddress,
            googlepay_amount: acceptblue_final_price,
            billing_address: billingAddress,
            nonce: acceptblue_hosted_token_params.nonce
        },
        success: function(response) {
          $('#acceptblue-google-pay-ajax-loader').fadeOut();
          if (response.success) {
              window.location.href = response.data;
          } else {
              var errorMessage = '<ul class="woocommerce-error" role="alert">' +
                            '<li><strong>Error:</strong> '+ response.data +'</li>' +
                            '</ul>';                   
              $('.woocommerce-notices-wrapper').html(errorMessage);
              $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 1000);                    
          }
        },
        error: function(xhr, status, error) {
          $('#acceptblue-google-pay-ajax-loader').fadeOut(); 
          var errorMessage = '<ul class="woocommerce-error" role="alert">' +
                             '<li><strong>AJAX request failed:</strong> '+ error +'</li>' +
                             '</ul>';                   
          $('.woocommerce-notices-wrapper').html(errorMessage);
          $('html, body').animate({ scrollTop: $('.woocommerce-notices-wrapper').offset().top }, 1000);
      }
    });
  
  });
  }
  

  //onGooglePayLoaded();

  document.addEventListener('DOMContentLoaded', function() {    

    if (window.google && window.google.payments && window.google.payments.api) {
        onGooglePayLoaded();
    } else {
    }

  });
  
  