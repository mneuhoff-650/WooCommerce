/**
 * accept.blue Payment Gateway v2 — Settings Page JS
 */
(function () {
    'use strict';

    var WRAP      = 'acceptblue-ab-settings-wrap';
    var TAB_ACT   = 'acceptblue-ab-nav-tab-active';
    var PNL_ACT   = 'acceptblue-ab-tab-panel-active';
    var STORE_KEY = 'acceptblue_ab_active_tab';

    /* ── Tab switching ────────────────────────────────────────────────────── */

    function activateTab(slug) {
        var wrap = document.getElementById(WRAP);
        if (!wrap) return;

        // Buttons
        wrap.querySelectorAll('.acceptblue-ab-nav-tab').forEach(function (btn) {
            var active = btn.getAttribute('data-tab') === slug;
            btn.classList.toggle(TAB_ACT, active);
            btn.setAttribute('aria-selected', active ? 'true' : 'false');
        });

        // Panels — toggle display via class; do NOT use hidden attribute
        wrap.querySelectorAll('.acceptblue-ab-tab-panel').forEach(function (panel) {
            var active = panel.getAttribute('data-tab') === slug;
            panel.classList.toggle(PNL_ACT, active);
        });

        try { sessionStorage.setItem(STORE_KEY, slug); } catch (e) {}
    }

    function initTabs() {
        var wrap = document.getElementById(WRAP);
        if (!wrap) return;

        var buttons = wrap.querySelectorAll('.acceptblue-ab-nav-tab');
        if (!buttons.length) return;

        // Resolve initial tab: URL hash > sessionStorage > first button
        var initial = '';

        var hash = (window.location.hash || '').replace('#', '');
        if (hash && wrap.querySelector('.acceptblue-ab-nav-tab[data-tab="' + hash + '"]')) {
            initial = hash;
        }

        if (!initial) {
            try {
                var stored = sessionStorage.getItem(STORE_KEY);
                if (stored && wrap.querySelector('.acceptblue-ab-nav-tab[data-tab="' + stored + '"]')) {
                    initial = stored;
                }
            } catch (e) {}
        }

        if (!initial) {
            initial = buttons[0].getAttribute('data-tab');
        }

        activateTab(initial);

        buttons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                activateTab(this.getAttribute('data-tab'));
            });
        });
    }

    /* ── Toast notification ───────────────────────────────────────────────── */

    function initToast() {
        var TOAST_ID = 'acceptblue-ab-toast';

        function makeToast() {
            var el = document.getElementById(TOAST_ID);
            if (el) return el;
            el = document.createElement('div');
            el.id = TOAST_ID;
            el.addEventListener('click', function () {
                el.classList.remove('acceptblue-ab-toast-visible');
            });
            document.body.appendChild(el);
            return el;
        }

        function showToast(state, text) {
            var el = makeToast();
            el.className = 'acceptblue-ab-toast-' + state + ' acceptblue-ab-toast-visible';
            el.textContent = text;
        }

        function hideToast() {
            var el = document.getElementById(TOAST_ID);
            if (el) el.classList.remove('acceptblue-ab-toast-visible');
        }

        // "Saving…" on form submit — WC uses the outer #mainform
        var form = document.getElementById('mainform');
        if (form) {
            form.addEventListener('submit', function () {
                window.onbeforeunload = null; // prevent "Leave site?" popup
                showToast('saving', '💾 Saving…');
            });
        }

        // "Saved!" after redirect (WC adds settings-updated=1 or updated=1)
        var qs = window.location.search;
        if (qs.indexOf('settings-updated') !== -1 || qs.indexOf('updated=1') !== -1) {
            setTimeout(function () {
                showToast('success', '✅ Settings saved!');
                setTimeout(hideToast, 3500);
            }, 250);
        }
    }

    /* ── Color picker + custom colour row show/hide ───────────────────────── */

    function initColorPicker() {
        if (typeof jQuery === 'undefined') return;
        jQuery(function ($) {
            if (!$.fn.wpColorPicker) return;

            function toggleCustomColors() {
                var val = $('#woocommerce_acceptbluev2_form_color_scheme').val();
                $('.ab-color-picker').closest('tr').toggle(val === 'custom');
            }

            $('.ab-color-picker').wpColorPicker({ change: function () {}, clear: function () {} });
            toggleCustomColors();
            $('#woocommerce_acceptbluev2_form_color_scheme').on('change', toggleCustomColors);
        });
    }

    /* ── API key visibility toggles ──────────────────────────────────────── */

    function initKeyToggles() {
        var wrap = document.getElementById(WRAP);
        if (!wrap) return;
        wrap.querySelectorAll('.ab-key-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(this.getAttribute('data-target'));
                if (!input) return;
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                this.textContent = show ? '🙈 Hide' : '👁 Show';
            });
        });
    }

    /* ── Boot ─────────────────────────────────────────────────────────────── */

    document.addEventListener('DOMContentLoaded', function () {
        initTabs();
        initToast();
        initColorPicker();
        initKeyToggles();
    });

}());
