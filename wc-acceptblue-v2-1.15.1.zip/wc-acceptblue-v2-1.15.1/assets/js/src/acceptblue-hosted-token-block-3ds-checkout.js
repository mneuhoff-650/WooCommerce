(()=>{
/**
 * Accept.Blue Hosted Tokenization + 3DS
 * WooCommerce Blocks Integration
 */

const settings = window.wc.wcSettings.getSetting(
	'acceptbluev2_data',
	{}
);


const { createElement, useEffect, useRef, useState } = window.wp.element;

/**
 * Surcharge Fee Notice
 */
const AcceptBlueV2SurchargeNotice = () => {
	const notice = settings.surcharge_notice;
	if ( ! notice ) return null;

	return createElement(
		'div',
		{
			className: 'ab-surcharge-notice',
			style: {
				display: 'flex',
				alignItems: 'center',
				gap: '10px',
				background: '#eef6ff',
				border: '1px solid #93c5fd',
				borderLeft: '4px solid #3b82f6',
				borderRadius: '6px',
				padding: '11px 14px',
				margin: '0 0 14px',
				boxSizing: 'border-box',
			},
		},
		createElement(
			'span',
			{
				'aria-hidden': 'true',
				style: {
					flexShrink: 0,
					width: '20px',
					height: '20px',
					background: '#3b82f6',
					color: '#fff',
					borderRadius: '50%',
					fontSize: '13px',
					fontWeight: '700',
					display: 'flex',
					alignItems: 'center',
					justifyContent: 'center',
					lineHeight: '1',
				},
			},
			'\u2139'
		),
		createElement(
			'span',
			{
				style: {
					fontSize: '0.88em',
					color: '#1e3a5f',
					lineHeight: '1.5',
					margin: '0',
				},
			},
			'A ',
			createElement( 'strong', { style: { fontWeight: '700', color: '#1d4ed8' } }, notice.fee_formatted ),
			' ',
			createElement( 'strong', { style: { fontWeight: '700', color: '#1d4ed8' } }, notice.fee_name + notice.fee_extra ),
			' will be applied at checkout.'
		)
	);
};

/**
 * Sandbox Test Cards Notice
 */
const AcceptBlueTestCardsNotice = () => {
	if (settings.sandbox !== 1) {
		return null;
	}

	const isThreeDS = settings.threeDS === 1;

	let lines = [];
	lines.push('TEST MODE / SANDBOX ENABLED');

	if (isThreeDS) {
		lines.push('');
		lines.push('3DS TEST CARDS');
		lines.push('Visa - 4012000033330026');
		lines.push('MasterCard - 5100060000000002');
	} else {
		lines.push('');
		lines.push('TEST CARDS');
		lines.push('Visa - 4761530001111118');
		lines.push('Discover - 6011208701117775');
	}

	const scheme     = settings.form_color_scheme || 'auto';
	const isDark     = scheme === 'dark' ||
	                   ( scheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );
	const noticeBg     = isDark ? '#3a2e00' : '#fff3cd';
	const noticeBorder = isDark ? '#665200' : '#ffeeba';
	const textColor    = isDark ? '#f0f0f0' : '#333333';

	return createElement(
		'div',
		{
			className: 'acceptblue-test-cards-notice',
			style: {
				backgroundColor: noticeBg,
				border: '1px solid ' + noticeBorder,
				color: textColor,
				padding: '12px',
				marginBottom: '12px',
				fontSize: '13px',
				borderRadius: '4px',
			},
		},
		lines.map((line, index) =>
			createElement(
				'div',
				{
					key: index,
					style: { fontWeight: index === 0 ? 'bold' : 'normal' },
				},
				line
			)
		)
	);
};

/**
 * Hosted Tokenization + 3DS Frame
 */
const AcceptBlueHosted3DSFrame = ({ onReady }) => {
	const containerRef = useRef(null);
	const hostedRef = useRef(null);

	useEffect(() => {
		const env = settings.sandbox === 1 ? 'test' : 'prod';

		const threeDS = {
			env,
			apiKey: settings.pk_threeds_key,
			frictionless: settings.frictionless === 1,
			timeout: 30000,
		};

		const options = {
			target: containerRef.current,
			threeDS,
		};

		hostedRef.current = new window.HostedTokenization(
			settings.pk_hosted_token,
			options
		);

		hostedRef.current
			.on('input', () => {})
			.on('change', () => {})
			.on('challenge', () => {
				// Scroll to top so the 3DS challenge window is visible in the viewport.
				// This mirrors the classic-checkout behaviour where a scroll-to-top
				// is performed before verify3DS() is awaited.
				window.scrollTo({ top: 0, behavior: 'smooth' });
			});

		// ── Color scheme ─────────────────────────────────────────────
				const abScheme = ( settings.form_color_scheme || 'auto' );
		const abDark   = abScheme === 'dark' ||
		                 ( abScheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );
		if ( abScheme === 'light' || abScheme === 'dark' || abScheme === 'custom' ) {
		    document.body.setAttribute( 'data-ab-scheme', abScheme );
		}
		if ( abScheme === 'custom' ) {
		    const abBg     = settings.custom_color_bg     || '#f7f7f7';
		    const abText   = settings.custom_color_text   || '#333333';
		    const abBorder = settings.custom_color_border || '#cccccc';
		    document.documentElement.style.setProperty( '--ab-custom-bg',     abBg );
		    document.documentElement.style.setProperty( '--ab-custom-text',   abText );
		    document.documentElement.style.setProperty( '--ab-custom-border', abBorder );
		}
		const abCustomBg     = settings.custom_color_bg     || '#f7f7f7';
		const abCustomText   = settings.custom_color_text   || '#333333';
		const abCustomBorder = settings.custom_color_border || '#cccccc';
		hostedRef.current.setStyles( abScheme === 'custom' ? {
			card:        'background-color:' + abCustomBg + ';border:2px solid ' + abCustomBorder + ';color:' + abCustomText + ';padding:12px;font-size:16px;',
			expiryMonth: 'background-color:' + abCustomBg + ';border:2px solid ' + abCustomBorder + ';color:' + abCustomText + ';padding:12px;',
			expiryYear:  'background-color:' + abCustomBg + ';border:2px solid ' + abCustomBorder + ';color:' + abCustomText + ';padding:12px;',
			cvv2:        'background-color:' + abCustomBg + ';border:2px solid ' + abCustomBorder + ';color:' + abCustomText + ';padding:12px;',
		} : abDark ? {
			card:        'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:12px;font-size:16px;',
			expiryMonth: 'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:12px;',
			expiryYear:  'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:12px;',
			cvv2:        'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:12px;',
		} : {
			card:        'background:#f7f7f7;border:1px solid #ccc;padding:12px;font-size:16px;',
			expiryMonth: 'background:#f7f7f7;border:1px solid #ccc;padding:12px;',
			expiryYear:  'background:#f7f7f7;border:1px solid #ccc;padding:12px;',
			cvv2:        'background:#f7f7f7;border:1px solid #ccc;padding:12px;',
		} );

		onReady(() => hostedRef.current);
	}, []);

	return createElement('div', {
		ref: containerRef,
		id: 'acceptblue-hosted-3ds-container',
	});
};

/**
 * Saved Payment Token selector
 * Shows stored cards and a "Use a new card" option.
 */
const AcceptBlueV2SavedTokens = ({ selectedToken, onChange }) => {
	const tokens = settings.saved_tokens || [];
	if (!tokens.length) return null;

	const cardLabel = (token) => {
		const type = token.card_type
			? token.card_type.charAt(0).toUpperCase() + token.card_type.slice(1)
			: 'Card';
		return `${type} ···· ${token.last4}  exp ${token.expiry_month}/${String(token.expiry_year).slice(-2)}`;
	};

	return createElement(
		'div',
		{ className: 'acceptbluev2-saved-tokens' },
		tokens.map((token) => {
			const isSelected = selectedToken === String(token.id);
			return createElement(
				'div',
				{
					key: token.id,
					className: 'acceptbluev2-token-option' + (isSelected ? ' acceptbluev2-token-option--selected' : ''),
				},
				createElement(
					'label',
					{ className: 'acceptbluev2-token-label' },
					createElement('input', {
						type: 'radio',
						name: 'acceptbluev2-saved-token',
						value: String(token.id),
						checked: isSelected,
						onChange: () => onChange(String(token.id)),
					}),
						createElement('span', null, cardLabel(token))
				)
			);
		}),
		createElement(
			'div',
			{
				className: 'acceptbluev2-token-option acceptbluev2-token-new' + (selectedToken === 'new' ? ' acceptbluev2-token-option--selected' : ''),
			},
			createElement(
				'label',
				{ className: 'acceptbluev2-token-label' },
				createElement('input', {
					type: 'radio',
					name: 'acceptbluev2-saved-token',
					value: 'new',
					checked: selectedToken === 'new',
					onChange: () => onChange('new'),
				}),
					createElement('span', null, 'Use a new card')
			)
		)
	);
};

/**
 * Save to Account Checkbox
 * Only shown to logged-in users when saving is enabled and not forced.
 */
const AcceptBlueV2SaveCard = ({ saveCard, onChange }) => {
	if (!settings.is_logged_in) return null;
	if (!settings.save_card_enabled) return null;
	if (settings.force_save_card) return null;

	return createElement(
		'div',
		{ className: 'acceptbluev2-save-card-row' },
		createElement(
			'label',
			{ className: 'acceptbluev2-save-card-label' },
			createElement('input', {
				type: 'checkbox',
				id: 'acceptbluev2-save-card',
				checked: saveCard,
				onChange: (e) => onChange(e.target.checked),
			}),
			settings.save_card_label || 'Save to account'
		)
	);
};

/**
 * Main Blocks Payment Component
 */
const AcceptBlueV2Content = ({ eventRegistration }) => {
	const tokens = settings.saved_tokens || [];
	const defaultToken = tokens.length
		? (tokens.find(t => t.is_default) || tokens[0])
		: null;

	const [hostedInstance, setHostedInstance] = useState(null);
	const [saveCard, setSaveCard] = useState(!!settings.force_save_card);
	const [selectedToken, setSelectedToken] = useState(
		defaultToken ? String(defaultToken.id) : 'new'
	);

	const usingNewCard = selectedToken === 'new';
	const onPaymentSetup = eventRegistration?.onPaymentSetup;

	useEffect(() => {
		if (!onPaymentSetup) return;
		if (usingNewCard && !hostedInstance) return;

		const unsubscribe = onPaymentSetup(async () => {

			// Using a saved token
			if (!usingNewCard) {
				return {
					type: 'success',
					meta: {
						paymentMethodData: {
							'acceptbluev2-block-token-id': selectedToken,
						},
					},
				};
			}

			try {
				// STEP 1: Tokenize
				const nonceResult = await hostedInstance.getNonceToken();

				if (!nonceResult?.nonce) {
					return {
						type: 'error',
						message: 'Card tokenization failed.',
					};
				}

				const shouldSave = settings.force_save_card || saveCard;

				// STEP 2: 3DS Flow
				if (settings.threeDS === 1) {
					// For trial subscription orders the cart total is $0, but the API
					// processes a $0.01 auth-and-void. Pass 0.01 to verify3DS so the
					// CAVV matches the actual charge amount.
					const rawTotal   = Number( settings.order_total ) || 0;
					const isTrial    = settings.is_trial_subscription === 1;
					const verifyAmt  = ( rawTotal < 0.01 && isTrial ) ? 0.01 : rawTotal;

					const threeDSData = {
						amount: verifyAmt,
						email:
							document.querySelector('input[id="email"]')
								?.value || '',
					};

					const threeDSResult =
						await hostedInstance.verify3DS(threeDSData);

					return {
						type: 'success',
						meta: {
							paymentMethodData: {
								'acceptbluev2-payment-token': String(nonceResult.nonce || ''),
								'acceptbluev2-payment-expiry_month': String(nonceResult.expiryMonth || ''),
								'acceptbluev2-payment-expiry_year': String(nonceResult.expiryYear || ''),
								'acceptbluev2-payment-eci': String(threeDSResult?.eci || ''),
								'acceptbluev2-payment-authenticationvalue': String(threeDSResult?.authenticationValue || ''),
								'acceptbluev2-payment-dstransid': String(threeDSResult?.dsTransId || ''),
								'acceptbluev2-save-card': shouldSave ? '1' : '0',
							},
						},
					};
				}

				// STEP 3: Non-3DS
				return {
					type: 'success',
					meta: {
						paymentMethodData: {
							'acceptbluev2-payment-token': String(nonceResult.nonce || ''),
							'acceptbluev2-payment-expiry_month': String(nonceResult.expiryMonth || ''),
							'acceptbluev2-payment-expiry_year': String(nonceResult.expiryYear || ''),
							'acceptbluev2-save-card': shouldSave ? '1' : '0',
						},
					},
				};
			} catch (err) {
				return {
					type: 'error',
					message: err.message || 'Payment failed',
				};
			}
		});

		return () => unsubscribe?.();
	}, [hostedInstance, saveCard, selectedToken, usingNewCard, onPaymentSetup]);

	return createElement(
		'div',
		null,
		createElement(AcceptBlueV2SurchargeNotice),
		createElement(AcceptBlueTestCardsNotice),
		createElement(AcceptBlueV2SavedTokens, { selectedToken, onChange: setSelectedToken }),
		usingNewCard && createElement(AcceptBlueHosted3DSFrame, { onReady: setHostedInstance }),
		usingNewCard && createElement(AcceptBlueV2SaveCard, { saveCard, onChange: setSaveCard })
	);
};

/**
 * Register Payment Method
 */
const label =
	window.wp.htmlEntities.decodeEntities(settings.title) ||
	'Credit Card';

const AcceptBlueV2Label = () => {
	return createElement(
		'span',
		{ style: { display: 'flex', alignItems: 'center', gap: '6px' } },
		label,
		settings.icon_url
			? createElement('img', {
				src: settings.icon_url,
				srcSet: settings.icon_url_2x
					? `${settings.icon_url} 1x, ${settings.icon_url_2x} 2x`
					: undefined,
				alt: label,
				style: { height: '24px', width: 'auto', verticalAlign: 'middle' },
			})
			: null
	);
};

window.wc.wcBlocksRegistry.registerPaymentMethod({
	name: 'acceptbluev2',
	label: createElement(AcceptBlueV2Label),
	content: createElement(AcceptBlueV2Content),
	edit: createElement(AcceptBlueV2Content),
	canMakePayment: () => true,
	ariaLabel: label,
	supports: {
		features: settings.supports,
	},
});
})();
