<?php
/**
 * Plugin Name: accept.blue Payment Gateway v2
 * Description: accept.blue Payment Gateway v2 for WooCommerce (Tokenization, Google Pay and Surcharge)
 * Version: 1.15.1
 * Author: RyanPlugins
 * Author URI: https://ryanplugins.net/
 * Plugin URI: https://www.patreon.com/RyanPlugins
 *
 * WC requires at least: 3.0
 * WC tested up to: 9.7.0
 * WC Subscription tested up to: 7.1.0
 */

defined( 'ABSPATH' ) || exit;

// =============================================================================
// Constants
// =============================================================================

$plugin_data    = get_file_data( __FILE__, array( 'Version' => 'Version' ), false );
$plugin_version = $plugin_data['Version'];

define( 'AB_V2_VERSION', $plugin_version );

if ( ! defined( 'AB_V2_PLUGIN_FILE' ) ) {
    define( 'AB_V2_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'AB_V2_PLUGIN_DIR' ) ) {
    define( 'AB_V2_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

// =============================================================================
// Bootstrap — only when WooCommerce is active
// =============================================================================

if ( in_array(
    'woocommerce/woocommerce.php',
    apply_filters( 'active_plugins', get_option( 'active_plugins' ) )
) ) {
    add_action( 'plugins_loaded', 'wc_acceptblue_v2_init' );
}

function wc_acceptblue_v2_init() {
    // ── Core classes ─────────────────────────────────────────────────────────
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-log-masker.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-api.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-addons.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/class-wc-acceptblue-v2-google-pay-actions.php';

    // ── Hook files ───────────────────────────────────────────────────────────
    require_once AB_V2_PLUGIN_DIR . 'includes/admin-actions.php';
    require_once AB_V2_PLUGIN_DIR . 'includes/custom-actions.php';

    // ── Google Pay actions (needs gateway instance — defer to woocommerce_init)
    add_action( 'woocommerce_init', 'wc_acceptblue_v2_init_google_pay', 20 );
}

/**
 * Bootstrap WC_AcceptBlue_Google_Pay_Actions once WooCommerce is fully loaded.
 * Deferred to priority 20 so the gateway settings are available.
 */
function wc_acceptblue_v2_init_google_pay() {
    // Use the WC registry — never new WC_Gateway_AcceptBlue_v2() here.
    // Instantiating the gateway inside a hook callback re-runs __construct()
    // which registers additional add_action() calls on every invocation,
    // causing an ever-growing listener stack that exhausts PHP memory.
    if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways ) {
        return;
    }
    $gateways = WC()->payment_gateways()->payment_gateways();
    $gateway  = $gateways['acceptbluev2'] ?? null;

    if ( $gateway && $gateway->is_enabled() ) {
        $gpay = new WC_AcceptBlue_Google_Pay_Actions( $gateway );
        $gpay->register_hooks();
    }
}

// =============================================================================
// WooCommerce gateway registration
// =============================================================================

add_filter( 'woocommerce_payment_gateways', 'wc_acceptblue_v2_add_gateway' );

/**
 * Register the correct gateway class:
 *   - WC_Gateway_AcceptBlue_v2_Addons when WooCommerce Subscriptions or
 *     WooCommerce Pre-Orders is active (extends the base gateway).
 *   - WC_Gateway_AcceptBlue_v2 otherwise.
 *
 * @param array $methods
 * @return array
 */
function wc_acceptblue_v2_add_gateway( $methods ) {
    if (
        class_exists( 'WC_Subscriptions_Order' ) ||
        class_exists( 'WC_Pre_Orders_Order' )
    ) {
        $methods[] = 'WC_Gateway_AcceptBlue_v2_Addons';
    } else {
        $methods[] = 'WC_Gateway_AcceptBlue_v2';
    }
    return $methods;
}
