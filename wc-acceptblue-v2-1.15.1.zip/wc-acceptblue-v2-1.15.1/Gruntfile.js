module.exports = function(grunt) {
    // Project configuration
    grunt.initConfig({
      pkg: grunt.file.readJSON('package.json'),
  
      // Uglify task to minify multiple JS files
      uglify: {
        build: {
          files: {
            // Destination: Source
            'assets/js/dist/acceptblue-checkout-form.min.js': ['assets/js/src//acceptblue-checkout-form.js'], 
            'assets/js/dist/acceptblue-hosted-token-iframe.min.js': ['assets/js/src/acceptblue-hosted-token-iframe.js'], 
            'assets/js/dist/acceptblue-hosted-token-iframe-3ds.min.js': ['assets/js/src/acceptblue-hosted-token-iframe-3ds.js'], 
            'assets/js/dist/acceptblue-hosted-token-iframe-addons.min.js': ['assets/js/src/acceptblue-hosted-token-iframe-addons.js'], 
            'assets/js/dist/acceptblue-hosted-token-iframe-addons-3ds.min.js': ['assets/js/src/acceptblue-hosted-token-iframe-addons-3ds.js'], 
            'assets/js/dist/acceptblue-hosted-token-local-script.min.js': ['assets/js/src/acceptblue-hosted-token-local-script.js'],
            'assets/js/dist/acceptblue-hosted-token-block-checkout.min.js': ['assets/js/src/acceptblue-hosted-token-block-checkout.js'],
            'assets/js/dist/acceptblue-google-pay-cart.min.js' : [ 'assets/js/src/acceptblue-google-pay-cart.js' ],
            'assets/js/dist/acceptblue-google-pay-cart-addons.min.js' : [ 'assets/js/src/acceptblue-google-pay-cart-addons.js' ],
            'assets/js/dist/acceptblue-google-pay-checkout-page.min.js' : [ 'assets/js/src/acceptblue-google-pay-checkout-page.js' ],
            'assets/js/dist/acceptblue-google-pay-checkout-page-addons.min.js' : [ 'assets/js/src/acceptblue-google-pay-checkout-page-addons.js' ],
            'assets/js/dist/acceptblue-google-pay-product.min.js' : [ 'assets/js/src/acceptblue-google-pay-product.js' ],
            'assets/js/dist/acceptblue-google-pay-product-addons.min.js' : [ 'assets/js/src/acceptblue-google-pay-product-addons.js' ],
            'assets/js/dist/acceptblue-google-pay-place-order.min.js' : [ 'assets/js/src/acceptblue-google-pay-place-order.js' ],
            'assets/js/dist/acceptblue-google-pay-place-order-addons.min.js' : [ 'assets/js/src/acceptblue-google-pay-place-order-addons.js' ],     
            'assets/js/dist/acceptblue-hosted-token-iframe-checkout.min.js' : [ 'assets/js/src/acceptblue-hosted-token-iframe-checkout.js' ],
            'assets/js/dist/acceptblue-hosted-token-block-3ds-checkout.min.js' : [ 'assets/js/src/acceptblue-hosted-token-block-3ds-checkout.js' ],
            'assets/js/dist/acceptblue-surcharge.min.js': ['assets/js/src/acceptblue-surcharge.js'] // Single file              
            
          }
        }
      },
  
      // CSSMin task to minify multiple CSS files
      cssmin: {
        target: {
          files: {
            // Destination: Source
            'assets/css/dist/acceptblue-hosted-token-iframe.min.css': ['assets/css/src/acceptblue-hosted-token-iframe.css'], // Multiple files specified
            'assets/css/dist/acceptblue-google-pay.min.css': ['assets/css/src/acceptblue-google-pay.css'],
            'assets/css/dist/acceptblue-main.min.css': ['assets/css/src/acceptblue-main.css'],
            //'build/vendor.min.css': ['src/css/vendor/*.css'] // All CSS files in 'vendor' folder using wildcard
          }
        }
      }
    });
  
    // Load the plugins
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
  
    // Register default tasks
    grunt.registerTask('default', ['uglify', 'cssmin']);
  };
  