(function ( $ ) {
"use strict";

/* ============================================================
   accept.blue Hosted Tokenization — order-pay page
   Lazy HostedTokenization init: the SDK is only mounted when
   the new-card section is actually visible. This prevents the
   SDK's internal form-validation listeners from firing the
   "Card Number Required" error when a saved token is selected.
   ============================================================ */

const chargeButton   = document.querySelector('#acceptblue-ht-charge');
const iframeWrap     = document.querySelector('#acceptblue-ht-iframe-container');
const errorMessageEl = document.querySelector('#acceptblue-ht-error-message');
const orderKey       = document.querySelector('#acceptblue-ht-order-key');
const orderAmount    = document.querySelector('#acceptblue-ht-order-amount');
const cardName       = document.querySelector('#acceptbluev2-card-name');
const newCardLabel   = document.querySelector('.ab-ht-new-card-label');
const saveCardWrap   = document.querySelector('.ab-ht-save-card-row');

// ── Color scheme ──────────────────────────────────────────────────────────────
const abScheme = ( acceptblue_hosted_token_params.form_color_scheme || 'auto' );
const abDark   = abScheme === 'dark' ||
                 ( abScheme === 'auto' && window.matchMedia( '(prefers-color-scheme: dark)' ).matches );

if ( abScheme === 'light' || abScheme === 'dark' || abScheme === 'custom' ) {
    document.body.setAttribute( 'data-ab-scheme', abScheme );
}
if ( abScheme === 'custom' ) {
    const abBg     = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
    const abText   = acceptblue_hosted_token_params.custom_color_text   || '#333333';
    const abBorder = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
    document.documentElement.style.setProperty( '--ab-custom-bg',     abBg );
    document.documentElement.style.setProperty( '--ab-custom-text',   abText );
    document.documentElement.style.setProperty( '--ab-custom-border', abBorder );
}

function getIframeStyles() {
    if ( abScheme === 'custom' ) {
        const bg = acceptblue_hosted_token_params.custom_color_bg     || '#f7f7f7';
        const tx = acceptblue_hosted_token_params.custom_color_text   || '#333333';
        const bd = acceptblue_hosted_token_params.custom_color_border || '#cccccc';
        return {
            card:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:'+bg+';border:2px solid '+bd+';color:'+tx+';padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    if ( abDark ) {
        return {
            card:        'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:10px;font-size:16px;width:48%;border-radius:5px;',
            expiryMonth: 'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            expiryYear:  'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:10px;font-size:16px;border-radius:5px;',
            cvv2:        'background-color:#2a2a2a;border:2px solid #555555;color:#f0f0f0;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
        };
    }
    return {
        card:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;width:48%;border-radius:5px;',
        expiryMonth: 'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        expiryYear:  'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;border-radius:5px;',
        cvv2:        'background-color:#f7f7f7;border:2px solid #ccc;padding:10px;font-size:16px;margin-right:4%;border-radius:5px;',
    };
}

// ── Lazy HostedTokenization init ─────────────────────────────────────────────
// Only mount the SDK when the new-card section is visible.
// Eager init causes "Card Number Required" on every button click because the
// SDK registers form-validation listeners on mount, even when hidden.

const sandbox          = acceptblue_hosted_token_params.sandbox == 1 ? 'test' : 'prod';
const threeDSApiKey    = acceptblue_hosted_token_params.pk_threeds_key;
const threeDSFriction  = acceptblue_hosted_token_params.frictionless == 1;

let hostedTokenization = null;

function mountIframe() {
    if ( hostedTokenization ) return;
    const opts = { target: '#acceptblue-ht-iframe-container', threeDS: { env: sandbox, apiKey: threeDSApiKey, frictionless: threeDSFriction, timeout: 30000 } };
    hostedTokenization = new window.HostedTokenization( acceptblue_hosted_token_params.pk_hosted_token, opts );
    hostedTokenization.on('input', _onEvent).on('change', _onEvent).on('challenge', function(){});
    hostedTokenization.setStyles( getIframeStyles() );
}

function destroyIframe() {
    if ( ! hostedTokenization ) return;
    try {
        if ( typeof hostedTokenization.unmount === 'function' ) {
            hostedTokenization.unmount();
        } else if ( iframeWrap ) {
            iframeWrap.innerHTML = '';
        }
    } catch(e) {}
    hostedTokenization = null;
}

// ── Saved token radio handling ────────────────────────────────────────────────
function getSelectedToken() {
    const checked = document.querySelector('input[name="ab-ht-selected-token"]:checked');
    return checked ? checked.value : null;
}

function syncIframeVisibility() {
    const selected   = getSelectedToken();
    const showIframe = ( selected === null || selected === 'new' );

    if ( iframeWrap )   iframeWrap.style.display   = showIframe ? '' : 'none';
    if ( newCardLabel ) newCardLabel.style.display  = showIframe ? '' : 'none';
    if ( saveCardWrap ) saveCardWrap.style.display  = showIframe ? '' : 'none';

    if ( showIframe ) {
        mountIframe();
    } else {
        destroyIframe();
    }
}

document.querySelectorAll('input[name="ab-ht-selected-token"]').forEach(function(radio) {
    radio.addEventListener('change', syncIframeVisibility);
});

syncIframeVisibility();

// If no saved tokens (no radios), mount immediately
if ( ! document.querySelector('input[name="ab-ht-selected-token"]') ) {
    mountIframe();
}

if ( chargeButton ) { chargeButton.addEventListener('click', onChargeClick); }

async function onChargeClick() {
    clearError();
    $('#acceptblue-hosted-token-ajax-loader').fadeIn();

    const selectedToken = getSelectedToken();

    // Path A: saved token
    if ( selectedToken !== null && selectedToken !== 'new' ) {
        const isAddPm = acceptblue_hosted_token_params.is_add_payment_method == 1;
        postCharge({
            action:         isAddPm ? 'acceptblue_ht_add_payment_method' : 'acceptblue_ht_request_place_order_charge_addons',
            order_key:      orderKey ? orderKey.value : '',
            nonce:          acceptblue_hosted_token_params.nonce,
            saved_token_id: selectedToken,
            card_name:      cardName ? cardName.value : '',
        });
        return;
    }

    // Path B: new card with 3DS
    if ( ! hostedTokenization ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        showError( 'Card form not ready. Please refresh the page.' );
        return;
    }

    try {
        const result = await hostedTokenization.getNonceToken();
        if ( ! result || ! result.nonce ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            showError( 'Card tokenization failed — no response.' );
            return;
        }

        $('html, body').animate({ scrollTop: '0px' }, 0);

        const threeDSData = {
            // For trial subscription orders the cart total is $0, but the API processes
            // a $0.01 auth-and-void. Use 0.01 to match so the CAVV is not mismatched.
            amount: ( orderAmount && orderAmount.getAttribute('data-is-trial') === '1' )
                ? 0.01
                : Number( orderAmount ? orderAmount.value : 0 ),
            email: typeof acceptblue_order_email !== 'undefined' ? acceptblue_order_email : ''
        };

        try {
            const threeDSResult = await hostedTokenization.verify3DS( threeDSData );

            // Validate the result — a falsy result or missing ECI means 3DS failed/was cancelled.
            if ( ! threeDSResult ) {
                $('#acceptblue-hosted-token-ajax-loader').fadeOut();
                showError( '3D Secure verification was not completed. Please try again.' );
                return;
            }
            if ( ! threeDSResult.eci ) {
                $('#acceptblue-hosted-token-ajax-loader').fadeOut();
                showError( '3D Secure verification failed — authentication data missing. Please try again.' );
                return;
            }

            const isAddPm3ds = acceptblue_hosted_token_params.is_add_payment_method == 1;
            postCharge({
                action:             isAddPm3ds ? 'acceptblue_ht_add_payment_method' : 'acceptblue_ht_request_place_order_charge_addons',
                order_key:          orderKey ? orderKey.value : '',
                nonce:              acceptblue_hosted_token_params.nonce,
                hosted_token_nonce: result.nonce,
                expiry_month:       result.expiryMonth,
                expiry_year:        result.expiryYear,
                threed_secure:      { eci: threeDSResult.eci, cavv: threeDSResult.authenticationValue, ds_trans_id: threeDSResult.dsTransId },
                card_name:          cardName ? cardName.value : '',
                save_card:          getSaveCard(),
            });
        } catch ( threeDSError ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            showError( '3D Secure verification failed: ' + ( threeDSError.message || 'Please try again.' ) );
        }

    } catch ( error ) {
        $('#acceptblue-hosted-token-ajax-loader').fadeOut();
        showError( 'Card tokenization error: ' + error.message );
    }
}

// ── AJAX helper ───────────────────────────────────────────────────────────────
function postCharge( data ) {
    $.ajax({
        type: 'POST',
        url:  acceptblue_hosted_token_params.ajax_url,
        data: data,
        success: function( response ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            if ( response.success ) {
                // Order-pay returns a plain URL string; add-payment-method returns { redirect: '...' }
                const dest = ( response.data && response.data.redirect )
                    ? response.data.redirect
                    : response.data;
                window.location.href = dest;
            } else {
                showError( ( response.data && response.data.message ) ? response.data.message : ( response.data || 'Payment failed.' ) );
            }
        },
        error: function( xhr, status, error ) {
            $('#acceptblue-hosted-token-ajax-loader').fadeOut();
            showError( 'AJAX request failed: ' + error );
        },
    });
}

function getSaveCard() {
    const cb = document.getElementById('acceptbluev2-ht-save-card');
    return cb && cb.checked ? '1' : '0';
}

function showError( msg ) {
    if ( ! errorMessageEl ) return;
    errorMessageEl.innerHTML =
        '<ul class="woocommerce-error" role="alert"><li><strong>Error:</strong> ' +
        escHtml( msg ) + '</li></ul>';
    $('html, body').animate({ scrollTop: $( errorMessageEl ).offset().top - 80 }, 600);
}

function clearError() {
    if ( errorMessageEl ) errorMessageEl.innerHTML = '';
}

function escHtml( str ) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function _onEvent( event ) {
    if ( event.error !== undefined && event.error !== '' ) {
        if ( errorMessageEl ) errorMessageEl.innerText = event.error;
    } else {
        if ( errorMessageEl ) errorMessageEl.innerText = '';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const target = document.querySelector('.ab-ht-saved-tokens') || document.querySelector('#acceptblue-ht-iframe-container');
    if ( target ) $('html, body').animate({ scrollTop: $( target ).offset().top - 80 }, 800);
});

}( jQuery ) );
