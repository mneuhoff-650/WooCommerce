/**
 * accept.blue — Google Pay WooCommerce Block Checkout Integration
 *
 * Registers Google Pay as a payment method with WooCommerce Blocks so it
 * appears inside the Checkout Block and Cart Block payment options.
 *
 * Flow:
 *  1. canMakePayment() → async Google Pay isReadyToPay check.
 *  2. Content component renders the Google Pay button.
 *  3. Customer clicks → Google Pay sheet opens.
 *  4. On approval → token stored via useEffect into onPaymentSetup's
 *     paymentMethodData. WooCommerce Blocks forwards this to the Store API
 *     checkout endpoint, which makes it available as $_POST in process_payment().
 *  5. process_payment() in WC_Gateway_AcceptBlue_v2_GooglePay_Checkout
 *     reads acceptbluev2_googlepay_checkout_token and charges the order.
 *
 * Settings are exposed by WC_AcceptBlue_V2_GooglePay_Blocks::get_payment_method_data()
 * as window.wc.wcSettings.getSetting('acceptbluev2_googlepay_checkout_data', {}).
 */
(function () {
    'use strict';

    /* ── Aliases ──────────────────────────────────────────────────────── */
    const { createElement, useState, useEffect, useRef, useCallback } = window.wp.element;
    const { decodeEntities } = window.wp.htmlEntities;
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { getSetting } = window.wc.wcSettings;

    /* ── Settings (injected by PHP) ───────────────────────────────────── */
    const settings = getSetting('acceptbluev2_googlepay_checkout_data', {});

    if (!settings || !settings.google_pay_environment) {
        // Plugin not configured — don't register
        return;
    }

    // Guard: missing gateway_merchant_id causes OR_BIBED_11 from Google Pay.
    if (!settings.gateway_merchant_id) {
        console.warn('[accept.blue] GPay block: gateway_merchant_id is not configured. Payment method will not register.');
        return;
    }

    /* ── Normalise settings arrays ───────────────────────────────────── */
    // WC may JSON-encode PHP associative arrays as JS objects {VISA:'VISA'}.
    // Google Pay requires actual JS arrays — normalise both fields here.
    function toArray(val, fallback) {
        if (Array.isArray(val)) return val;
        if (val && typeof val === 'object') return Object.values(val);
        return fallback;
    }
    settings.allowed_card_networks     = toArray(settings.allowed_card_networks,     ['AMEX','DISCOVER','INTERAC','JCB','MASTERCARD','VISA']);
    settings.allowed_card_auth_methods = toArray(settings.allowed_card_auth_methods, ['PAN_ONLY']);

    /* ── Google Pay API helpers ───────────────────────────────────────── */
    const BASE_REQUEST = { apiVersion: 2, apiVersionMinor: 0 };

    function buildTokenizationSpec() {
        return {
            type: 'PAYMENT_GATEWAY',
            parameters: {
                gateway: 'acceptblue',
                gatewayMerchantId: settings.gateway_merchant_id || '',
            },
        };
    }

    function buildBaseCardPaymentMethod() {
        const params = {
            allowedAuthMethods:  settings.allowed_card_auth_methods || ['PAN_ONLY'],
            allowedCardNetworks: settings.allowed_card_networks     || ['MASTERCARD', 'VISA'],
            billingAddressRequired: !!settings.billing_address_required,
        };
        if (settings.billing_address_required) {
            params.billingAddressParameters = {
                format: 'FULL',
                phoneNumberRequired: !!settings.phone_number_required,
            };
        }
        return { type: 'CARD', parameters: params };
    }

    const baseCardPaymentMethod = buildBaseCardPaymentMethod();

    const cardPaymentMethod = Object.assign({}, baseCardPaymentMethod, {
        tokenizationSpecification: buildTokenizationSpec(),
    });

    function getPaymentsClient() {
        return new google.payments.api.PaymentsClient({
            environment: settings.google_pay_environment || 'TEST',
        });
    }

    function isReadyToPayRequest() {
        return Object.assign({}, BASE_REQUEST, {
            allowedPaymentMethods: [baseCardPaymentMethod],
            existingPaymentMethodRequired: false,
        });
    }

    /**
     * Build the full paymentDataRequest.
     * totalPrice is read from the live WC totals where possible so the
     * sheet reflects any coupons / shipping method changes the customer made
     * before choosing Google Pay.
     */
    function buildPaymentDataRequest(liveTotalOverride) {
        const total = liveTotalOverride || settings.cart_total || '0.00';

        const request = Object.assign({}, BASE_REQUEST, {
            allowedPaymentMethods: [cardPaymentMethod],
            transactionInfo: {
                countryCode:      settings.google_pay_country_code || 'US',
                currencyCode:     settings.currency_code           || 'USD',
                totalPriceStatus: 'FINAL',
                totalPrice:       String(total),
            },
            merchantInfo: {
                merchantId:   settings.google_merchant_id   || '',
                merchantName: settings.google_merchant_name || '',
            },
            emailRequired: false,
        });

        // In TEST mode, log the full request so config issues are easy to spot.
        if (settings.google_pay_environment === 'TEST') {
        }

        return request;
    }

    /* ── canMakePayment — async Google Pay availability check ─────────── */
    /**
     * WooCommerce Blocks calls this once per page load.
     * If it resolves to false the payment method radio button is hidden.
     * We guard against google.payments not yet being available by waiting
     * for it on a short poll (it's loaded async from the CDN).
     */
    async function canMakePayment() {
        try {
            await waitForGooglePay();

            if (settings.google_pay_environment === 'TEST') {
            }

            const client   = getPaymentsClient();
            const response = await client.isReadyToPay(isReadyToPayRequest());
            return !!response.result;
        } catch (e) {
            console.warn('[accept.blue] GPay blocks canMakePayment error:', e);
            return false;
        }
    }

    /** Poll up to 3 seconds for window.google.payments to be available. */
    function waitForGooglePay(maxMs = 3000, intervalMs = 100) {
        return new Promise((resolve, reject) => {
            if (window.google && window.google.payments && window.google.payments.api) {
                return resolve();
            }
            let elapsed = 0;
            const iv = setInterval(() => {
                if (window.google && window.google.payments && window.google.payments.api) {
                    clearInterval(iv);
                    resolve();
                } else {
                    elapsed += intervalMs;
                    if (elapsed >= maxMs) {
                        clearInterval(iv);
                        reject(new Error('Google Pay SDK not loaded'));
                    }
                }
            }, intervalMs);
        });
    }

    /* ── Status message helper ────────────────────────────────────────── */
    /**
     * Small inline status bar rendered below the button.
     * type: 'success' | 'error' | 'info'
     */
    const GPayStatus = ({ message, type }) => {
        if (!message) return null;
        const colors = {
            success: '#15803d',
            error:   '#dc2626',
            info:    '#1d4ed8',
        };
        return createElement('p', {
            style: {
                margin: '8px 0 0',
                fontSize: '.875em',
                color: colors[type] || '#333',
            },
        }, message);
    };

    /* ── Google Pay Button component ──────────────────────────────────── */
    /**
     * Props:
     *   onToken(base64Token)  — called after successful sheet approval
     *   liveTotal             — current cart total string e.g. "49.99"
     */
    const GPayButton = ({ onToken, liveTotal }) => {
        const containerRef  = useRef(null);
        const [status, setStatus] = useState(null);  // { message, type }
        const buttonRef     = useRef(null); // keep track of inserted button

        const handleClick = useCallback(async (e) => {
            if (e && e.preventDefault) e.preventDefault();
            setStatus(null);

            try {
                const client  = getPaymentsClient();
                const request = buildPaymentDataRequest(liveTotal);

                // Always log the FULL request in TEST mode so we can spot config issues
                if (settings.google_pay_environment === 'TEST') {
                }

                const paymentData = await client.loadPaymentData(request);
                const rawToken = paymentData.paymentMethodData.tokenizationData.token;
                const b64Token = btoa(rawToken);
                setStatus({ message: settings.i18n.authorised, type: 'success' });
                onToken(b64Token);
            } catch (err) {
                if (err && err.statusCode === 'CANCELED') {
                    setStatus(null);
                    return;
                }
                const msg = (err && err.statusMessage)
                    ? err.statusMessage
                    : settings.i18n.payment_failed;
                setStatus({ message: msg, type: 'error' });
                console.warn('[accept.blue] GPay blocks loadPaymentData error:', err);
            }
        }, [liveTotal, onToken]);

        useEffect(() => {
            const container = containerRef.current;
            if (!container) return;

            // Re-render the button whenever liveTotal changes so the sheet always
            // shows the accurate amount.
            let cancelled = false;

            (async () => {
                try {
                    await waitForGooglePay();
                    if (cancelled) return;

                    const client   = getPaymentsClient();
                    const ready    = await client.isReadyToPay(isReadyToPayRequest());
                    if (!ready.result || cancelled) return;

                    // Remove old button if any
                    while (container.firstChild) container.removeChild(container.firstChild);

                    const button = client.createButton({
                        buttonColor:    settings.button_color  || 'default',
                        buttonType:     settings.button_type   || 'buy',
                        buttonLocale:   settings.button_locale || 'en',
                        buttonRadius:   4,
                        buttonSizeMode: 'fill',
                        allowedPaymentMethods: [baseCardPaymentMethod],
                        onClick: handleClick,
                    });
                    buttonRef.current = button;
                    container.appendChild(button);
                } catch (err) {
                    if (!cancelled) {
                        setStatus({ message: settings.i18n.gpay_not_ready, type: 'error' });
                    }
                }
            })();

            return () => { cancelled = true; };
        }, [handleClick]); // re-run if handleClick identity changes (i.e. liveTotal changes)

        return createElement('div', { className: 'ab-gpay-block-wrap' },
            createElement('div', {
                ref: containerRef,
                className: 'ab-gpay-block-button-container',
                style: { minHeight: '48px' },
            }),
            status && createElement(GPayStatus, status)
        );
    };

    /* ── Main content component ───────────────────────────────────────── */
    /**
     * WooCommerce Blocks injects several helpers via props:
     *   eventRegistration.onPaymentSetup — subscribe to the "place order" event
     *   billing.billingAddress           — current billing address
     *   emitResponse                     — helpers for response shape
     */
    const AcceptBlueGPayBlockContent = ({
        eventRegistration,
        emitResponse,
        billing,
        cartTotals,
    }) => {
        const { onPaymentSetup } = eventRegistration;
        const [token, setToken]  = useState('');
        const tokenRef           = useRef('');

        // Keep ref in sync so the onPaymentSetup callback closure always
        // sees the latest value without needing to re-register.
        const handleToken = useCallback((b64) => {
            tokenRef.current = b64;
            setToken(b64);
        }, []);

        // Auto-submit: once the token is captured, trigger the WC Blocks
        // checkout submission so the customer never has to click twice.
        useEffect(() => {
            if (!token) return;

            // Strategy 1 — WP Data store dispatch (most reliable, version-agnostic).
            // Triggers WC Blocks' internal "before processing" state which kicks off
            // the full payment flow exactly as if Place Order was clicked.
            const dispatchViaStore = () => {
                try {
                    if (window.wp && window.wp.data) {
                        const store = window.wp.data.dispatch('wc/store/checkout');
                        if (store) {
                            // WC Blocks 9+
                            if (typeof store.__internalSetBeforeProcessing === 'function') {
                                store.__internalSetBeforeProcessing();
                                return true;
                            }
                            // WC Blocks 8 / older naming
                            if (typeof store.setBeforeProcessing === 'function') {
                                store.setBeforeProcessing();
                                return true;
                            }
                        }
                    }
                } catch (e) {
                    console.warn('[accept.blue] GPay store dispatch failed:', e);
                }
                return false;
            };

            // Strategy 2 — DOM button click with exhaustive selectors + text fallback.
            const clickPlaceOrder = () => {
                // Explicit class selectors (vary by WC Blocks version)
                const selectors = [
                    '.wc-block-components-checkout-place-order-button button',
                    '.wp-block-woocommerce-checkout-actions-block button[type="submit"]',
                    '.wc-block-checkout__actions_row button[type="submit"]',
                    'form.wc-block-checkout__form button[type="submit"]',
                    '.wc-block-checkout button[type="submit"]',
                ];

                for (const sel of selectors) {
                    const btn = document.querySelector(sel);
                    if (btn && !btn.disabled && btn.offsetParent !== null) {
                        btn.click();
                        return true;
                    }
                }

                // Text-content fallback: find any visible submit button whose
                // label contains "place" or "order"
                const allSubmit = document.querySelectorAll('button[type="submit"], button.wc-block-components-button');
                for (const b of allSubmit) {
                    if (!b.disabled && b.offsetParent !== null) {
                        const txt = (b.textContent || b.innerText || '').trim().toLowerCase();
                        if (txt.includes('place') || txt.includes('order') || txt.includes('pay')) {
                            b.click();
                            return true;
                        }
                    }
                }
                return false;
            };

            // Strategy 3 — native form submit (last resort)
            const submitForm = () => {
                const form =
                    document.querySelector('form.wc-block-checkout__form') ||
                    document.querySelector('form[data-block-name="woocommerce/checkout"]');
                if (form) {
                    form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
                    return true;
                }
                return false;
            };

            // Give React one tick to flush tokenRef, then try all strategies
            // with a retry loop in case the button hasn't mounted yet.
            let attempts = 0;
            const MAX_ATTEMPTS = 12; // ~1.2 seconds total

            const attempt = () => {
                if (dispatchViaStore()) return;
                if (clickPlaceOrder())  return;
                if (submitForm())       return;
                if (++attempts < MAX_ATTEMPTS) {
                    setTimeout(attempt, 100);
                } else {
                    console.warn('[accept.blue] GPay auto-submit: could not find Place Order button after', MAX_ATTEMPTS, 'attempts.');
                }
            };

            const timer = setTimeout(attempt, 200);
            return () => clearTimeout(timer);
        }, [token]);

        // Derive live cart total from cartTotals (cents string → dollars)
        const liveTotal = (() => {
            if (cartTotals && cartTotals.total_price) {
                const cents = parseInt(cartTotals.total_price, 10);
                if (!isNaN(cents)) {
                    return (cents / Math.pow(10, cartTotals.currency_minor_unit || 2))
                        .toFixed(cartTotals.currency_minor_unit || 2);
                }
            }
            return settings.cart_total || '0.00';
        })();

        // Register the payment setup subscriber.
        // Called by WooCommerce Blocks when the customer clicks "Place Order".
        useEffect(() => {
            const unsubscribe = onPaymentSetup(async () => {
                if (!tokenRef.current) {
                    return {
                        type:    emitResponse.responseTypes.ERROR,
                        message: settings.i18n.token_missing,
                    };
                }
                return {
                    type: emitResponse.responseTypes.SUCCESS,
                    meta: {
                        paymentMethodData: {
                            // These POST keys are read by process_payment()
                            acceptbluev2_googlepay_checkout_token: tokenRef.current,
                            acceptbluev2_googlepay_checkout_nonce: settings.nonce || '',
                            // Flag so process_payment knows this is a block checkout request
                            acceptbluev2_googlepay_block_checkout: '1',
                        },
                    },
                };
            });
            return () => { if (typeof unsubscribe === 'function') unsubscribe(); };
        }, [onPaymentSetup, emitResponse]);

        return createElement('div', { className: 'ab-gpay-block-content' },
            // Description
            settings.description
                ? createElement('p', {
                    className: 'ab-gpay-block-description',
                    style: { marginBottom: '10px', fontSize: '.9em' },
                }, decodeEntities(settings.description))
                : null,

            // After approval: show a brief "Placing order…" spinner overlay.
            // The button is hidden and auto-submit fires after 250ms.
            token
                ? createElement('p', {
                    style: {
                        color: '#15803d',
                        fontSize: '.9em',
                        margin: '4px 0',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                    },
                },
                    // Simple CSS spinner via a span
                    createElement('span', {
                        style: {
                            display: 'inline-block',
                            width: '14px',
                            height: '14px',
                            border: '2px solid #15803d',
                            borderTopColor: 'transparent',
                            borderRadius: '50%',
                            animation: 'ab-gpay-spin 0.7s linear infinite',
                        },
                    }),
                    settings.i18n.authorised
                )
                : createElement(GPayButton, { onToken: handleToken, liveTotal }),

            // Inject the keyframe animation once
            createElement('style', { key: 'ab-spin' },
                '@keyframes ab-gpay-spin { to { transform: rotate(360deg); } }'
            ),

            // Test mode badge
            settings.google_pay_environment === 'TEST'
                ? createElement('p', {
                    style: { color: '#d97706', fontSize: '.8em', marginTop: '8px' },
                }, '⚠ TEST MODE — Google Pay sandbox')
                : null
        );
    };

    /* ── Label component ──────────────────────────────────────────────── */
    const labelText = decodeEntities(settings.title) || 'Google Pay';

    const AcceptBlueGPayLabel = () =>
        createElement('span', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
            labelText,
            settings.icon_url
                ? createElement('img', {
                    src:   settings.icon_url,
                    alt:   labelText,
                    style: { height: '20px', width: 'auto', verticalAlign: 'middle' },
                })
                : null
        );

    /* ── Register with WooCommerce Blocks ─────────────────────────────── */
    registerPaymentMethod({
        name:    'acceptbluev2_googlepay_checkout',
        label:   createElement(AcceptBlueGPayLabel),
        content: createElement(AcceptBlueGPayBlockContent),
        edit:    createElement(AcceptBlueGPayLabel),   // editor preview — just show label
        canMakePayment,
        ariaLabel: labelText,
        supports: {
            features: settings.supports || ['products'],
        },
    });

})();
