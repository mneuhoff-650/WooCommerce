/**
 * accept.blue — Google Pay Checkout Payment Method
 *
 * Manages the Google Pay button that appears inside the WooCommerce payment
 * methods list when the customer selects "Google Pay (accept.blue)".
 *
 * Flow:
 *  1. On DOMContentLoaded / checkout update: if the GPay radio is selected,
 *     initialise the GPay payments client and render the button.
 *  2. Customer clicks the Google Pay button → GPay sheet opens.
 *  3. On sheet approval → token stored in a hidden field → WC checkout form
 *     is auto-submitted programmatically (bypassing the native Place Order btn).
 *  4. PHP process_payment() picks up the token and charges the order.
 *
 * UX decisions:
 *  - The native "Place Order" button is hidden while this method is selected.
 *  - After GPay approval a brief "Authorised — placing order…" message is shown.
 *  - On cancellation the button is simply re-enabled (no page reload needed).
 *  - Errors surface as WooCommerce-style notices above the payment section.
 *
 * @requires acceptblue_gpay_checkout_params  — localised via wp_localize_script
 */
(function ($) {
    'use strict';

    /* ------------------------------------------------------------------ */
    /* 1. Guard                                                             */
    /* ------------------------------------------------------------------ */

    if (typeof acceptblue_gpay_checkout_params === 'undefined') {
        console.warn('[accept.blue] GPay checkout: params not defined.');
        return;
    }

    var p = acceptblue_gpay_checkout_params;

    // Guard: missing gateway_merchant_id causes OR_BIBED_11 from Google Pay.
    if ( ! p.gateway_merchant_id ) {
        console.warn('[accept.blue] GPay checkout: gateway_merchant_id is not configured. Payment method button will not render.');
        return;
    }

    /* ------------------------------------------------------------------ */
    /* 1b. Normalise settings arrays                                        */
    /* ------------------------------------------------------------------ */
    // WP JSON-encoding may turn PHP assoc arrays into JS objects {VISA:'VISA'}.
    // Google Pay requires real JS arrays — normalise on the JS side too.
    (function normaliseArrays() {
        function toArray(val, fallback) {
            if (Array.isArray(val)) return val;
            if (val && typeof val === 'object') return Object.values(val);
            return fallback;
        }
        p.allowed_card_networks     = toArray(p.allowed_card_networks,     ['AMEX','DISCOVER','INTERAC','JCB','MASTERCARD','VISA']);
        p.allowed_card_auth_methods = toArray(p.allowed_card_auth_methods, ['PAN_ONLY']);
    })();

    /* ------------------------------------------------------------------ */
    /* 2. State                                                             */
    /* ------------------------------------------------------------------ */

    var paymentsClient  = null;
    var buttonRendered  = false;  // true once button DOM is inserted
    var tokenCaptured   = false;  // true after successful GPay sheet

    /* ------------------------------------------------------------------ */
    /* 3. Google Pay API helpers                                            */
    /* ------------------------------------------------------------------ */

    var baseRequest = { apiVersion: 2, apiVersionMinor: 0 };

    var tokenizationSpec = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: 'acceptblue',
            gatewayMerchantId: p.gateway_merchant_id
        }
    };

    function buildCardPaymentMethod() {
        var params = {
            allowedAuthMethods:   p.allowed_card_auth_methods,
            allowedCardNetworks:  p.allowed_card_networks,
            billingAddressRequired: (p.google_pay_billing_address_required == 1)
        };
        if (p.google_pay_billing_address_required == 1) {
            params.billingAddressParameters = {
                format: 'FULL',
                phoneNumberRequired: (p.google_pay_phone_number_required == 1)
            };
        }
        return { type: 'CARD', parameters: params };
    }

    var baseCardPaymentMethod = buildCardPaymentMethod();

    var cardPaymentMethod = Object.assign({}, baseCardPaymentMethod, {
        tokenizationSpecification: tokenizationSpec
    });

    function getClient() {
        if (!paymentsClient) {
            paymentsClient = new google.payments.api.PaymentsClient({
                environment: p.google_pay_environment   // 'TEST' or 'PRODUCTION'
            });
        }
        return paymentsClient;
    }

    function isReadyToPayRequest() {
        return Object.assign({}, baseRequest, {
            allowedPaymentMethods: [baseCardPaymentMethod],
            existingPaymentMethodRequired: false
        });
    }

    /**
     * Build the GPay payment data request.
     * Amount is read fresh from the live cart total injected by PHP, which may
     * have been updated after a coupon / shipping method change.
     */
    function paymentDataRequest() {
        if (p.google_pay_environment === 'TEST') {
        }
        // Prefer a dynamic cart total from a data attribute we write on init;
        // fall back to the total baked in by PHP at enqueue time.
        var total = $('#acceptblue-gpay-live-total').val() || p.cart_total;

        return Object.assign({}, baseRequest, {
            allowedPaymentMethods: [cardPaymentMethod],
            transactionInfo: {
                countryCode:       p.google_pay_country_code || 'US',
                currencyCode:      p.currency_code || 'USD',
                totalPriceStatus:  'FINAL',
                totalPrice:        total
            },
            merchantInfo: {
                merchantId:   p.google_pay_merchant_id,
                merchantName: p.google_pay_merchant_name
            },
            emailRequired: (p.is_user_logged_in != 1)
        });
    }

    /* ------------------------------------------------------------------ */
    /* 4. DOM helpers                                                       */
    /* ------------------------------------------------------------------ */

    function gatewayId() {
        return p.gateway_id; // 'acceptbluev2_googlepay_checkout'
    }

    /** @return {boolean} true if the GPay radio is currently selected */
    function isGpaySelected() {
        var radio = document.querySelector('input[name="payment_method"][value="' + gatewayId() + '"]');
        return radio && radio.checked;
    }

    function getButtonContainer() {
        return document.getElementById('acceptblue-gpay-checkout-button');
    }

    function getStatusEl() {
        return document.getElementById('acceptblue-gpay-checkout-status');
    }

    function getTokenField() {
        return document.getElementById('acceptbluev2_googlepay_checkout_token');
    }

    function showStatus(message, type) {
        var el = getStatusEl();
        if (!el) return;
        el.className = 'acceptblue-gpay-checkout-status-' + (type || 'info');
        el.textContent = message;
        el.style.display = 'block';
    }

    function clearStatus() {
        var el = getStatusEl();
        if (!el) return;
        el.style.display = 'none';
        el.textContent = '';
    }

    /**
     * Show / hide the native WC "Place Order" button based on which method is
     * active.  We toggle a body class so the CSS rule kicks in.
     */
    function syncPlaceOrderButton() {
        if (isGpaySelected()) {
            $('body').addClass('acceptblue-gpay-active');
        } else {
            $('body').removeClass('acceptblue-gpay-active');
        }
    }

    /* ------------------------------------------------------------------ */
    /* 5. Button lifecycle                                                  */
    /* ------------------------------------------------------------------ */

    /**
     * Initialise the Google Pay button inside the payment fields container.
     * Called whenever the payment method may have changed or the checkout
     * section is refreshed by WooCommerce AJAX.
     */
    function maybeInit() {
        if (!isGpaySelected()) {
            syncPlaceOrderButton();
            return;
        }
        syncPlaceOrderButton();

        // Container may have been removed & re-inserted by WC AJAX — re-check
        var container = getButtonContainer();
        if (!container) {
            return;
        }

        // Reset captured state on each fresh render (e.g. after checkout update)
        if (!tokenCaptured) {
            buttonRendered = false;
            container.innerHTML = '';
        }

        if (buttonRendered) {
            return; // Button already present, don't double-render
        }

        if (!window.google || !window.google.payments || !window.google.payments.api) {
            showStatus(p.i18n.gpay_not_ready, 'error');
            return;
        }

        getClient()
            .isReadyToPay(isReadyToPayRequest())
            .then(function (response) {
                if (response.result) {
                    renderButton(container);
                } else {
                    showStatus(p.i18n.gpay_not_ready, 'error');
                }
            })
            .catch(function (err) {
                console.warn('[accept.blue] GPay checkout isReadyToPay error:', err);
                showStatus(p.i18n.gpay_not_ready, 'error');
            });
    }

    function renderButton(container) {
        var client = getClient();
        var button = client.createButton({
            buttonColor:    p.button_color    || 'default',
            buttonType:     p.button_type     || 'buy',
            buttonLocale:   p.button_locale   || 'en',
            buttonRadius:   4,
            buttonSizeMode: 'fill',
            allowedPaymentMethods: [baseCardPaymentMethod],
            onClick: handleButtonClick
        });

        container.innerHTML = '';
        container.appendChild(button);
        buttonRendered = true;
        clearStatus();
    }

    /* ------------------------------------------------------------------ */
    /* 6. Click handler → loadPaymentData                                  */
    /* ------------------------------------------------------------------ */

    function handleButtonClick(event) {
        // Prevent the click from bubbling to the checkout form
        if (event && event.preventDefault) {
            event.preventDefault();
        }

        clearStatus();

        // Refresh live cart total before opening the sheet
        syncCartTotal(function () {
            getClient()
                .loadPaymentData(paymentDataRequest())
                .then(onPaymentAuthorised)
                .catch(function (err) {
                    if (err && err.statusCode === 'CANCELED') {
                        // User dismissed — do nothing
                        return;
                    }
                    var msg = (err && err.statusMessage) ? err.statusMessage : p.i18n.payment_failed;
                    console.warn('[accept.blue] GPay checkout loadPaymentData error:', err);
                    showStatus(msg, 'error');
                });
        });
    }

    /* ------------------------------------------------------------------ */
    /* 7. Payment authorised → store token → submit checkout               */
    /* ------------------------------------------------------------------ */

    function onPaymentAuthorised(paymentData) {
        var rawToken  = paymentData.paymentMethodData.tokenizationData.token;
        var b64Token  = btoa(rawToken);

        var tokenField = getTokenField();
        if (!tokenField) {
            showStatus(p.i18n.payment_failed, 'error');
            return;
        }

        // Persist token into the hidden field
        tokenField.value = b64Token;
        tokenCaptured = true;

        showStatus(p.i18n.token_stored, 'success');

        // Briefly show the Place Order button so WC can submit the form,
        // then programmatically click it.
        $('body').removeClass('acceptblue-gpay-active');

        // Give the DOM a tick to apply the class change, then submit
        setTimeout(function () {
            var placeOrderBtn = document.getElementById('place_order');
            if (placeOrderBtn) {
                placeOrderBtn.click();
            } else {
                // Fallback: submit the form directly
                $('form.checkout').submit();
            }
        }, 150);
    }

    /* ------------------------------------------------------------------ */
    /* 8. Live cart total sync                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Read the current cart total from the WC order review table and store it
     * in a hidden field so paymentDataRequest() picks up the up-to-date figure.
     * Calls `callback` when done (sync or async).
     */
    function syncCartTotal(callback) {
        // Prefer the WC order-total data attribute if available
        var $totalEl = $('tr.order-total .amount');
        if ($totalEl.length) {
            var rawText = $totalEl.text().replace(/[^\d.,]/g, '').replace(',', '.');
            var total   = parseFloat(rawText);
            if (!isNaN(total)) {
                ensureLiveTotalField().val(total.toFixed(2));
                return callback();
            }
        }
        callback();
    }

    function ensureLiveTotalField() {
        var $f = $('#acceptblue-gpay-live-total');
        if (!$f.length) {
            $f = $('<input>', { type: 'hidden', id: 'acceptblue-gpay-live-total', value: p.cart_total });
            $('form.checkout').append($f);
        }
        return $f;
    }

    /* ------------------------------------------------------------------ */
    /* 9. Validate before WC form submission                               */
    /* ------------------------------------------------------------------ */

    /**
     * Hook into WC's checkout:place_order event (jQuery trigger).
     * If the GPay method is selected and no token has been captured yet,
     * prevent submission and prompt the user to click the GPay button.
     */
    $(document.body).on('checkout_place_order_' + gatewayId(), function () {
        if (!tokenCaptured) {
            showStatus(p.i18n.complete_gpay, 'error');
            return false; // Prevent WC from submitting
        }
        return true; // Token present — allow submission
    });

    /* ------------------------------------------------------------------ */
    /* 10. React to payment method changes & checkout refreshes            */
    /* ------------------------------------------------------------------ */

    // Payment method radio changed
    $(document.body).on('change', 'input[name="payment_method"]', function () {
        tokenCaptured  = false;
        buttonRendered = false;
        maybeInit();
    });

    // WooCommerce refreshes the checkout payment section via AJAX on shipping,
    // coupon, or country changes — re-init after each update.
    $(document.body).on('updated_checkout', function () {
        tokenCaptured  = false;
        buttonRendered = false;
        maybeInit();
    });

    // Also re-init when the payment accordion opens (theme compatibility)
    $(document.body).on('payment_method_selected', function () {
        maybeInit();
    });

    /* ------------------------------------------------------------------ */
    /* 11. Bootstrap on DOMContentLoaded                                   */
    /* ------------------------------------------------------------------ */

    $(function () {
        // Wait one tick for WC to finish its own DOMContentLoaded work
        setTimeout(maybeInit, 0);
    });

})(jQuery);
