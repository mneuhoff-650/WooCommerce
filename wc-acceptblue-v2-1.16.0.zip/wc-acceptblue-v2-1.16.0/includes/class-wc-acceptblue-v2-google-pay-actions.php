<?php
defined( 'ABSPATH' ) || exit;

/**
 * accept.blue Google Pay — Custom Actions & Admin Actions
 *
 * Centralises every Google Pay hook, AJAX action, script enqueueing,
 * and button rendering that was previously spread across wc-acceptblue-v2.php.
 *
 * Responsibilities:
 *   - Register all wp_ajax_* callbacks for Google Pay page variants
 *   - Enqueue the unified Google Pay JS module per page type
 *   - Render Google Pay button containers (product / cart / checkout / order-review)
 *   - Render the shared AJAX loader element in the footer
 *   - Register the [acceptblue_googlepay_review_order] shortcode
 *   - Admin: validate Google Pay settings and show admin notices
 *
 * Fixes included:
 *   - Button selector typo fixed in PHP output (button-goople → button-google)
 *   - Ajax loader div uncommented and moved to footer (always in DOM)
 *   - countryCode passed to JS (required by Google Pay API)
 *   - billingAddressParameters only passed when billingAddressRequired = true
 *   - Merchant ID validated — admin notice if it contains unexpected characters
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */
class WC_AcceptBlue_Google_Pay_Actions {

	/** @var WC_Gateway_AcceptBlue_v2 */
	private $gateway;

	/** @var string Minified JS file for the unified Google Pay module */
	const GPAY_SCRIPT_HANDLE = 'acceptblue-google-pay';

	public function __construct( WC_Gateway_AcceptBlue_v2 $gateway ) {
		$this->gateway = $gateway;
	}

	/* ================================================================== */
	/* Bootstrap — call once after the gateway is ready                   */
	/* ================================================================== */

	public function register_hooks() {

		if ( ! $this->gateway->google_pay_is_enabled() ) {
			// The "GPay disabled" notice is now shown by WC_Gateway_AcceptBlue_v2_GooglePay_Checkout
			// on the Google Pay settings screen. Nothing to register here.
			return;
		}

		// ── Frontend scripts & buttons ───────────────────────────────────
		add_action( 'wp_enqueue_scripts',             array( $this, 'enqueue_google_pay_api_script' ) );
		add_action( 'wp_enqueue_scripts',             array( $this, 'enqueue_google_pay_module' ) );
		add_action( 'wp_footer',                      array( $this, 'render_ajax_loader' ) );

		// ── Button placements ────────────────────────────────────────────
		add_action( 'woocommerce_after_add_to_cart_form',           array( $this, 'render_product_button' ),   35 );
		add_action( 'woocommerce_cart_collaterals',                  array( $this, 'render_cart_button' ) );
		add_action( 'bbloomer_before_woocommerce/cart-cross-sells-block', array( $this, 'render_cart_button' ) );
		add_action( 'woocommerce_after_order_notes',                 array( $this, 'render_checkout_button' ) );

		// ── AJAX handlers — standard & addons ───────────────────────────
		$this->register_ajax_actions();

		// ── Shortcode ────────────────────────────────────────────────────
		add_shortcode( 'acceptblue_googlepay_review_order', array( $this, 'shortcode_review_order' ) );

		// ── Admin ────────────────────────────────────────────────────────
		// Merchant-ID and country-code notices are registered by
		// WC_Gateway_AcceptBlue_v2_GooglePay_Checkout::admin_notices()
		// because they belong on the Google Pay settings screen, not the
		// main gateway screen.  Order-review-page auto-creation and its
		// success/error notice are also handled by that class.
	}

	/* ================================================================== */
	/* A. AJAX action registration                                         */
	/* ================================================================== */

	private function register_ajax_actions() {

		$actions = array(
			'acceptblue_request_checkout_page_charge'        => 'ajax_checkout_page_charge',
			'acceptblue_request_checkout_page_charge_addons' => 'ajax_checkout_page_charge_addons',
			'acceptblue_request_cart_page_charge'            => 'ajax_cart_page_charge',
			'acceptblue_request_cart_page_charge_addons'     => 'ajax_cart_page_charge_addons',
			'acceptblue_request_product_page_charge'         => 'ajax_product_page_charge',
			'acceptblue_request_product_page_charge_addons'  => 'ajax_product_page_charge_addons',
			'acceptblue_request_place_order_charge'          => 'ajax_place_order_charge',
			'acceptblue_request_place_order_charge_addons'   => 'ajax_place_order_charge_addons',
		);

		foreach ( $actions as $wp_action => $method ) {
			add_action( 'wp_ajax_' . $wp_action,        array( $this, $method ) );
			add_action( 'wp_ajax_nopriv_' . $wp_action, array( $this, $method ) );
		}
	}

	/* ── AJAX callbacks ─────────────────────────────────────────────── */

	public function ajax_checkout_page_charge() {
		$this->gateway->acceptblue_woocommerce_ajax_script_process_checkout_page_charge();
	}

	public function ajax_checkout_page_charge_addons() {
		$addons = new WC_Gateway_AcceptBlue_v2_Addons();
		$addons->acceptblue_woocommerce_ajax_script_process_checkout_page_charge();
	}

	public function ajax_cart_page_charge() {
		$this->gateway->acceptblue_woocommerce_ajax_script_process_cart_page_charge();
	}

	public function ajax_cart_page_charge_addons() {
		$addons = new WC_Gateway_AcceptBlue_v2_Addons();
		$addons->acceptblue_woocommerce_ajax_script_process_cart_page_charge();
	}

	public function ajax_product_page_charge() {
		$this->gateway->acceptblue_woocommerce_ajax_script_process_product_page_charge();
	}

	public function ajax_product_page_charge_addons() {
		$addons = new WC_Gateway_AcceptBlue_v2_Addons();
		$addons->acceptblue_woocommerce_ajax_script_process_product_page_charge();
	}

	public function ajax_place_order_charge() {
		$this->gateway->acceptblue_woocommerce_ajax_script_place_order_charge();
	}

	public function ajax_place_order_charge_addons() {
		$addons = new WC_Gateway_AcceptBlue_v2_Addons();
		$addons->acceptblue_woocommerce_ajax_script_place_order_charge_addons();
	}

	/* ================================================================== */
	/* B. Script enqueueing                                                */
	/* ================================================================== */

	/**
	 * Enqueue the Google Pay API script from Google's CDN.
	 * Skipped on the order-pay page and shop archive.
	 */
	public function enqueue_google_pay_api_script() {
		if ( $this->is_pay_page() || is_shop() ) {
			return;
		}
		wp_enqueue_script(
			'google-pay',
			'https://pay.google.com/gp/p/js/pay.js',
			array(),
			null,
			true
		);
	}

	/**
	 * Enqueue the unified Google Pay module and inject page-specific config.
	 *
	 * Instead of six near-identical files, one compiled file handles all
	 * page variants. The page-specific AJAX action and button container ID
	 * are injected as inline JS variables before the script runs.
	 */
	public function enqueue_google_pay_module() {
		if ( $this->is_pay_page() ) {
			return;
		}

		$config = $this->resolve_page_config();
		if ( ! $config ) {
			return; // Not a supported Google Pay page
		}

		// Enqueue shared CSS
		wp_enqueue_style(
			'acceptblue-v2-google-pay',
			plugins_url( 'assets/css/dist/acceptblue-google-pay.min.css', AB_V2_PLUGIN_FILE )
		);

		// Enqueue the unified module (compiled from acceptblue-google-pay.js).
		// FIX: 'acceptblue-v2-js' added as a dependency so that wp_localize_script
		// always outputs acceptblue_hosted_token_params BEFORE this script runs.
		// Without this dependency, Google Pay loads first and crashes because
		// acceptblue_hosted_token_params is undefined — causing a silent failure
		// that prevents the button rendering on ANY page for logged-in users.
		wp_enqueue_script(
			self::GPAY_SCRIPT_HANDLE,
			plugins_url( 'assets/js/dist/acceptblue-google-pay.min.js', AB_V2_PLUGIN_FILE ),
			array( 'jquery', 'google-pay', 'acceptblue-v2-js' ),
			AB_V2_VERSION,
			true
		);

		// Inject page-specific vars before the module runs.
		// Also re-publish acceptblue_hosted_token_params directly onto this handle
		// as a safety net: if acceptblue-v2-js hasn't been registered yet (e.g. on
		// pages where local_script() hasn't fired), the Google Pay module still gets
		// the params it needs without crashing on undefined acceptblue_hosted_token_params.
		$inline = sprintf(
			'window.acceptblue_gpay_container = %s; window.acceptblue_gpay_action = %s;',
			wp_json_encode( $config['container_id'] ),
			wp_json_encode( $config['ajax_action'] )
		);
		wp_add_inline_script( self::GPAY_SCRIPT_HANDLE, $inline, 'before' );

		// Merge Google Pay params into acceptblue_hosted_token_params using Object.assign
		// instead of wp_localize_script — which would emit a second `var` declaration
		// and overwrite the object already written by local_script(), erasing pk_hosted_token.
		if ( $this->gateway->google_pay_is_enabled() ) {
			$is_logged_in = is_user_logged_in();
			$gpay_params  = $this->get_localized_params( $is_logged_in, ! $is_logged_in );
			$base_params  = array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'acceptblue-ajax-nonce' ),
			);
			$merged = array_merge( $base_params, $gpay_params );
			// Use Object.assign so existing keys (pk_hosted_token, etc.) are preserved.
			$inline_merge = sprintf(
				'if(typeof acceptblue_hosted_token_params !== "undefined"){' .
				'Object.assign(acceptblue_hosted_token_params, %s);' .
				'} else { acceptblue_hosted_token_params = %s; }',
				wp_json_encode( $merged ),
				wp_json_encode( $merged )
			);
			wp_add_inline_script( self::GPAY_SCRIPT_HANDLE, $inline_merge, 'before' );
		}

		// If this is the order-review page, also enqueue the place-order handler
		if ( isset( $config['place_order_action'] ) ) {
			wp_enqueue_script(
				'acceptblue-google-pay-place-order',
				plugins_url( 'assets/js/dist/acceptblue-google-pay-place-order.min.js', AB_V2_PLUGIN_FILE ),
				array( 'jquery' ),
				AB_V2_VERSION,
				true
			);
			$inline_place = sprintf(
				'window.acceptblue_gpay_place_order_action = %s;',
				wp_json_encode( $config['place_order_action'] )
			);
			wp_add_inline_script( 'acceptblue-google-pay-place-order', $inline_place, 'before' );
		}
	}

	/**
	 * Determine which Google Pay config to use based on the current page type.
	 *
	 * @return array|false  Config array or false if not applicable.
	 */
	private function resolve_page_config() {
		$has_addons = class_exists( 'WC_Subscriptions_Order' ) || class_exists( 'WC_Pre_Orders_Order' );

		if ( is_product() && $this->gateway->google_pay_button_product_enable ) {
			return array(
				'container_id' => 'acceptblue-google-pay-product-button',
				'ajax_action'  => $has_addons
					? 'acceptblue_request_product_page_charge_addons'
					: 'acceptblue_request_product_page_charge',
			);
		}

		if ( is_cart() && $this->gateway->google_pay_button_cart_enable ) {
			return array(
				'container_id' => 'acceptblue-google-pay-cart-button',
				'ajax_action'  => $has_addons
					? 'acceptblue_request_cart_page_charge_addons'
					: 'acceptblue_request_cart_page_charge',
			);
		}

		if ( is_checkout() && ! is_checkout_pay_page() && $this->gateway->google_pay_button_checkout_enable ) {
			return array(
				'container_id' => 'acceptblue-google-pay-checkout-button',
				'ajax_action'  => $has_addons
					? 'acceptblue_request_checkout_page_charge_addons'
					: 'acceptblue_request_checkout_page_charge',
			);
		}

		// Order-review page (shortcode) — identified by ?key= in URL
		if ( is_page() && ! empty( $_GET['key'] ) ) {
			return array(
				'container_id'        => 'acceptblue-google-pay-product-button',
				'ajax_action'         => 'acceptblue_request_checkout_page_charge',
				'place_order_action'  => $has_addons
					? 'acceptblue_request_place_order_charge_addons'
					: 'acceptblue_request_place_order_charge',
			);
		}

		return false;
	}

	/* ================================================================== */
	/* C. Button rendering                                                 */
	/* ================================================================== */

	/**
	 * Render the button container + inline price vars for the product page.
	 */
	public function render_product_button() {
		if ( $this->is_pay_page() ) return;
		if ( ! $this->gateway->google_pay_button_product_enable ) return;

		global $product;
		if ( ! $product instanceof WC_Product ) {
			$product = wc_get_product( get_the_ID() );
		}
		if ( ! $product ) return;

		// Variable products have no single price — skip; each variation handles its own price
		if ( $product->is_type( 'variable' ) ) return;

		// Use the base product price (tax-inclusive), matching the original plugin behaviour.
		// wc_get_price_including_tax() is used to avoid the deprecated WC 3.0 instance method.
		$base_price = wc_get_price_including_tax( $product );
		$currency   = get_woocommerce_currency();
		$product_id = $product->get_id();

		$this->output_button_container(
			'acceptblue-google-pay-product-button',
			$base_price,
			$currency,
			$product_id
		);
	}

	/**
	 * Render the button container + inline price vars for the cart page.
	 */
	public function render_cart_button() {
		if ( $this->is_pay_page() ) return;
		if ( ! $this->gateway->google_pay_button_cart_enable ) return;

		$final_price = WC()->cart->get_total( '' );
		$currency    = get_woocommerce_currency();

		$this->output_button_container( 'acceptblue-google-pay-cart-button', $final_price, $currency );
	}

	/**
	 * Render the button container + inline price vars for the checkout page.
	 */
	public function render_checkout_button() {
		if ( $this->is_pay_page() ) return;
		if ( ! $this->gateway->google_pay_button_checkout_enable ) return;

		$final_price = (float) WC()->cart->get_total( 'edit' );
		$currency    = get_woocommerce_currency();

		$this->output_button_container( 'acceptblue-google-pay-checkout-button', $final_price, $currency );
	}

	/**
	 * Output a button container div and the inline JS vars the module needs.
	 *
	 * @param string $container_id  DOM element id for the Google Pay button.
	 * @param float  $price         Order/cart total.
	 * @param string $currency      ISO currency code.
	 * @param int    $product_id    Optional product ID (product page only).
	 */
	private function output_button_container( $container_id, $price, $currency, $product_id = 0 ) {
		$price_formatted = number_format( (float) $price, 2, '.', '' );
		?>
		<div id="<?php echo esc_attr( $container_id ); ?>" class="acceptblue-google-pay-button-wrap"></div>
		<script type="text/javascript">
		/* accept.blue — Google Pay page vars */
		var acceptblue_final_price    = <?php echo wp_json_encode( $price_formatted ); ?>;
		var acceptblue_currency_code  = <?php echo wp_json_encode( $currency ); ?>;
		<?php if ( $product_id ) : ?>
		var acceptblue_product_id     = <?php echo wp_json_encode( (string) $product_id ); ?>;
		<?php endif; ?>
		</script>
		<?php
	}

	/**
	 * FIX: Ajax loader div was commented out in the old per-button render
	 * methods. It now lives once in the footer, always available to JS.
	 */
	public function render_ajax_loader() {
		echo '<div id="acceptblue-google-pay-ajax-loader" style="display:none;"></div>';
	}

	/* ================================================================== */
	/* D. Localised JS params — called from the gateway's local_script()  */
	/* ================================================================== */

	/**
	 * Return the Google Pay specific key/value pairs to merge into the main
	 * acceptblue_hosted_token_params JS object.
	 *
	 * FIX: countryCode is now included.
	 * FIX: billingAddressParameters only sent when billingAddressRequired=true.
	 * FIX: Merchant ID validated before being passed to JS.
	 *
	 * @param  bool $is_logged_in  Whether the current user is logged in.
	 * @param  bool $force_billing Force billingAddressRequired regardless of settings.
	 * @return array
	 */
	public function get_localized_params( $is_logged_in, $force_billing = false ) {

		$gw = $this->gateway;

		$billing_required = $force_billing ? true : (bool) $gw->google_pay_billing_address_required;
		$phone_required   = $force_billing ? true : (bool) $gw->google_pay_phone_number_required;

		// FIX: Validate merchant ID — strip hyphens but flag if other unexpected chars exist
		$merchant_id = preg_replace( '/[^0-9]/', '', $gw->google_merchant_id );

		$params = array(
			'google_pay_merchant_name'          => $gw->google_merchant_name,
			'google_pay_environment'            => $gw->testmode ? 'TEST' : 'PRODUCTION',
			'google_pay_merchant_id'            => $merchant_id,
			'google_pay_country_code'           => $this->get_store_country_code(), // FIX: added
			'gateway_merchant_id'               => $gw->gateway_merchant_id,
			'allowed_card_networks'             => $gw->card_networks,
			'allowed_card_auth_methods'         => $gw->card_auth_methods,
			'button_color'                      => $gw->button_color,
			'button_type'                       => $gw->button_type,
			'button_locale'                     => $gw->button_locale,
			'google_pay_billing_address_required' => $billing_required,
			'google_pay_phone_number_required'  => $phone_required,
			'surcharge_card'                    => ! empty( $gw->settings['surcharge_card'] ) ? $gw->settings['surcharge_card'] : 'no',
			'is_user_logged_in'                 => $is_logged_in ? 1 : 0,
		);

		return $params;
	}

	/**
	 * Resolve the WooCommerce store country as an ISO-3166-1 alpha-2 code.
	 *
	 * @return string e.g. 'US'
	 */
	private function get_store_country_code() {
		$country = WC()->countries->get_base_country();
		return $country ?: 'US';
	}

	/* ================================================================== */
	/* E. Shortcode — [acceptblue_googlepay_review_order]                 */
	/* ================================================================== */

	public function shortcode_review_order() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return '<p>' . esc_html__( 'WooCommerce is not active.', 'woocommerce' ) . '</p>';
		}

		$order_key = ! empty( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';
		if ( empty( $order_key ) ) {
			return '<p>' . esc_html__( 'No order found.', 'woocommerce' ) . '</p>';
		}

		$order_id = wc_get_order_id_by_order_key( $order_key );
		if ( empty( $order_id ) ) {
			return '<p>' . esc_html__( 'No order found.', 'woocommerce' ) . '</p>';
		}

		if ( class_exists( 'WC_Subscriptions_Order' ) && wcs_order_contains_subscription( $order_id ) ) {
			return $this->render_subscription_review( $order_id, $order_key );
		}

		return $this->render_order_review( $order_id, $order_key );
	}

	/** @return string */
	private function render_order_review( $order_id, $order_key ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return '<p>' . esc_html__( 'Invalid order ID or key.', 'woocommerce' ) . '</p>';
		}

		// Already paid
		if ( $order->get_transaction_id() ) {
			return '<p>' . esc_html__( 'The order has been processed.', 'woocommerce' ) . '</p>';
		}

		$has_addons           = class_exists( 'WC_Subscriptions_Order' ) || class_exists( 'WC_Pre_Orders_Order' );
		$place_order_action   = $has_addons
			? 'acceptblue_request_place_order_charge_addons'
			: 'acceptblue_request_place_order_charge';

		ob_start();
		$this->render_order_review_html( $order, $order_key, $place_order_action );
		return ob_get_clean();
	}

	/** @return string */
	private function render_subscription_review( $order_id, $order_key ) {
		if ( ! class_exists( 'WC_Subscriptions' ) ) {
			return '<p>' . esc_html__( 'WooCommerce Subscriptions is not active.', 'woocommerce' ) . '</p>';
		}

		// Verify the parent order exists and hasn't been paid yet
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return '<p>' . esc_html__( 'Invalid order.', 'woocommerce' ) . '</p>';
		}
		if ( $order->get_transaction_id() ) {
			return '<p>' . esc_html__( 'The order has been processed.', 'woocommerce' ) . '</p>';
		}

		$subscriptions = wcs_get_subscriptions_for_order( $order_id );
		if ( empty( $subscriptions ) ) {
			return '<p>' . esc_html__( 'No subscriptions found for this order.', 'woocommerce' ) . '</p>';
		}

		$subscription = reset( $subscriptions );
		if ( ! $subscription ) {
			return '<p>' . esc_html__( 'Invalid subscription.', 'woocommerce' ) . '</p>';
		}

		ob_start();
		// Pass both the subscription (for items/totals) and the parent order_key
		// (for the place-order AJAX handler which looks up payment_token on the order)
		$this->render_subscription_review_html( $subscription, $order_key, $order );
		return ob_get_clean();
	}

	/* ── Shared review page helpers ──────────────────────────────────── */

	private function gpay_icon_url() {
		return esc_url( WC_HTTPS::force_https_url(
			plugin_dir_url( AB_V2_PLUGIN_FILE ) . 'assets/images/google_pay/google-pay-icon.svg'
		) );
	}

	private function render_order_review_html( WC_Order $order, $order_key, $place_order_action ) {
		$payment_method_title = $this->get_payment_method_title( $order );
		$show_gpay_icon       = $this->is_gpay_title( $payment_method_title );
		$fee_amount_value     = 0;
		$settings             = get_option( 'woocommerce_acceptbluev2_settings', array() );
		$surcharge_row        = $this->get_surcharge_row_data( $settings, (float) $order->get_total() );
		if ( $surcharge_row ) {
			$fee_amount_value = $surcharge_row['amount'];
		}
		?>
		<div class="ab-review-wrap">
			<div class="woocommerce-notices-wrapper"><?php wc_print_notices(); ?></div>
			<h1 class="ab-review-title"><?php esc_html_e( 'Review Your Order', 'woocommerce' ); ?></h1>

			<div class="ab-review-grid">

				<!-- Left column: items -->
				<div class="ab-col-left">

					<div class="ab-card">
						<div class="ab-card-header">
							<h2><?php esc_html_e( 'Order Items', 'woocommerce' ); ?></h2>
						</div>
						<ul class="ab-items-list">
							<?php foreach ( $order->get_items() as $item ) :
								$product = $item->get_product();
								$img_src = $product ? wp_get_attachment_image_src( $product->get_image_id(), 'thumbnail' ) : false;
								$img_url = $img_src ? $img_src[0] : wc_placeholder_img_src();
							?>
							<li class="ab-item">
								<button type="button"
								        class="ab-item-thumb-btn"
								        title="<?php echo $product ? esc_attr( $product->get_name() ) : ''; ?>"
								        style="--ab-thumb-url: url('<?php echo esc_url( $img_url ); ?>')">
									<?php if ( $img_src ) : ?>
										<img class="ab-item-img"
										     src="<?php echo esc_url( $img_url ); ?>"
										     alt="<?php echo $product ? esc_attr( $product->get_name() ) : ''; ?>" />
									<?php else : ?>
										<span class="ab-item-icon" aria-hidden="true">&#128230;</span>
									<?php endif; ?>
								</button>
								<div class="ab-item-details">
									<p class="ab-item-name"><?php echo esc_html( $item->get_name() ); ?></p>
									<p class="ab-item-qty"><?php printf( esc_html__( 'Qty: %s', 'woocommerce' ), esc_html( $item->get_quantity() ) ); ?></p>
								</div>
								<span class="ab-item-price"><?php echo wp_kses_post( wc_price( $item->get_total() ) ); ?></span>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>

				</div><!-- /.ab-col-left -->

				<!-- Right column: summary + payment + actions -->
				<div class="ab-col-right">

					<!-- Order summary -->
					<div class="ab-card">
						<div class="ab-card-header">
							<h3><?php esc_html_e( 'Order Summary', 'woocommerce' ); ?></h3>
						</div>
						<div class="ab-card-body">
							<table class="ab-totals">
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $order->get_subtotal() ) ); ?></td>
								</tr>
								<?php if ( $order->get_total_discount() > 0 ) : ?>
								<tr class="ab-discount">
									<td class="ab-label"><?php esc_html_e( 'Discount', 'woocommerce' ); ?></td>
									<td class="ab-value">-<?php echo wp_kses_post( wc_price( $order->get_total_discount() ) ); ?></td>
								</tr>
								<?php endif; ?>
								<?php if ( $order->get_shipping_total() > 0 ) : ?>
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Shipping', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $order->get_shipping_total() ) ); ?></td>
								</tr>
								<?php endif; ?>
								<?php foreach ( $order->get_tax_totals() as $tax ) : ?>
								<tr>
									<td class="ab-label"><?php echo esc_html( $tax->label ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
								</tr>
								<?php endforeach; ?>
								<?php if ( $surcharge_row ) : ?>
								<tr class="ab-surcharge">
									<td class="ab-label"><?php echo esc_html( $surcharge_row['label'] ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $surcharge_row['amount'] ) ); ?></td>
								</tr>
								<?php endif; ?>
								<tr class="ab-total-row">
									<td class="ab-label"><?php esc_html_e( 'Total', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $order->get_total() + $fee_amount_value ) ); ?></td>
								</tr>
							</table>
						</div>
					</div>

					<!-- Payment method -->
					<div class="ab-card">
						<div class="ab-card-header">
							<h3><?php esc_html_e( 'Payment', 'woocommerce' ); ?></h3>
						</div>
						<div class="ab-payment-badge">
							<?php if ( $show_gpay_icon ) : ?>
								<img class="ab-payment-badge-icon"
								     src="<?php echo $this->gpay_icon_url(); ?>"
								     alt="Google Pay" />
							<?php endif; ?>
							<span class="ab-payment-badge-label"><?php echo esc_html( $payment_method_title ); ?></span>
						</div>
					</div>

					<!-- Actions -->
					<div class="ab-card">
						<div class="ab-actions">
							<a href="javascript:;"
							   data-order-key="<?php echo esc_attr( $order_key ); ?>"
							   class="ab-btn-place-order button-google-pay-place-order">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
								<?php esc_html_e( 'Place Order', 'woocommerce' ); ?>
							</a>
							<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"
							   class="ab-btn-cancel">
								<?php esc_html_e( 'Cancel Order', 'woocommerce' ); ?>
							</a>
						</div>
						<p class="ab-trust-note">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
							<?php esc_html_e( 'Secure checkout — powered by Google Pay', 'woocommerce' ); ?>
						</p>
					</div>

				</div><!-- /.ab-col-right -->

			</div><!-- /.ab-review-grid -->
		</div><!-- /.ab-review-wrap -->
		<?php
	}

	private function render_subscription_review_html( $subscription, $order_key, $parent_order = null ) {
		$payment_method_title = $this->get_payment_method_title( $subscription );
		$show_gpay_icon       = $this->is_gpay_title( $payment_method_title );
		$fee_amount_value     = 0;
		$settings             = get_option( 'woocommerce_acceptbluev2_settings', array() );

		// Use parent order total for surcharge calculation (subscription total == first payment)
		$total_for_surcharge  = $parent_order ? (float) $parent_order->get_total() : (float) $subscription->get_total();
		$surcharge_row        = $this->get_surcharge_row_data( $settings, $total_for_surcharge );
		if ( $surcharge_row ) {
			$fee_amount_value = $surcharge_row['amount'];
		}

		// Subscription meta — billing period, next payment, trial
		$billing_period    = $subscription->get_billing_period();
		$billing_interval  = $subscription->get_billing_interval();
		$trial_end         = $subscription->get_date( 'trial_end' );
		$next_payment      = $subscription->get_date( 'next_payment' );
		$sub_total         = $subscription->get_total();
		$first_total       = $parent_order ? $parent_order->get_total() : $sub_total;

		// Frequency label e.g. "Every month", "Every 3 months"
		$interval_label = ( (int) $billing_interval === 1 )
			? sprintf( esc_html__( 'Every %s', 'woocommerce' ), $billing_period )
			: sprintf( esc_html__( 'Every %d %ss', 'woocommerce' ), $billing_interval, $billing_period );
		?>
		<div class="ab-review-wrap">
			<div class="woocommerce-notices-wrapper"><?php wc_print_notices(); ?></div>
			<h1 class="ab-review-title"><?php esc_html_e( 'Review Your Subscription', 'woocommerce' ); ?></h1>

			<div class="ab-review-grid">

				<!-- Left column: items + subscription details -->
				<div class="ab-col-left">

					<div class="ab-card">
						<div class="ab-card-header">
							<h2><?php esc_html_e( 'Subscription Items', 'woocommerce' ); ?></h2>
							<span class="ab-sub-badge"><?php echo esc_html( $interval_label ); ?></span>
						</div>
						<ul class="ab-items-list">
							<?php foreach ( $subscription->get_items() as $item ) :
								$product = $item->get_product();
								$img_src = $product ? wp_get_attachment_image_src( $product->get_image_id(), 'thumbnail' ) : false;
								$img_url = $img_src ? $img_src[0] : wc_placeholder_img_src();
							?>
							<li class="ab-item">
								<button type="button"
								        class="ab-item-thumb-btn"
								        title="<?php echo $product ? esc_attr( $product->get_name() ) : ''; ?>"
								        style="--ab-thumb-url: url('<?php echo esc_url( $img_url ); ?>')">
									<?php if ( $img_src ) : ?>
										<img class="ab-item-img"
										     src="<?php echo esc_url( $img_url ); ?>"
										     alt="<?php echo $product ? esc_attr( $product->get_name() ) : ''; ?>" />
									<?php else : ?>
										<span class="ab-item-icon" aria-hidden="true">&#128230;</span>
									<?php endif; ?>
								</button>
								<div class="ab-item-details">
									<p class="ab-item-name"><?php echo esc_html( $item->get_name() ); ?></p>
									<p class="ab-item-qty"><?php printf( esc_html__( 'Qty: %s', 'woocommerce' ), esc_html( $item->get_quantity() ) ); ?></p>
								</div>
								<span class="ab-item-price"><?php echo wp_kses_post( wc_price( $item->get_total() ) ); ?></span>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>

					<!-- Subscription schedule card -->
					<div class="ab-card">
						<div class="ab-card-header">
							<h2><?php esc_html_e( 'Subscription Schedule', 'woocommerce' ); ?></h2>
						</div>
						<div class="ab-card-body">
							<table class="ab-totals">
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Billing frequency', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo esc_html( ucfirst( $interval_label ) ); ?></td>
								</tr>
								<?php if ( ! empty( $trial_end ) ) : ?>
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Free trial ends', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo esc_html( wcs_get_datetime_utc_string( $trial_end ) ); ?></td>
								</tr>
								<?php endif; ?>
								<?php if ( ! empty( $next_payment ) ) : ?>
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Next payment', 'woocommerce' ); ?></td>
									<td class="ab-value ab-next-payment"><?php echo esc_html( date_i18n( wc_date_format(), strtotime( $next_payment ) ) ); ?></td>
								</tr>
								<?php endif; ?>
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Recurring total', 'woocommerce' ); ?></td>
									<td class="ab-value ab-recurring-total"><?php echo wp_kses_post( wc_price( $sub_total ) . ' / ' . $billing_period ); ?></td>
								</tr>
							</table>
						</div>
					</div>

				</div><!-- /.ab-col-left -->

				<!-- Right column: summary + payment + actions -->
				<div class="ab-col-right">

					<!-- Order summary — first payment -->
					<div class="ab-card">
						<div class="ab-card-header">
							<h3><?php esc_html_e( 'First Payment', 'woocommerce' ); ?></h3>
						</div>
						<div class="ab-card-body">
							<table class="ab-totals">
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $subscription->get_subtotal() ) ); ?></td>
								</tr>
								<?php if ( $subscription->get_shipping_total() > 0 ) : ?>
								<tr>
									<td class="ab-label"><?php esc_html_e( 'Shipping', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $subscription->get_shipping_total() ) ); ?></td>
								</tr>
								<?php endif; ?>
								<?php foreach ( $subscription->get_tax_totals() as $tax ) : ?>
								<tr>
									<td class="ab-label"><?php echo esc_html( $tax->label ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
								</tr>
								<?php endforeach; ?>
								<?php if ( $surcharge_row ) : ?>
								<tr class="ab-surcharge">
									<td class="ab-label"><?php echo esc_html( $surcharge_row['label'] ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $surcharge_row['amount'] ) ); ?></td>
								</tr>
								<?php endif; ?>
								<tr class="ab-total-row">
									<td class="ab-label"><?php esc_html_e( 'Due today', 'woocommerce' ); ?></td>
									<td class="ab-value"><?php echo wp_kses_post( wc_price( $first_total + $fee_amount_value ) ); ?></td>
								</tr>
							</table>
						</div>
					</div>

					<!-- Payment method -->
					<div class="ab-card">
						<div class="ab-card-header">
							<h3><?php esc_html_e( 'Payment', 'woocommerce' ); ?></h3>
						</div>
						<div class="ab-payment-badge">
							<?php if ( $show_gpay_icon ) : ?>
								<img class="ab-payment-badge-icon"
								     src="<?php echo $this->gpay_icon_url(); ?>"
								     alt="Google Pay" />
							<?php endif; ?>
							<span class="ab-payment-badge-label"><?php echo esc_html( $payment_method_title ); ?></span>
						</div>
					</div>

					<!-- Actions -->
					<div class="ab-card">
						<div class="ab-actions">
							<a href="javascript:;"
							   data-order-key="<?php echo esc_attr( $order_key ); ?>"
							   class="ab-btn-place-order button-google-pay-place-order">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
								<?php esc_html_e( 'Start Subscription', 'woocommerce' ); ?>
							</a>
							<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'subscriptions' ) ); ?>"
							   class="ab-btn-cancel">
								<?php esc_html_e( 'Cancel', 'woocommerce' ); ?>
							</a>
						</div>
						<p class="ab-trust-note">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
							<?php esc_html_e( 'Secure checkout — powered by Google Pay', 'woocommerce' ); ?>
						</p>
					</div>

				</div><!-- /.ab-col-right -->

			</div><!-- /.ab-review-grid -->
		</div><!-- /.ab-review-wrap -->
		<?php
	}

		/* ── Surcharge helper ────────────────────────────────────────────── */

	/**
	 * Return surcharge label + computed amount, or null if surcharge is disabled.
	 *
	 * @param  array $settings Plugin settings.
	 * @param  float $order_total Order/subscription total before surcharge.
	 * @return array|null  ['label' => string, 'amount' => float] or null.
	 */
	private function get_surcharge_row_data( $settings, $order_total ) {
		if ( empty( $settings['enabled'] ) || $settings['enabled'] !== 'yes' ) return null;
		if ( empty( $settings['surcharge_card'] ) || $settings['surcharge_card'] !== 'yes' ) return null;

		$response  = apply_filters( 'acceptblue_googlepay_get_surcharge', true );
		if ( empty( $response['card'] ) ) return null;

		$surcharge = $response['card'];
		$label_key = ! empty( $settings['surcharge_label'] ) ? $settings['surcharge_label'] : 'Surcharge';
		$amount    = 0;

		if ( $surcharge->type === 'percent' ) {
			$amount = round( $order_total * ( $surcharge->value / 100 ), 2 );
			$label  = sprintf( '%s (%s%%)', $label_key, $surcharge->value );
		} else {
			$amount = (float) $surcharge->value;
			$label  = $label_key;
		}

		return array( 'label' => $label, 'amount' => $amount );
	}

	/* ── Payment method title helper ─────────────────────────────────── */

	private function get_payment_method_title( $order ) {
		$method   = $order->get_payment_method();
		$gateways = WC()->payment_gateways->payment_gateways();
		return isset( $gateways[ $method ] )
			? $gateways[ $method ]->get_title()
			: __( 'Unknown Payment Method', 'woocommerce' );
	}

	private function is_gpay_title( $title ) {
		return false !== stripos( $title, 'google' );
	}

	/* ================================================================== */
	/* F. Admin notices                                                    */
	/* ================================================================== */

	/* ================================================================== */
	/* G. Notices moved to WC_Gateway_AcceptBlue_v2_GooglePay_Checkout   */
	/* ================================================================== */
	// admin_notice_gpay_disabled(), admin_notice_gpay_merchant_id(),
	// admin_notice_gpay_country_code(), admin_notice_review_page_created(),
	// and maybe_create_order_review_page() have all been moved to
	// class-wc-acceptblue-v2-google-pay-checkout.php so they appear on
	// the Google Pay settings screen (section=acceptbluev2_googlepay_checkout).

	/* ── Helper ─────────────────────────────────────────────────────── */

	private function is_pay_page() {
		return is_checkout_pay_page() && absint( get_query_var( 'order-pay' ) ) > 0;
	}

	private function is_payment_settings_screen() {
		if ( ! is_admin() ) return false;
		$screen = get_current_screen();
		if ( ! $screen ) return false;
		// Match either the main gateway screen or the Google Pay gateway screen
		$section = $_GET['section'] ?? '';
		return in_array( $section, array( 'acceptbluev2', 'acceptbluev2_googlepay_checkout' ), true );
	}
}
