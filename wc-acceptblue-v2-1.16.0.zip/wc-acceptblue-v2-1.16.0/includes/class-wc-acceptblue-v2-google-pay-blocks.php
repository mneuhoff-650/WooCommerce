<?php
/**
 * accept.blue — Google Pay WooCommerce Blocks Integration
 *
 * Registers the Google Pay gateway with the WooCommerce Block Checkout
 * payment method registry (Cart Block + Checkout Block).
 *
 * Flow:
 *  1. This class provides the JS handle + data object the Blocks JS needs.
 *  2. The JS renders the Google Pay button inside the block payment option.
 *  3. On Google Pay sheet approval the JS stores the base64 token in
 *     paymentMethodData, which WooCommerce Blocks forwards as a POST field
 *     to process_payment() in WC_Gateway_AcceptBlue_v2_GooglePay_Checkout.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.3
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class WC_AcceptBlue_V2_GooglePay_Blocks extends AbstractPaymentMethodType {

	/** Must match the Google Pay gateway ID. */
	protected $name = 'acceptbluev2_googlepay_checkout';

	/** @var array Raw WooCommerce settings option for the GPay gateway. */
	protected $settings = [];

	/** @var WC_Gateway_AcceptBlue_v2_GooglePay_Checkout|null */
	protected $gateway = null;

	/** @var WC_Gateway_AcceptBlue_v2|null Main gateway (provides API helpers). */
	protected $main_gateway = null;

	// =========================================================================
	// AbstractPaymentMethodType interface
	// =========================================================================

	/**
	 * Called by WooCommerce Blocks before any other method.
	 * Loads settings and resolves gateway instances.
	 */
	public function initialize() {
		$this->settings     = get_option( 'woocommerce_acceptbluev2_googlepay_checkout_settings', [] );
		$this->gateway      = $this->resolve_gateway( 'acceptbluev2_googlepay_checkout' );
		$this->main_gateway = $this->resolve_gateway( 'acceptbluev2' );
	}

	/**
	 * Whether Google Pay should appear in the Block Checkout.
	 *
	 * @return bool
	 */
	public function is_active() {
		return $this->gateway instanceof WC_Payment_Gateway
			&& $this->gateway->is_available();
	}

	/**
	 * Return the script handle(s) to enqueue for the Block Checkout.
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {

		// Google Pay CDN script — must be loaded before our module
		if ( ! wp_script_is( 'google-pay', 'registered' ) ) {
			wp_register_script(
				'google-pay',
				'https://pay.google.com/gp/p/js/pay.js',
				[],
				null,
				true
			);
		}

		wp_register_script(
			'wc-acceptblue-googlepay-blocks-integration',
			plugins_url( 'assets/js/src/acceptblue-google-pay-block-checkout.js', AB_V2_PLUGIN_FILE ),
			[
				'google-pay',
				'wc-blocks-registry',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
				'wp-i18n',
			],
			AB_V2_VERSION,
			true
		);

		return [ 'wc-acceptblue-googlepay-blocks-integration' ];
	}

	/**
	 * Return the data object exposed to the Block JS as:
	 * window.wc.wcSettings.getSetting('acceptbluev2_googlepay_checkout_data', {})
	 *
	 * @return array
	 */
	public function get_payment_method_data() {

		$settings = $this->settings;
		$main     = $this->main_gateway;

		// Environment — read from the Google Pay gateway's OWN settings so this
		// works correctly even when the main acceptbluev2 gateway is disabled.
		$is_test = ( ( $settings['testmode'] ?? 'yes' ) === 'yes' );
		// Fall back to main gateway testmode if own setting is not explicitly saved yet.
		if ( ! isset( $settings['testmode'] ) && $main ) {
			$is_test = (bool) $main->testmode;
		}
		$environment = $is_test ? 'TEST' : 'PRODUCTION';

		// Merchant info
		$google_merchant_id   = $settings['google_merchant_id']   ?? '';
		$google_merchant_name = $settings['google_merchant_name'] ?? get_bloginfo( 'name' );
		$gateway_merchant_id  = $settings['gateway_merchant_id']  ?? '';

		// Card options
		// WC multiselect fields may save as associative array ['VISA'=>'VISA'] — normalise to
		// a clean indexed array so JSON-encoding produces a proper JS array, not an object.
		$raw_networks = $settings['card_networks'] ?? [ 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' ];
		$raw_auths    = $settings['card_auth_methods'] ?? [ 'PAN_ONLY' ];
		$card_networks     = is_array( $raw_networks ) ? array_values( array_filter( array_map( 'strval', $raw_networks ) ) ) : [ 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' ];
		$card_auth_methods = is_array( $raw_auths )    ? array_values( array_filter( array_map( 'strval', $raw_auths ) ) )    : [ 'PAN_ONLY' ];

		// Button appearance
		$button_color  = $settings['button_color']  ?? 'default';
		$button_type   = $settings['button_type']   ?? 'buy';
		$button_locale = $settings['button_locale'] ?? 'en';

		// Billing / phone
		$billing_required = ( ( $settings['google_pay_billing_address_required'] ?? 'no' ) === 'yes' );
		$phone_required   = ( ( $settings['google_pay_phone_number_required']    ?? 'no' ) === 'yes' );

		// Country code for transactionInfo
		$country_code = WC()->countries ? WC()->countries->get_base_country() : 'US';

		// Currency
		$currency_code = get_woocommerce_currency();

		// Cart total (used as a hint — the actual charge uses the server-side order total)
		$cart_total = '0.00';
		if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			$cart_total = number_format( (float) WC()->cart->get_total( 'edit' ), 2, '.', '' );
		}

		// Gateway title / description from the GPay gateway
		$title       = $this->gateway ? $this->gateway->get_title()       : __( 'Google Pay', 'woocommerce' );
		$description = $this->gateway ? $this->gateway->get_description() : '';

		// Pre-generate a nonce the JS will include in paymentMethodData so
		// process_payment() can verify it (same pattern as classic checkout).
		$nonce = wp_create_nonce( 'acceptblue-gpay-checkout-nonce' );

		$data = [
			// Gateway identification
			'title'       => $title,
			'description' => $description,
			'supports'    => $this->gateway ? $this->gateway->supports : [],

			// Google Pay API config
			'google_pay_environment'   => $environment,
			'google_merchant_id'       => $google_merchant_id,
			'google_merchant_name'     => $google_merchant_name,
			'gateway_merchant_id'      => $gateway_merchant_id,
			'allowed_card_networks'    => $card_networks,
			'allowed_card_auth_methods'=> $card_auth_methods,
			'google_pay_country_code'  => $country_code,
			'currency_code'            => $currency_code,
			'cart_total'               => $cart_total,

			// Button appearance
			'button_color'  => $button_color,
			'button_type'   => $button_type,
			'button_locale' => $button_locale,

			// Customer data requirements
			'billing_address_required' => $billing_required,
			'phone_number_required'    => $phone_required,

			// Security
			'nonce'      => $nonce,

			// Icon (reuse main gateway icon path)
			'icon_url'   => plugins_url( 'assets/images/google_pay/google-pay-icon.svg', AB_V2_PLUGIN_FILE ),

			// i18n strings surfaced to JS
			'i18n' => [
				'gpay_not_ready'  => __( 'Google Pay is not available on this device or browser.', 'woocommerce' ),
				'payment_failed'  => __( 'Google Pay payment failed. Please try again or use a different method.', 'woocommerce' ),
				'token_missing'   => __( 'Google Pay authorisation missing. Please click the button again.', 'woocommerce' ),
				'authorised'      => __( 'Google Pay authorised — placing order…', 'woocommerce' ),
			],
		];

		// In testmode: output a JS console.info with the raw PHP data so we can
		// confirm exactly what the blocks integration is sending to the JS layer.
		if ( $is_test ) {
			add_action( 'wp_footer', function() use ( $data ) {
				?>
				<script>
				console.group('[accept.blue] GPay Blocks PHP get_payment_method_data()');
				console.table(<?php echo wp_json_encode( array(
					'environment'          => $data['google_pay_environment'],
					'gateway_merchant_id'  => $data['gateway_merchant_id'],
					'google_merchant_id'   => $data['google_merchant_id'],
					'google_merchant_name' => $data['google_merchant_name'],
					'card_networks_type'   => gettype( $data['allowed_card_networks'] ) . ' count=' . count( $data['allowed_card_networks'] ),
					'card_networks'        => implode( ',', $data['allowed_card_networks'] ),
					'auth_methods_type'    => gettype( $data['allowed_card_auth_methods'] ) . ' count=' . count( $data['allowed_card_auth_methods'] ),
					'auth_methods'         => implode( ',', $data['allowed_card_auth_methods'] ),
				) ); ?>);
				console.groupEnd();
				</script>
				<?php
			}, 99 );
		}

		return $data;
	}

	// =========================================================================
	// Private helpers
	// =========================================================================

	/**
	 * Resolve a gateway instance from the WC payment gateways registry.
	 *
	 * @param  string $gateway_id
	 * @return WC_Payment_Gateway|null
	 */
	private function resolve_gateway( $gateway_id ) {
		if ( ! function_exists( 'WC' ) ) return null;
		$wc = WC();
		if ( ! $wc || ! is_callable( array( $wc, 'payment_gateways' ) ) ) return null;
		$registry = $wc->payment_gateways();
		if ( ! $registry || ! is_callable( array( $registry, 'payment_gateways' ) ) ) return null;
		$gateways = $registry->payment_gateways();
		return $gateways[ $gateway_id ] ?? null;
	}
}
