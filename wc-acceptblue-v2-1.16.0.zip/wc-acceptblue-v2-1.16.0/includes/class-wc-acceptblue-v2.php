<?php
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce accept.blue v2 - Payment Gateway
 * 
 * @author RyanPlugins
 * @version since 1.1
 */

class WC_Gateway_AcceptBlue_v2 extends WC_Payment_Gateway_CC {

    private static $log_enabled = true;
    private static $log = false;
    private $api_pin;
    private $api_key;
    private $public_key;
    public $force_capture;
    public $force_save_card_token;
    public $default_status;
	
	public bool $testmode = false;
	public bool $acceptblue_googlepay_enabled = false;
	public string $acceptblue_url = '';

    public $surcharge_card;
	public $surcharge_manual;
	public $surcharge_type;
	public $surcharge_value;
	public $surcharge_label;
	public $surcharge_checkout;
    //* Tokenization
    public $acceptblue_hosted_url;
    public $hosted_token_enabled;
    public $threeds_key;
    public $threeds;
    public $tokenization;
	public $frictionless;

    //* Icon
    public bool $show_icon = true;

    //* Google Pay
    public $card_networks;
	public $card_auth_methods;
	public $button_color;
	public $button_type;
	public $button_locale;
	public $google_merchant_name;
	public $google_merchant_id;
	public $gateway_merchant_id;
	public $google_pay_billing_address_required;
	public $google_pay_phone_number_required;
    public $source;
	public $order_origin;
	public $google_pay_button_product_enable;
	public $google_pay_button_cart_enable;
	public $google_pay_button_checkout_enable;
	public $order_review_enable;
	public $order_review_page;
    public $googlepay;
	//* Name on Card
	public $name_on_card;
	public $name_on_card_required;
	public $name_on_card_label;    

	public $card_code;
	public $card_code_required;
	public $card_code_label;

	// Level 3 data
	
	public $enable_level3;
	public $level3_truncate;
	public $level3_unit_of_measure;
	public $level3_commodity_code;

	public $card_number_field_label;
	public $card_expiry_field_label;
	public $card_cvc_field_label;

	public $save_card_token_disable;
	public $save_card_label;
	public $block_support_checkout;
	public $form_color_scheme;
	public $custom_color_bg;
	public $custom_color_text;
	public $custom_color_border;

	public $order_capture_status;

	private static $before_cc_form_hooked = false;

    public function __construct() {

        $this->has_fields           = true; 

        $this->supports = array(
		  'products',
		  'default_credit_card_form',
		  'tokenization',
		  'refunds',
		  'subscriptions',
		  'subscription_cancellation',
		  'subscription_reactivation',
		  'subscription_suspension',
		  'subscription_amount_changes',
		  'subscription_payment_method_change', // Subs 1.n compatibility.
		  'subscription_payment_method_change_customer', //* not supported
		  'subscription_payment_method_change_admin',
		  'subscription_date_changes',
		  'multiple_subscriptions',
		  'pre-orders',
		  'woocommerce-payment-blocks'
		);

        $this->id = 'acceptbluev2';
        // Icon is set conditionally after settings are loaded (see below, after init_settings)
        $this->has_fields = true; // in case you need a custom credit card form
        $this->method_title = 'accept.blue Gateway v2';
        $this->method_description = 'Description of accept.blue payment gateway v2'; // will be displayed on the options page

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->title            = $this->get_option('title');
        $this->description      = $this->get_option('description');
        $this->enabled          = $this->get_option('enabled');
        $this->testmode         = 'yes' === $this->get_option('testmode');
        $this->show_icon        = 'yes' === $this->get_option( 'show_icon', 'yes' );

        // Always set the icon URL — hiding is handled inside get_icon() on checkout only.
        $this->icon = plugins_url( 'assets/images/icons/icon.svg', dirname(__FILE__) );

        // API keys      
        $this->api_key          = $this->testmode ? $this->get_option('test_api_key') : $this->get_option('live_api_key');
        $this->api_pin          = $this->testmode ? $this->get_option('test_pin') : $this->get_option('live_pin');

        // Tokenization
        $this->public_key       =  $this->testmode ? $this->get_option('pk_key_test') : $this->get_option('pk_key_live'); //Tokenization SourceKey 
        $this->threeds_key      = $this->testmode ? $this->get_option('threeds_api_key_test') : $this->get_option('threeds_api_key_live'); //3DS SourceKey        
        $this->threeds          = 'yes' ===  $this->get_option( 'threeds' );
        $this->tokenization     = 'yes' ===  $this->get_option( 'tokenization' );    
		$this->frictionless     = 'yes' ===  $this->get_option( 'threeds_frictionless' );

        $this->force_capture          	= 'yes' ===  $this->get_option('force_capture');
        $this->force_save_card_token  	= 'yes' ===  $this->get_option('force_save_card_token');
        $this->default_status   		= $this->get_option('default_status');
		$this->order_capture_status 	= $this->get_option('capture_status');

		//Woocommerce Block Checkout
		$this->block_support_checkout 	= 'yes' === $this->get_option('block_support_checkout');

        // Surcharge
        $this->surcharge_card = !empty($this->settings['surcharge_card']) && 'yes' === $this->settings['surcharge_card'];
		$this->surcharge_checkout = !empty($this->settings['surcharge_checkout']) && 'yes' === $this->settings['surcharge_checkout'];
		$this->surcharge_manual = !empty($this->settings['surcharge_manual']) && 'yes' === $this->settings['surcharge_manual'];

		$this->surcharge_type       = !empty( $this->settings[ 'surcharge_type' ]) ? $this->settings[ 'surcharge_type' ] : '';
		$this->surcharge_value      = !empty( $this->settings[ 'surcharge_value' ]) ? $this->settings[ 'surcharge_value' ] : 0 ;
		$this->surcharge_label      = !empty( $this->settings[ 'surcharge_label' ] ) ? $this->settings[ 'surcharge_label' ] : esc_html__( 'Surcharge Fee' );

		// Google Pay — settings live in the dedicated Google Pay gateway
		// (WooCommerce → Payments → Google Pay (accept.blue)).
		// We read them here so all downstream code (express buttons,
		// WC_AcceptBlue_Google_Pay_Actions, AJAX handlers) continues to
		// work without modification.
		$this->source = 'googlepay';
		$_gpay = get_option( 'woocommerce_acceptbluev2_googlepay_checkout_settings', array() );
		$this->googlepay                           = ( ( $_gpay['enabled']                          ?? 'no'  ) === 'yes' );
		$this->gateway_merchant_id                 = $_gpay['gateway_merchant_id']                  ?? '';
		$this->google_merchant_id                  = $_gpay['google_merchant_id']                   ?? '';
		$this->google_merchant_name                = $_gpay['google_merchant_name']                 ?? '';
		$this->card_networks                       = $_gpay['card_networks']                        ?? array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' );
		$this->card_auth_methods                   = $_gpay['card_auth_methods']                    ?? array( 'PAN_ONLY' );
		$this->button_color                        = $_gpay['button_color']                         ?? 'default';
		$this->button_type                         = $_gpay['button_type']                          ?? 'buy';
		$this->button_locale                       = $_gpay['button_locale']                        ?? 'en';
		$this->google_pay_billing_address_required = ( ( $_gpay['google_pay_billing_address_required'] ?? 'no' ) === 'yes' );
		$this->google_pay_phone_number_required    = ( ( $_gpay['google_pay_phone_number_required']    ?? 'no' ) === 'yes' );
		$this->acceptblue_googlepay_enabled        = $this->googlepay;
		$this->order_origin                        = $this->method_title;
		$this->google_pay_button_product_enable    = ( ( $_gpay['google_pay_button_product_enable']  ?? 'yes' ) === 'yes' );
		$this->google_pay_button_cart_enable       = ( ( $_gpay['google_pay_button_cart_enable']     ?? 'yes' ) === 'yes' );
		$this->google_pay_button_checkout_enable   = ( ( $_gpay['google_pay_button_checkout_enable'] ?? 'yes' ) === 'yes' );
		$this->order_review_enable                 = ( ( $_gpay['order_review_enable']               ?? 'no'  ) === 'yes' );
		$this->order_review_page                   = $_gpay['order_review_page']                    ?? '';

		// Name on Card
		$this->name_on_card 			= 'yes' ===  $this->settings[ 'name_on_card' ];
		$this->name_on_card_required 	= 'yes' ===  $this->settings[ 'name_on_card_required' ];
		$this->name_on_card_label 		= ! empty( $this->settings['name_on_card_label'] )
											? $this->settings['name_on_card_label']
											: esc_html__( 'Name on Card', 'woocommerce' );

		$this->card_code 			= 'yes' ===  $this->settings[ 'card_code' ];
		$this->card_code_required 	= 'yes' ===  $this->settings[ 'card_code_required' ];
		$this->card_code_label 		= esc_html__( 'Card Code', 'woocommerce' );	

		// Level 3 data

		$this->enable_level3   = $this->get_option('enable_level3') === 'yes';
		$this->level3_truncate = $this->get_option('level3_truncate') === 'yes';
		
		$this->level3_unit_of_measure 	= !empty($this->settings['level3_unit_of_measure']) ? $this->settings['level3_unit_of_measure'] : '';
		$this->level3_commodity_code 	= !empty($this->settings['level3_commodity_code']) ? $this->settings['level3_commodity_code'] : '';

		// Card labels
		$this->card_number_field_label 	= !empty($this->settings['card_number_field_label']) ? $this->settings['card_number_field_label'] : esc_html__( 'Card number', 'woocommerce' );
		$this->card_expiry_field_label 	= !empty($this->settings['card_expiry_field_label']) ? $this->settings['card_expiry_field_label'] : esc_html__( 'Expiry (MM/YY)', 'woocommerce' );
		$this->card_cvc_field_label 		= !empty($this->settings['card_cvc_field_label']) ? $this->settings['card_cvc_field_label'] : esc_html__( 'Card code (CVC)', 'woocommerce' );

		// Save Card token

		$this->save_card_token_disable 	= 'yes' ===  $this->settings[ 'save_card_token_disable' ];
		$this->save_card_label 			= !empty($this->settings['save_card_label']) ? $this->settings['save_card_label'] : esc_html__( 'Save to account', 'woocommerce' );
		$this->form_color_scheme        = $this->get_option( 'form_color_scheme', 'auto' );
		$this->custom_color_bg          = $this->get_option( 'custom_color_bg',     '#f7f7f7' );
		$this->custom_color_text        = $this->get_option( 'custom_color_text',   '#333333' );
		$this->custom_color_border      = $this->get_option( 'custom_color_border', '#cccccc' );

        self::$log_enabled = 'yes' === $this->settings[ 'debug' ];

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
       
		//add_action( 'wp_enqueue_scripts', array( $this, 'style' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		// Card Labels
		add_filter( 'woocommerce_credit_card_form_fields', array( $this, 'custom_cc_labels' ), 10, 2 );

		// Save Card Token option
		add_filter( 'woocommerce_payment_gateway_supports', array( $this, 'disabled_enabled_save_card_token' ), 10, 3 );

		// Save Card Token label
		add_filter( 'woocommerce_payment_gateway_save_new_payment_method_option_html', array( $this, 'custom_save_card_token_label' ), 10, 2 );


        // Initialize logger
        // if (self::$log_enabled) {
        //     self::$log = wc_get_logger();
        // }

        //* Accept.Blue Gateway URL

		if( $this->testmode === true ) {
			$this->acceptblue_url = "https://api.develop.accept.blue/api/v2/";
            $this->acceptblue_hosted_url    = "https://tokenization.sandbox.accept.blue/tokenization/v0.3";
           
		} else {
            $this->acceptblue_url = "https://api.accept.blue/api/v2/";	
            $this->acceptblue_hosted_url    = "https://tokenization.accept.blue/tokenization/v0.3";
						
		}

        // ── Add Payment Method page: force Classic Non-3DS mode ─────────────────
        // is_add_payment_method_page() is NOT reliable at __construct() time because
        // WooCommerce hasn't parsed the URL endpoint yet. We defer the mode override
        // to the 'wp' action which fires after WP_Query is set up but before
        // wp_enqueue_scripts, so is_add_payment_method_page() works correctly there.
        add_action( 'wp', array( $this, 'force_classic_mode_on_add_payment_method' ), 1 );

        if( $this->tokenization === true ){
			add_action( 'wp_enqueue_scripts', array( $this, 'local_script' ) );
            add_action( 'woocommerce_receipt_' . $this->id, array($this, 'tokenization_receipt_page'));
            add_action( 'wp_enqueue_scripts', array( $this, 'tokenization_script' ) );
             
        } else {
            add_action( 'wp_enqueue_scripts', array( $this, 'script' ) );

            // On the order-pay page, acceptblue_v2_enqueue_global_params() is skipped,
            // so local_script() (which registers + localises acceptblue-v2-js) is never
            // called. script() depends on acceptblue-v2-js, so we must ensure local_script()
            // runs on order-pay regardless of block_support_checkout mode.
            // When block_support_checkout=true we use the wrapper that temporarily sets
            // block_checkout:false so the classic card-form JS handles the submit.
            // When block_support_checkout=false (classic mode) we call local_script() directly.
            add_action( 'wp', array( $this, 'maybe_local_script_on_pay_order_page' ), 2 );
        }

		// Always register the add-payment-method script hook regardless of tokenization mode.
		// When block_support_checkout=true and tokenization=false, we still need the
		// hosted iframe JS on the add-payment-method page.
		add_action( 'wp_enqueue_scripts', array( $this, 'add_payment_method_script' ) );

		
		add_action( 'wp_enqueue_scripts', array( $this, 'style' ) );

		// Ensure the action is only added once
        if (!self::$before_cc_form_hooked) {
            add_action('woocommerce_credit_card_form_start', array($this, 'before_cc_form'));
			//add_action( 'woocommerce_after_checkout_payment_form', array( $this, 'add_custom_input_after_saved_payment_methods' ) );

            self::$before_cc_form_hooked = true;
        }

    }

    public function init_form_fields() {

        //* WP Custom Page List

		$pages = get_pages(); 

		$page_list = array();

		if( !empty($pages)){				

			$page_list[''] = __( 'Default' );     

			foreach ( $pages as $page ) {
				$page_list[$page->ID] = __( $page->post_title );        
			}


		}

        $this->form_fields = array(
                        'section_general' => array(
                'title' => __( 'General', 'wc-ab-ae' ),
                'type'  => 'title',
            ),
            'enabled' => array(
                'title'   => 'Enable/Disable',
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Enable AcceptBlue Payment Gateway', 'woocommerce' ),
                'default' => 'yes',
            ),
            'title' => array(
                'title'       => 'Title',
                'type'        => 'text',
                'description' => esc_html__( 'Controls the title customers see at checkout.', 'woocommerce' ),
                'default'     => esc_html__( 'Credit Card', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'Controls the description customers see at checkout.',
                'default'     => 'Pay with your credit card.',
            ),
            'show_icon' => array(
                'title'       => esc_html__( 'Gateway Icon', 'woocommerce' ),
                'label'       => esc_html__( 'Show accept.blue icon on checkout', 'woocommerce' ),
                'type'        => 'checkbox',
                'default'     => 'yes',
                'description' => esc_html__( 'Display the accept.blue icon next to the payment method title on the checkout page.', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'block_support_checkout' => array(
                'title'       => esc_html__( 'Checkout Block', 'woocommerce' ),
                'label'       => esc_html__( 'Enable WooCommerce Checkout Block support', 'woocommerce' ),
                'type'        => 'checkbox',
                'default'     => 'no',
                'description' => esc_html__( 'When enabled, supports both standard (non-3DS) and 3D Secure (3DS) card payments on the WooCommerce block-based checkout page.', 'woocommerce' ),
                'desc_tip'    => false,
            ),
                        'section_api' => array(
                'title' => __( 'API Keys', 'wc-ab-ae' ),
                'type'  => 'title',
            ),
            'testmode' => array(
                'title'       => 'Test Mode',
                'type'        => 'checkbox',
                'label'       => 'Enable Test Mode',
                'default'     => 'yes',
                'description' => 'Place the payment gateway in test mode using test API keys.',
            ),
            'test_api_key' => array(
                'title'       => 'Test API Key',
                'type'        => 'text',
                'description' => 'Used for processing transactions in test/sandbox mode.',
            ),
            'live_api_key' => array(
                'title'       => 'Live API Key',
                'type'        => 'text',
                'description' => 'Used for processing live transactions.',
            ),
            'test_pin' => array(
                'title'       => 'Test PIN',
                'type'        => 'text',
                'description' => 'Required for Check Refund, recommended for CC Refund.',
            ),
            'live_pin' => array(
                'title'       => 'Live PIN',
                'type'        => 'text',
                'description' => 'Required for Check Refund, recommended for CC Refund.',
            ),
                        'section_tokenization' => array(
                'title' => __( 'Tokenization', 'wc-ab-ae' ),
                'type'  => 'title',
            ),
            'tokenization' => array(
                'title'   => esc_html__( 'Hosted Tokenization', 'woocommerce' ),
                'label'   => esc_html__( 'Enable Hosted Tokenization (redirects to a dedicated payment page)', 'woocommerce' ),
                'type'    => 'checkbox',
                'default' => 'no',
            ),
            'pk_key_live' => array(
                'title'       => esc_html__( 'Tokenization Key (Live)', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Your Live public tokenization key from accept.blue.', 'woocommerce' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'pk_key_test' => array(
                'title'       => esc_html__( 'Tokenization Key (Test)', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Your Test public tokenization key from accept.blue.', 'woocommerce' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'threeds' => array(
                'title'   => esc_html__( 'Paay 3D Secure', 'woocommerce' ),
                'label'   => esc_html__( 'Enable Paay 3D Secure', 'woocommerce' ),
                'type'    => 'checkbox',
                'default' => 'no',
            ),
            'threeds_api_key_live' => array(
                'title'       => esc_html__( 'Paay 3DS API Key (Live)', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Your Live Paay 3DS API Key.', 'woocommerce' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'threeds_api_key_test' => array(
                'title'       => esc_html__( 'Paay 3DS API Key (Test)', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Your Test Paay 3DS API Key.', 'woocommerce' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'threeds_frictionless' => array(
                'title'   => esc_html__( 'Paay 3DS Frictionless', 'woocommerce' ),
                'label'   => esc_html__( 'Enable Paay 3DS Frictionless mode', 'woocommerce' ),
                'type'    => 'checkbox',
                'default' => 'no',
            ),
                        'section_payment' => array(
                'title' => __( 'Card & Payment', 'wc-ab-ae' ),
                'type'  => 'title',
            ),
            'force_capture' => array(
                'title'       => 'Force Capture',
                'type'        => 'checkbox',
                'label'       => 'Automatically capture payment after order is placed',
                'default'     => 'no',
                'description' => 'Enable to automatically force-capture the payment after the order is placed.',
            ),
            'force_save_card_token' => array(
                'title'       => 'Force Save Card Token',
                'type'        => 'checkbox',
                'label'       => 'Force save card token after every order',
                'default'     => 'no',
                'description' => 'Enable to force save the card token after the order is placed.',
            ),
            'default_status' => array(
                'title'       => esc_html__( 'Default Order Status', 'woocommerce' ),
                'type'        => 'select',
                'description' => esc_html__( 'Order status set after a successful payment.', 'woocommerce' ),
                'default'     => 'default',
                'desc_tip'    => true,
                'options'     => array( 'default' => 'Default', 'on-hold' => 'On Hold', 'processing' => 'Processing', 'pending' => 'Pending Payment', 'completed' => 'Completed' ),
            ),
            'capture_status' => array(
                'title'       => esc_html__( 'Capture Order Status', 'woocommerce' ),
                'type'        => 'select',
                'description' => esc_html__( 'Order status that triggers payment capture.', 'woocommerce' ),
                'default'     => 'completed',
                'desc_tip'    => true,
                'options'     => array( 'on-hold' => 'On Hold', 'processing' => 'Processing', 'completed' => 'Completed' ),
            ),
            'surcharge_card' => array(
                'title'   => esc_html__( 'Enable Surcharge', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Apply surcharge to card payments', 'woocommerce' ),
                'default' => 'no',
            ),
            'surcharge_checkout' => array(
                'title'   => esc_html__( 'Show Surcharge in Checkout', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Display surcharge amount on the checkout page', 'woocommerce' ),
                'default' => 'no',
            ),
            'surcharge_manual' => array(
                'title'   => esc_html__( 'Manual Surcharge', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Use manual surcharge value instead of API', 'woocommerce' ),
                'default' => 'no',
            ),
            'surcharge_type' => array(
                'title'       => esc_html__( 'Surcharge Type', 'woocommerce' ),
                'type'        => 'select',
                'description' => esc_html__( 'Must match your merchant surcharge setting.', 'woocommerce' ),
                'default'     => 'percent',
                'desc_tip'    => true,
                'options'     => array( 'percent' => 'Percent', 'currency' => 'Currency' ),
            ),
            'surcharge_value' => array(
                'title'       => esc_html__( 'Surcharge Value', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Must match your merchant surcharge setting value.', 'woocommerce' ),
                'default'     => '0',
                'desc_tip'    => true,
            ),
            'surcharge_label' => array(
                'title'       => esc_html__( 'Surcharge Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label shown to customers for the surcharge line item.', 'woocommerce' ),
                'default'     => 'Surcharge',
                'desc_tip'    => true,
            ),
            'name_on_card' => array(
                'title'   => esc_html__( 'Name on Card', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Show "Name on Card" field at checkout', 'woocommerce' ),
                'default' => 'no',
            ),
            'name_on_card_required' => array(
                'title'   => esc_html__( 'Name on Card Required', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Make "Name on Card" field mandatory', 'woocommerce' ),
                'default' => 'no',
            ),
            'name_on_card_label' => array(
                'title'       => esc_html__( 'Name on Card Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label text for the Name on Card field.', 'woocommerce' ),
                'default'     => esc_html__( 'Name on Card', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'card_code' => array(
                'title'   => esc_html__( 'Card Code (CVC)', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Show CVC field for saved card payments', 'woocommerce' ),
                'default' => 'no',
            ),
            'card_code_required' => array(
                'title'   => esc_html__( 'Card Code Required', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Make CVC field mandatory', 'woocommerce' ),
                'default' => 'no',
            ),
            'card_code_label' => array(
                'title'       => esc_html__( 'Card Code Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label text for the Card Code field.', 'woocommerce' ),
                'default'     => esc_html__( 'Card code', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'enable_level3' => array(
                'title'   => __( 'Level III Data', 'acceptblue' ),
                'type'    => 'checkbox',
                'label'   => __( 'Send Level III line item data with transactions', 'acceptblue' ),
                'default' => 'yes',
            ),
            'level3_truncate' => array(
                'title'   => __( 'Auto Trim Field Lengths', 'acceptblue' ),
                'type'    => 'checkbox',
                'label'   => __( 'Automatically enforce processor character limits', 'acceptblue' ),
                'default' => 'yes',
            ),
            'level3_unit_of_measure' => array(
                'title'       => esc_html__( 'Unit of Measure', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Unit of measure for Level III line items (e.g. EA).', 'woocommerce' ),
                'default'     => esc_html__( 'EA', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'level3_commodity_code' => array(
                'title'       => esc_html__( 'Commodity Code', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'International UNSPSC code used to classify items. See unspsc.org for reference.', 'woocommerce' ),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'card_number_field_label' => array(
                'title'       => esc_html__( 'Card Number Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label for the card number input field.', 'woocommerce' ),
                'default'     => 'Card number',
                'desc_tip'    => true,
            ),
            'card_expiry_field_label' => array(
                'title'       => esc_html__( 'Card Expiry Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label for the card expiry input field.', 'woocommerce' ),
                'default'     => 'Expiry (MM/YY)',
                'desc_tip'    => true,
            ),
            'card_cvc_field_label' => array(
                'title'       => esc_html__( 'Card CVC Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label for the CVC input field.', 'woocommerce' ),
                'default'     => 'Card code',
                'desc_tip'    => true,
            ),
            'save_card_token_disable' => array(
                'title'   => esc_html__( 'Disable Save Card', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => esc_html__( 'Disable the "Save Card" option for customers', 'woocommerce' ),
                'default' => 'no',
            ),
            'save_card_label' => array(
                'title'       => esc_html__( 'Save Card Label', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Label shown next to the save card checkbox.', 'woocommerce' ),
                'default'     => esc_html__( 'Save to account', 'woocommerce' ),
                'desc_tip'    => true,
            ),
                        'section_appearance' => array(
                'title' => __( 'Appearance', 'wc-ab-ae' ),
                'type'  => 'title',
            ),
            'form_color_scheme' => array(
                'title'       => esc_html__( 'Form Color Scheme', 'woocommerce' ),
                'type'        => 'select',
                'description' => esc_html__( 'Color scheme for the hosted payment form. "Auto" follows the customer\'s OS/browser preference. "Custom" lets you pick your own colors.', 'woocommerce' ),
                'default'     => 'auto',
                'desc_tip'    => true,
                'options'     => array(
                    'auto'   => esc_html__( 'Auto (Follow System)', 'woocommerce' ),
                    'light'  => esc_html__( 'Light', 'woocommerce' ),
                    'dark'   => esc_html__( 'Dark', 'woocommerce' ),
                    'custom' => esc_html__( 'Custom', 'woocommerce' ),
                ),
            ),
            'custom_color_bg' => array(
                'title'       => esc_html__( 'Custom: Input Background', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Background color for card input fields.', 'woocommerce' ),
                'default'     => '#f7f7f7',
                'desc_tip'    => true,
                'class'       => 'ab-color-picker',
            ),
            'custom_color_text' => array(
                'title'       => esc_html__( 'Custom: Input Text', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Text color inside card input fields.', 'woocommerce' ),
                'default'     => '#333333',
                'desc_tip'    => true,
                'class'       => 'ab-color-picker',
            ),
            'custom_color_border' => array(
                'title'       => esc_html__( 'Custom: Input Border', 'woocommerce' ),
                'type'        => 'text',
                'description' => esc_html__( 'Border color for card input fields.', 'woocommerce' ),
                'default'     => '#cccccc',
                'desc_tip'    => true,
                'class'       => 'ab-color-picker',
            ),
            'debug' => array(
                'title'       => esc_html__( 'Debug Log', 'woocommerce' ),
                'type'        => 'checkbox',
                'label'       => esc_html__( 'Enable logging', 'woocommerce' ),
                'default'     => 'no',
                'description' => sprintf(
                    esc_html__( 'Log %s events, such as API requests. Logs can be viewed under WooCommerce → Status → Logs.', 'woocommerce' ),
                    $this->method_title
                ),
            ),
        );
    }

	public function gateway_enabled(){
		return (bool)  $this->enabled;
	}

	public function admin_enqueue_scripts( $hook ) {
		// Only load on WooCommerce settings page
		if ( 'woocommerce_page_wc-settings' !== $hook ) {
			return;
		}

		// Settings page CSS
		wp_enqueue_style(
			'acceptblue-v2-settings',
			plugins_url( 'assets/css/dist/acceptblue-settings.min.css', dirname( __FILE__ ) ),
			array(),
			AB_V2_VERSION
		);

		// wp-color-picker (for Appearance tab)
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		// Settings page JS (depends on jQuery + color picker)
		wp_enqueue_script(
			'acceptblue-v2-settings',
			plugins_url( 'assets/js/dist/acceptblue-settings.min.js', dirname( __FILE__ ) ),
			array( 'jquery', 'wp-color-picker' ),
			AB_V2_VERSION,
			true
		);
	}

	public function admin_options() {

		$tabs = array(
			'general'      => __( 'General',       'wc-ab-ae' ),
			'api'          => __( 'API Keys',       'wc-ab-ae' ),
			'tokenization' => __( 'Tokenization',  'wc-ab-ae' ),
			'payment'      => __( 'Card & Payment', 'wc-ab-ae' ),
			'appearance'   => __( 'Appearance',     'wc-ab-ae' ),
		);

		$tab_sections = array(
			'general'      => 'section_general',
			'api'          => 'section_api',
			'tokenization' => 'section_tokenization',
			'payment'      => 'section_payment',
			'appearance'   => 'section_appearance',
		);

		// Detect missing API keys for tab badge
		$settings    = $this->settings;
		$is_testmode = ( $settings['testmode'] ?? 'no' ) === 'yes';
		$missing_api = $is_testmode
			? empty( $settings['test_api_key'] ?? '' )
			: empty( $settings['live_api_key'] ?? '' );

		// SSL warning
		if (
			! $this->testmode
			&& ! is_ssl()
			&& 'no' === get_option( 'woocommerce_force_ssl_checkout' )
			&& 'yes' === $this->enabled
		) {
			echo '<div class="inline error"><p>' . esc_html( sprintf(
				__( '%s: Live mode is active but SSL is not enabled. Your checkout is not secure.', 'wc-ab-ae' ),
				$this->method_title
			) ) . '</p></div>';
		}

		// NOTE: WooCommerce already wraps admin_options() output in <form id="mainform">.
		// We must NOT output our own <form> — only the inner content goes here.
		?>
		<div id="acceptblue-ab-settings-wrap">

			<!-- ── Header ──────────────────────────────────────────────────── -->
			<div class="acceptblue-ab-header">
				<div class="acceptblue-ab-header-left">
					<img src="<?php echo esc_url( plugins_url( 'assets/images/icons/logo.png', dirname( __FILE__ ) ) ); ?>"
					     alt="accept.blue" class="acceptblue-ab-header-logo" />
					<div>
						<strong class="acceptblue-ab-header-title"><?php esc_html_e( 'accept.blue Payment Gateway v2', 'wc-ab-ae' ); ?></strong>
						<span class="acceptblue-ab-header-version"><?php echo esc_html( AB_V2_VERSION ); ?></span>
					</div>
				</div>
				<div class="acceptblue-ab-header-actions">
					<a href="https://acceptblue.ryanplugins.net/blog/docs/accept-blue-version-2/"
					   target="_blank" rel="noopener" class="button button-secondary">
						<?php esc_html_e( '📖 Docs', 'wc-ab-ae' ); ?>
					</a>
					<a href="https://www.patreon.com/RyanPlugins/membership"
					   target="_blank" rel="noopener" class="button button-secondary">
						<?php esc_html_e( '❤️ Support', 'wc-ab-ae' ); ?>
					</a>
				</div>
			</div>

			<!-- ── Tab nav ─────────────────────────────────────────────────── -->
			<div class="acceptblue-ab-nav-tabs" role="tablist">
				<?php foreach ( $tabs as $slug => $label ) : ?>
				<button type="button"
				        class="acceptblue-ab-nav-tab"
				        data-tab="<?php echo esc_attr( $slug ); ?>"
				        role="tab"
				        aria-selected="false"
				        aria-controls="acceptblue-ab-panel-<?php echo esc_attr( $slug ); ?>">
					<?php echo esc_html( $label ); ?>
					<?php if ( $slug === 'api' && $missing_api ) : ?>
					<span class="acceptblue-ab-tab-badge acceptblue-ab-tab-badge-warn"
					      title="<?php esc_attr_e( 'API key not set', 'wc-ab-ae' ); ?>">!</span>
					<?php endif; ?>
				</button>
				<?php endforeach; ?>
				<?php if ( $this->testmode ) : ?>
				<span class="acceptblue-ab-test-indicator">🧪 <?php esc_html_e( 'Test Mode', 'wc-ab-ae' ); ?></span>
				<?php endif; ?>
			</div>

			<!-- ── Tab panels ──────────────────────────────────────────────── -->
			<?php
			// Capture all WC-generated fields HTML
			ob_start();
			$this->generate_settings_html();
			$html = ob_get_clean();

			// Split at section boundaries
			$pattern    = '/<\/table>[\s\S]*?<h3[^>]*id="woocommerce_acceptbluev2_(section_[^"]+)"[^>]*>[\s\S]*?<\/h3>[\s\S]*?<table[^>]*>/';
			$row_chunks = preg_split( $pattern, $html, -1, PREG_SPLIT_DELIM_CAPTURE );

			$buckets = array_fill_keys( array_values( $tab_sections ), '' );
			$buckets['section_general'] = $row_chunks[0] ?? '';
			for ( $i = 1; $i + 1 < count( $row_chunks ); $i += 2 ) {
				$key = $row_chunks[ $i ];
				if ( isset( $buckets[ $key ] ) ) {
					$buckets[ $key ] = $row_chunks[ $i + 1 ];
				}
			}

			foreach ( $tab_sections as $tab => $section_key ) :
			?>
			<div class="acceptblue-ab-tab-panel"
			     id="acceptblue-ab-panel-<?php echo esc_attr( $tab ); ?>"
			     role="tabpanel"
			     data-tab="<?php echo esc_attr( $tab ); ?>">
				<div class="acceptblue-ab-section-heading"><?php echo esc_html( $tabs[ $tab ] ); ?></div>
				<table class="form-table">
					<?php echo $buckets[ $section_key ]; // phpcs:ignore ?>
				</table>
			</div>
			<?php endforeach; ?>

		</div><!-- #acceptblue-ab-settings-wrap -->
		<?php
	}

    public function is_enabled(){
		return (bool)  $this->enabled;
	}

    /**
     * Override get_icon() to render the accept.blue icon with a srcset so it looks
     * sharp on HiDPI / Retina displays. Respects the "Gateway Icon" setting on the
     * frontend — the admin payments list always shows the icon via its own filter.
     */
    public function get_icon() {
        // Only suppress the icon on the frontend checkout page.
        // Everywhere else (admin payments list, order pages, etc.) always shows it.
        if ( ! $this->show_icon && function_exists( 'is_checkout' ) && is_checkout() ) {
            return apply_filters( 'woocommerce_gateway_icon', '', $this->id );
        }
        // Use SVG for crisp rendering at all DPIs — no srcset needed.
        $icon_url  = plugins_url( 'assets/images/icons/icon.svg', dirname(__FILE__) );
        $icon_html = '<img src="' . esc_url( $icon_url ) . '" '
                   . 'alt="' . esc_attr( $this->get_title() ) . '" '
                   . 'style="max-height:24px;width:auto;vertical-align:middle;margin-left:4px;" />';
        return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
    }

    public function google_pay_is_enabled(){
        return (bool)  $this->googlepay;
    }

	/**
	 * Render the hosted tokenization iframe form inside the WooCommerce
	 * payment method box (.payment_method_acceptbluev2 .payment_box).
	 *
	 * Previously this was appended after #payment via woocommerce_review_order_after_payment
	 * and shown/hidden with JS. Now it lives inside payment_fields() so WooCommerce
	 * handles show/hide natively when the payment method radio is selected.
	 *
	 * The outer #acceptblue-v2-hosted-tokenization-form wrapper is kept for JS
	 * compatibility (acceptbluev2_handle_build_token_data appends hidden inputs to it).
	 */
	public function render_hosted_tokenization_form() {

		$settings = $this->settings;

		// Test-mode notice
		if ( $this->testmode === true ) {
			$is_3ds    = $this->threeds === true;
			$card_rows = $is_3ds
				? array( 'Visa — 4012000033330026', 'MasterCard — 5100060000000002' )
				: array( 'Visa — 4761530001111118', 'Discover — 6011208701117775' );

			echo '<div class="acceptbluev2-sandbox-notice">';
			echo '<strong>' . esc_html__( 'TEST MODE — SANDBOX ENABLED', 'woocommerce' ) . '</strong><br>';
			echo esc_html( $is_3ds ? __( '3DS Test Cards:', 'woocommerce' ) : __( 'Test Cards:', 'woocommerce' ) ) . '<br>';
			foreach ( $card_rows as $row ) {
				echo '<code>' . esc_html( $row ) . '</code><br>';
			}
			echo '</div>';
		}

		// Resolve the order amount for the 3DS verify3DS() call.
		// On a normal checkout the cart total is authoritative and remove_surcharge()
		// strips the surcharge fee from WC()->cart->get_fees().
		// On the order-pay page (e.g. admin-created fee-only order sent as a payment link)
		// the cart is empty, so remove_surcharge() finds nothing and returns the full order
		// total including the surcharge. Strip the surcharge directly from the order fees instead.
		if ( WC()->cart && ! WC()->cart->is_empty() ) {

			$client         = new WC_AcceptBlue_API_v2();
			$raw_amount     = $client->remove_surcharge( (float) WC()->cart->get_total( 'edit' ) );
			$surcharge_data = self::get_threeds_amount( $raw_amount, 0 );

		} elseif ( is_checkout_pay_page() ) {

			$pay_order_id = absint( get_query_var( 'order-pay' ) );
			$pay_order    = $pay_order_id > 0 ? wc_get_order( $pay_order_id ) : null;

			if ( $pay_order instanceof WC_Order ) {
				// Use order total minus the surcharge fee line item.
				// The "subtotal + shipping + tax" approach fails for fee-only orders
				// (e.g. $0 subtotal + $20 fee) where subtotal = 0, producing amount = 0
				// which causes 3DS verify to fail.
				// Also substitute 0.01 for $0 trial subscription orders.
				$raw_amount     = self::get_order_total_excluding_surcharge( $pay_order );
				$surcharge_data = self::get_threeds_amount( $raw_amount, $pay_order->get_id() );
			} else {
				$surcharge_data = 0.0;
			}

		} else {
			$surcharge_data = 0.0;
		}

		// Detect trial subscription so JS can pass 0.01 to verify3DS.
		// WC Subscriptions uses WC_Subscriptions_Cart::cart_contains_subscription(),
		// not the non-existent wcs_cart_contains_subscription().
		$_ht_is_trial = '0';
		if ( (float) $surcharge_data < 0.01 ) {
			$_trial_check = false;
			if ( class_exists( 'WC_Subscriptions_Cart' ) && method_exists( 'WC_Subscriptions_Cart', 'cart_contains_subscription' ) ) {
				$_trial_check = (bool) WC_Subscriptions_Cart::cart_contains_subscription();
			}
			if ( ! $_trial_check && function_exists( 'WC' ) && WC()->cart ) {
				foreach ( WC()->cart->get_cart() as $_trial_item ) {
					$_trial_product = isset( $_trial_item['data'] ) ? $_trial_item['data'] : null;
					if ( $_trial_product && is_a( $_trial_product, 'WC_Product' ) && strpos( $_trial_product->get_type(), 'subscription' ) !== false ) {
						$_trial_check = true;
						break;
					}
				}
			}
			if ( $_trial_check ) {
				$surcharge_data = 0.01; // ensure hidden input value is also correct
				$_ht_is_trial   = '1';
			}
		}

		$name_label    = $this->name_on_card_label;
		$name_required = $this->name_on_card_required;

		// ── Saved tokens for logged-in users ──────────────────────────────────
		$ht_saved_tokens = array();
		if ( is_user_logged_in() && ! $this->save_card_token_disable ) {
			$raw_tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
			foreach ( $raw_tokens as $tok ) {
				$raw = $tok->get_token();
				if ( empty( $raw ) || $raw === 'tkn-' ) continue;
				$ht_saved_tokens[] = $tok;
			}
		}
		?>
		<div id="acceptblue-v2-hosted-tokenization-form">

			<div id="acceptblue-ht-error-message"></div>

			<?php if ( ! empty( $ht_saved_tokens ) ) : ?>
			<div class="ab-ht-saved-tokens">
				<p class="ab-ht-saved-tokens__label"><?php esc_html_e( 'Saved payment methods', 'woocommerce' ); ?></p>
				<ul class="ab-ht-token-list">
				<?php foreach ( $ht_saved_tokens as $tok ) :
					$type  = ucfirst( $tok->get_card_type() ?: 'Card' );
					$last4 = $tok->get_last4();
					$exp   = $tok->get_expiry_month() . '/' . substr( $tok->get_expiry_year(), -2 );
				?>
				<li class="ab-ht-token-item<?php echo $tok->is_default() ? ' ab-ht-token-item--default' : ''; ?>">
					<label class="ab-ht-token-label">
						<input type="radio"
						       class="ab-ht-token-radio"
						       name="ab-ht-selected-token"
						       value="<?php echo esc_attr( $tok->get_id() ); ?>"
						       <?php checked( $tok->is_default() ); ?>
						/>
						<span class="ab-ht-token-card-icon ab-ht-token-card-icon--<?php echo esc_attr( strtolower( $tok->get_card_type() ?: 'card' ) ); ?>"></span>
						<span class="ab-ht-token-card-info">
							<strong><?php echo esc_html( $type ); ?></strong>
							&bull;&bull;&bull;&bull; <?php echo esc_html( $last4 ); ?>
							<span class="ab-ht-token-exp"><?php echo esc_html( $exp ); ?></span>
						</span>
					</label>
				</li>
				<?php endforeach; ?>
				<li class="ab-ht-token-item ab-ht-token-new">
					<label class="ab-ht-token-label">
						<input type="radio" class="ab-ht-token-radio" name="ab-ht-selected-token" value="new" />
						<span class="ab-ht-token-card-icon ab-ht-token-card-icon--new"></span>
						<span class="ab-ht-token-card-info"><?php esc_html_e( 'Use a new card', 'woocommerce' ); ?></span>
					</label>
				</li>
				</ul>
			</div>
			<?php endif; ?>

			<input type="hidden" id="acceptblue-ht-order-key"    name="acceptblue-ht-order-key"    value="" />
			<input type="hidden" id="acceptblue-ht-order-amount" name="acceptblue-ht-order-amount"
			       value="<?php echo esc_attr( $surcharge_data ); ?>"
			       data-is-trial="<?php echo esc_attr( $_ht_is_trial ); ?>" />

			<div class="ab-ht-new-card-section">

				<p class="ab-ht-new-card-label"><?php esc_html_e( 'Enter your credit card details below to complete the payment.', 'woocommerce' ); ?></p>

				<?php if ( $this->name_on_card === true ) : ?>
				<div class="ab-ht-field">
					<label class="ab-ht-field__label" for="acceptbluev2-card-name">
						<?php echo esc_html( $name_label ); ?>
						<?php if ( $name_required ) : ?><span style="color:var(--ab-ht-error,#cc1818);margin-left:2px;" aria-hidden="true">*</span><?php endif; ?>
					</label>
					<input type="text"
					       id="acceptbluev2-card-name"
					       name="acceptbluev2-card-name"
					       placeholder="<?php echo esc_attr( $name_label ); ?>"
					       value=""
					       class="acceptblue-ht-input"
					       autocomplete="cc-name"
					       <?php if ( $name_required ) echo 'required aria-required="true"'; ?>
					/>
				</div>
				<?php else : ?>
					<input type="hidden" id="acceptbluev2-card-name" name="acceptbluev2-card-name" value="" />
				<?php endif; ?>

				<div id="acceptblue-ht-iframe-container"></div>

				<?php if ( is_user_logged_in() && ! $this->save_card_token_disable && ! $this->force_save_card_token ) : ?>
				<div class="acceptbluev2-save-card-row ab-ht-save-card-row">
					<label class="acceptbluev2-save-card-label">
						<input type="checkbox" id="acceptbluev2-ht-save-card" name="acceptbluev2-ht-save-card" value="1" />
						<?php echo esc_html( $this->save_card_label ); ?>
					</label>
				</div>
				<?php endif; ?>

			</div><!-- .ab-ht-new-card-section -->

			<div>
				<button type="button" id="acceptblue-ht-charge">
					<?php esc_html_e( 'Place Order', 'woocommerce' ); ?>
				</button>
			</div>
			<div id="acceptblue-hosted-token-ajax-loader" style="display:none;"></div>
		</div>
		<?php
	}

	//* WC card payment form 

	/**
	 * Fires on the 'wp' action — after WP_Query is fully set up so
	 * is_add_payment_method_page() returns the correct value.
	 *
	 * Forces all mode properties to false on my-account/add-payment-method/
	 * so every downstream method (payment_fields, script enqueue hooks,
	 * local_script, add_payment_method) behaves exactly like Classic Non-3DS:
	 * WC default card fields are shown, acceptblue-checkout-form.js handles
	 * form submit, and the existing Classic Non-3DS add_payment_method() path
	 * saves the token. No scattered special-case guards needed anywhere else.
	 *

	/**
	 * On the order-pay page, when block_support_checkout=true and tokenization=false,
	 * payment_fields() falls back to classic WC card fields. Enqueue local_script()
	 * so that acceptblue-v2-js is registered + localised (required by script()).
	 *
	 * Hooked to the 'wp' action at priority 2 (before wp_enqueue_scripts at 10),
	 * but only registered in __construct() when block_support_checkout=true.
	 */
	public function maybe_local_script_on_pay_order_page() {
		if ( ! is_checkout_pay_page() || absint( get_query_var( 'order-pay' ) ) < 1 ) {
			return;
		}
		// Always ensure local_script() runs on the order-pay page so that
		// acceptblue-v2-js is registered + localised (script() depends on it).
		// acceptblue_v2_enqueue_global_params() skips the order-pay page entirely,
		// so without this hook, acceptblue-v2-js is never registered in any mode.
		//
		// When block_support_checkout=true: use the wrapper that temporarily forces
		// block_checkout:false so the classic card-form JS handles submit (not the iframe).
		// When block_support_checkout=false (classic mode): call local_script() directly.
		if ( $this->block_support_checkout === true ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'local_script_for_pay_order_page' ) );
		} else {
			add_action( 'wp_enqueue_scripts', array( $this, 'local_script' ) );
		}
	}

	/**
	 * Calls local_script() with block_support_checkout temporarily forced to false,
	 * so the localized acceptblue_hosted_token_params data contains block_checkout:false.
	 * This lets the classic card-form JS handle submit instead of the hosted iframe JS.
	 * The flag is restored immediately after, before payment_fields() renders the form.
	 */
	public function local_script_for_pay_order_page() {
		$saved = $this->block_support_checkout;
		$this->block_support_checkout = false;
		$this->local_script();
		$this->block_support_checkout = $saved;
	}

	/**
	 * Fires on the 'wp' action — after WP_Query is fully set up so
	 * is_add_payment_method_page() returns the correct value.
	 *
	 * Forces all mode properties to false on my-account/add-payment-method/
	 * so every downstream method (payment_fields, script enqueue hooks,
	 * acceptblue_add_payment_method) behaves exactly like Classic Non-3DS.
	 *
	 * Priority 1 ensures this runs before wp_enqueue_scripts (priority 10).
	 */
	public function force_classic_mode_on_add_payment_method() {
		if ( ! function_exists( 'is_add_payment_method_page' ) ) return;
		if ( ! is_add_payment_method_page() ) return;

		// Override mode properties — makes payment_fields(), local_script(),
		// add_payment_method(), and process_payment() all use Classic Non-3DS logic.
		$this->tokenization           = false;
		$this->block_support_checkout = false;
		$this->threeds                = false;

		// Swap enqueue hooks registered at __construct() time.
		// If tokenization or 3DS mode was active, their wp_enqueue_scripts callbacks
		// are already bound. Remove them and ensure script() (Classic Non-3DS) runs.
		remove_action( 'wp_enqueue_scripts', array( $this, 'local_script' ) );
		remove_action( 'wp_enqueue_scripts', array( $this, 'tokenization_script' ) );

		// script() enqueues acceptblue-checkout-form.min.js (Classic Non-3DS JS).
		// add_payment_method_script() calls local_script() for JS params + style.
		// Both are idempotent — safe to add even if already registered.
		add_action( 'wp_enqueue_scripts', array( $this, 'script' ), 10 );
	}

	public function payment_fields(){

		// Description
		if ( $this->description ) {
			echo wp_kses_post( wpautop( wptexturize( $this->description ) ) );
		}

		// Surcharge fee notice — shown whenever surcharge is enabled and cart has a value
		$this->render_surcharge_notice();

        if( $this->tokenization === true ){

            // Hosted tokenization mode — redirect to order-pay page after checkout
            // The actual card entry form is rendered on the order-pay page.
            echo '<p class="ab-ht-new-card-label">' . esc_html__( 'You will enter your card details on the next step.', 'woocommerce' ) . '</p>';
            
        } else {

			// Block checkout / hosted iframe mode.
			// On the order-pay page (payment link), the block iframe JS is not loaded,
			// so fall back to the classic WC card fields just like the non-block path.
			$is_pay_order_page = is_checkout_pay_page() && absint( get_query_var( 'order-pay' ) ) > 0;

			if ( $this->block_support_checkout === true && ! $is_pay_order_page ) {

				$this->render_hosted_tokenization_form();

			} else {

				if ( $this->testmode === true ) {

					$cards_text  = '';
					$cards_text .=  esc_html__( 'TEST MODE/SANDBOX ENABLED', 'woocommerce');
					$cards_text .= '<br>' . esc_html__( 'TEST CARDS' , 'woocommerce' );
					$cards_text .= '<br>' . esc_html__( 'Visa - 4761530001111118' , 'woocommerce' );
					$cards_text .= '<br>' . esc_html__( 'Discover - 6011208701117775' , 'woocommerce' );
					
					echo wp_kses_post($cards_text);
				}
		
				if( $this->description === true ) {
					echo wp_kses_post( wpautop( wptexturize( $this->description ) ) );
				}

				parent::payment_fields();    

				// Custom Cardcode (CVC)
				$this->append_cardcode_input_saved_payment_methods();


			}
			
        }

	}

	/**
	 * Render the surcharge fee notice inside the payment fields area.
	 *
	 * Displays a styled blue info banner — e.g. "A $0.03 Credit card fee (3%) will be added
	 * to your order." — whenever surcharge is enabled and the cart total is positive.
	 * Uses the same API data and calculation logic as acceptblue_v2_surcharge_add_cart_fee().
	 */
	protected function render_surcharge_notice() {

		if ( $this->surcharge_card !== true ) {
			return;
		}

		// Respect the "Show Surcharge in Checkout" setting
		if ( $this->surcharge_checkout !== true ) {
			return;
		}

		// Skip on order-pay page — surcharge is already on the order total there
		if ( is_checkout_pay_page() && absint( get_query_var( 'order-pay' ) ) > 0 ) {
			return;
		}

		// Skip on add-payment-method page — no cart exists and no charge is being made
		if ( function_exists( 'is_add_payment_method_page' ) && is_add_payment_method_page() ) {
			return;
		}

		$client     = new WC_AcceptBlue_API_v2();
		$is_enabled = $client->is_surcharge_enabled();

		if ( empty( $is_enabled['code'] ) || $is_enabled['code'] === false ) {
			return;
		}

		$surcharge = $client->get_surcharge_info();

		if ( empty( $surcharge['fee']['value'] ) ) {
			return;
		}

		$surcharge_value = (float) $surcharge['fee']['value'];
		$surcharge_type  = $surcharge['fee']['type'];
		$surcharge_name  = ! empty( $surcharge['name'] ) ? $surcharge['name'] : $this->surcharge_label;

		// Calculate fee amount from the current cart total
		$cart = WC()->cart;
		if ( ! $cart ) {
			return;
		}

		$subtotal = $cart->get_cart_contents_total()
		          + $cart->get_shipping_total()
		          + $cart->get_taxes_total()
		          + $cart->get_fee_total();

		if ( $subtotal <= 0 ) {
			return;
		}

		if ( $surcharge_type === 'percent' ) {
			$fee_amount      = round( $subtotal * ( $surcharge_value / 100 ), 2 );
			$fee_label_extra = ' (' . $surcharge_value . '%)';
		} else {
			$fee_amount      = $surcharge_value;
			$fee_label_extra = '';
		}

		if ( $fee_amount <= 0 ) {
			return;
		}

		$fee_formatted = wc_price( $fee_amount );

		$notice_message = wp_kses_post(
			sprintf(
				/* translators: 1: formatted fee amount  2: fee label e.g. "Surcharge Fee"  3: percent suffix e.g. " (3%)" */
				__( 'A <span class="ab-surcharge-notice__amount">%1$s</span> <strong>%2$s%3$s</strong> will be applied at checkout.', 'woocommerce' ),
				$fee_formatted,
				esc_html( $surcharge_name ),
				esc_html( $fee_label_extra )
			)
		);

		echo '<div class="ab-surcharge-notice">'
			. '<span class="ab-surcharge-notice__icon" aria-hidden="true">&#x2139;</span>'
			. '<span class="ab-surcharge-notice__text">' . $notice_message . '</span>'
			. '</div>'
			. '<style>'
			. '.ab-surcharge-notice{'
			. 'display:flex;align-items:center;gap:10px;'
			. 'background:#eef6ff;border:1px solid #93c5fd;border-left:4px solid #3b82f6;'
			. 'border-radius:6px;padding:11px 14px;margin:0 0 14px;box-sizing:border-box;}'
			. '.ab-surcharge-notice__icon{'
			. 'flex-shrink:0;width:20px;height:20px;background:#3b82f6;color:#fff;'
			. 'border-radius:50%;font-size:13px;font-weight:700;font-style:normal;'
			. 'display:flex;align-items:center;justify-content:center;line-height:1;}'
			. '.ab-surcharge-notice__text{'
			. 'font-size:0.88em;color:#1e3a5f;line-height:1.5;margin:0;}'
			. '.ab-surcharge-notice__text strong,.ab-surcharge-notice__amount{'
			. 'font-weight:700;color:#1d4ed8;}'
			. '</style>';
	}

    public function validate_fields() {     		

        if($this->tokenization === true ){

            return true;

        } else {

			// On the order-pay page with block_support_checkout=true, payment_fields()
			// uses classic card fields, so classic validation must run — do NOT return early.
			// Detect order-pay context reliably during wc-ajax=checkout (page context is reset).
			// WooCommerce order-pay form sends all three signals; any one is sufficient.
			$is_pay_order_page = (
				( ! empty( $_POST['pay_for_order'] ) && $_POST['pay_for_order'] === 'true' ) ||
				( ! empty( $_POST['order_id'] ) && is_numeric( $_POST['order_id'] ) ) ||
				! empty( $_POST['woocommerce-pay-nonce'] )
			);
			if ( $this->block_support_checkout === true && ! $is_pay_order_page ) return;

			

			if (isset($_POST['wc-acceptbluev2-payment-token']) && is_numeric($_POST['wc-acceptbluev2-payment-token']) && $_POST['wc-acceptbluev2-payment-token'] > 0) {                      
				return true;
			} else {

					// Validate credit card fields
					if (empty($_POST['acceptbluev2-cardnumber'])) {
						wc_add_notice('Card Number is required!', 'error');
						return false;
					}
		
					if (empty($_POST['acceptbluev2-expiry_m'])) {
						wc_add_notice('Expiry Month is required!', 'error');
						return false;
					}
		
					if (empty($_POST['acceptbluev2-expiry_y'])) {
						wc_add_notice('Expiry Year is required!', 'error');
						return false;
					}
		
					if (empty($_POST['acceptbluev2-card_cvc'])) {
						wc_add_notice('CVC is required!', 'error');
						return false;
					}
						
				

					if( $this->name_on_card === true && $this->name_on_card_required === true ){

						$card_name= isset($_POST[$this->id . '-card-name']) ? wc_clean ($_POST[ $this->id . '-card-name']) : '';
			
						if(empty($card_name)){
			
							wc_add_notice(__( $this->name_on_card_label . ' is required!', 'woocommerce'), "error");
							return;
			
						}
			
					}
					
				} 
          
        }
       
        

		


        return true;


    }

    public function card_verification($data) {

        $token_id = isset( $_POST['wc-acceptbluev2-payment-token'] )
            ? sanitize_text_field( $_POST['wc-acceptbluev2-payment-token'] )
            : '';

        if ( is_numeric( $token_id ) && (int) $token_id > 0 ) {
            return true;
        }

		//Prepare AVS fields from WooCommerce order
		if (empty($data['billing_address_1']) || empty($data['billing_postcode'])) {
			$user_id = get_current_user_id();
			if ($user_id) {
				$user = new WC_Customer($user_id);
				$data['billing_address_1'] = $data['billing_address_1'] ?? $user->get_billing_address_1();
				$data['billing_address_2'] = $data['billing_address_2'] ?? $user->get_billing_address_2();
				$data['billing_postcode']  = $data['billing_postcode'] ?? $user->get_billing_postcode();
			}
		}

		// 2. Prepare AVS fields
		$avs_address = trim(($data['billing_address_1'] ?? '') . ' ' . ($data['billing_address_2'] ?? ''));
		$avs_address = preg_replace('/\s+/', ' ', $avs_address);
		$avs_address = substr($avs_address, 0, 255);

		$avs_zip = substr($data['billing_postcode'] ?? '', 0, 50);
		
        $params = array(
            'card'         => $data['acceptbluev2-cardnumber'],
            'expiry_month' => (int) $data['acceptbluev2-expiry_m'],
            'expiry_year'  => (int) $data['acceptbluev2-expiry_y'],
            'cvv2'         => $data['acceptbluev2-card_cvc'],
			'avs_address'  => $avs_address,
    		'avs_zip'      => $avs_zip,
        );

        $response = $this->request_api( $params, 'transactions/verify', 'POST' );

        $body   = $response['response_body'] ?? null;
        $status = is_object( $body ) ? ( $body->status ?? '' ) : '';

        if ( $response['response_code'] == 200 && $status === 'Approved' ) {
            return true;
        }

        $error_msg = is_object( $body ) ? ( $body->error_message ?? $status ) : 'Verification failed.';
        wc_add_notice( 'Card ' . esc_html( $error_msg ), 'error' );
        return false;

    }


    public function process_payment($order_id) {

        global $woocommerce;

        $order = wc_get_order( $order_id );
		

        if($this->tokenization === true ){   

			$this->surcharge_fee_to_order($order, "");

			// Store a trial indicator meta so ht_place_order_charge can detect it
			// reliably without depending on WCS subscription-linking (which may not
			// have happened yet at order-pay time).
			if ( (float) $order->get_total() < 0.01 ) {
				$order->update_meta_data( '_acceptblue_ht_trial', '1' );
				$order->save();
			}
		
            $checkout_url_args 	= array( 'order-pay' => $order_id, 'key' => $order->get_order_key() );
            $checkout_url 		= add_query_arg( $checkout_url_args, wc_get_checkout_url() );

            if(  $order_id > 0 ){
                return array(
                    'result'    => 'success',
                    'redirect'  => esc_url_raw( $checkout_url )
                );
            } 

            else {
                wc_add_notice( 
                    __( sprintf( "Error when processing payment: '%s'", "Invalid Order ID!" ) , 'woocommerce' ), "error" );
                return false;

            }

        } else {		


			// Detect order-pay context reliably during wc-ajax=checkout (page context is reset).
			// WooCommerce order-pay form sends all three signals; any one is sufficient.
			$is_pay_order_page = (
				( ! empty( $_POST['pay_for_order'] ) && $_POST['pay_for_order'] === 'true' ) ||
				( ! empty( $_POST['order_id'] ) && is_numeric( $_POST['order_id'] ) ) ||
				! empty( $_POST['woocommerce-pay-nonce'] )
			);

			// Block checkout saved token: read directly from POST to avoid $_REQUEST unreliability
			// in the Store API (WooCommerce Blocks) context.
			// On order-pay page in block-only mode, fall through to classic token reading below.
			if ( $this->block_support_checkout && ! $is_pay_order_page && ! empty( $_POST['acceptbluev2-block-token-id'] ) ) {
				$token_id = sanitize_text_field( $_POST['acceptbluev2-block-token-id'] );
			} else {
				$token_id = ! empty( $_REQUEST['wc-acceptbluev2-payment-token'] ) ? sanitize_text_field( $_REQUEST['wc-acceptbluev2-payment-token'] ) : '';
			}

			if( empty($token_id)){				

				// Allow classic card_verification on order-pay page even when block_support_checkout=true.
				if ( $this->block_support_checkout === false || $is_pay_order_page ) {
					if($this->card_verification($_POST) === false ) return;
				}
				
			}            

            // Remove surcharge from the order!
		    $this->custom_remove_specific_fee_from_order( $order_id );

            $order = wc_get_order($order_id);

            $woo_currency 					= $order->get_currency();

            if($woo_currency != "USD" ) {
                wc_add_notice( esc_html__( "Invalid, Transaction amount should be in USD.", "woocommerce" ) );
                return false;
            }

            
            $woo_get_total 					= $order->get_total();
            $avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
            $avs_zip  						= $order->get_billing_postcode();
            
            //* Amount Details            

            $amount_details[ "tax" ] 		= (double) "0";
            $amount_details[ "shipping" ] 	= (double) "0";
            $amount_details[ "discount" ] 	= (double) "0";

            //* Transaction details

            $transaction_details = array();
            $transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
            $transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
            $transaction_details[ "order_number" ] 	= $order->get_order_number();
            $transaction_details[ "invoice_number" ] = $order->get_order_number();
            $transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

            //* Billing Address Fields

            $billing_info = array();

            $billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
            $billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
            $billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
            $billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
            $billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
            $billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
            $billing_info[ "zip" ] 			= $order->get_billing_postcode();
            $billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
            $billing_info[ "phone" ] 		= $order->get_billing_phone();						
            
            //* Shipping Address Fields

            $shipping_info = array();

            $shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
            $shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
            $shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
            $shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
            $shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
            $shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
            $shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
            $shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
            $shipping_info[ "phone" ] 		= $order->get_billing_phone();

            if($this->force_save_card_token === true ){

                $save_card = (bool) true;

            } else {

                // Classic checkout: reads the checkbox via $_REQUEST.
                // Block checkout: WooCommerce Blocks posts payment method data as
                // 'acceptbluev2-save-card' via paymentMethodData — read both.
                // Hosted tokenization iframe on classic checkout: render_hosted_tokenization_form()
                // renders its own 'acceptbluev2-ht-save-card' checkbox (parent::payment_fields()
                // is not called so WC's native wc-{id}-new-payment-method is not rendered).
                // WooCommerce posts 'wc-{id}-new-payment-method' as the string 'true' (not '1').
                $save_card_classic = isset($_REQUEST['wc-acceptbluev2-new-payment-method']) && sanitize_text_field($_REQUEST['wc-acceptbluev2-new-payment-method']) === 'true';
                // Use === '1' with isset to avoid PHP's empty('0')=true quirk.
                $save_card_block   = isset($_POST['acceptbluev2-save-card']) && sanitize_text_field($_POST['acceptbluev2-save-card']) === '1';
                $save_card_ht      = isset($_POST['acceptbluev2-ht-save-card']) && sanitize_text_field($_POST['acceptbluev2-ht-save-card']) === '1';
                $save_card = (bool) ($save_card_classic || $save_card_block || $save_card_ht);
                $save_card = ( $save_card === true && ! is_numeric( $token_id ) );

            }
			

            if( is_numeric($token_id) && $token_id > 0 ){
                
                $token = $this->use_card_token($token_id);

                if( !empty($token) && is_array($token)){

                    $card           = wc_clean($token[ "token" ]);
                    $expiry_month   = wc_clean($token[ "expiry_month" ]);		
                    $expiry_year    = wc_clean($token[ "expiry_year" ]);	
					$cvv2 = ! empty( $_POST['acceptbluev2-card-cvc'] ) ? wc_clean( $_POST['acceptbluev2-card-cvc'] ) : '';

                    $card_info = array(                        
                        'source' 		=> $card,
                        'expiry_month' 	=> (int) $expiry_month,
                        'expiry_year' 	=> (int) $expiry_year,
						//'cvv2'			=> (string) $cvv2
                    );
				
			    }

            } else {

				// On the order-pay page in block-only mode, skip the block token path and use
				// the classic card field POST keys read in the else branch below.
				if ( $this->block_support_checkout === true && ! $is_pay_order_page ) {

					// ── Block checkout token source resolution ───────────────────────────────
					//
					// Two distinct block checkout JS files each send different token types:
					//
					// 1. acceptblue-hosted-token-block-checkout.js (non-3DS):
					//    Calls wc_ajax=acceptbluev2_tokenize → save_card() → returns integer token_id.
					//    Sends paymentMethodData key: "token" (integer string).
					//    Accept.Blue API expects source = "tkn-{token_id}".
					//
					// 2. acceptblue-hosted-token-block-3ds-checkout.js (3DS / hosted iframe):
					//    Calls HostedTokenization.getNonceToken() → returns nonce string.
					//    Sends paymentMethodData key: "acceptbluev2-payment-token" (nonce string).
					//    Accept.Blue API expects source = "nonce-{nonce}".
					//
					if ( $this->threeds === true ) {
						// 3DS / hosted-tokenization nonce path
						$nonce_value = isset( $_POST['acceptbluev2-payment-token'] )
							? sanitize_text_field( $_POST['acceptbluev2-payment-token'] )
							: '';
						$card_token  = ! empty( $nonce_value ) ? 'nonce-' . $nonce_value : '';
					} else {
						// Non-3DS tokenize path — JS sends token_id as key "token"
						$raw_token_id = isset( $_POST['token'] )
							? sanitize_text_field( $_POST['token'] )
							: '';
						// Fallback: older JS may have sent as acceptbluev2-payment-token
						if ( empty( $raw_token_id ) ) {
							$raw_token_id = isset( $_POST['acceptbluev2-payment-token'] )
								? sanitize_text_field( $_POST['acceptbluev2-payment-token'] )
								: '';
						}
						$card_token = ! empty( $raw_token_id ) ? 'tkn-' . $raw_token_id : '';
					}

					if ( empty( $card_token ) ) {
						wc_add_notice( __( 'Payment token missing. Please try again.', 'woocommerce' ), 'error' );
						self::log( 'Block checkout: payment token missing from POST data.', 'error' );
						return false;
					}
					
						// Use real expiry sent back from tokenize AJAX (JS passes it in paymentMethodData).
						// Fall back to a dummy future date only if not provided.
						$expiry_month = ! empty( $_POST['acceptbluev2-expiry-month'] )
							? (int) sanitize_text_field( $_POST['acceptbluev2-expiry-month'] )
							: (int) date('n');
						$expiry_year  = ! empty( $_POST['acceptbluev2-expiry-year'] )
							? (int) sanitize_text_field( $_POST['acceptbluev2-expiry-year'] )
							: (int) date('Y') + 1;

						$card_info = array(
							'source' 		=> $card_token,
							'expiry_month' 	=> (int) $expiry_month,
							'expiry_year' 	=> (int) $expiry_year,
							//'cvv2'			=> (string) $cvv2
						);

						if($this->threeds === true ){

							$expiry_month = isset($_POST['acceptbluev2-payment-expiry_month']) ? sanitize_text_field($_POST['acceptbluev2-payment-expiry_month']) : "";
							$expiry_year = isset($_POST['acceptbluev2-payment-expiry_year']) ? sanitize_text_field($_POST['acceptbluev2-payment-expiry_year']) : "";

							$card_info = array(
								'source' 		=> $card_token,
								'expiry_month' 	=> (int) $expiry_month,
								'expiry_year' 	=> (int) $expiry_year,
								//'cvv2'			=> (string) $cvv2
							);

							if ( $this->frictionless === false ) {

								$raw_eci      = isset( $_POST['acceptbluev2-payment-eci'] )
												? wp_unslash( $_POST['acceptbluev2-payment-eci'] )
												: '';
								$raw_cavv     = isset( $_POST['acceptbluev2-payment-authenticationvalue'] )
												? wp_unslash( $_POST['acceptbluev2-payment-authenticationvalue'] )
												: '';
								$raw_trans_id = isset( $_POST['acceptbluev2-payment-dstransid'] )
												? wp_unslash( $_POST['acceptbluev2-payment-dstransid'] )
												: '';

								if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {

									$threeds_params = array(
										'3d_secure' => array(
											//'version'    => '2.1.0',
											'eci'        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
											'cavv'       => (string) $raw_cavv,
											'ds_trans_id'=> (string) $raw_trans_id,
										),
									);

									$card_info = array_merge( $card_info, $threeds_params );

								} else {

									self::log(
										'Block 3DS: missing 3d_secure fields — eci=' . var_export( $raw_eci, true )
										. ' cavv=' . ( empty( $raw_cavv ) ? 'EMPTY' : 'present' )
										. ' ds_trans_id=' . var_export( $raw_trans_id, true ),
										'error'
									);

									wc_add_notice( esc_html__( '3D Secure verification did not complete. Please try again.', 'woocommerce' ), 'error' );
									return array( 'result' => 'fail' );

								}

							}


						}

				} else {

					$card = wc_clean( $_POST['acceptbluev2-cardnumber'] );
					$expiry_month = wc_clean( $_POST['acceptbluev2-expiry_m'] );	
					$expiry_year = wc_clean( $_POST['acceptbluev2-expiry_y'] );
					$cvv2		 = 	wc_clean( $_POST['acceptbluev2-card_cvc'] );

					$card_info = array(
						'card' 			=> $card,
						'expiry_month' 	=> (int) $expiry_month,
						'expiry_year' 	=> (int) $expiry_year,
						'cvv2'			=> (string) $cvv2
					);

				}
                
            }

			$card_name = !empty($_REQUEST[ $this->id .'-card-name']) ? sanitize_text_field($_REQUEST[ $this->id .'-card-name']) : '';


            $params = array(
                "amount" 		=> (double) $woo_get_total,                
                "billing_info" 	=> $billing_info,
                "shipping_info" => $shipping_info,						
                "avs_zip" 		=> $avs_zip,
                //"avs_address" 	=> $avs_address,
                "transaction_details" => $transaction_details,
                "amount_details" => $amount_details,     
				"name"			 => $card_name,           
                "capture"        => (bool) $this->force_capture,
                "save_card"      => (bool) $save_card
            ); 

            

            $params = array_merge($params, $card_info);

			$level3_line_items = (array) $this->level3_data_line_items( $order->get_id() );

			$params = array_merge($params, $level3_line_items);

            //Surcharge add into order details
		    $this->surcharge_fee_to_order($order, '' );

            $result = $this->request_api($params, 'transactions/charge', 'POST');

            if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
                $defaults = array();
                $data     = wp_parse_args( (array) $result['response_body'], $defaults );
                
                if( $data[ 'status' ] == 'Approved' ){

                    //$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );

                    if( $this->default_status == 'default' ){
						// Mark as complete or processing based on virtual order or not
						$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );                        
                    } else {                        
						$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
						$order->update_status( $this->default_status );
                    }
                    
                    $order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );

                    // Store the API's auth_amount as the authorized amount for Adjust & Capture.
                    // auth_amount is the ground truth — it's the exact amount authorized on the card,
                    // inclusive of surcharge and all fees. Using $woo_get_total would miss the surcharge
                    // added by surcharge_fee_to_order() and cause false "total changed" warnings.
                    if ( ! (bool) $this->force_capture ) {
                        $auth_amount = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) $woo_get_total;
                        $order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount );
                    }

                    $order->save();

                    $order->add_order_note(
                        esc_html__(
                            sprintf(
                                "%s Payment Completed with Transaction Id of '%s'",
                                $this->method_title,
                                sanitize_text_field( $data['reference_number'] )
                            ),
                            'woocommerce'
                        )
                    );


                    $card_token = array();

                   

                    //* Save token
                    if( $save_card === true && !is_numeric($token_id) ){

                        // accept.blue does not return card_ref when charging an already-saved
                        // card token (tkn-). Fall back to extracting the ref from the source.
                        $card_ref = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );
                        if ( empty( $card_ref ) && ! empty( $card_info['source'] ) ) {
                            $source_val = $card_info['source'];
                            if ( strpos( $source_val, 'tkn-' ) === 0 ) {
                                $card_ref = substr( $source_val, 4 ); // strip "tkn-" prefix
                            }
                        }

                        // Only save when we have a valid, non-empty card reference
                        if ( ! empty( $card_ref ) ) {
                            $order->update_meta_data( '_tokenid', $card_ref );
                            $order->save();

                            // API may return card_type (snake) or cardType (camel) — check both
                            $api_card_type = $data['card_type'] ?? $data['cardType'] ?? '';
                            // API may return last_4 or last4 — check both, then fall back to JS value
                            $api_last4     = $data['last_4'] ?? $data['last4'] ?? '';
                            if ( empty( $api_last4 ) ) {
                                $api_last4 = sanitize_text_field( $_POST['acceptbluev2-last4'] ?? '' );
                            }

                            $card_token['token']            = 'tkn-' . $card_ref;
                            $card_token['card_type']        = sanitize_text_field( $api_card_type );
                            $card_token['set_last4']        = sanitize_text_field( $api_last4 );
                            $card_token['set_expiry_month'] = absint( $card_info['expiry_month'] ?? 0 );
                            $card_token['set_expiry_year']  = absint( $card_info['expiry_year']  ?? 0 );

                            // Guard: WC_Payment_Token_CC::validate() requires a 4-digit year
                            // and a non-empty last4. Skip saving if either is missing.
                            if (
                                $card_token['set_expiry_year'] >= 2000 &&
                                ! empty( $card_token['set_last4'] )
                            ) {
                                $this->save_token( $card_token );
                            } else {
                                self::log( 'save_token skipped: missing expiry year or last4. month='
                                    . $card_token['set_expiry_month'] . ' year=' . $card_token['set_expiry_year']
                                    . ' last4=' . $card_token['set_last4'], 'warning' );
                            }
                        }
                    }

                    WC()->cart->empty_cart();
					//WC()->session->__unset( 'acceptblue_v2_surcharge_info' );
					WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
                        //wp_send_json_success($order->get_checkout_order_received_url());

                        $redirect_url = $this->get_return_url( $order );

                        $pay_for_order = ! empty($_REQUEST[ 'pay_for_order' ]) ? $_REQUEST[ 'pay_for_order' ] : '';

                        if( $pay_for_order == 'true' ){
                                ob_start();
                                ?>
                                <script type="text/javascript">
                                    window.location.replace("<?php echo esc_url($redirect_url); ?>");	
                                </script>
                                <?php
                                exit;

                        } else {

                        return array(
                                'result' => 'success',
                                'redirect' => $redirect_url
                            );

                        }

                } else {

                    $e = ! empty( $data['error_message'] )
                        ? esc_html( $data['error_message'] )
                        : esc_html( $data['status'] ?? 'Payment declined.' );

                    $order->update_status( 'failed' );
                    $order->add_order_note(
                        esc_html( sprintf( "%s Payment Failed: '%s'", $this->method_title, $e ) )
                    );

                    wc_add_notice( esc_html( sprintf( "Payment Failed: '%s'", $e ) ), 'error' );

                    if ( $this->block_support_checkout === true ) {
                        return array(
                            'result'  => 'failure',
                            'message' => esc_html( sprintf( "Payment Failed: '%s'", $e ) ),
                        );
                    }

                    return false;

                }
            
            } else{

               return $this->handle_payment_failure( $order, $result );
                
            }
            
        }     

        
    }

	// Level 3 data
	public function level3_data_line_items($order_id) {

		if (!$this->enable_level3) {
			return array();
		}

		$data = array('line_items' => array());

		$get_commodity_code = function($code) {
			$code = trim((string) $code);
			return (empty($code) || strlen($code) < 8) ? '00000000' : substr($code, 0, 255);
		};

		$build_item = function($product, $quantity, $tax, $subtotal, $total) use ($get_commodity_code) {

			$quantity  = max(1, (int) $quantity); // prevent division by zero
			$unit_cost = round($subtotal / $quantity, 4); // derive cost, avoid float precision issues

			// Safe SKU: fallback to 'ITEM' if empty
			$sku = $this->ab_clean_level3_text($product->get_sku() ?: 'ITEM', 12);

			// Safe description: custom line items may have no description
			$description = method_exists($product, 'get_description')
				? $this->ab_clean_level3_text($product->get_description(), 255)
				: '';

			return array(
				'sku'             => $sku,
				'name'            => $this->ab_clean_level3_text($product->get_name(), 64),
				'description'     => $description,
				'cost'            => floatval(wc_format_decimal($unit_cost)),
				'quantity'        => $quantity,
				'tax_amount'      => round(floatval($tax), 4),
				'unit_of_measure' => $this->level3_unit_of_measure,
				'commodity_code'  => $get_commodity_code($this->level3_commodity_code),
				'discount_amount' => round(floatval($subtotal - $total), 4),
			);
		};

		$make_mock = function($item, $sku = '') {
			return new class($item, $sku) {
				private $item;
				private $sku;
				public function __construct($item, $sku) { $this->item = $item; $this->sku = $sku; }
				public function get_sku()         { return $this->sku; }
				public function get_name()        { return $this->item->get_name(); }
				public function get_description() { return ''; }
			};
		};

		// Try cart first (checkout flow)
		if (WC()->cart && !WC()->cart->is_empty()) {
			foreach (WC()->cart->get_cart() as $cart_item) {
				$product = $cart_item['data'] ?? null;

				if (!$product instanceof WC_Product) continue; // skip invalid items

				$data['line_items'][] = $build_item(
					$product,
					$cart_item['quantity']      ?? 1,
					$cart_item['line_tax']      ?? 0,
					$cart_item['line_subtotal'] ?? 0,
					$cart_item['line_total']    ?? 0
				);
			}
		}

		// Fallback to saved order (admin/manual orders, custom line items)
		if (empty($data['line_items']) && $order_id) {
			$order = wc_get_order($order_id);

			if ($order instanceof WC_Order) {

				// Regular and custom product line items
				foreach ($order->get_items() as $item) {
					/** @var WC_Order_Item_Product $item */
					$product = $item->get_product();

					if (!$product instanceof WC_Product) {
						$product = $make_mock($item); // custom line item fallback
					}

					$data['line_items'][] = $build_item(
						$product,
						$item->get_quantity(),
						$item->get_total_tax(),
						$item->get_subtotal(),
						$item->get_total()
					);
				}

				// Fee line items (e.g. $0 product + fee scenario)
				foreach ($order->get_fees() as $fee) {
					/** @var WC_Order_Item_Fee $fee */
					$fee_total = floatval($fee->get_total());

					if ($fee_total <= 0) continue; // skip zero or negative fees

					$data['line_items'][] = $build_item(
						$make_mock($fee, 'FEE'),
						1, // fees are always quantity 1
						$fee->get_total_tax(),
						$fee_total,
						$fee_total
					);
				}
			}
		}

		// Remove any line items with zero cost (gateway requires cost >= 0.0001)
		$data['line_items'] = array_values(array_filter(
			$data['line_items'],
			fn($item) => $item['cost'] >= 0.0001
		));

		// If no line items could be built, skip Level 3 data entirely
		if (empty($data['line_items'])) {
			return array();
		}

		return $data;
	}

	private function ab_clean_level3_text($value, $max_length) {
		$value = is_string($value) ? $value : '';
		$value = wp_strip_all_tags($value);
		$value = preg_replace('/\s+/', ' ', $value);
		$value = trim($value);

		if ($this->level3_truncate) {
			return mb_substr($value, 0, $max_length);
		}

		return $value;
	}

	
    //* WC check product is virtual

	public function virtual_order_payment_complete_order_status( $order_id ){
		
		$order = wc_get_order( $order_id );
	 
    	$virtual_order = null;

    	if( is_a( $order, 'WC_Order' ) ) {

    		if ( count( $order->get_items() ) > 0 ) {
 
	      		foreach( $order->get_items() as $order_item_id => $order_item ) {

	      			$product_id = $order_item['product_id'];
					$product = wc_get_product( $product_id );

					if( $product ) {
						if( $product->is_virtual() ){
							$virtual_order = true;
							break;
						}
						else{
							$virtual_order = false;
							break;
						}
					}
	        		
	      		}
	    	}

    	}
	 
	    // virtual order, mark as completed
	    if ( $virtual_order ) {
	      return 'completed';
	    }
	  	
	 
	  	// non-virtual order, return original status
	  	return $order->get_status();
	}

    public static function log( $message, $level = 'info' ) {

		if ( ! self::$log_enabled ) {
			return;
		}

		if ( ! self::$log ) {
			self::$log = wc_get_logger();
		}

		// Normalize log level
		$allowed_levels = array(
			'emergency',
			'alert',
			'critical',
			'error',
			'warning',
			'notice',
			'info',
			'debug',
		);

		if ( ! in_array( $level, $allowed_levels, true ) ) {
			$level = 'info';
		}

		// Convert complex data to string safely
		if ( is_array( $message ) || is_object( $message ) ) {
			$message = wp_json_encode( $message, JSON_PRETTY_PRINT );
		} elseif ( is_wp_error( $message ) ) {
			$message = $message->get_error_message();
		}

		self::$log->log(
			$level,
			(string) $message,
			array(
				'source' => 'acceptbluev2',
			)
		);
	}


    //* Accept.Blue API v2 request

	/**
	 * Resolve the customer IP address for transaction_details.client_ip.
	 *
	 * $order->get_customer_ip_address() is empty for Block/Store-API checkouts because
	 * WooCommerce's Store API may not have stored the IP into the order meta by the time
	 * process_payment() fires. Fall back to WC_Geolocation::get_ip_address() which walks
	 * the standard proxy-header chain (CF-Connecting-IP, X-Real-IP, X-Forwarded-For,
	 * REMOTE_ADDR) to find the real client IP.
	 *
	 * @param  WC_Order $order
	 * @return string   Sanitized IP address, or empty string if none found.
	 */
	protected function get_client_ip( WC_Order $order ) {
		$ip = $order->get_customer_ip_address();

		if ( empty( $ip ) && class_exists( 'WC_Geolocation' ) ) {
			$ip = WC_Geolocation::get_ip_address();
		}

		return sanitize_text_field( (string) $ip );
	}

	public function request_api( $params, $action = '', $method = 'POST' ) {

		// JSON_PRESERVE_ZERO_FRACTION ensures whole-number floats (e.g. 12.0) encode
		// as "12.0" not "12". The accept.blue API requires amount to be a JSON decimal;
		// integer-encoded amounts cause a 500 Internal Server Error.
		$params   = ! empty( $params ) ? json_encode( $params, JSON_PRESERVE_ZERO_FRACTION ) : '';
		$username = $this->api_key;
		$password = $this->api_pin;

		// Log the outgoing request — sensitive fields masked before writing
		self::log(
			$this->method_title . ' ' . AB_V2_VERSION
			. ' Request [' . strtoupper( $method ) . ' ' . $action . '] '
			. WC_AcceptBlue_Log_Masker::mask_request( $params )
		);

		$response = wp_remote_request(
			$this->acceptblue_url . $action,
			array(
				'method'     => $method,
				'headers'    => array(
					'Content-Type'  => 'application/json',
					// Credentials stay out of the log — never passed to self::log()
					'Authorization' => 'Basic ' . base64_encode( $username . ':' . $password ),
				),
				'body'       => $params,
				'timeout'    => 90,
				'sslverify'  => true,
				'user-agent' => __( 'accept.blue v2 for WooCommerce ' . AB_V2_VERSION, 'woocommerce' ),
			)
		);

		if ( is_wp_error( $response ) ) {

			$result['code']    = false;
			$result['message'] = $response->get_error_message();

			self::log(
				$this->method_title . ' ' . AB_V2_VERSION . ' Response [ERROR] ' . $result['message'],
				'error'
			);

		} else {

			$response_body = json_decode( $response['body'] );

			// Log the response — card refs, tokens and PII masked
			self::log(
				$this->method_title . ' ' . AB_V2_VERSION
				. ' Response [' . $response['response']['code'] . '] '
				. WC_AcceptBlue_Log_Masker::mask_response( $response_body )
			);

			$result['code']             = true;
			$result['response_code']    = $response['response']['code'];
			$result['response_message'] = $response['response']['message'];
			$result['response_body']    = $response_body;
		}

		return $result;
	}

    public function script() {
        wp_enqueue_script( 'acceptblue-v2', plugins_url( 'assets/js/dist/acceptblue-checkout-form.min.js', dirname(__FILE__) ), array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ), AB_V2_VERSION, true );
    }

    public function style(){
		wp_enqueue_style( 'acceptblue-v2-main', plugins_url( 'assets/css/dist/acceptblue-main.min.css', dirname(__FILE__) ) ); 
	}

	public function google_pay_style(){
		wp_enqueue_style( 'acceptblue-v2-google-pay', plugins_url( 'assets/css/dist/acceptblue-google-pay.min.css', dirname(__FILE__) ) ); 
	}

    public function process_refund($order_id, $amount = null, $reason = '') {
        global $woocommerce;

        $order = wc_get_order($order_id);

        if (!$order) {
            return false;
        }
       
		// _transaction_id is a WC internal key — use the proper getter.
		$transaction_id = $order->get_transaction_id();

		if ( ! $transaction_id ) {

			$order->add_order_note(
			            esc_html__( sprintf(
							'%s Refund failed because the Transaction ID is missing.',
							ucwords($this->id)
						), 'woocommerce' )
			        );

			return new WP_Error(
				'acceptblue_no_transaction_id',
				sprintf(
					/* translators: %s: gateway name */
					__( '%s Refund failed: Transaction ID is missing from this order.', 'woocommerce' ),
					ucwords( $this->id )
				)
			);
		}	

		if($amount > 0 ){
			$params[ 'amount' ] = (double) $amount;	
		}		

		$order->add_order_note(
			esc_html__( sprintf(
				'%1$s Refund with amount of %2$s',
				$this->method_title,					
				get_woocommerce_currency_symbol() . wc_format_decimal( $amount )
			), 'woocommerce' )
		);

		$current_user = wp_get_current_user();

		$params[ 'reference_number' ] 	 = (int) $transaction_id;
		$params[ 'transaction_details' ] = array(
			"description" 		=> sprintf( "Order No.#%s Refund Amount %s",$order->get_order_number(), get_woocommerce_currency_symbol() . wc_format_decimal( $amount ) ),
			"order_number" 		=> $order->get_order_number(),
			"invoice_number" 	=> $order->get_order_number(),
			"clerk"             => sprintf( "User ID: %s", esc_html( $current_user->ID ) )
		);
		
		
        $result = $this->request_api($params, 'transactions/reversal', 'POST');

		if ( empty( $result['response_body'] ) ) {
			return new WP_Error( $this->id . '_refund_error', esc_html__( 'Refund failed: empty response from gateway.', 'woocommerce' ) );
		}

		$data = (array) $result['response_body'];

		if($data[ 'status' ] == 'Approved' ){

			$order->add_order_note(
		            esc_html__( sprintf(
		                '%1$s Refund %2$s with type of %3$s',
		                $this->method_title,
		                sanitize_text_field($data['status']),
		                sanitize_text_field($data['type'])
		            ), 'woocommerce' )
				);
			

			if( $amount == 0 ){

				$order->update_status( 'refunded' );

			} else {

				$refund_amount = ( $order->get_remaining_refund_amount() - $amount );

				if($refund_amount == 0 ){
					$order->update_status( 'refunded' );
				}

			}		

			return true;

		} else {

			$err_msg  = sanitize_text_field( $data['error_message'] ?? $data['status'] ?? 'Unknown error' );
			$err_code = sanitize_text_field( $data['error_code']    ?? '' );

			$order->add_order_note(
		            esc_html__( sprintf(
		                '%1$s Refund %2$s with Error Code of %3$s',
		                $this->method_title,
		                $err_msg,
		                $err_code
		            ), 'woocommerce' )
		        );
			
			return new WP_Error( $this->id . '_refund_error', esc_html__( ucwords($this->method_title). ' ' . $err_msg . ( $err_code ? ' - Error code ' . $err_code : '' ), 'woocommerce' ) );

		}
		
		return false;
    }

    // Capture payment after order status changed to specific status
	public static function process_capture($order_id, $order = null) {
		
		if (! $order instanceof WC_Order) {
			$order = wc_get_order($order_id);
			if (! $order) return false;
		}

		// Try WC getter first
		$payment_method = $order->get_payment_method();

		// Fallback to meta in case getter is empty
		if (empty($payment_method)) {
			$payment_method = $order->get_meta('_payment_method', true);
		}
		

		// Resolve the gateway instance for this order — supports both the main
		// credit-card gateway (acceptbluev2) and the Google Pay gateway
		// (acceptbluev2_googlepay_checkout). Both gateways use the same
		// /transactions/adjust-capture API endpoint and the same meta keys.
		$accepted_ids = array( 'acceptbluev2', 'acceptbluev2_googlepay_checkout' );
		if ( ! in_array( $payment_method, $accepted_ids, true ) ) {
			return false;
		}

		$all_gateways = WC()->payment_gateways()->payment_gateways();

		// For Google Pay orders, we must use the main gateway's API credentials
		// (the Google Pay gateway inherits keys from the main gateway), so always
		// resolve capture through the main acceptbluev2 gateway instance.
		if ( ! empty( $all_gateways['acceptbluev2'] ) ) {
			$gateway = $all_gateways['acceptbluev2'];
		} else {
			$gateway = new self();
		}

		// Skip if force capture enabled
		if ( ! empty( $gateway->force_capture ) ) {
			return true;
		}

		// Validate capture trigger status from gateway setting
		$current_status = $order->get_status();
		$capture_setting = str_replace('wc-', '', $gateway->order_capture_status);
		
		if ($capture_setting !== $current_status) {
			return false;
		}

		// Prevent duplicate capture
		if ($order->get_meta('_acceptblue_capture_done')) {
			return true;
		}


		// Get transaction ID — use WC getter; _transaction_id is an internal key.
		$transaction_id = $order->get_transaction_id();

		if ( empty( $transaction_id ) ) {
			$transaction_id = $order->get_meta( '_' . $gateway->id . '_refnum' );
		}
		// Also check the Google Pay refnum key in case this is a GPay order
		if ( empty( $transaction_id ) && $payment_method === 'acceptbluev2_googlepay_checkout' ) {
			$transaction_id = $order->get_meta( '_acceptbluev2_googlepay_checkout_refnum' );
		}

		if ( empty( $transaction_id ) ) {
			$order->add_order_note(
				sprintf(
					'%s Capture failed: Missing Transaction ID.',
					$gateway->method_title
				)
			);
			return false;
		}

		// Use /transactions/capture (capture-only) — captures the originally
		// authorized amount without modification. Only reference_number is required.
		// For amount adjustments before capture, use Adjust & Capture instead.
		$capture_params = array(
			'reference_number' => (int) $transaction_id,
		);

		$result = $gateway->request_api( $capture_params, 'transactions/capture', 'POST' );

		if (
			isset($result['response_code'], $result['response_message'], $result['response_body']) &&
			(int) $result['response_code'] === 200 &&
			$result['response_message'] === 'OK'
		) {
			$data = wp_parse_args($result['response_body'], array());

			if (! empty($data['status']) && $data['status'] === 'Approved') {

				$order->update_meta_data('_' . $gateway->id . '_capture_status', sanitize_text_field($data['status']));
				$order->update_meta_data('_acceptblue_capture_done', 'yes');
				$order->save();

				$captured_amount = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) $order->get_total();
				$note = sprintf(
					'%1$s capture approved. Captured: %2$s',
					$gateway->method_title,
					wc_price( $captured_amount, array( 'currency' => $order->get_currency() ) )
				);
				$note .= sprintf(
					' | Auth: %s | %s •••• %s | Status: %s (%s).',
					sanitize_text_field( $data['auth_code'] ?? 'N/A' ),
					sanitize_text_field( $data['card_type'] ?? 'Card' ),
					sanitize_text_field( $data['last_4'] ?? '----' ),
					sanitize_text_field( $data['status'] ?? '' ),
					sanitize_text_field( $data['status_code'] ?? '' )
				);
				$order->add_order_note( $note );

				return true;

			} else {
				$order->add_order_note(
					sprintf(
						'%1$s Capture failed. Status: %2$s | Error: %3$s - %4$s',
						$gateway->method_title,
						sanitize_text_field($data['status'] ?? 'Unknown'),
						sanitize_text_field($data['error'] ?? ''),
						sanitize_text_field($data['errorcode'] ?? '')
					)
				);
				return false;
			}
		}

		// API failure fallback
		$order->add_order_note(
			sprintf('%s Capture request failed or invalid API response.', $gateway->method_title)
		);

		return false;
	}


	// =========================================================================
	// Surcharge helper — order total excluding surcharge fee
	// =========================================================================

	/**
	 * Return the order total with the accept.blue surcharge fee stripped out.
	 *
	 * The surcharge is added as a WC_Order_Item_Fee whose name matches
	 * $this->surcharge_label. All Adjust & Capture comparisons and the amount
	 * sent to /transactions/adjust-capture must exclude this fee because:
	 *   - The surcharge is already embedded in the original authorized amount
	 *     at charge time via surcharge_fee_to_order().
	 *   - When comparing authorized vs current total for the "total changed"
	 *     warning/validation, adding the surcharge again would produce a false
	 *     positive diff.
	 *   - The adjust-capture payload amount must match what the merchant wants
	 *     to capture for goods/services, not inflated by a re-applied surcharge.
	 *
	 * @param  WC_Order $order
	 * @return float  Order total minus any surcharge fee line item.
	 */
	public static function get_order_total_excluding_surcharge( WC_Order $order ) {

		$total = (float) $order->get_total();

		// Retrieve the configured surcharge label from gateway settings.
		$settings       = get_option( 'woocommerce_acceptbluev2_settings', array() );
		$surcharge_label = ! empty( $settings['surcharge_label'] ) ? $settings['surcharge_label'] : 'Surcharge Fee';

		// Walk every fee on the order and subtract any that match the surcharge label.
		foreach ( $order->get_items( 'fee' ) as $item ) {
			/** @var WC_Order_Item_Fee $item */
			if ( strtolower( trim( $item->get_name() ) ) === strtolower( trim( $surcharge_label ) ) ) {
				$total -= (float) $item->get_total();
			}
		}

		return round( $total, 2 );
	}

	/**
	 * Return the amount to pass to verify3DS() for a given order/cart total.
	 *
	 * The 3DS SDK requires amount >= 0.01. For subscription trial orders where
	 * the initial total is $0.00, we pass 0.01 (matching the $0.01 auth-and-void
	 * that the payment flow sends to the API). Passing 0 causes a CAVV mismatch
	 * because the API charges 0.01 but 3DS was verified against 0.
	 *
	 * @param  float $raw_amount  Pre-surcharge order/cart total.
	 * @param  int   $order_id    WC order ID (0 if cart-only context).
	 * @return float              Amount safe to pass to verify3DS().
	 */
	public static function get_threeds_amount( $raw_amount, $order_id = 0 ) {
		$amount = (float) $raw_amount;

		// If the total is already >= 0.01 there is nothing to adjust.
		if ( $amount >= 0.01 ) {
			return $amount;
		}

		// $0 total — only substitute 0.01 for subscription orders (trial period).
		// For non-subscription $0 orders (e.g. 100% coupon) leave as 0 so the
		// caller can decide not to run 3DS at all.
		$is_subscription = false;

		if ( $order_id > 0 ) {
			// Order context: use WCS order helpers
			$is_subscription = (
				( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order_id ) )
				|| ( function_exists( 'wcs_order_contains_renewal' )   && wcs_order_contains_renewal( $order_id ) )
			);
		} else {
			// Cart context (block/classic checkout before order is created).
			// WC Subscriptions uses WC_Subscriptions_Cart::cart_contains_subscription(),
			// not wcs_cart_contains_subscription() which does not exist.
			if ( class_exists( 'WC_Subscriptions_Cart' ) && method_exists( 'WC_Subscriptions_Cart', 'cart_contains_subscription' ) ) {
				$is_subscription = (bool) WC_Subscriptions_Cart::cart_contains_subscription();
			}
			// Fallback: walk cart items and look for subscription product types
			if ( ! $is_subscription && function_exists( 'WC' ) && WC()->cart ) {
				foreach ( WC()->cart->get_cart() as $item ) {
					$product = isset( $item['data'] ) ? $item['data'] : null;
					if ( $product && is_a( $product, 'WC_Product' ) ) {
						$type = $product->get_type();
						if ( strpos( $type, 'subscription' ) !== false ) {
							$is_subscription = true;
							break;
						}
					}
				}
			}
		}

		return $is_subscription ? 0.01 : $amount;
	}


	// =========================================================================
	// Adjust and Capture — capture with updated amount when order total changed
	// =========================================================================

	/**
	 * Capture an authorized (auth-only) transaction with the current order total.
	 *
	 * Called via:
	 *   - WooCommerce order action "acceptblue_adjust_and_capture"
	 *   - AJAX endpoint acceptblue_v2_ajax_adjust_capture (admin button)
	 *
	 * @param  int            $order_id
	 * @param  WC_Order|null  $order
	 * @return bool
	 */
	public static function adjust_and_capture( $order_id, $order = null ) {

		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) return false;
		}

		// Accept both the main credit-card gateway and Google Pay — both use the
		// same accept.blue /transactions/adjust-capture API endpoint.
		$pm = $order->get_payment_method();
		$accepted_ids = array( 'acceptbluev2', 'acceptbluev2_googlepay_checkout' );
		if ( ! in_array( $pm, $accepted_ids, true ) ) {
			return false;
		}

		$gateways = WC()->payment_gateways()->payment_gateways();
		if ( empty( $gateways['acceptbluev2'] ) ) return false;
		$gateway = $gateways['acceptbluev2']; // always use main gateway for API creds

		// Must not have already been captured
		if ( $order->get_meta( '_acceptblue_capture_done' ) ) {
			$order->add_order_note(
				sprintf( '%s Adjust & Capture skipped: payment already captured.', $gateway->method_title )
			);
			return true;
		}

		$transaction_id = $order->get_transaction_id();
		if ( empty( $transaction_id ) ) {
			$transaction_id = $order->get_meta( '_' . $gateway->id . '_refnum' );
		}
		// Fallback: Google Pay stores refnum under its own gateway id meta key
		if ( empty( $transaction_id ) && $pm === 'acceptbluev2_googlepay_checkout' ) {
			$transaction_id = $order->get_meta( '_acceptbluev2_googlepay_checkout_refnum' );
		}

		if ( empty( $transaction_id ) ) {
			$order->add_order_note(
				sprintf( '%s Adjust & Capture failed: missing Transaction ID.', $gateway->method_title )
			);
			return false;
		}

		// Use the full order total including surcharge for capture amount and comparison.
		$new_total         = round( (float) $order->get_total(), 2 );
		$authorized_amount = (float) $order->get_meta( '_acceptblue_authorized_amount' );
		$total_changed     = $authorized_amount && abs( $new_total - $authorized_amount ) >= 0.01;

		// -----------------------------------------------------------------------
		// Build the payload for POST /transactions/adjust-capture
		//
		// Per accept.blue API docs:
		//   - Endpoint: /transactions/adjust-capture  (NOT /transactions/capture)
		//   - If the amount changes, amount_details MUST be resent alongside amount.
		//   - Requires Capture permission always; Adjust permission when amount changes.
		//   - TSYS only: US/Canadian cards only; international cards must use refunds.
		//   - A transaction can only be adjusted once.
		//   - amount includes the surcharge fee.
		// -----------------------------------------------------------------------
		$params = array(
			'reference_number' => (int) $transaction_id,
			'amount'           => (float) number_format( $new_total, 2, '.', '' ),
		);

		// amount_details MUST be resent whenever the amount changes (API requirement).
		// We always include it for safety — it never hurts to send it.
		// These are also surcharge-exclusive: tax/shipping/discount on the order items only.
		$params['amount_details'] = array(
			'tax'      => round( (float) $order->get_total_tax(), 4 ),
			'shipping' => round( (float) $order->get_shipping_total(), 4 ),
			'discount' => round( (float) $order->get_discount_total(), 4 ),
		);

		// transaction_details for audit trail
		$params['transaction_details'] = array(
			'description'    => sprintf( '%s - Adjust & Capture ORDER No. #%s', ucwords( get_bloginfo( 'name' ) ), $order->get_order_number() ),
			'order_number'   => $order->get_order_number(),
			'invoice_number' => $order->get_order_number(),
			'clerk'          => sprintf( 'User ID: %s', get_current_user_id() ),
		);

		// Level 3 line items — resend with the captured amount so L3 data stays
		// aligned with the actual transaction amount (docs: line_items non-empty array).
		$level3 = (array) $gateway->level3_data_line_items( $order_id );
		if ( ! empty( $level3['line_items'] ) ) {
			$params['line_items'] = $level3['line_items'];
		}

		// Use the dedicated /transactions/adjust-capture endpoint.
		$result = $gateway->request_api( $params, 'transactions/adjust-capture', 'POST' );

		if (
			isset( $result['response_code'], $result['response_message'], $result['response_body'] ) &&
			(int) $result['response_code'] === 200 &&
			$result['response_message'] === 'OK'
		) {
			$data = wp_parse_args( $result['response_body'], array() );

			if ( ! empty( $data['status'] ) && $data['status'] === 'Approved' ) {

				$order->update_meta_data( '_' . $gateway->id . '_capture_status', sanitize_text_field( $data['status'] ) );
				$order->update_meta_data( '_acceptblue_capture_done', 'yes' );
				$order->update_meta_data( '_acceptblue_adjust_capture_done', 'yes' );
				$order->save();

				// Auto-complete order after adjust-and-capture
				if ( $order->get_status() !== 'completed' ) {
					$order->update_status( 'completed', sprintf(
						'%s Adjust & Capture: order auto-completed.',
						$gateway->method_title
					) );
				}

				$note = sprintf(
					'%1$s Adjust & Capture approved. Captured: %2$s',
					$gateway->method_title,
					wc_price( $data['auth_amount'] ?? $new_total, array( 'currency' => $order->get_currency() ) )
				);

				if ( $total_changed ) {
					$note .= sprintf(
						' (adjusted from authorized: %s)',
						wc_price( $authorized_amount, array( 'currency' => $order->get_currency() ) )
					);
				}

				$note .= sprintf(
					' | Auth: %s | %s •••• %s | Status: %s (%s).',
					sanitize_text_field( $data['auth_code'] ?? 'N/A' ),
					sanitize_text_field( $data['card_type'] ?? 'Card' ),
					sanitize_text_field( $data['last_4'] ?? '----' ),
					sanitize_text_field( $data['status'] ?? '' ),
					sanitize_text_field( $data['status_code'] ?? '' )
				);

				$order->add_order_note( $note );

				return true;

			} else {

				$order->add_order_note( sprintf(
					'%1$s Adjust & Capture failed. Status: %2$s | Error: %3$s - %4$s',
					$gateway->method_title,
					sanitize_text_field( $data['status'] ?? 'Unknown' ),
					sanitize_text_field( $data['error'] ?? '' ),
					sanitize_text_field( $data['errorcode'] ?? '' )
				) );

				return false;
			}
		}

		$order->add_order_note(
			sprintf( '%s Adjust & Capture: API request failed or invalid response.', $gateway->method_title )
		);

		return false;
	}


    //* WC process cancelled order
	public static function process_cancelled( $order_id, $order ) {

		if ( ! $order ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				return;
			}
		}

		// Only run for AcceptBlue orders
		if ( $order->get_payment_method() !== 'acceptbluev2' ) {
			return;
		}

		// Get the real configured gateway instance
		$gateways = WC()->payment_gateways()->payment_gateways();

		if ( empty( $gateways['acceptbluev2'] ) ) {
			return;
		}

		$gateway = $gateways['acceptbluev2'];

		// Prevent duplicate reversal
		if ( $order->get_meta( '_acceptblue_cancel_processed' ) ) {
			return;
		}

		$transaction_id = $order->get_transaction_id();

		if ( ! $transaction_id ) {
			$order->add_order_note(
				sprintf(
					'%s Refund failed because the Transaction ID is missing.',
					ucwords( $gateway->id )
				)
			);
			return;
		}

		$current_user = wp_get_current_user();

		$params = array(
			'reference_number' => (int) $transaction_id,
			'transaction_details' => array(
				'description'    => sprintf( 'Order No.#%s Cancelled', $order->get_order_number() ),
				'order_number'   => $order->get_order_number(),
				'invoice_number' => $order->get_order_number(),
				'clerk'          => sprintf( 'User ID: %s', esc_html( $current_user->ID ) ),
			),
		);

		$result = $gateway->request_api( $params, 'transactions/reversal', 'POST' );
		$data   = (array) $result['response_body'];

		if ( isset( $data['status'] ) && $data['status'] === 'Approved' ) {

			$order->add_order_note(
				sprintf(
					'%1$s cancellation approved. Ref #%2$s | Status: %3$s (%4$s) | Method: %5$s •••• %6$s | Type: %7$s.',
					$gateway->method_title,
					sanitize_text_field( $data['reference_number'] ?? '' ),
					sanitize_text_field( $data['status'] ?? '' ),
					sanitize_text_field( $data['status_code'] ?? '' ),
					sanitize_text_field( $data['card_type'] ?? 'Card' ),
					sanitize_text_field( $data['last_4'] ?? '----' ),
					sanitize_text_field( $data['type'] ?? 'Transaction' )
				)
			);


			$order->update_meta_data( '_acceptblue_cancel_processed', 'yes' );
			$order->save();

			return true;

		} else {

			$order->add_order_note(
				sprintf(
					'%1$s Cancel failed: %2$s (Code %3$s)',
					$gateway->method_title,
					sanitize_text_field( $data['error_message'] ?? 'Unknown error' ),
					sanitize_text_field( $data['error_code'] ?? '' )
				)
			);

			return new WP_Error(
				$gateway->id . '_cancel_error',
				sanitize_text_field( $data['error_message'] ?? 'Unknown error' )
			);
		}
	}


    //* Accept.Blue save card token

	public function save_token( $params ) {

		// Only save tokens for logged-in users — WC_Payment_Token requires a user_id
		if ( ! is_user_logged_in() ) {
			return null;
		}

		$user_id           = get_current_user_id();
		$customer_token    = get_user_meta( $user_id, $this->id . '_customer_token', true );
		$customer_token_id = null;

		// Check if this customer already has a matching token stored
		$customer_tokens = WC_Payment_Tokens::get_customer_tokens( $user_id, $this->id );
		if ( ! empty( $customer_tokens ) ) {
			foreach ( $customer_tokens as $c_token ) {
				if ( $c_token->get_token() === $customer_token ) {
					$customer_token_id = $c_token->get_id();
					break;
				}
			}
		}

		$token = ( $customer_token_id !== null )
			? WC_Payment_Tokens::get( $customer_token_id )
			: new WC_Payment_Token_CC();

		if ( ! $token ) {
			$token = new WC_Payment_Token_CC();
		}

		// Ensure expiry year is 4 digits — WC_Payment_Token_CC::validate() requires it
		$expiry_year = (int) $params['set_expiry_year'];
		if ( $expiry_year > 0 && $expiry_year < 100 ) {
			$expiry_year = 2000 + $expiry_year;
		}

		$token->set_token( $params['token'] );
		$token->set_gateway_id( $this->id );
		$token->set_card_type( $params['card_type'] ?? '' );
		$token->set_last4( $params['set_last4'] ?? '' );
		$token->set_expiry_month( (string) $params['set_expiry_month'] );
		$token->set_expiry_year( (string) $expiry_year );
		$token->set_user_id( $user_id );

		$result = $token->save();

		if ( $result ) {
			return $token;
		}

		self::log( 'save_token failed for user ' . $user_id . ' token=' . $params['token'], 'warning' );
		return null;
	}

    //* Accept.Blue get saved card token

	public function use_card_token( $token_id = '' ){

		$result = array();

		if( !empty( $token_id) && is_numeric($token_id)){
			$card_token = WC_Payment_Tokens::get( $token_id );
			$raw_token  = $card_token ? $card_token->get_token() : '';

			// Reject tokens saved with an empty card_ref (value is just "tkn-")
			$valid = ! empty( $raw_token ) && $raw_token !== 'tkn-';

			if( $valid ){

				$result = array(
					'token' 	=> 	$raw_token,
                    'expiry_month' 	=> 	$card_token->get_expiry_month(),
					'expiry_year' 	=> 	$card_token->get_expiry_year(),
				);

			}

		}

		return $result;
	}

    public function add_payment_method() {

		$current_user   = wp_get_current_user();
		$customer_info = get_user_meta( $current_user->ID );

		if( !empty($_POST['payment_method']) && $_POST['payment_method'] == $this->id && $_POST[ 'woocommerce_add_payment_method' ] == 1 ){

			// ── Hosted tokenization path (block_support_checkout mode) ────────────
			// The checkout iframe JS submits a nonce token instead of raw card fields.
			$hosted_nonce = ! empty( $_POST['acceptbluev2-payment-token'] )
				? sanitize_text_field( $_POST['acceptbluev2-payment-token'] )
				: '';

			if ( ! empty( $hosted_nonce ) ) {

				// Build charge params for a $0.01 auth-and-void to validate the card
				// and capture a card_ref (token) for saving.
				$params = array(
					'amount'      => 0.01,
					'source'      => 'nonce-' . $hosted_nonce,
					'capture'     => false,
					'save_card'   => true,
					'billing_info' => array(
						'first_name' => $current_user->first_name,
						'last_name'  => $current_user->last_name,
					),
					'transaction_details' => array(
						'description' => sprintf( '%s - Add Payment Method', ucwords( get_bloginfo('name') ) ),
						'client_ip'   => $this->get_client_ip( null ),
					),
				);

				// Include expiry if submitted by the iframe JS
				$expiry_month = ! empty( $_POST['acceptbluev2-payment-expiry_month'] ) ? (int) $_POST['acceptbluev2-payment-expiry_month'] : 0;
				$expiry_year  = ! empty( $_POST['acceptbluev2-payment-expiry_year'] )  ? (int) $_POST['acceptbluev2-payment-expiry_year']  : 0;
				if ( $expiry_month ) $params['expiry_month'] = $expiry_month;
				if ( $expiry_year )  $params['expiry_year']  = $expiry_year;

				// Include 3DS data if present
				$raw_eci      = ! empty( $_POST['acceptbluev2-payment-eci'] )                ? sanitize_text_field( $_POST['acceptbluev2-payment-eci'] )                : '';
				$raw_cavv     = ! empty( $_POST['acceptbluev2-payment-authenticationvalue'] ) ? sanitize_text_field( $_POST['acceptbluev2-payment-authenticationvalue'] ) : '';
				$raw_trans_id = ! empty( $_POST['acceptbluev2-payment-dstransid'] )           ? sanitize_text_field( $_POST['acceptbluev2-payment-dstransid'] )           : '';
				if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {
					$params['3d_secure'] = array(
						'eci'        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
						'cavv'       => (string) $raw_cavv,
						'ds_trans_id'=> (string) $raw_trans_id,
					);
				}

				$result = $this->request_api( $params, 'transactions/charge', 'POST' );

				if ( $result['response_code'] == 200 && $result['response_message'] === 'OK' && ! empty( $result['response_body'] ) ) {
					$data     = wp_parse_args( (array) $result['response_body'], array() );
					$card_ref = sanitize_text_field( $data['card_ref'] ?? $data['cardRef'] ?? '' );

					if ( ! empty( $card_ref ) ) {
						// Void the $0.01 auth immediately
						$ref_num = sanitize_text_field( $data['reference_number'] ?? '' );
						if ( $ref_num ) {
							$this->request_api( array( 'reference_number' => (int) $ref_num ), 'transactions/reversal', 'POST' );
						}

						$card_token = array(
							'token'            => 'tkn-' . $card_ref,
							'card_type'        => sanitize_text_field( $data['card_type'] ?? '' ),
							'set_last4'        => sanitize_text_field( $data['last_4'] ?? '' ),
							'set_expiry_month' => (int) ( $data['expiry_month'] ?? $expiry_month ),
							'set_expiry_year'  => (int) ( $data['expiry_year']  ?? $expiry_year  ),
						);
						$this->save_token( $card_token );

						return array(
							'result'   => 'success',
							'redirect' => wc_get_endpoint_url( 'payment-methods' ),
						);
					}
				}

				wc_add_notice( esc_html__( 'There was a problem adding this card.', 'woocommerce' ), 'error' );
				return;
			}

			// ── Classic (non-hosted) path — raw card fields ────────────────────
			$params[ "card" ] 	 	        = sanitize_text_field($_REQUEST[ 'acceptbluev2-cardnumber' ]);
            $params[ "expiry_month" ] 		= (int) wc_clean($_REQUEST[ 'acceptbluev2-expiry_m' ]);
            $params[ "expiry_year" ] 		= (int) wc_clean($_REQUEST[ 'acceptbluev2-expiry_y' ]);
		
            $result = $this->request_api($params, 'saved-cards', 'POST');		

			if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){

				$defaults = array();
				$data     = wp_parse_args( (array) $result['response_body'], $defaults );

				if( !empty($data[ 'cardRef' ]) ){

					$card_token = array();

					//* Save token
					$card_token[ 'token' ] 				= "tkn-" . sanitize_text_field($data[ 'cardRef' ]);
					$card_token[ 'card_type' ] 			= sanitize_text_field($this->get_card_type($params[ 'card' ]));
					$card_token[ 'set_last4' ]			= substr(sanitize_text_field($params[ 'card' ]), -4 );
					$card_token[ 'set_expiry_month' ]	= absint($params['expiry_month']);
					$card_token[ 'set_expiry_year' ]	= absint($params[ 'expiry_year' ]);

					//* Fire save card token
					$this->save_token($card_token);
				
				}

				return array(
					'result'   => 'success',
					'redirect' => wc_get_endpoint_url( 'payment-methods' ),
				);

			} else {
				wc_add_notice( esc_html__( 'There was a problem adding this card.', 'woocommerce' ), 'error' );
				return;
			}
	 }

	}


    //* Get card type

	public function get_card_type( $cardnum ) { 
	  		
        /* Visa */
        
        if ( preg_match( "/^4(\d{12}|\d{15})$/", $cardnum ) ) { 
                $type = 'Visa'; 
                    
            /* MasterCard */	
                    
            } else if( preg_match( "/^5[1-5]\d{14}$/", $cardnum ) ) { 
                $type = 'Master'; 
                
            /* American Express */	
                
            } else if( preg_match( "/^3[47]\d{13}$/", $cardnum ) ) { 
                    $type = 'AMEX';
                    
            /* Discover */
                        
            } else if( preg_match( "/^6011\d{12}$/", $cardnum ) ){ 
                $type = 'Discover'; // Discover
                    
            /* Diners Club */
                            
            } else if( preg_match( "/^3(0[0-5])\d{11}$/", $cardnum ) || 
            preg_match( "/^3[68]\d{12}$/", $cardnum ) ){ 
                $type = 'Diners'; 
                
            /* EnRoute */
                        
            } else if ( preg_match( "/^2(014|149)\d{11}$/", $cardnum) ) {
            $type = 'EnRoute'; 

            /* JCB */
            
            } else if ( preg_match( "/^3\d{15}$/", $cardnum ) || 
            preg_match("/^(2131|1800)\d{11}$/", $cardnum)) {
            $type = 'JCB'; 
            
            /* Maestro */
            } else if ( preg_match( "/^(?:5020|6\\d{3})\\d{12}$/", $cardnum ) ) {
            $type = 'Maestro';     
            
            /* Visa Electron */
            
            } else if ( preg_match( "/^4(17500|917[0-9][0-9]|913[0-9][0-9]|508[0-9][0-9]|844[0-9][0-9])\d{10}$/", $cardnum ) ) {
            $type = 'Visa';
            
            /*Laser*/
            
            } else if ( preg_match( "/^(6304|670[69]|6771)[0-9]{12,15}$/", $cardnum ) ) {
            $type = 'Laser';
            
            /* Carte Blanche */
            
        }else if(preg_match("/^389[0-9]{11}$/", $cardnum)){
            $type = 'Carte';

            /* Dankort */
            
        }else if(preg_match("/^5019\d{12}$/", $cardnum)){
            $type = 'Dankort';
        
        }else{
                $type = '';
        } 
            
        
        return $type; 
    }

    public function get_surcharge( $params = array(), $method = 'GET' ){
	
		if($this->surcharge_manual === true ){

			return array( 'card' => (object) array(
										'type' =>  $this->surcharge_type,
										'value'=>  $this->surcharge_value
										)
								);

		} else {

			$response 	= $this->request_api($params,'surcharge', $method);

			$data 		= (array) $response['response_body'];		

			if( !empty($data) && $response[ 'response_code' ] == 200 ){

				return $data;

			}

		}
		
		
		
		return '';
	}

	public function custom_remove_specific_fee_from_order( $order_id ){

		if( $this->surcharge_card === false ){
			return; 
		}

		$order = wc_get_order( $order_id );

		if( $order->get_payment_method() !== $this->id ){
			return;
		}

		//$response 	= $this->get_surcharge();
		//$surcharge = !empty($response['card']) ? $response['card'] : null;

		$client = new WC_AcceptBlue_API_v2();    
        $surcharge = $client->get_surcharge_info();
		
		$surcharge_name     = $surcharge['name'];
        $surcharge_value    = (float) $surcharge['fee']['value'];
        $surcharge_type     = $surcharge['fee']['type'];

		// if ($surcharge && $surcharge->type == 'percent') {
		// 	$fee_label = sprintf(esc_html__("%s (%s", 'woocommerce'), $this->surcharge_label, $surcharge->value) . "%)";
		// } else {
		// 	$fee_label = esc_html__($this->surcharge_label, 'woocommerce');
		// }

		//$fee_label = $this->surcharge_label;
		$fee_label = $surcharge_name;

		// Get all order items (fees, products, etc.)
		foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
			// Check if the fee name matches the one you want to remove			
			if ( $item->get_name() === $fee_label ) {
				// Remove the fee from the order
				$order->remove_item( $item_id );
			}
		}

		// Recalculate totals after removing the fee
		$order->calculate_totals();
		$order->save();

	}

	public function add_custom_surcharge_fee(){

		if( $this->surcharge_card === false ){
			return; 
		}

		// Get the order total
		//$order_total = WC()->cart->get_subtotal();
		
		// Get subtotal of items in the cart (products only)
        $cart_subtotal = WC()->cart->get_cart_contents_total(); 

        // Get the total shipping cost
        $shipping_total = WC()->cart->get_shipping_total();

        // Get the total tax (including both item and shipping taxes)
        $tax_total = WC()->cart->get_taxes_total();

        // Get existing fees already added to the cart
        $fee_total = WC()->cart->get_fee_total();
        
        // Calculate the total (subtotal + taxes + shipping + fees)
        $order_total = $cart_subtotal + $shipping_total + $tax_total + $fee_total;

		//$response 	= $this->get_surcharge();
		//$surcharge = !empty($response['card']) ? $response['card'] : '';

		$client = new WC_AcceptBlue_API_v2();    
        $surcharge = $client->get_surcharge_info();
		
		$surcharge_name     = $surcharge['name'];
        $surcharge_value    = (float) $surcharge['fee']['value'];
        $surcharge_type     = $surcharge['fee']['type'];

		if($surcharge_type == 'percent' ){
			$fee_label = esc_html__( sprintf("%s (%s", $this->surcharge_label ,$surcharge_value) . "%)" );
			$percentage = $surcharge_value / 100; // 10%
			$fee_amount = $order_total * $percentage; 
		} else {
			$fee_label = esc_html__( $this->surcharge_label );
			$fee_amount = $surcharge_value; 
		}
		
		// Define the fee name
		$fee_name = $fee_label; // Fee name displayed to the customer
		
		
		//exit;
	
		// Prevent double add: Only add the fee if it doesn't already exist
		if ( ! is_admin() && is_checkout() ) {

			$fee_exists = false;
			foreach ( WC()->cart->get_fees() as $fee ) {
				if ( $fee->name === $fee_name ) {
					$fee_exists = true;
					break;
				}
			}
			if ( ! $fee_exists ) {				
				WC()->cart->add_fee( $fee_name, $fee_amount, false, '' );
			}
		}

	}

	

	// Get the surcharge settings
	public function surcharge_fee_to_order( $order, $data ) {

		if( $this->surcharge_card === false ){
			return; 
		}

		if( $order->get_payment_method() !== $this->id ){
			return;
		}

		// Get the order total
		$order_total = $order->get_total();

		//$response 	= $this->get_surcharge();
		//$surcharge = !empty($response['card']) ? $response['card'] : '';

		$client = new WC_AcceptBlue_API_v2();    
        $surcharge = $client->get_surcharge_info();

		$surcharge_name     = $surcharge['name'];
        $surcharge_value    = (float) $surcharge['fee']['value'];
        $surcharge_type     = $surcharge['fee']['type'];


		if($surcharge_type == 'percent' ){
			//$fee_label = esc_html__( sprintf("%s (%s", $this->surcharge_label, $surcharge->value) . "%)" );
			$percentage = $surcharge_value / 100; // 10%
			$fee_amount = $order_total * $percentage; 
		} else {			
			$fee_amount = $surcharge_value; 
		}

		$fee_label =  $this->surcharge_label;

		// Create a new fee item
		// Avoid double entry: Remove any existing fee with the same label before adding
		foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
			if ( $item->get_name() === $fee_label ) {
				$order->remove_item( $item_id );
			}
		}

		$item_fee = new WC_Order_Item_Fee();
		$item_fee->set_name( $fee_label ); // Set the fee name
		$item_fee->set_amount( $fee_amount ); // Set the fee amount
		$item_fee->set_tax_class( '' ); // Set the tax class (empty for no tax)
		$item_fee->set_tax_status( 'none' ); // Tax status ('none', 'taxable')
		$item_fee->set_total( $fee_amount ); // Total fee
		$item_fee->set_order_id( $order->get_id() ); // Associate item with order before saving

		// Save the item first via the modern OOP path to avoid triggering the legacy
		// wc_add_order_item() code path, which fires the deprecated
		// 'woocommerce_add_order_item_meta' hook (deprecated since WooCommerce 3.0).
		$item_fee->save();

		// Add the fee to the order (item already persisted above)
		$order->add_item( $item_fee );

		// Recalculate totals to account for the new fee
		$order->calculate_totals();
		$order->save();

		return $order;
	}


    public function tokenization_receipt_page($order_id) {

        $order = wc_get_order($order_id);

		// Debug: Break down the order total

        if ( $this->testmode === true ){

			$cards_text  = '';
			$cards_text .=  esc_html__( 'TEST MODE/SANDBOX ENABLED', 'woocommerce');
            $cards_text .= '<br>';
			

			if($this->threeds === true ){

				$cards_text .= '<br>' . esc_html__( '3DS TEST CARDS' , 'woocommerce' );
				$cards_text .= '<br>' . esc_html__( 'Visa - 4012000033330026' , 'woocommerce' );
            	$cards_text .= '<br>' . esc_html__( 'MasterCard - 5100060000000002' , 'woocommerce' );

			} else {

				$cards_text .= '<br>' . esc_html__( 'TEST CARDS' , 'woocommerce' );
				$cards_text .= '<br>' . esc_html__( 'Visa - 4761530001111118' , 'woocommerce' );
            	$cards_text .= '<br>' . esc_html__( 'Discover - 6011208701117775' , 'woocommerce' );

			}	

			
            $cards_text .= '<br><br>';			

			echo wp_kses_post($cards_text);
		}

        ?>
        <?php // Note: The CDN tokenization script is enqueued via tokenization_script() using
              // wp_enqueue_script() to prevent "window.HostedTokenization is already defined" errors.
              // Do NOT add an inline <script src> here as it would bypass WordPress deduplication. ?>

        <div id="acceptblue-ht-error-message"></div>

		<?php
		// ── Saved token selection (logged-in users only) ──────────────────────
		if ( is_user_logged_in() && ! $this->save_card_token_disable ) :
			$saved_tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
			// Filter out empty / sentinel tokens
			$saved_tokens = array_filter( $saved_tokens, function( $t ) {
				$raw = $t->get_token();
				return ! empty( $raw ) && $raw !== 'tkn-';
			} );
		endif;

		if ( ! empty( $saved_tokens ) ) :
		?>
		<div class="ab-ht-saved-tokens">
			<p class="ab-ht-saved-tokens__label"><?php esc_html_e( 'Saved payment methods', 'woocommerce' ); ?></p>
			<ul class="ab-ht-token-list">
			<?php foreach ( $saved_tokens as $tok ) :
				$type  = ucfirst( $tok->get_card_type() ?: 'Card' );
				$last4 = $tok->get_last4();
				$exp   = $tok->get_expiry_month() . '/' . substr( $tok->get_expiry_year(), -2 );
			?>
			<li class="ab-ht-token-item<?php echo $tok->is_default() ? ' ab-ht-token-item--default' : ''; ?>">
				<label class="ab-ht-token-label">
					<input type="radio"
					       class="ab-ht-token-radio"
					       name="ab-ht-selected-token"
					       value="<?php echo esc_attr( $tok->get_id() ); ?>"
					       <?php checked( $tok->is_default() ); ?>
					/>
					<span class="ab-ht-token-card-icon ab-ht-token-card-icon--<?php echo esc_attr( strtolower( $tok->get_card_type() ?: 'card' ) ); ?>"></span>
					<span class="ab-ht-token-card-info">
						<strong><?php echo esc_html( $type ); ?></strong>
						&bull;&bull;&bull;&bull; <?php echo esc_html( $last4 ); ?>
						<span class="ab-ht-token-exp"><?php echo esc_html( $exp ); ?></span>
					</span>
				</label>
			</li>
			<?php endforeach; ?>
			<li class="ab-ht-token-item ab-ht-token-new">
				<label class="ab-ht-token-label">
					<input type="radio" class="ab-ht-token-radio" name="ab-ht-selected-token" value="new" />
					<span class="ab-ht-token-card-icon ab-ht-token-card-icon--new"></span>
					<span class="ab-ht-token-card-info"><?php esc_html_e( 'Use a new card', 'woocommerce' ); ?></span>
				</label>
			</li>
			</ul>
		</div>
		<?php endif; ?>

        <p class="ab-ht-new-card-label">
			<?php echo esc_html__( 'Enter your credit card details below to complete the payment.', 'woocommerce' ); ?>
		</p>

		<?php
		// Surcharge notice on order-pay page — show fee amount based on order total
		if ( $this->surcharge_card === true && $this->surcharge_checkout === true ) {
			$_ab_notice_client  = new WC_AcceptBlue_API_v2();
			$_ab_notice_enabled = $_ab_notice_client->is_surcharge_enabled();
			if ( ! empty( $_ab_notice_enabled['code'] ) && $_ab_notice_enabled['code'] !== false ) {
				$_ab_surcharge = $_ab_notice_client->get_surcharge_info();
				if ( ! empty( $_ab_surcharge['fee']['value'] ) ) {
					$_ab_sv    = (float) $_ab_surcharge['fee']['value'];
					$_ab_stype = $_ab_surcharge['fee']['type'];
					$_ab_sname = ! empty( $_ab_surcharge['name'] ) ? $_ab_surcharge['name'] : $this->surcharge_label;
					// Use order total minus surcharge fee (handles fee-only orders where subtotal = 0)
					$_ab_subtotal = (float) self::get_order_total_excluding_surcharge( $order );
					if ( $_ab_subtotal > 0 ) {
						$_ab_fee = ( $_ab_stype === 'percent' )
							? round( $_ab_subtotal * ( $_ab_sv / 100 ), 2 )
							: $_ab_sv;
						if ( $_ab_fee > 0 ) {
							$_ab_extra = ( $_ab_stype === 'percent' ) ? ' (' . $_ab_sv . '%)' : '';
							printf(
								'<div class="ab-surcharge-notice">
									<span class="ab-surcharge-notice__icon" aria-hidden="true">&#x2139;</span>
									<span class="ab-surcharge-notice__text">%s</span>
								</div>',
								wp_kses_post( sprintf(
									__( 'A <span class="ab-surcharge-notice__amount">%1$s</span> <strong>%2$s%3$s</strong> will be applied at checkout.', 'woocommerce' ),
									wc_price( $_ab_fee ),
									esc_html( $_ab_sname ),
									esc_html( $_ab_extra )
								) )
							);
						}
					}
				}
			}
		}
		?>

        <input type="hidden" id="acceptblue-ht-order-key" name="acceptblue-ht-order-key" value="<?php echo esc_js($order->get_order_key());?>"/>
		<?php
			// Compute the pre-surcharge amount for verify3DS().
			//
			// Use order total minus the surcharge fee line item.
			// The "subtotal + shipping + tax" approach fails for fee-only orders
			// (e.g. $0 subtotal + $20 fee) where subtotal = 0, producing amount = 0
			// which causes 3DS verify to fail with a CAVV mismatch.
			// get_order_total_excluding_surcharge() starts from the real order total
			// and subtracts only the surcharge fee by label match.
			// For $0 trial subscription orders, substitute 0.01 to match the
			// $0.01 auth-and-void the API flow sends — passing 0 causes a CAVV mismatch.
			$_ab_ht_raw_amount    = (float) self::get_order_total_excluding_surcharge( $order );
			$_ab_ht_order_amount  = self::get_threeds_amount( $_ab_ht_raw_amount, $order->get_id() );
			// Pass is_trial flag so JS can enforce 0.01 even if the value reads correctly.
			$_ab_ht_is_trial = ( $_ab_ht_order_amount >= 0.01 && $_ab_ht_raw_amount < 0.01 ) ? '1' : '0';
		?>
		<input type="hidden" id="acceptblue-ht-order-amount" name="acceptblue-ht-order-amount"
		       value="<?php echo esc_js( $_ab_ht_order_amount ); ?>"
		       data-is-trial="<?php echo esc_attr( $_ab_ht_is_trial ); ?>"/>

		<?php
			// Name on card
			if( $this->name_on_card === true ) :
			?>
			<div class="ab-ht-field">
				<label class="ab-ht-field__label" for="<?php echo esc_attr( $this->id . '-card-name' ); ?>">
					<?php echo esc_html( $this->name_on_card_label ?: __( 'Name on card', 'woocommerce' ) ); ?>
					<?php if ( $this->name_on_card_required ) : ?><span style="color:var(--ab-ht-error,#cc1818);margin-left:2px;" aria-hidden="true">*</span><?php endif; ?>
				</label>
				<input type="text"
				       id="<?php echo esc_attr( $this->id . '-card-name' ); ?>"
				       name="<?php echo esc_attr( $this->id . '-card-name' ); ?>"
				       placeholder="<?php echo esc_attr( $this->name_on_card_label ?: __( 'Name on card', 'woocommerce' ) ); ?>"
				       value=""
				       class="acceptblue-ht-input"
				       autocomplete="cc-name"
				       <?php if ( $this->name_on_card_required ) echo 'required aria-required="true"'; ?>
				/>
			</div>
			<?php else : ?>
				<input type="hidden"
				       id="<?php echo esc_attr( $this->id . '-card-name' ); ?>"
				       name="<?php echo esc_attr( $this->id . '-card-name' ); ?>"
				       value=""
				/>
			<?php endif; ?>

        <div id="acceptblue-ht-iframe-container"></div>

		<?php if ( is_user_logged_in() && ! $this->save_card_token_disable && ! $this->force_save_card_token ) : ?>
		<div class="acceptbluev2-save-card-row ab-ht-save-card-row" style="margin: 12px 0;">
			<label class="acceptbluev2-save-card-label">
				<input type="checkbox" id="acceptbluev2-ht-save-card" name="acceptbluev2-ht-save-card" value="1"/>
				<?php echo esc_html( $this->save_card_label ); ?>
			</label>
		</div>
		<?php endif; ?>

        <div>
            <button type="button" id="acceptblue-ht-charge"><?php echo esc_html__( 'Place Order', 'woocommerce' ); ?></button>
        </div>
		<div id="acceptblue-hosted-token-ajax-loader" style="display:none"></div>

		

        <?php

			echo '<script type="text/javascript">';
			echo 'const acceptblue_order_email = "' . esc_js($order->get_billing_email()) . '";'; // Use json_encode for safe output
			//echo 'console.log("Order email:", acceptblue_order_email);'; // Example: log to console
			echo '</script>';

    }

    public function local_script(){	

		// Guard: only register and localize once per page load.
		// wp_localize_script() appends a new inline <script> every time it is called
		// on the same handle — if local_script() is called twice (e.g. from both
		// enqueue_tokenization_checkout and enqueue_global_params), the second
		// var acceptblue_hosted_token_params = {...} overwrites the first and may
		// produce an empty pk_hosted_token because the Google Pay merge hasn't run yet.
		static $localized = false;
		if ( $localized ) {
			// Script already registered + localized — just ensure it is enqueued.
			wp_enqueue_script( 'acceptblue-v2-js' );
			return;
		}
		$localized = true;

        // Register the script

		wp_register_script( 'acceptblue-v2-js', plugins_url( 'assets/js/dist/acceptblue-hosted-token-local-script.min.js', dirname(__FILE__) ), array( 'jquery' ), AB_V2_VERSION, true );
	
        // Localize the script with new data
		// Build saved tokens list for logged-in users on the order-pay page
		$ht_saved_tokens = array();
		if ( is_user_logged_in() && ! $this->save_card_token_disable ) {
			$customer_tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->id );
			foreach ( $customer_tokens as $tok ) {
				$raw = $tok->get_token();
				if ( empty( $raw ) || $raw === 'tkn-' ) continue;
				$ht_saved_tokens[] = array(
					'id'           => $tok->get_id(),
					'card_type'    => $tok->get_card_type(),
					'last4'        => $tok->get_last4(),
					'expiry_month' => $tok->get_expiry_month(),
					'expiry_year'  => $tok->get_expiry_year(),
					'is_default'   => $tok->is_default(),
				);
			}
		}

		$translation_array = array(
			'pk_hosted_token' 	        => $this->public_key,
			'pk_threeds_key' 	        => $this->threeds_key,
			'frictionless'              => (bool) $this->frictionless,
			'site_url'                  => get_site_url(),
			'ajax_url' 					=> admin_url('admin-ajax.php'),
        	'nonce'    					=> wp_create_nonce( 'acceptblue-ajax-nonce' ),
			'is_user_logged_in' 		=> (bool) is_user_logged_in() === true ? true : false,
			'sandbox'					=> (bool) $this->testmode === true ? true : false,
			'threeDS'					=> (bool) $this->threeds === true ? true : false,
			'block_checkout'             =>  (bool) $this->block_support_checkout === true ? true : false,
			'form_color_scheme'          => $this->form_color_scheme,
			'custom_color_bg'            => $this->custom_color_bg,
			'custom_color_text'          => $this->custom_color_text,
			'custom_color_border'        => $this->custom_color_border,
			'saved_tokens'               => $ht_saved_tokens,
			'save_card_label'            => $this->save_card_label,
			'force_save_card'            => (bool) $this->force_save_card_token,
			'save_card_enabled'          => is_user_logged_in() && ! $this->save_card_token_disable,
			'is_add_payment_method'      => ( function_exists( 'is_add_payment_method_page' ) && is_add_payment_method_page() ) ? 1 : 0,
		);

        
        if ( $this->google_pay_is_enabled() === true ) {
            // Google Pay localized params are now built by WC_AcceptBlue_Google_Pay_Actions
            // which fixes: countryCode missing, billingAddressParameters always sent,
            // merchant ID silent mutation, and guest billing override.
            if ( class_exists( 'WC_AcceptBlue_Google_Pay_Actions' ) ) {
                $is_logged_in  = is_user_logged_in();
                // For guests, always require billing (Google Pay needs a contact)
                $force_billing = ! $is_logged_in;
                $gpay_actions  = new WC_AcceptBlue_Google_Pay_Actions( $this );
                $google_pay_translation_array = $gpay_actions->get_localized_params( $is_logged_in, $force_billing );
                $translation_array = array_merge( $translation_array, $google_pay_translation_array );
            }
        }

		wp_localize_script( 'acceptblue-v2-js', 'acceptblue_hosted_token_params', $translation_array );

		// Enqueued script with localized data.
		wp_enqueue_script( 'acceptblue-v2-js' );

    }

    public function tokenization_script(){

        if( $this->is_enabled() === false ) return;

		if($this->tokenization === false) return;

		
		//wp_enqueue_script( 'acceptblue-gateway-hosted-token', plugins_url( 'assets/js/dist/acceptblue-hosted-token-iframe.min.js', dirname(__FILE__) ), array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ), WC_VERSION, true );			
		// Enqueue using the canonical handle registered in register_acceptblue_hosted_sdk().
		// Never pass a URL here — passing a URL with a different handle loads a second copy
		// of the CDN script, causing "window.HostedTokenization is already defined".
		wp_enqueue_script( 'acceptblue-hosted-sdk' );

       // $this->local_script();

        // Resolve correct iframe JS once; reused for both order-pay and add-payment-method.
		$needs_addons_js = class_exists( 'WC_Subscriptions_Order' ) || class_exists( 'WC_Pre_Orders_Order' );
		if ( $this->threeds === true ) {
			$iframe_js_file = $needs_addons_js
				? 'acceptblue-hosted-token-iframe-addons-3ds.min.js'
				: 'acceptblue-hosted-token-iframe-3ds.min.js';
		} else {
			$iframe_js_file = $needs_addons_js
				? 'acceptblue-hosted-token-iframe-addons.min.js'
				: 'acceptblue-hosted-token-iframe.min.js';
		}

        if( is_checkout_pay_page() === true && absint( get_query_var( 'order-pay' ) ) > 0){
			add_action('wp_enqueue_scripts', array( $this, 'acceptblue_ht_enqueue_dashicons' ) );
			wp_enqueue_script( 'acceptblue-gateway-hosted-token', plugins_url( 'assets/js/dist/' . $iframe_js_file, dirname(__FILE__) ), array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ), AB_V2_VERSION, true );
			wp_enqueue_style( 'acceptblue-gateway-hosted-token-css', plugins_url( 'assets/css/dist/acceptblue-hosted-token-iframe.min.css', dirname(__FILE__) ) );
        }

		// Add Payment Method page — hosted tokenization iframe JS must load here too.
		// Without this, acceptblue-hosted-sdk (Paay CDN) loads but nothing calls
		// new HostedTokenization() so the card fields never appear.
		if ( function_exists( 'is_add_payment_method_page' ) && is_add_payment_method_page() ) {
			wp_enqueue_script( 'acceptblue-gateway-hosted-token', plugins_url( 'assets/js/dist/' . $iframe_js_file, dirname(__FILE__) ), array( 'jquery', 'wc-credit-card-form', 'acceptblue-v2-js' ), AB_V2_VERSION, true );
			wp_enqueue_style( 'acceptblue-gateway-hosted-token-css', plugins_url( 'assets/css/dist/acceptblue-hosted-token-iframe.min.css', dirname(__FILE__) ) );
		}
        
	}

	/**
	 * Enqueue the hosted iframe JS + CSS on the Add Payment Method page.
	 *
	 * This runs unconditionally (not gated by tokenization mode) so that
	 * block_support_checkout=true + tokenization=false still gets the SDK
	 * and the order-pay iframe JS needed to mount HostedTokenization.
	 */
	public function add_payment_method_script() {

		if ( $this->is_enabled() === false ) return;
		if ( ! function_exists( 'is_add_payment_method_page' ) ) return;
		if ( ! is_add_payment_method_page() ) return;

		// On the add-payment-method page, mode properties (tokenization,
		// block_support_checkout, threeds) are forced to false in __construct(),
		// so script() already enqueues acceptblue-checkout-form.min.js (Classic Non-3DS).
		// We only need local_script() here to ensure acceptblue_hosted_token_params
		// is localized (it provides form_color_scheme, sandbox flag, etc. to the JS).
		$this->local_script();
	}

	public function acceptblue_ht_enqueue_dashicons() {
		wp_enqueue_style('dashicons');
	}

     //* Callback Hosted Token Ajax Server

    public function ht_place_order_charge(){

        if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {


            $order_key = !empty($_POST['order_key']) ? wc_clean($_POST['order_key']) : '';

			if (!empty($order_key)) {
				$order_id = wc_get_order_id_by_order_key($order_key);
			} 

			if (empty($order_id)) {
				wp_send_json_error( esc_html__( 'No order found.', 'woocommerce' ) );
			}

            $saved_token_id     = ! empty( $_POST['saved_token_id'] ) ? absint( $_POST['saved_token_id'] ) : 0;
            $hosted_token_nonce = ! empty( $_POST['hosted_token_nonce'] ) ? wc_clean( $_POST['hosted_token_nonce'] ) : '';

			// One of saved_token_id or hosted_token_nonce must be present
            if ( empty( $hosted_token_nonce ) && empty( $saved_token_id ) ) {
				wp_send_json_error( esc_html__( 'No payment token found.', 'woocommerce' ) );
			}

			// ── Saved token fast path ─────────────────────────────────────────
			// When the customer selects a previously saved card, charge it directly
			// using its tkn- source without going through HostedTokenization.
			if ( $saved_token_id > 0 && empty( $hosted_token_nonce ) ) {
				$wc_token = WC_Payment_Tokens::get( $saved_token_id );

				// Security: token must belong to this user and this gateway
				if (
					! $wc_token ||
					$wc_token->get_gateway_id() !== $this->id ||
					( is_user_logged_in() && $wc_token->get_user_id() !== get_current_user_id() )
				) {
					wp_send_json_error( esc_html__( 'Invalid payment token.', 'woocommerce' ) );
				}

				$raw_token = $wc_token->get_token();
				if ( empty( $raw_token ) || $raw_token === 'tkn-' ) {
					wp_send_json_error( esc_html__( 'Saved card reference is invalid.', 'woocommerce' ) );
				}

				$name_on_card = ! empty( $_POST['card_name'] ) ? wc_clean( $_POST['card_name'] ) : '';
				if ( $this->name_on_card_required && empty( $name_on_card ) && $this->name_on_card ) {
					wp_send_json_error( esc_html__( 'Name on card is required.', 'woocommerce' ) );
				}

				// Remove old surcharge and get fresh order
				$this->custom_remove_specific_fee_from_order( $order_id );
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					wp_send_json_error( esc_html__( 'Invalid order.', 'woocommerce' ) );
				}
				if ( ! empty( $order->get_transaction_id() ) ) {
					wp_send_json_error( esc_html__( 'The order has been processed.', 'woocommerce' ) );
				}
				if ( $order->get_currency() !== 'USD' ) {
					wp_send_json_error( esc_html__( 'Transaction amount should be in USD.', 'woocommerce' ) );
				}

				$billing_info  = array(
					'first_name' => $order->get_billing_first_name(),
					'last_name'  => $order->get_billing_last_name(),
					'street'     => $order->get_billing_address_1(),
					'street2'    => $order->get_billing_address_2(),
					'city'       => $order->get_billing_city(),
					'state'      => $order->get_billing_state(),
					'zip'        => $order->get_billing_postcode(),
					'country'    => $order->get_billing_country(),
					'phone'      => $order->get_billing_phone(),
				);
				$shipping_info = array(
					'first_name' => $order->get_shipping_first_name(),
					'last_name'  => $order->get_shipping_last_name(),
					'street'     => $order->get_shipping_address_1(),
					'street2'    => $order->get_shipping_address_2(),
					'city'       => $order->get_shipping_city(),
					'state'      => $order->get_shipping_state(),
					'zip'        => $order->get_shipping_postcode(),
					'country'    => $order->get_shipping_country(),
					'phone'      => $order->get_billing_phone(),
				);
				$transaction_details = array(
					'description'    => sprintf( '%s - ORDER No. #%s', ucwords( get_bloginfo('name') ), $order->get_order_number() ),
					'client_ip'      => $this->get_client_ip( $order ),
					'order_number'   => $order->get_order_number(),
					'invoice_number' => $order->get_order_number(),
					'terminal'       => $order->get_payment_method_title(),
				);

				$this->surcharge_fee_to_order( $order, '' );

				// Trial detection: use the _acceptblue_ht_trial meta flag stored at process_payment time.
				// This is 100% reliable — no WCS function dependency needed.
				$_ht_sc_is_trial = ( $order->get_meta( '_acceptblue_ht_trial' ) === '1' );
				$_ht_sc_amount   = $_ht_sc_is_trial ? 0.01 : (float) $order->get_total();

				$params = array(
					'amount'              => $_ht_sc_amount,
					'source'              => $raw_token,
					'expiry_month'        => (int) $wc_token->get_expiry_month(),
					'expiry_year'         => (int) $wc_token->get_expiry_year(),
					'billing_info'        => $billing_info,
					'shipping_info'       => $shipping_info,
					'avs_zip'             => $order->get_billing_postcode(),
					'avs_address'         => trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() ),
					'transaction_details' => $transaction_details,
					'amount_details'      => array( 'tax' => 0.0, 'shipping' => 0.0, 'discount' => 0.0 ),
					'capture'             => $_ht_sc_is_trial ? false : (bool) $this->force_capture,
					'save_card'           => false,
					'name'                => $name_on_card,
				);

				$level3 = (array) $this->level3_data_line_items( $order->get_id() );
				$params = array_merge( $params, $level3 );

				$result = $this->request_api( $params, 'transactions/charge', 'POST' );

				if ( $result['response_code'] == 200 && $result['response_message'] === 'OK' && ! empty( $result['response_body'] ) ) {
					$defaults = array();
					$data     = wp_parse_args( (array) $result['response_body'], $defaults );

					if ( $data['status'] === 'Approved' ) {

						// Trial: void the $0.01 auth immediately
						if ( $_ht_sc_is_trial ) {
							$ref_num = sanitize_text_field( $data['reference_number'] ?? '' );
							if ( $ref_num ) {
								$this->request_api(
									array( 'reference_number' => (int) $ref_num ),
									'transactions/reversal',
									'POST'
								);
							}
							$order->payment_complete( $ref_num );
							$order->update_meta_data( '_' . $this->id . '_refnum', $ref_num );
							$order->add_order_note( sprintf(
								__( '%s Trial — card verified via $0.01 auth (Ref: %s, auth voided). Future renewals charged normally.', 'woocommerce' ),
								$this->method_title, $ref_num
							) );
							$order->save();
							WC()->cart->empty_cart();
							wp_send_json_success( $order->get_checkout_order_received_url() );
							wp_die();
						}

						if ( $this->default_status === 'default' ) {
							$order->payment_complete( sanitize_text_field( $data['reference_number'] ) );
						} else {
							$order->set_transaction_id( sanitize_text_field( $data['reference_number'] ) );
							$order->update_status( $this->default_status );
						}
						$order->update_meta_data( '_' . $this->id . '_refnum', sanitize_text_field( $data['reference_number'] ) );

						// Store authorized amount for Adjust & Capture total-change detection.
						if ( ! (bool) $this->force_capture ) {
							$auth_amount_sc = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : 0;
							if ( $auth_amount_sc > 0 ) {
								$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_sc );
							}
						}

						$order->add_order_note( sprintf(
							"%s Payment Completed (saved card) — Txn ID '%s'",
							$this->method_title,
							sanitize_text_field( $data['reference_number'] )
						) );
						$order->save();
						WC()->cart->empty_cart();
						WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
						wp_send_json_success( $order->get_checkout_order_received_url() );
					} else {
						$err = ! empty( $data['error_message'] ) ? $data['error_message'] : ( $data['status'] ?? 'Declined' );
						$order->update_status( 'failed' );
						$order->add_order_note( sprintf( "%s Payment Failed (saved card): '%s'", $this->method_title, esc_html( $err ) ) );
						$order->save();
						wp_send_json_error( esc_html( $err ) );
					}
				} else {
					$msg = ! empty( $result['response_message'] ) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'ht_place_order_charge (saved token) API error: ' . $msg, 'error' );
					wp_send_json_error( esc_html( wc_clean( $msg ) ) );
				}

				wp_die();
			} // end saved token path

                     

            $expiry_month = !empty($_POST[ 'expiry_month' ]) ? wc_clean($_POST[ 'expiry_month' ]) : '';
            $expiry_year = !empty($_POST[ 'expiry_year' ]) ? wc_clean($_POST[ 'expiry_year' ]) : '';
			$name_on_card = !empty($_POST[ 'card_name' ]) ? wc_clean($_POST[ 'card_name' ]) : '';
			// Save card: force_save_card_token overrides; otherwise read checkbox value from POST.
			$save_card_ht = $this->force_save_card_token
				? true
				: ( isset( $_POST['save_card'] ) && $_POST['save_card'] === '1' );

			if( $this->name_on_card_required === true && empty($name_on_card) && $this->name_on_card === true ){
				wp_send_json_error( esc_html__( 'Name on card is required.', 'woocommerce' ) );
			}

            // Remove surcharge from the order!
		    $this->custom_remove_specific_fee_from_order( $order_id );

			// Get the order object
			$order = wc_get_order($order_id);

           

			if (!$order) {				
				wp_send_json_error( esc_html__( 'Invalid order ID or key', 'woocommerce' ) );
			} else {

				$status 		= $order->get_status();
				$transaction_id = $order->get_transaction_id();

				//* validate the if transaction id is already exist
				if(!empty($transaction_id)){
					//wp_send_json_success($order->get_checkout_order_received_url());
					wp_send_json_error( esc_html__( "The order has been processed.", "woocommerce" ) );
				}

				// $payment_token 					= $order->get_meta( 'payment_token' );

				// if(empty($payment_token)) {
				// 	wp_send_json_error( esc_html__( "Invalid, Payment Token.", "woocommerce" ) );
				// }


				$woo_currency 					= $order->get_currency();

				if($woo_currency != "USD" ) {
					wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD.", "woocommerce" ) );
				}

				//$currency_code 					= self::get_currency_code($woo_currency);
				$woo_get_total 					= $order->get_total();
				$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
				$avs_zip  						= $order->get_billing_postcode();

				// For trial subscription orders ($0 total), the API requires amount >= 0.01.
				// Run a $0.01 auth-and-void to validate the card and capture the token,
				// Trial detection: use the _acceptblue_ht_trial meta flag stored at process_payment time.
				// This is 100% reliable — no WCS function dependency needed.
				$_ht_is_trial_order = ( $order->get_meta( '_acceptblue_ht_trial' ) === '1' );
				$charge_amount      = $_ht_is_trial_order ? 0.01 : (double) $woo_get_total;

				//$amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
				//$amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
				//$amount_details[ "discount" ] 	= (double) $order->get_discount_total();

                $amount_details[ "tax" ] 		= (double) "0";
				$amount_details[ "shipping" ] 	= (double) "0";
				$amount_details[ "discount" ] 	= (double) "0";

				//* Transaction details

				$transaction_details = array();
				$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
				$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
				$transaction_details[ "order_number" ] 	= $order->get_order_number();
				$transaction_details[ "invoice_number" ] = $order->get_order_number();
				$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

				//* Billing Address Fields

				$billing_info = array();

				$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
				$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
				$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
				$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
				$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
				$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
				$billing_info[ "zip" ] 			= $order->get_billing_postcode();
				$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
				$billing_info[ "phone" ] 		= $order->get_billing_phone();						
				
				//* Shipping Address Fields

				$shipping_info = array();

				$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
				$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
				$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
				$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
				$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
				$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
				$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
				$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
				$shipping_info[ "phone" ] 		= $order->get_billing_phone();

                if($this->is_enabled() === false){ 
                    wp_send_json_error( esc_html__( 'Payment Gateway is Disabled!', 'woocommerce' ) );
                }                

				$threed_secure = ! empty( $_POST['threed_secure'] ) ? wp_unslash( $_POST['threed_secure'] ) : '';

				if($threed_secure){

					if( $this->frictionless === true ){

						$params = array(
							"amount" 		=> $charge_amount,
							"source" 		=> "nonce-" . $hosted_token_nonce,
							"billing_info" 	=> $billing_info,
							"shipping_info" => $shipping_info,						
							"avs_zip" 		=> $avs_zip,
							"avs_address" 	=> $avs_address,
							"transaction_details" => $transaction_details,
							"amount_details" => $amount_details,
							"expiry_month"   => (int) $expiry_month,
							"expiry_year"    => (int) $expiry_year,
							"capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
							"save_card"      => (bool) $save_card_ht,							
							"name"			=> $name_on_card
						);

						
					} else {

						$raw_eci      = isset( $threed_secure['eci'] )         ? wp_unslash( $threed_secure['eci'] )         : '';
						$raw_cavv     = isset( $threed_secure['cavv'] )        ? wp_unslash( $threed_secure['cavv'] )        : '';
						$raw_trans_id = isset( $threed_secure['ds_trans_id'] ) ? wp_unslash( $threed_secure['ds_trans_id'] ) : '';

						if ( ! empty( $raw_eci ) && ! empty( $raw_cavv ) && ! empty( $raw_trans_id ) ) {

							$params = array(
								"amount" 		=> $charge_amount,
								"source" 		=> "nonce-" . $hosted_token_nonce,
								"billing_info" 	=> $billing_info,
								"shipping_info" => $shipping_info,						
								"avs_zip" 		=> $avs_zip,
								"avs_address" 	=> $avs_address,
								"transaction_details" => $transaction_details,
								"amount_details" => $amount_details,
								"expiry_month"   => (int) $expiry_month,
								"expiry_year"    => (int) $expiry_year,
								"capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
								"save_card"      => (bool) $save_card_ht,
								"3d_secure" => array(
									"eci"        => str_pad( (string) $raw_eci, 2, '0', STR_PAD_LEFT ),
									"cavv"       => (string) $raw_cavv,
									"ds_trans_id"=> (string) $raw_trans_id,
								),
								"name" => $name_on_card
							);

						} else {

							self::log(
								'Classic 3DS: missing 3d_secure fields — eci=' . var_export( $raw_eci, true )
								. ' cavv=' . ( empty( $raw_cavv ) ? 'EMPTY' : 'present' )
								. ' ds_trans_id=' . var_export( $raw_trans_id, true ),
								'error'
							);

							wp_send_json_error( esc_html__( '3D Secure data missing. Please try again.', 'woocommerce' ) );
							return;

						}
						

					}

					

				} else {

					$params = array(
						"amount" 		=> $charge_amount,
						"source" 		=> "nonce-" . $hosted_token_nonce,
						"billing_info" 	=> $billing_info,
						"shipping_info" => $shipping_info,						
						"avs_zip" 		=> $avs_zip,
						"avs_address" 	=> $avs_address,
						"transaction_details" => $transaction_details,
						"amount_details" => $amount_details,
						"expiry_month"   => (int) $expiry_month,
						"expiry_year"    => (int) $expiry_year,
						"capture"        => $_ht_is_trial_order ? false : (bool) $this->force_capture,
						"save_card"      => (bool) $save_card_ht,
						"name"			 => $name_on_card
					);

				}

				$level3_line_items = (array) $this->level3_data_line_items( $order->get_id() );
				$params = array_merge($params, $level3_line_items);				

                //Surcharge add into order details
		        $this->surcharge_fee_to_order($order, '' );
				
				//* Execute the payments					                
                $result = $this->request_api($params, 'transactions/charge', 'POST');

				if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
					$defaults = array();
				$data     = wp_parse_args( (array) $result['response_body'], $defaults );
					
					if( $data[ 'status' ] == 'Approved' ){

						// Trial subscription: immediately void the $0.01 auth so nothing settles.
						if ( $_ht_is_trial_order ) {
							$ref_num = sanitize_text_field( $data['reference_number'] ?? '' );
							if ( $ref_num ) {
								$this->request_api(
									array( 'reference_number' => (int) $ref_num ),
									'transactions/reversal',
									'POST'
								);
							}
							$order->payment_complete( $ref_num );
							$order->update_meta_data( '_' . $this->id . '_refnum', $ref_num );
							$order->add_order_note( sprintf(
								__( '%s Trial — card verified via $0.01 auth (Ref: %s, auth voided). Future renewals charged normally.', 'woocommerce' ),
								$this->method_title, $ref_num
							) );
							$order->save();
							wp_send_json_success( $order->get_checkout_order_received_url() );
							return;
						}

                        $order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );

                        if( $this->default_status == 'default' ){
    
                            // Mark as complete or processing based on virtual order or not
							$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
                            
                        } else {
							$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );	
                            $order->update_status( $this->default_status );
                        }
						
						$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );

						// Store authorized amount for Adjust & Capture total-change detection.
						if ( ! (bool) $this->force_capture ) {
							$auth_amount_ht = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) $woo_get_total;
							if ( $auth_amount_ht > 0 ) {
								$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_ht );
							}
						}

						$order->save();

						$order->add_order_note(
							esc_html__( sprintf(
								"%s Payment Completed with Transaction Id of '%s'",
								$this->method_title,
								sanitize_text_field($data[ 'reference_number' ])
							), 'woocommerce' )
						);

						// Save WC payment token when user opted in (or force-save is on)
						if ( $save_card_ht && is_user_logged_in() ) {
							$card_ref = sanitize_text_field( $data['card_ref'] ?? '' );
							if ( ! empty( $card_ref ) ) {
								$card_token_arr = array(
									'token'            => 'tkn-' . $card_ref,
									'card_type'        => sanitize_text_field( $data['card_type'] ?? '' ),
									'set_last4'        => sanitize_text_field( $data['last_4'] ?? '' ),
									'set_expiry_month' => absint( $expiry_month ),
									'set_expiry_year'  => absint( $expiry_year ),
								);
								$this->save_token( $card_token_arr );
							}
						}

						WC()->cart->empty_cart();
							WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
							wp_send_json_success($order->get_checkout_order_received_url());
					} else {

						wp_send_json_error( esc_html__( $data[ 'error_message' ], 'woocommerce' ) );
					}
				
				} else{

					$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
					wp_send_json_error( esc_html__( wc_clean($message), 'woocommerce' ) );
				}


			} 
                

        }

        wp_die();

    }

    //* Google pay integrtion

    //* process checkout page ajax request

	public function acceptblue_woocommerce_ajax_script_process_checkout_page_charge(){
			
		
		if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {

			$payment_token 	= !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
			$product_id 	= !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
			$billing_address = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
			$email_address 	= !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
			$googlepay_amount = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';

			if(!empty($payment_token)){
					
					$payment_token = base64_decode($payment_token);
					
					if(!WC()->cart->is_empty()){

						$woo_get_total = (float) WC()->cart->get_total( 'edit' );						

						$order_id = WC()->session->get('order_awaiting_payment');

						if ($order_id) {

								if ( is_user_logged_in() ) {
									$user_id = get_current_user_id();								
									if($user_id > 0 ){
										$this->process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount );
									} else {
										$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount  );
									}
								} else {
									$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount );
								}
						

						} else {

							$order = wc_create_order();
							$order_id = $order->get_id();

							// Optionally, add items to the order
							foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
								$order->add_product( $values['data'], $values['quantity'] ); // Add product to order
							}

							// Calculate totals and save
							$order->calculate_totals();
							$order->save();

							if ( is_user_logged_in() ) {
								$user_id = get_current_user_id();
								//echo 'User ID is: ' . $user_id;
								if($user_id > 0 ){
									$this->process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount );
								} else {
									$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount  );
								}
							} else {
								$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount );
							}
							
							
						}

					} else {
						wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
					}


			} else {
				wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
			}

		}
			
		wp_die();

	}

	//* process cart page ajax request

	public function acceptblue_woocommerce_ajax_script_process_cart_page_charge(){			
		
		if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {

			$payment_token = !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
			$product_id = !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
			$billing_address = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
			$email_address = !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
			$googlepay_amount = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';			

			if(!empty($payment_token)){
					
					$payment_token = base64_decode($payment_token);
					
					if(!WC()->cart->is_empty()){

						$woo_get_total = (float) WC()->cart->get_total( 'edit' );						

						$order_id = WC()->session->get('order_awaiting_payment');

						if ($order_id) {							
							if ( is_user_logged_in() ) {
								$user_id = get_current_user_id();
								//echo 'User ID is: ' . $user_id;
								
									if($user_id > 0 ){
										$this->process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount );
									} else {
										$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount  );
									}
								
								
							} else {
								$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount );
							}
						} else {
							$order = wc_create_order();
							$order_id = $order->get_id();

							// Optionally, add items to the order
							foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
								$order->add_product( $values['data'], $values['quantity'] ); // Add product to order
							}

							// Calculate totals and save
							$order->calculate_totals();
							$order->save();

								if ( is_user_logged_in() ) {
									$user_id = get_current_user_id();
									//echo 'User ID is: ' . $user_id;
									if($user_id > 0 ){
										$this->process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount );
									} else {
										$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount  );
									}
								} else {
									$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount );
								}
							
						}

					} else {
						wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
					}


			} else {
				wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
			}

		}
			
		wp_die();

	}

	//* Process product page ajax request

	public function acceptblue_woocommerce_ajax_script_process_product_page_charge(){

		if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {

			$payment_token = !empty($_POST['payment_token']) ? wc_clean($_POST['payment_token']) : '';	
			$product_id = !empty($_POST['product_id']) ? wc_clean($_POST['product_id']) : '';
			$billing_address = !empty($_POST['billing_address']) ? wc_clean($_POST['billing_address']) : '';	
			$email_address = !empty($_POST['email_address']) ? wc_clean($_POST['email_address']) : '';	
			$googlepay_amount = !empty($_POST['googlepay_amount']) ? wc_clean($_POST['googlepay_amount']) : '';			

			if(!empty($payment_token) && !empty($product_id)){

					// // Initialize the WooCommerce session
					// if ( ! WC()->session ) {
					// 	WC()->session = new WC_Session_Handler();
					// 	WC()->session->init();
					// }
					
					$payment_token = base64_decode($payment_token);						
					
					$order = wc_create_order();
					$order_id = $order->get_id();

					// Add products to the order
					$quantity = 1; // Set the quantity of the product
					$order->add_product( wc_get_product( $product_id ), $quantity );

					// Calculate totals for the order
					$order->calculate_totals();

					// Set the order status (e.g., 'pending', 'processing')
					
					$order->update_status('pending');
					$order->save();

					if ( is_user_logged_in() ) {
						$user_id = get_current_user_id();
						//echo 'User ID is: ' . $user_id;
						if($user_id > 0 ){
							$this->process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount );
						} else {
							$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount  );
						}
					} else {
						$this->non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount );
					}


			} else {
				wp_send_json_error( esc_html__( 'Invalid Order data!', 'woocommerce' ) );
			}

		}
			
		wp_die();

	}

    //* Process payment by order id Callback from Google Pay

	public function process_payment_by_order_id( $order_id, $payment_token, $googlepay_amount ){

		if(!$order_id) return;

		// Remove surcharge from the order!
		$this->custom_remove_specific_fee_from_order( $order_id );	
						
		$order = wc_get_order($order_id);		

		$woo_currency 					= $order->get_currency();

		if($woo_currency != "USD" ) {
			wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD!", "woocommerce" ) );			
		}

		//$currency_code 					= $this->get_currency_code($woo_currency);
		$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
		$avs_zip  						= $order->get_billing_postcode();
		
		//* Amount Details

		// $amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
		// $amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
		// $amount_details[ "discount" ] 	= (double) $order->get_discount_total();

		$amount_details[ "tax" ] 		= (double) 0;
		$amount_details[ "shipping" ] 	= (double) 0;
		$amount_details[ "discount" ] 	= (double) 0;

		//* Transaction details		

		$transaction_details = array();
		$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
		$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
		$transaction_details[ "order_number" ] 	= $order->get_order_number();
		$transaction_details[ "invoice_number" ] = $order->get_order_number();
		$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();
		

		//* Billing Address Fields

		$billing_info = array();

		$billing_first_name 	= !empty($order->get_billing_first_name()) ? $order->get_billing_first_name() : WC()->cart->get_customer()->get_billing_first_name();
		$billing_last_name 		= !empty($order->get_billing_last_name()) ? $order->get_billing_last_name() : WC()->cart->get_customer()->get_billing_last_name();
		$billing_address_1 		= !empty($order->get_billing_address_1()) ? $order->get_billing_address_1() : WC()->cart->get_customer()->get_billing_address();
		$billing_address_2 		= !empty($order->get_billing_address_2()) ? $order->get_billing_address_2() : WC()->cart->get_customer()->get_billing_address_2();
		$billing_city 			= !empty($order->get_billing_city()) ? $order->get_billing_city() : WC()->cart->get_customer()->get_billing_city();
		$billing_state 			= !empty($order->get_billing_state()) ? $order->get_billing_state() : WC()->cart->get_customer()->get_billing_state();
		$billing_postcode 		= !empty($order->get_billing_postcode()) ? $order->get_billing_postcode() : WC()->cart->get_customer()->get_billing_postcode();
		$billing_country 		= !empty($order->get_billing_country()) ? $order->get_billing_country() : WC()->cart->get_customer()->get_billing_country();
		$billing_phone 			= !empty($order->get_billing_phone()) ? $order->get_billing_phone() : WC()->cart->get_customer()->get_billing_phone();
		$billing_email 			= !empty($order->get_billing_email()) ? $order->get_billing_email() : WC()->cart->get_customer()->get_billing_email();


		$billing_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
		$billing_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
		$billing_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
		$billing_info[ "street2" ] 		= esc_html__( $billing_address_2, 'woocommerce' );
		$billing_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
		$billing_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
		$billing_info[ "zip" ] 			= $billing_postcode;
		$billing_info[ "country" ] 		= esc_html__( $billing_country, 'woocommerce');
		$billing_info[ "phone" ] 		= $billing_phone;						
		
		//* Shipping Address Fields

		$shipping_info = array();

		$shipping_first_name 			= !empty($order->get_shipping_first_name()) ? $order->get_shipping_first_name() : WC()->cart->get_customer()->get_shipping_first_name();
		$shipping_last_name 			= !empty($order->get_shipping_last_name()) ? $order->get_shipping_last_name() : WC()->cart->get_customer()->get_shipping_last_name();
		$shipping_address_1 			= !empty($order->get_shipping_address_1()) ? $order->get_shipping_address_1() : WC()->cart->get_customer()->get_shipping_address();
		$shipping_address_2 			= !empty($order->get_shipping_address_2()) ? $order->get_shipping_address_2() : WC()->cart->get_customer()->get_shipping_address_2();
		$shipping_city 					= !empty($order->get_shipping_city()) ? $order->get_shipping_city() : WC()->cart->get_customer()->get_shipping_city();
		$shipping_state 				= !empty($order->get_shipping_state()) ? $order->get_shipping_state() : WC()->cart->get_customer()->get_shipping_state();
		$shipping_postcode 				= !empty($order->get_shipping_postcode()) ? $order->get_shipping_postcode() : WC()->cart->get_customer()->get_shipping_postcode();
		$shipping_country 				= !empty($order->get_shipping_country()) ? $order->get_shipping_country() : WC()->cart->get_customer()->get_shipping_country();
				
		$shipping_info[ "first_name" ] 	= esc_html__( $shipping_first_name, 'woocommerce' );
		$shipping_info[ "last_name" ] 	= esc_html__( $shipping_last_name, 'woocommerce' );
		$shipping_info[ "street" ] 		= esc_html__( $shipping_address_1, 'woocommerce' );
		$shipping_info[ "street2" ] 	= esc_html__( $shipping_address_2 , 'woocommerce' );
		$shipping_info[ "city" ] 		= esc_html__( $shipping_city, 'woocommerce' );
		$shipping_info[ "state" ] 		= esc_html__( $shipping_state, 'woocommerce' );
		$shipping_info[ "zip" ] 		= $shipping_postcode;
		$shipping_info[ "country" ] 	= esc_html__( $shipping_country , 'woocommerce' );
		$shipping_info[ "phone" ] 		= $billing_phone;

		// Update Billing Information
		$order->set_billing_first_name( $billing_first_name );
		$order->set_billing_last_name( $billing_last_name );		
		$order->set_billing_address_1( $billing_address_1 );
		$order->set_billing_address_2( $billing_address_2  );
		$order->set_billing_city( $billing_city );
		$order->set_billing_state( $billing_state );
		$order->set_billing_postcode( $billing_postcode );
		$order->set_billing_country( $billing_country );
		$order->set_billing_email( $billing_email );
		$order->set_billing_phone( $billing_phone );

		// Update Shipping Information
		$order->set_shipping_first_name( $shipping_first_name );
		$order->set_shipping_last_name( $shipping_last_name );		
		$order->set_shipping_address_1( $shipping_address_1 );
		$order->set_shipping_address_2( $shipping_address_2 );
		$order->set_shipping_city( $shipping_city );
		$order->set_shipping_state( $shipping_state );
		$order->set_shipping_postcode( $shipping_postcode );
		$order->set_shipping_country( $shipping_country );

		// Set Payment gateway 
		$order->set_payment_method( $this->id );

		// Set Customer id 
		$current_user = wp_get_current_user();
		$order->set_customer_id($current_user->ID);

		// Set Coupons
		$applied_coupons = WC()->cart->get_applied_coupons();

		if ( ! empty( $applied_coupons ) ) {

			// Loop through each applied coupon
			foreach ( $applied_coupons as $coupon_code ) {
				
				// Get the coupon object
				$coupon = new WC_Coupon( $coupon_code );
		
				// Ensure the coupon is valid
				if ( ! $coupon->get_id() ) {
					continue; // Skip invalid coupon codes
				}
				
				$order->apply_coupon($coupon_code);
				
			}

			// Calculate totals
			//$order->calculate_totals(true);
			// Save the order after updating the details
			$order->save();

		}


		//* Check if has physical product
		$has_physical_product = false;

		foreach ($order->get_items() as $item_id => $item) {
			$product_id = $item->get_product_id();
			$product = wc_get_product($product_id);
			
			if ($product && $product->is_virtual() === false) {
				// If the product is not virtual, it is considered a physical product
				$has_physical_product = true;
				break;
			}
		}
		
		if ($has_physical_product) {

			// Create a shipping package
			$packages = [
				[
					'contents'        => [],
					'contents_cost'   => 0,
					'applied_coupons' => $order->get_used_coupons(),
					'user'            => [
						'ID' => get_current_user_id(),
					],
					'destination'     => [
						'country'   => $shipping_country,
						'state'     => $shipping_state,
						'postcode'  => $shipping_postcode,
						'city'      => $shipping_city,
						'address'   => $shipping_address_1,
						'address_2' => $shipping_address_2,
					],
				],
			];
		
			// Calculate the shipping rates
			WC()->shipping()->calculate_shipping( $packages );
		
			// Get available shipping rates for the package
			$available_methods = WC()->shipping->get_packages()[0]['rates'];

			// Retrieve the chosen shipping method IDs
			$chosen_methods = WC()->session->get('chosen_shipping_methods');
		
			// Add the first available shipping method (default method) to the order
			if ( ! empty( $available_methods ) ) {

				if( ! empty($chosen_methods) && !empty($chosen_methods[0])){
					$shipping_rate = $available_methods[$chosen_methods[0]]; 

				} else {
					$shipping_rate = reset( $available_methods ); // Get the first available method	
				}

				$order->add_shipping( $shipping_rate );			
				
			}
		}
		

		// Calculate totals
		$order->calculate_totals();

		$order->update_meta_data( 'payment_token', $payment_token );

		// Save the order after updating the details
		$order->save();

		$woo_get_total 	= $order->get_total();
		//  exit;

		//* Google Pay Order Review Page

		if($this->order_review_enable === true ){

			$page_id = $this->order_review_page;

			if( !empty($page_id) ){

				$args 	= array( 'key' => $order->get_order_key() );
				$url 	= add_query_arg( $args, get_permalink( $page_id ) );

				wp_send_json_success( esc_url( $url  ) );

			} else {

				wp_send_json_error( esc_html__( "Invalid Google Pay Order Review Page!" , "woocommerce" ));

			}

			

		} else {

			$params = array(
				"amount" 		=> (double) $woo_get_total,
				"source" 		=> $this->source,
				"token" 		=> $payment_token,	
				"billing_info" 	=> $billing_info,
				"shipping_info" => $shipping_info,						
				"avs_zip" 		=> $avs_zip,
				"avs_address" 	=> $avs_address,
				"transaction_details" => $transaction_details,
				"amount_details" => $amount_details,
				"capture"        => (bool) $this->force_capture,
				//"save_card"      => (bool) $this->save_card_token 
			);

			$level3_line_items = (array) $this->level3_data_line_items(  $order->get_id() );

			$params = array_merge($params, $level3_line_items);

			//Surcharge add into order details
			$this->surcharge_fee_to_order($order, '' );

			$this->execute_payment( $order, $params, 'transactions/charge' );

		}		
			

		
	}

	public function execute_payment( $order, $params, $action ){

		//* Execute the payments	
		$result = $this->request_api($params, $action );		 
	
		if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
			$defaults = array();
			$data     = wp_parse_args( (array) $result['response_body'], $defaults );

			if( $data[ 'status' ] == 'Approved' ){

				//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
				//$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );

				//$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );

				if( $this->default_status == 'default' ){

					// Mark as complete or processing based on virtual order or not
					$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) ); 
					
				} else {

					$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
					$order->update_status( $this->default_status );
				}
				

				$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );

				// Store authorized amount for Adjust & Capture total-change detection.
				if ( ! (bool) $this->force_capture ) {
					$auth_amount_ep = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : (float) ( $params['amount'] ?? 0 );
					if ( $auth_amount_ep > 0 ) {
						$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount_ep );
					}
				}

				$order->save();

				$order->add_order_note(
					esc_html__( sprintf(
						"%s Payment Completed with Transaction Id of '%s'",
						$this->method_title,
						sanitize_text_field($data[ 'reference_number' ])
					), 'woocommerce' )
				);

				//$order->get_checkout_order_received_url();
				 WC()->cart->empty_cart();
				 WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
				 wp_send_json_success($order->get_checkout_order_received_url());				
			} else {
				wp_send_json_error( esc_html__( $data[ 'error_message' ], "woocommerce" ) );
			}
		
		} else{

			$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
			wp_send_json_error( esc_html__( $message, "woocommerce" ));
		}

	}

    //* Non Member Process payment by order id Callback from Google Pay

	public function non_member_process_payment_by_order_id( $order_id, $payment_token, $billing_address, $email_address, $googlepay_amount ){

		if(!$order_id) return;

		// Remove surcharge from the order!
		$this->custom_remove_specific_fee_from_order( $order_id );	
						
		$order = wc_get_order($order_id);
		

		$woo_currency 					= $order->get_currency();

		if($woo_currency != "USD" ) {
			wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD!", "woocommerce"  ) );
		}

		//$currency_code 					= $this->get_currency_code($woo_currency);	
		
		//* Amount Details

		// $amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
		// $amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
		// $amount_details[ "discount" ] 	= (double) $order->get_discount_total();

		$amount_details[ "tax" ] 		= (double) 0;
		$amount_details[ "shipping" ] 	= (double) 0;
		$amount_details[ "discount" ] 	= (double) 0;

		//* Transaction details		

		$transaction_details = array();
		$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
		$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
		$transaction_details[ "order_number" ] 	= $order->get_order_number();
		$transaction_details[ "invoice_number" ] = $order->get_order_number();
		$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

		$email_address = base64_decode($email_address);
		
		//* Billing Address Fields

		$billing_info = array();

		$name_parts = explode( ' ', $billing_address['name'], 2 );

		$billing_first_name 	= !empty($name_parts[0]) ? $name_parts[0] : '';
		$billing_last_name 		= !empty($name_parts[1]) ? $name_parts[1] : '';
		$billing_address_1 		= !empty($billing_address['address1']) ? $billing_address['address1'] : '';
		$billing_address_2 		= !empty($billing_address['address2']) ? $billing_address['address2'] : '';
		$billing_city 			= !empty($billing_address['locality']) ? $billing_address['locality'] : '';
		$billing_state 			= !empty($billing_address['administrativeArea']) ? $billing_address['administrativeArea'] : '';
		$billing_postcode 		= !empty($billing_address['postalCode']) ? $billing_address['postalCode'] : '';
		$billing_country 		= !empty($billing_address['countryCode']) ? $billing_address['countryCode'] : '';
		$billing_phone 			= !empty($billing_address['phoneNumber']) ? $billing_address['phoneNumber'] : '';
		$billing_email 			= !empty($email_address) ? $email_address : '';


		$billing_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
		$billing_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
		$billing_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
		$billing_info[ "street2" ] 		= esc_html__( $billing_address_2, 'woocommerce' );
		$billing_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
		$billing_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
		$billing_info[ "zip" ] 			= $billing_postcode;
		$billing_info[ "country" ] 		= esc_html__( $billing_country, 'woocommerce');
		$billing_info[ "phone" ] 		= $billing_phone;						
		
		//* Shipping Address Fields

		$shipping_info = array();

				
		$shipping_info[ "first_name" ] 	= esc_html__( $billing_first_name, 'woocommerce' );
		$shipping_info[ "last_name" ] 	= esc_html__( $billing_last_name, 'woocommerce' );
		$shipping_info[ "street" ] 		= esc_html__( $billing_address_1, 'woocommerce' );
		$shipping_info[ "street2" ] 	= esc_html__( $billing_address_2 , 'woocommerce' );
		$shipping_info[ "city" ] 		= esc_html__( $billing_city, 'woocommerce' );
		$shipping_info[ "state" ] 		= esc_html__( $billing_state, 'woocommerce' );
		$shipping_info[ "zip" ] 		= $billing_postcode;
		$shipping_info[ "country" ] 	= esc_html__( $billing_country , 'woocommerce' );
		$shipping_info[ "phone" ] 		= $billing_phone;

		// Update Billing Information
		$order->set_billing_first_name( $billing_first_name );
		$order->set_billing_last_name( $billing_last_name );		
		$order->set_billing_address_1( $billing_address_1 );
		$order->set_billing_address_2( $billing_address_2  );
		$order->set_billing_city( $billing_city );
		$order->set_billing_state( $billing_state );
		$order->set_billing_postcode( $billing_postcode );
		$order->set_billing_country( $billing_country );
		$order->set_billing_email( $billing_email );
		$order->set_billing_phone( $billing_phone );

		// Update Shipping Information
		$order->set_shipping_first_name( $billing_first_name );
		$order->set_shipping_last_name( $billing_last_name );		
		$order->set_shipping_address_1( $billing_address_1 );
		$order->set_shipping_address_2( $billing_address_2 );
		$order->set_shipping_city( $billing_city );
		$order->set_shipping_state( $billing_state );
		$order->set_shipping_postcode( $billing_postcode );
		$order->set_shipping_country( $billing_country );

		// Set Payment gateway 
		$order->set_payment_method( $this->id );

		// Set Customer id 
		$current_user = wp_get_current_user();
		$order->set_customer_id($current_user->ID);

		// Set Coupons
		$applied_coupons = WC()->cart->get_applied_coupons();

		if ( ! empty( $applied_coupons ) ) {

			// Loop through each applied coupon
			foreach ( $applied_coupons as $coupon_code ) {
				
				// Get the coupon object
				$coupon = new WC_Coupon( $coupon_code );
		
				// Ensure the coupon is valid
				if ( ! $coupon->get_id() ) {
					continue; // Skip invalid coupon codes
				}
				
				$order->apply_coupon($coupon_code);
				
			}

			// Calculate totals
			//$order->calculate_totals(true);
			// Save the order after updating the details
			$order->save();

		}

		//* Check if has physical product
		$has_physical_product = false;

		foreach ($order->get_items() as $item_id => $item) {
			$product_id = $item->get_product_id();
			$product = wc_get_product($product_id);
			
			if ($product && $product->is_virtual() === false) {
				// If the product is not virtual, it is considered a physical product
				$has_physical_product = true;
				break;
			}
		}
		
		if ($has_physical_product) {

			// Create a shipping package
			$packages = [
				[
					'contents'        => [],
					'contents_cost'   => 0,
					'applied_coupons' => $order->get_used_coupons(),
					'user'            => [
						'ID' => get_current_user_id(),
					],
					'destination'     => [
						'country'   => $shipping_info[ "country" ],
						'state'     => $shipping_info[ "state" ],
						'postcode'  => $shipping_info[ "zip" ] ,
						'city'      => $shipping_info[ "city" ],
						'address'   => $shipping_info[ "street" ],
						'address_2' => $shipping_info[ "street2" ],
					],
				],
			];
		
			// Calculate the shipping rates
			WC()->shipping()->calculate_shipping( $packages );
		
			// Get available shipping rates for the package
			$available_methods = WC()->shipping->get_packages()[0]['rates'];
		
			// Retrieve the chosen shipping method IDs
			$chosen_methods = WC()->session->get('chosen_shipping_methods');
		
			// Add the first available shipping method (default method) to the order
			if ( ! empty( $available_methods ) ) {

				if( ! empty($chosen_methods) && !empty($chosen_methods[0])){
					$shipping_rate = $available_methods[$chosen_methods[0]]; 					
				} else {
					$shipping_rate = reset( $available_methods ); // Get the first available method				
				}
				
				$order->add_shipping( $shipping_rate );		
				
			}

		}

		

		// Calculate totals
		$order->calculate_totals();

		$order->update_meta_data( 'payment_token', $payment_token );

		// Save the order after updating the details
		$order->save();

		$woo_get_total 					= $order->get_total();
		$avs_address					= esc_html__( $billing_address_1 .' '. $billing_address_2, 'woocommerce' );
		$avs_zip  						= $billing_postcode;	

		if($this->order_review_enable === true ){

			$page_id = $this->order_review_page;

			if( !empty($page_id) ){

				$args 	= array( 'key' => $order->get_order_key() );
				$url 	= add_query_arg( $args, get_permalink( $page_id ) );

				wp_send_json_success( esc_url( $url  ) );

			} else {

				wp_send_json_error( esc_html__( "Invalid Google Pay Order Review Page!" , "woocommerce" ));

			}

			

		} else {

			$params = array(
				"amount" 		=> (double) $woo_get_total,
				"source" 		=> $this->source,
				"token" 		=> $payment_token,	
				"billing_info" 	=> $billing_info,
				"shipping_info" => $shipping_info,						
				"avs_zip" 		=> $avs_zip,
				"avs_address" 	=> $avs_address,
				"transaction_details" => $transaction_details,
				"amount_details" => $amount_details,
				"capture"        => (bool) $this->force_capture,
				//"save_card"      => (bool) $this->save_card_token 
			);

			$level3_line_items = (array) $this->level3_data_line_items(  $order->get_id() );

			$params = array_merge($params, $level3_line_items);

			//Surcharge add into order details
			$this->surcharge_fee_to_order($order, '' );

			$this->execute_payment( $order, $params, 'transactions/charge' );

		}
		
		
	}

    public function acceptblue_woocommerce_ajax_script_place_order_charge(){

		if ( ! check_ajax_referer('acceptblue-ajax-nonce', 'nonce', false) ) {
			wp_send_json_error( esc_html__( 'Invalid nonce', 'woocommerce' ) );
		} else {

			$order_key = !empty($_POST['order_key']) ? wc_clean($_POST['order_key']) : '';

			if (!empty($order_key)) {
				$order_id = wc_get_order_id_by_order_key($order_key);
			} 

			if (empty($order_id)) {
				wp_send_json_error( esc_html__( 'No order found.', 'woocommerce' ) );
			}

			// Remove surcharge from the order!
			$this->custom_remove_specific_fee_from_order( $order_id );	

			// Get the order object
			$order = wc_get_order($order_id);

			if (!$order) {				
				wp_send_json_error( esc_html__( 'Invalid order ID or key', 'woocommerce' ) );
			} else {

				$status 		= $order->get_status();
				$transaction_id = $order->get_transaction_id();

				//* validate the if transaction id is already exist
				if(!empty($transaction_id)){
					//wp_send_json_success($order->get_checkout_order_received_url());
					wp_send_json_error( esc_html__( "The order has been processed.", "woocommerce" ) );
				}

				$payment_token 					= $order->get_meta( 'payment_token' );

				if(empty($payment_token)) {
					wp_send_json_error( esc_html__( "Invalid, Payment Token.", "woocommerce" ) );
				}

				$woo_currency 					= $order->get_currency();

				if($woo_currency != "USD" ) {
					wp_send_json_error( esc_html__( "Invalid, Transaction amount should be in USD.", "woocommerce" ) );
				}

				//$currency_code 					= $this->get_currency_code($woo_currency);
				$woo_get_total 					= $order->get_total();
				$avs_address					= esc_html__( $order->get_billing_address_1() .' '. $order->get_billing_address_2(), 'woocommerce' );
				$avs_zip  						= $order->get_billing_postcode();
				
				//* Amount Details

				// $amount_details[ "tax" ] 		= (double) $order->get_tax_totals();
				// $amount_details[ "shipping" ] 	= (double) $order->get_shipping_total();
				// $amount_details[ "discount" ] 	= (double) $order->get_discount_total();

				$amount_details[ "tax" ] 		= (double) 0;
				$amount_details[ "shipping" ] 	= (double) 0;
				$amount_details[ "discount" ] 	= (double) 0;

				//* Transaction details

				$transaction_details = array();
				$transaction_details[ "description" ] 	= sprintf( "%s - ORDER No. #%s", ucwords(get_bloginfo( 'name' )), $order->get_order_number() );
				$transaction_details[ "client_ip" ] = $this->get_client_ip( $order );
				$transaction_details[ "order_number" ] 	= $order->get_order_number();
				$transaction_details[ "invoice_number" ] = $order->get_order_number();
				$transaction_details[ "terminal" ] 		= $order->get_payment_method_title();

				//* Billing Address Fields

				$billing_info = array();

				$billing_info[ "first_name" ] 	= esc_html__( $order->get_billing_first_name(), 'woocommerce' );
				$billing_info[ "last_name" ] 	= esc_html__( $order->get_billing_last_name(), 'woocommerce' );
				$billing_info[ "street" ] 		= esc_html__( $order->get_billing_address_1(), 'woocommerce' );
				$billing_info[ "street2" ] 		= esc_html__( $order->get_billing_address_2(), 'woocommerce' );
				$billing_info[ "city" ] 		= esc_html__( $order->get_billing_city(), 'woocommerce' );
				$billing_info[ "state" ] 		= esc_html__( $order->get_billing_state(), 'woocommerce' );
				$billing_info[ "zip" ] 			= $order->get_billing_postcode();
				$billing_info[ "country" ] 		= esc_html__( $order->get_billing_country(), 'woocommerce');
				$billing_info[ "phone" ] 		= $order->get_billing_phone();						
				
				//* Shipping Address Fields

				$shipping_info = array();

				$shipping_info[ "first_name" ] 	= esc_html__( $order->get_shipping_first_name(), 'woocommerce' );
				$shipping_info[ "last_name" ] 	= esc_html__( $order->get_shipping_last_name(), 'woocommerce' );
				$shipping_info[ "street" ] 		= esc_html__( $order->get_shipping_address_1(), 'woocommerce' );
				$shipping_info[ "street2" ] 	= esc_html__( $order->get_shipping_address_2(), 'woocommerce' );
				$shipping_info[ "city" ] 		= esc_html__( $order->get_shipping_city(), 'woocommerce' );
				$shipping_info[ "state" ] 		= esc_html__( $order->get_shipping_state(), 'woocommerce' );
				$shipping_info[ "zip" ] 		= $order->get_shipping_postcode();
				$shipping_info[ "country" ] 	= esc_html__( $order->get_shipping_country(), 'woocommerce' );
				$shipping_info[ "phone" ] 		= $order->get_billing_phone();

				$params = array(
					"amount" 		=> (double) $woo_get_total,
					"source" 		=> $this->source,
					"token" 		=> $payment_token,	
					"billing_info" 	=> $billing_info,
					"shipping_info" => $shipping_info,						
					"avs_zip" 		=> $avs_zip,
					"avs_address" 	=> $avs_address,
					"transaction_details" => $transaction_details,
					"amount_details" => $amount_details,
					"capture"        => (bool) $this->force_capture,
					//"save_card"      => (bool) $this->save_card_token 
				);

				$level3_line_items = (array) $this->level3_data_line_items(  $order->get_id() );

				$params = array_merge($params, $level3_line_items);

				//Surcharge add into order details
				$this->surcharge_fee_to_order($order, '' );
				
				//* Execute the payments	
				$result = $this->request_api($params,'transactions/charge');

				// exit;

				if( $result['response_code'] == 200 && $result[ 'response_message' ] == 'OK' && ! empty($result['response_body'])){
					$defaults = array();
				$data     = wp_parse_args( (array) $result['response_body'], $defaults );
					
					if( $data[ 'status' ] == 'Approved' ){

						//$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) );
						//$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
						//$order_status = $this->virtual_order_payment_complete_order_status( $order->get_id() );

						if( $this->default_status == 'default' ){

							// Mark as complete or processing based on virtual order or not
							$order->payment_complete( sanitize_text_field($data[ 'reference_number' ]) ); 
							
						} else {
							$order->set_transaction_id( sanitize_text_field($data[ 'reference_number' ]) );
							$order->update_status( $this->default_status );
						}
						
						$order->update_meta_data( '_'. $this->id .'_refnum', sanitize_text_field($data[ 'reference_number' ]) );
						//* removed the Google Pay payment token
						$order->delete_meta_data( 'payment_token' );

						$order->save();

						$order->add_order_note(
							esc_html__( sprintf(
								"%s Payment Completed with Transaction Id of '%s'",
								$this->method_title,
								sanitize_text_field($data[ 'reference_number' ])
							), 'woocommerce' )
						);

						WC()->cart->empty_cart();
						WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );
							wp_send_json_success($order->get_checkout_order_received_url());

					} else {

						wp_send_json_error( esc_html__( $data[ 'error_message' ], 'woocommerce' ) );
					}
				
				} else{

					$message = !empty($result['response_message']) ? $result['response_message'] : 'Invalid Request!';
					self::log( 'API error: ' . $message, 'error' );
					wp_send_json_error( esc_html__( wc_clean($message), 'woocommerce' ) );
				}


			} 

		}
			
		wp_die();

	}

	public function custom_google_pay_product_button(){

		global $product;

		

		if($this->google_pay_button_product_enable === false ) return;

		if ( $product && $product->is_type( 'variable' ) ) return;		

		// Get the base product price
		$base_price = $product->get_price();
		$product_id = $product->get_id();
		$product = wc_get_product( $product_id );
		$price = $product->get_price() * 1;

		// Get the product price including tax
		 $product_price_incl_tax = wc_get_price_including_tax( $product );

		//Check if virtual
		$has_physical_product = false;

		if ($product && $product->is_virtual() === false) {
            // If the product is not virtual, it is considered a physical product
            $has_physical_product = true;
           
        }

		$shipping_cost = 0;
		$shipping_tax = 0;

		if ($has_physical_product) {

			// Create a shipping package
			$packages = [
				[
					'contents'        => [],
					'contents_cost'   => 0,
					//'applied_coupons' => $order->get_used_coupons(),
					'user'            => [
						'ID' => get_current_user_id(),
					],
					'destination'     => [
						'country'   => WC()->customer->get_shipping_country(),
						'state'     => WC()->customer->get_shipping_state(),
						'postcode'  => WC()->customer->get_shipping_postcode(),
						'city'      => WC()->customer->get_shipping_city(),
						'address'   => WC()->customer->get_shipping_address(),
						'address_2' => WC()->customer->get_shipping_address_2(),
					],
				],
			];
		
			// Calculate the shipping rates
			WC()->shipping()->calculate_shipping( $packages );
		
			// Get available shipping rates for the package
			$available_methods = WC()->shipping->get_packages()[0]['rates'];

			// Retrieve the chosen shipping method IDs
			$chosen_methods = WC()->session->get('chosen_shipping_methods');
		
			// Add the first available shipping method (default method) to the order
			if ( ! empty( $available_methods ) ) {

				if( ! empty($chosen_methods)){
					$shipping_rate = $available_methods[$chosen_methods[0]]; 
				} else {
					$shipping_rate = reset( $available_methods ); // Get the first available method				
				}

				$price_includes_tax 	= get_option( 'woocommerce_prices_include_tax' ) === 'yes';
				$shipping_cost 			= $shipping_rate->cost; // Example: select the first available shipping method's cost
				
				// Calculate tax for the shipping cost
				$shipping_tax_rates = WC_Tax::get_shipping_tax_rates();
				$shipping_taxes = WC_Tax::calc_tax($shipping_cost, $shipping_tax_rates, $price_includes_tax);
				$shipping_tax = array_sum($shipping_taxes); // Total shipping tax				
			}
			
		}

		// Calculate the total price
		//$final_price = $product_price_incl_tax  + $shipping_cost + $shipping_tax;
		$final_price = $base_price;

		// Get the currency code
		$currency = get_woocommerce_currency();
		
		?>
    		<div id="acceptblue-google-pay-product-button"></div>
			<!-- <div id="acceptblue-google-pay-ajax-loader" style="display:none" /> -->
			<script type="text/javascript">
			// Get dynamic final product price and currency
			const acceptblue_final_price = "<?php echo esc_js(number_format($final_price, 2, '.', '')); ?>";
			const acceptblue_currency_code = "<?php echo esc_js($currency); ?>";
			const acceptblue_product_id = "<?php echo esc_js($product_id); ?>";
			</script>
		<?php
	}

	public function custom_google_pay_cart_button(){

		if($this->google_pay_button_cart_enable === false ) return;

		 // Get the WooCommerce cart total and currency
		 $final_price = WC()->cart->get_total(''); // Cart total without HTML tags
		 $currency_code = get_woocommerce_currency(); // Get the currency code
 
		//  // Pass the cart total and currency code to JavaScript
		//  wp_localize_script('google-pay-script', 'wc_cart_params', [
		// 	 'totalPrice' => WC()->cart->get_cart_total(),
		// 	 'currencyCode' => $currency_code,
		//  ]);
		
		 ?>
    		<div id="acceptblue-google-pay-product-button"></div>
			<!-- <div id="acceptblue-google-pay-ajax-loader" style="display:none" /> -->
			<script type="text/javascript">
			// Get dynamic final product price and currency
			const acceptblue_final_price = "<?php echo esc_js(number_format($final_price, 2, '.', '')); ?>";
			const acceptblue_currency_code = "<?php echo esc_js($currency_code); ?>";
			</script>
		<?php
	}

	public function custom_google_pay_checkout_page_button(){

		if($this->google_pay_button_checkout_enable === false ) return; 

		// Get the WooCommerce cart total and currency
		$final_price = (float) WC()->cart->get_total( 'edit' ); // Cart total without HTML tags
		$currency_code = get_woocommerce_currency(); // Get the currency code
   
		?>
		
		   <div id="acceptblue-google-pay-product-button"></div>		   
		   <script type="text/javascript">
		   // Get dynamic final product price and currency
		   const acceptblue_final_price = "<?php echo esc_js(number_format($final_price, 2, '.', '')); ?>";
		   const acceptblue_currency_code = "<?php echo esc_js($currency_code); ?>";
		   </script>
		    <!-- <div id="acceptblue-google-pay-ajax-loader" style="display:none" /> -->
	   <?php

	}

	//* Accept.Blue Card Name

	public function before_cc_form( $gateway_id ) {
		// Check if the gateway ID matches
		if ( $gateway_id !== $this->id ) {
			return;
		}
	
		// Check if 'name_on_card_required' setting is enabled
		$name_on_card_required = !empty($this->settings['name_on_card_required']) && $this->settings['name_on_card_required'] === 'yes';
	
		static $card_name_printed = false;

		if ( ! empty( $this->settings['name_on_card'] ) && $this->settings['name_on_card'] === 'yes' && !$card_name_printed ) {
			// Print the form field
			woocommerce_form_field( $this->id . '-card-name', array(
				'label'             => esc_html__( $this->name_on_card_label, 'woocommerce' ),
				'required'          => $name_on_card_required,
				'class'             => array( 'form-row-wide' ),
				'input_class'       => array( $this->id . '-card-name' ),
				'custom_attributes' => array(
					'autocomplete'  => 'off',
				),
			) );
	
			// Set the flag to true after the field is printed
			$card_name_printed = true;
		}

		
	}


	public function append_cardcode_input_saved_payment_methods() {

		// Check if 'card_code' setting is enabled
		$card_code_required = !empty($this->settings['card_code_required']) && $this->settings['card_code_required'] === 'yes';
	
		static $card_code_printed = false;

		if ( ! empty( $this->settings['card_code'] ) && $this->settings['card_code'] === 'yes' && !$card_code_printed ) {
			// Print the form field
			woocommerce_form_field( $this->id . '-card-cvc', array(
				'label'             => esc_html__( $this->card_code_label, 'woocommerce' ),
				'required'          => $card_code_required,
				'class'             => array( 'form-row form-row-wide', $this->id . '-card-code-custom', 'woocommerce-acceptblue-hidden' ),
				'input_class'       => array( $this->id . '-card-cvc' , 'wc-credit-card-form-card-cvc' ),
				'type'              => 'tel',
				'placeholder'       => esc_html__( "CVC", 'woocommerce' ),
				'style'				=> "display:none;",
				'custom_attributes' => array(
					'autocomplete'  => 'off',
					'inputmode'    => 'numeric',
					'maxlength'    => 4,
					'autocorrect'  => 'no',
					'autocapitalize'=> 'no',
					'style' 	   => 'width:100px',					

				),
			) );
	
			// Set the flag to true after the field is printed
			$card_code_printed = true;
		}	

      
    }

	//* customize card form label

	public function custom_cc_labels( $fields, $gateway_id ) {
		if ( 'acceptbluev2' !== $gateway_id ) {
			return $fields;
		}

		if ( isset( $fields['card-number-field'] ) ) {
			$fields['card-number-field'] = str_replace(
				'Card number',
				esc_html__( $this->card_number_field_label , 'woocommerce' ), 
				$fields['card-number-field']
			);
		}

		if ( isset( $fields['card-expiry-field'] ) ) {
			$fields['card-expiry-field'] = str_replace(
				'Expiry (MM/YY)',
				esc_html__( $this->card_expiry_field_label , 'woocommerce' ), 
				$fields['card-expiry-field']
			);
		}

		if ( isset( $fields['card-cvc-field'] ) ) {
			$fields['card-cvc-field'] = str_replace(
				'Card code',
				esc_html__( $this->card_cvc_field_label , 'woocommerce' ), 
				$fields['card-cvc-field']
			);
		}

		return $fields;
	}

	public function disabled_enabled_save_card_token( $supports, $feature, $gateway ){

		if ( $this->id !== $gateway->id || 'tokenization' !== $feature ) {
			return $supports;
		}

		// Never show "Save to account" to guests — WC_Payment_Token requires a user ID
		if ( ! is_user_logged_in() ) {
			return false;
		}

		// Admin setting: save card disabled
		if ( $this->save_card_token_disable === true ) {
			return false;
		}

		return $supports;

	}

	public function custom_save_card_token_label( $html, $gateway ){

		if ( $this->id === $gateway->id && !empty($this->settings['save_card_label']) ) {

			$label = $this->settings['save_card_label'];
			$html = str_replace( 'Save to account', $label, $html );
		}

		

		return $html;		

	}

	/**
	 * Handle payment failure consistently.
	 *
	 * @param WC_Order $order
	 * @param array    $result
	 * @return array|false
	 */
	protected function handle_payment_failure( $order, $result ) {
		
		// Build failure message safely
		$message = '';

		if ( ! empty( $result['response_body'] ) && is_object( $result['response_body'] ) ) {
			$code = $result['response_body']->response_code ?? '';
			$text = $result['response_body']->response_message ?? '';
			$message = trim( $code . ' - ' . $text, ' -' );

			if( empty($message) ) {
				// Check for detailed error information
				if ( ! empty( $result['response_body']->error_details ) && is_object( $result['response_body']->error_details ) ) {
					$error_details = (array) $result['response_body']->error_details;
					$detail_messages = array();
					
					foreach ( $error_details as $field => $errors ) {
						if ( is_array( $errors ) && ! empty( $errors[0] ) ) {
							$detail_messages[] = $field . ': ' . $errors[0];
						}
					}
					
					if ( ! empty( $detail_messages ) ) {
						$message = implode( ' | ', $detail_messages );
					}
				}
				
				// Fallback to generic message if still empty
				if ( empty( $message ) ) {
					$message = __( 'Payment failed without a specific error message.', 'woocommerce' );
				}
			}

		} else {
			$message = $result['message'] ?? __( 'Unknown error', 'woocommerce' );
		}

		// Full internal message
		$internal_message = sprintf(
			"%s Payment Failed with message: '%s'",
			$this->method_title,
			$message
		);

		// Update order
		$order->update_status( 'failed' );
		$order->add_order_note( esc_html( $internal_message ) );

		// Customer notice
		$customer_message = sprintf(
			__( "Payment Failed with message: '%s'", 'woocommerce' ),
			$message
		);

		wc_add_notice( esc_html( $customer_message ), 'error' );

		// Block checkout response
		if ( $this->block_support_checkout === true ) {
			return array(
				'result'  => 'failure',
				'message' => esc_html( $customer_message ),
			);
		}

		return false;
	}



}

