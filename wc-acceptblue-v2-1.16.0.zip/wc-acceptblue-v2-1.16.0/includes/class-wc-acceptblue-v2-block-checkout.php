<?php
defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * accept.blue v2 — WooCommerce Blocks Payment Method Integration
 *
 * Registers the gateway with the WooCommerce Blocks payment method registry
 * and provides the JS handles + payment method data required for the
 * Block Checkout (Cart & Checkout blocks).
 *
 * Fatal error fixes applied:
 *   - $this->gateway could be null when Blocks initialises before WC payment
 *     gateways are fully loaded. Every method now guards against null.
 *   - get_payment_method_script_handles() dereferenced $this->gateway without
 *     a null check before any is_active() guard ran.
 *   - get_payment_method_data() had 15+ direct $this->gateway-> dereferences
 *     without null checks; all now go through $this->get_setting().
 *   - threeds_frictionless settings key accessed inconsistently; normalised.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.0
 */
final class WC_AcceptBlue_V2_Gateway_Blocks extends AbstractPaymentMethodType {

    /** @var string Must match the gateway ID. */
    protected $name = 'acceptbluev2';

    /** @var array Raw WooCommerce settings option. */
    protected $settings = [];

    /** @var WC_Gateway_AcceptBlue_v2|null */
    protected $gateway = null;

    // =========================================================================
    // AbstractPaymentMethodType interface
    // =========================================================================

    /**
     * Called by WooCommerce Blocks before any other method.
     * Loads settings and resolves the gateway instance.
     */
    public function initialize() {
        $this->settings = get_option( 'woocommerce_acceptbluev2_settings', [] );
        $this->gateway  = $this->resolve_gateway();
    }

    /**
     * Whether this payment method should appear in the Block Checkout.
     *
     * @return bool
     */
    public function is_active() {
        return $this->gateway instanceof WC_Payment_Gateway
            && $this->gateway->is_available();
    }

    /**
     * Return the script handles to enqueue for the Block Checkout.
     * Safe even when $this->gateway is null.
     *
     * @return string[]
     */
    public function get_payment_method_script_handles() {

        $tokenization = $this->get_setting( 'tokenization', 'no' ) === 'yes';

        // When Hosted Tokenization is enabled, show a simple redirect notice
        // ("You will enter your card details on the next step.") instead of
        // the iframe card form. The SDK is not needed in this path.
        if ( $tokenization ) {
            wp_register_script(
                'wc-acceptblue-hosted-token-blocks-integration',
                plugins_url( 'assets/js/dist/acceptblue-block-tokenization-redirect.js', AB_V2_PLUGIN_FILE ),
                [ 'wc-blocks-registry', 'wc-settings', 'wp-element' ],
                AB_V2_VERSION,
                true
            );
            return [ 'wc-acceptblue-hosted-token-blocks-integration' ];
        }

        // Hosted Tokenization OFF — determine which iframe block JS to load
        $threeds   = $this->get_setting( 'threeds', 'no' );
        $file_js   = ( $threeds === 'yes' )
            ? 'assets/js/dist/acceptblue-hosted-token-block-3ds-checkout.min.js'
            : 'assets/js/dist/acceptblue-hosted-token-block-checkout.min.js';

        // Register the hosted SDK if not already done.
        // wp_enqueue_scripts doesn't fire in the Blocks/REST context, so we
        // register here as a fallback to avoid a missing-dependency warning.
        if ( ! wp_script_is( 'acceptblue-hosted-sdk', 'registered' ) ) {
            $testmode    = $this->get_setting( 'testmode', 'no' );
            $hosted_url  = ( $testmode === 'yes' )
                ? 'https://tokenization.sandbox.accept.blue/tokenization/v0.3'
                : 'https://tokenization.accept.blue/tokenization/v0.3';

            wp_register_script( 'acceptblue-hosted-sdk', $hosted_url, [], null, true );
        }

        wp_register_script(
            'wc-acceptblue-hosted-token-blocks-integration',
            plugins_url( $file_js, AB_V2_PLUGIN_FILE ),
            [
                'acceptblue-hosted-sdk',
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            AB_V2_VERSION,
            true
        );

        return [ 'wc-acceptblue-hosted-token-blocks-integration' ];
    }

    /**
     * Return the data object exposed to the Block Checkout JS as
     * `window.wc.wcSettings.getSetting('acceptbluev2_data', {})`.
     *
     * Every value is safe to access even when $this->gateway is null.
     *
     * @return array
     */
    public function get_payment_method_data() {

        $testmode = $this->get_setting( 'testmode', 'no' );

        $pk_hosted_token = ( $testmode === 'yes' )
            ? $this->get_setting( 'pk_key_test',         '' )
            : $this->get_setting( 'pk_key_live',         '' );

        $pk_threeds_key  = ( $testmode === 'yes' )
            ? $this->get_setting( 'threeds_api_key_test', '' )
            : $this->get_setting( 'threeds_api_key_live', '' );

        // Surcharge-adjusted order total
        $total_amount = $this->get_cart_total();

        if (
            $total_amount > 0 &&
            $this->get_setting( 'surcharge_card', 'no' ) === 'yes'
        ) {
            try {
                $client       = new WC_AcceptBlue_API_v2();
                $adjusted     = $client->remove_surcharge( $total_amount );
                $total_amount = (float) ( $adjusted ?? $total_amount );
            } catch ( Exception $e ) {
                // Surcharge adjustment failed — use unadjusted total
                self::log( 'Block checkout surcharge error: ' . $e->getMessage(), 'warning' );
            }
        }

        // Saved tokens for logged-in users
        $saved_tokens = [];
        if ( is_user_logged_in() ) {
            $customer_tokens = WC_Payment_Tokens::get_customer_tokens(
                get_current_user_id(),
                'acceptbluev2'
            );
            foreach ( $customer_tokens as $token ) {
                $raw = $token->get_token();
                if ( empty( $raw ) || $raw === 'tkn-' ) {
                    continue; // skip invalid / empty-ref tokens
                }
                $saved_tokens[] = [
                    'id'           => $token->get_id(),
                    'card_type'    => $token->get_card_type(),
                    'last4'        => $token->get_last4(),
                    'expiry_month' => $token->get_expiry_month(),
                    'expiry_year'  => $token->get_expiry_year(),
                    'is_default'   => $token->is_default(),
                ];
            }
        }

        $show_icon = $this->get_setting( 'show_icon', 'yes' ) === 'yes';

        // Surcharge notice data for the block checkout JS component
        $surcharge_notice = null;
        if ( $this->get_setting( 'surcharge_card', 'no' ) === 'yes'
            && $this->get_setting( 'surcharge_checkout', 'no' ) === 'yes' ) {
            try {
                $client     = new WC_AcceptBlue_API_v2();
                $is_enabled = $client->is_surcharge_enabled();
                if ( ! empty( $is_enabled['code'] ) && $is_enabled['code'] !== false ) {
                    $surcharge = $client->get_surcharge_info();
                    if ( ! empty( $surcharge['fee']['value'] ) ) {
                        $sv    = (float) $surcharge['fee']['value'];
                        $stype = $surcharge['fee']['type'];
                        $sname = ! empty( $surcharge['name'] ) ? $surcharge['name'] : '';
                        $cart  = function_exists( 'WC' ) ? WC()->cart : null;
                        if ( $cart && ! $cart->is_empty() ) {
                            $subtotal = $cart->get_cart_contents_total()
                                      + $cart->get_shipping_total()
                                      + $cart->get_taxes_total()
                                      + $cart->get_fee_total();
                            if ( $subtotal > 0 ) {
                                $fee_amount = ( $stype === 'percent' )
                                    ? round( $subtotal * ( $sv / 100 ), 2 )
                                    : $sv;
                                if ( $fee_amount > 0 ) {
                                    $surcharge_notice = [
                                        'fee_formatted' => html_entity_decode( strip_tags( wc_price( $fee_amount ) ) ),
                                        'fee_name'      => $sname,
                                        'fee_extra'     => $stype === 'percent' ? ' (' . $sv . '%)' : '',
                                    ];
                                }
                            }
                        }
                    }
                }
            } catch ( Exception $e ) {
                // Surcharge notice failed — skip silently
            }
        }

        // Detect trial subscription ($0 total) so JS can pass 0.01 to verify3DS
        $is_trial_subscription = false;
        if ( $total_amount <= 0 ) {
            if ( class_exists( 'WC_Subscriptions_Cart' ) && method_exists( 'WC_Subscriptions_Cart', 'cart_contains_subscription' ) ) {
                $is_trial_subscription = (bool) WC_Subscriptions_Cart::cart_contains_subscription();
            }
            if ( ! $is_trial_subscription && function_exists( 'WC' ) && WC()->cart ) {
                foreach ( WC()->cart->get_cart() as $item ) {
                    $product = isset( $item['data'] ) ? $item['data'] : null;
                    if ( $product && is_a( $product, 'WC_Product' ) && strpos( $product->get_type(), 'subscription' ) !== false ) {
                        $is_trial_subscription = true;
                        break;
                    }
                }
            }
        }

        return [
            'title'       => $this->gateway ? $this->gateway->get_title()       : '',
            'description' => $this->gateway ? $this->gateway->get_description() : '',
            'supports'     => $this->gateway ? $this->gateway->supports           : [],
            'tokenization' => $this->get_setting( 'tokenization', 'no' ) === 'yes' ? 1 : 0,
            'icon_url'    => $show_icon
                ? plugins_url( 'assets/images/icons/icon-32.png', AB_V2_PLUGIN_FILE )
                : '',
            'icon_url_2x' => $show_icon
                ? plugins_url( 'assets/images/icons/icon-64.png', AB_V2_PLUGIN_FILE )
                : '',
            'card_number_field_label' => $this->get_setting( 'card_number_field_label', __( 'Card number',      'woocommerce' ) ),
            'card_expiry_field_label' => $this->get_setting( 'card_expiry_field_label', __( 'Expiry (MM/YY)',   'woocommerce' ) ),
            'card_cvc_field_label'    => $this->get_setting( 'card_cvc_field_label',    __( 'Card code (CVC)', 'woocommerce' ) ),
            'is_logged_in'      => is_user_logged_in(),
            'save_card_enabled' => is_user_logged_in() && $this->get_setting( 'save_card_token_disable', 'no' ) !== 'yes',
            'force_save_card'   => $this->get_setting( 'force_save_card_token',   'no' ) === 'yes',
            'save_card_label'   => $this->get_setting( 'save_card_label', __( 'Save to account', 'woocommerce' ) ),
            'saved_tokens'      => $saved_tokens,
            'pk_hosted_token' => $pk_hosted_token,
            'pk_threeds_key'  => $pk_threeds_key,
            'sandbox'         => $testmode === 'yes' ? 1 : 0,
            'threeDS'         => $this->get_setting( 'threeds',             'no' ) === 'yes' ? 1 : 0,
            'frictionless'    => $this->get_setting( 'threeds_frictionless', 'no' ) === 'yes' ? 1 : 0,
            'order_total'          => $total_amount,
            'is_trial_subscription' => $is_trial_subscription ? 1 : 0,
            'form_color_scheme'   => $this->get_setting( 'form_color_scheme',   'auto' ),
            'custom_color_bg'     => $this->get_setting( 'custom_color_bg',     '#f7f7f7' ),
            'custom_color_text'   => $this->get_setting( 'custom_color_text',   '#333333' ),
            'custom_color_border' => $this->get_setting( 'custom_color_border', '#cccccc' ),
            'surcharge_notice'    => $surcharge_notice,
        ];
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    /**
     * Resolve the gateway instance from the WC payment gateways registry.
     *
     * Returns null if WC isn't ready or the gateway isn't registered yet —
     * callers must guard against null.
     *
     * @return WC_Gateway_AcceptBlue_v2|null
     */
    private function resolve_gateway() {
        if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways ) {
            return null;
        }

        $gateways = WC()->payment_gateways()->payment_gateways();

        // Prefer the Addons class when subscriptions are active
        if ( isset( $gateways['acceptbluev2'] ) ) {
            return $gateways['acceptbluev2'];
        }

        return null;
    }

    /**
     * Safe settings accessor with a default fallback.
     * Reads from $this->settings (the raw WC option array).
     *
     * @param  string $key
     * @param  mixed  $default
     * @return mixed
     */
    protected function get_setting( $key, $default = '' ) {
        return $this->settings[ $key ] ?? $default;
    }

    /**
     * Get the pre-surcharge order total in a Blocks-safe way.
     *
     * For the normal checkout path this returns the raw cart total; the caller
     * (get_payment_method_data) strips the surcharge via remove_surcharge() which
     * reads WC()->cart->get_fees().
     *
     * On the order-pay page (e.g. admin-created fee-only order sent as a payment
     * link) the cart is empty, so remove_surcharge() would find no fees and return
     * the total unchanged. Here we fall back to the WC_Order total and subtract any
     * surcharge fee directly from the order's fee line items before returning, so
     * the caller's remove_surcharge() pass is a no-op (correct) rather than missing.
     *
     * @return float
     */
    private function get_cart_total() {
        // Normal checkout — cart has items; let get_payment_method_data strip surcharge
        if ( function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
            $raw = (float) WC()->cart->get_total( 'edit' );
            // Substitute 0.01 for $0 trial subscription orders so verify3DS
            // matches the $0.01 auth-and-void the API flow sends.
            return WC_Gateway_AcceptBlue_v2::get_threeds_amount( $raw, 0 );
        }

        // Order-pay page (manual/fee-only order with empty cart)
        if ( function_exists( 'is_checkout_pay_page' ) && is_checkout_pay_page() ) {
            $order_id = absint( get_query_var( 'order-pay' ) );
            if ( $order_id > 0 ) {
                $order = wc_get_order( $order_id );
                if ( $order instanceof WC_Order ) {
                    // Use order total minus the surcharge fee line item.
                    // The "subtotal + shipping + tax" approach fails for fee-only orders
                    // (e.g. $0 subtotal + $20 fee) — subtotal = 0 produces amount = 0
                    // which causes 3DS verify to fail. get_order_total_excluding_surcharge()
                    // starts from the real order total and subtracts only the surcharge fee.
                    // Also substitute 0.01 for $0 trial subscription orders.
                    $raw = (float) WC_Gateway_AcceptBlue_v2::get_order_total_excluding_surcharge( $order );
                    return WC_Gateway_AcceptBlue_v2::get_threeds_amount( $raw, $order_id );
                }
            }
        }

        return 0.0;
    }

    /**
     * Proxy to WC_Gateway_AcceptBlue_v2::log() for error reporting inside
     * this class without instantiating the full gateway.
     *
     * @param string $message
     * @param string $level
     */
    private static function log( $message, $level = 'info' ) {
        if ( class_exists( 'WC_Gateway_AcceptBlue_v2' ) ) {
            WC_Gateway_AcceptBlue_v2::log( $message, $level );
        }
    }
}
