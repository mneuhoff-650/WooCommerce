<?php
/**
 * accept.blue — Google Pay Gateway
 *
 * Settings hub + standalone WooCommerce checkout payment method.
 * Fully independent from the main acceptbluev2 gateway — has its own
 * API keys, testmode switch, and request_api() so it works even when
 * the main gateway is disabled.
 *
 * @package WC_AcceptBlue_v2
 * @since   1.15.3
 */

defined( 'ABSPATH' ) || exit;

class WC_Gateway_AcceptBlue_v2_GooglePay_Checkout extends WC_Payment_Gateway {

	const OPTION_KEY = 'woocommerce_acceptbluev2_googlepay_checkout_settings';

	/* ── Own API credentials ──────────────────────────────────────────── */
	private string $api_key  = '';
	private string $api_pin  = '';
	private string $api_url  = 'https://api.accept.blue/api/v2/';

	public bool $testmode = false;

	/** @var WC_Gateway_AcceptBlue_v2|null */
	private $main_gw = null;

	/* ================================================================== */
	/* A. Constructor                                                       */
	/* ================================================================== */

	public function __construct() {
		$this->id                 = 'acceptbluev2_googlepay_checkout';
		$this->has_fields         = true;
		$this->method_title       = __( 'Google Pay (accept.blue)', 'woocommerce' );
		$this->method_description = __( 'Accept Google Pay payments via accept.blue. Configure API credentials, button appearance, and express-button placements independently of the main gateway.', 'woocommerce' );
		$this->icon     = esc_url( plugins_url( 'assets/images/google_pay/google-pay-icon.svg', AB_V2_PLUGIN_FILE ) );
		$this->supports = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title',       __( 'Google Pay', 'woocommerce' ) );
		$this->description = $this->get_option( 'description', '' );
		$this->enabled     = $this->get_option( 'enabled', 'yes' );
		$this->testmode    = ( $this->get_option( 'testmode', 'yes' ) === 'yes' );

		// Resolve API keys: own settings first, then fall back to the main
		// gateway's saved option row. We read the option directly (NOT via
		// WC()->payment_gateways()) to avoid triggering gateway instantiation
		// inside the constructor which would cause infinite recursion.
		$own_live_key = $this->get_option( 'live_api_key', '' );
		$own_test_key = $this->get_option( 'test_api_key', '' );
		$own_live_pin = $this->get_option( 'live_pin', '' );
		$own_test_pin = $this->get_option( 'test_pin', '' );

		$main_settings = get_option( 'woocommerce_acceptbluev2_settings', array() );
		$fallback_key  = $this->testmode
			? ( $main_settings['test_api_key'] ?? '' )
			: ( $main_settings['live_api_key'] ?? '' );
		$fallback_pin  = $this->testmode
			? ( $main_settings['test_pin'] ?? '' )
			: ( $main_settings['live_pin'] ?? '' );

		if ( $this->testmode ) {
			$this->api_key = $own_test_key ?: $fallback_key;
			$this->api_pin = $own_test_pin ?: $fallback_pin;
			$this->api_url = 'https://api.sandbox.accept.blue/api/v2/';
		} else {
			$this->api_key = $own_live_key ?: $fallback_key;
			$this->api_pin = $own_live_pin ?: $fallback_pin;
			$this->api_url = 'https://api.accept.blue/api/v2/';
		}

		// Hooks
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'maybe_create_order_review_page' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'admin_notices',         array( $this, 'admin_notices' ) );
		add_action( 'wp_enqueue_scripts',    array( $this, 'enqueue_scripts' ) );
	}

	/* ================================================================== */
	/* B. Form fields                                                       */
	/* ================================================================== */

	public function init_form_fields() {
		$page_list = array( '' => __( '— Select a page —', 'woocommerce' ) );
		foreach ( get_pages() as $page ) {
			$page_list[ $page->ID ] = $page->post_title;
		}

		$this->form_fields = array(

			/* ── General ─────────────────────────────────────────────── */
			'section_general' => array( 'title' => __( 'General', 'wc-ab-ae' ), 'type' => 'title' ),
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Google Pay as a checkout payment method', 'woocommerce' ),
				'default' => 'yes',
			),
			'title' => array(
				'title'    => __( 'Title', 'woocommerce' ),
				'type'     => 'text',
				'default'  => __( 'Google Pay', 'woocommerce' ),
				'desc_tip' => true,
				'description' => __( 'Label shown to the customer in the payment methods list.', 'woocommerce' ),
			),
			'description' => array(
				'title'   => __( 'Description', 'woocommerce' ),
				'type'    => 'textarea',
				'default' => __( 'Pay quickly and securely using Google Pay.', 'woocommerce' ),
				'description' => __( 'Displayed below the payment method title on checkout.', 'woocommerce' ),
			),

			/* ── API Keys ─────────────────────────────────────────────── */
			'section_api' => array( 'title' => __( 'API Keys', 'wc-ab-ae' ), 'type' => 'title' ),
			'testmode' => array(
				'title'       => __( 'Test Mode', 'woocommerce' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable Test Mode (sandbox)', 'woocommerce' ),
				'default'     => 'yes',
				'description' => __( 'Use sandbox credentials. Disable for live payments.', 'woocommerce' ),
			),
			'test_api_key' => array(
				'title'       => __( 'Test API Key', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Sandbox API key from accept.blue. Leave blank to use the main gateway\'s key.', 'woocommerce' ),
				'default'     => '',
				'desc_tip'    => false,
			),
			'live_api_key' => array(
				'title'       => __( 'Live API Key', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Production API key from accept.blue. Leave blank to use the main gateway\'s key.', 'woocommerce' ),
				'default'     => '',
				'desc_tip'    => false,
			),
			'test_pin' => array(
				'title'       => __( 'Test PIN', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Sandbox PIN. Leave blank to use the main gateway\'s PIN.', 'woocommerce' ),
				'default'     => '',
				'desc_tip'    => false,
			),
			'live_pin' => array(
				'title'       => __( 'Live PIN', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Production PIN. Leave blank to use the main gateway\'s PIN.', 'woocommerce' ),
				'default'     => '',
				'desc_tip'    => false,
			),

			/* ── Google Pay Credentials ───────────────────────────────── */
			'section_credentials' => array( 'title' => __( 'Google Pay Credentials', 'wc-ab-ae' ), 'type' => 'title' ),
			'google_merchant_id' => array(
				'title'       => __( 'Google Merchant ID', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Your Google Pay Merchant ID or Payments Profile ID. Required for production.', 'woocommerce' ),
				'default'     => '',
			),
			'google_merchant_name' => array(
				'title'       => __( 'Google Merchant Name', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Shown to customers inside the Google Pay sheet.', 'woocommerce' ),
				'default'     => '',
			),
			'gateway_merchant_id' => array(
				'title'       => __( 'Gateway Merchant ID', 'woocommerce' ),
				'type'        => 'text',
				'description' => __( 'Your accept.blue Gateway Merchant ID for Google Pay tokenization.', 'woocommerce' ),
				'default'     => '',
			),

			/* ── Express Buttons ──────────────────────────────────────── */
			'section_buttons' => array( 'title' => __( 'Express Buttons & Appearance', 'wc-ab-ae' ), 'type' => 'title' ),
			'google_pay_button_product_enable' => array(
				'title'   => __( 'Product Page', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show Google Pay express button on product pages', 'woocommerce' ),
				'default' => 'yes',
			),
			'google_pay_button_cart_enable' => array(
				'title'   => __( 'Cart Page', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show Google Pay express button on the cart page', 'woocommerce' ),
				'default' => 'yes',
			),
			'google_pay_button_checkout_enable' => array(
				'title'   => __( 'Checkout Page (Express)', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show Google Pay express button above the checkout form', 'woocommerce' ),
				'default' => 'yes',
			),
			'button_color' => array(
				'title'    => __( 'Button Color', 'woocommerce' ),
				'type'     => 'select',
				'default'  => 'default',
				'desc_tip' => true,
				'description' => __( 'Google Pay button color.', 'woocommerce' ),
				'options'  => array( 'default' => 'Default', 'black' => 'Black', 'white' => 'White' ),
			),
			'button_type' => array(
				'title'    => __( 'Button Type', 'woocommerce' ),
				'type'     => 'select',
				'default'  => 'buy',
				'desc_tip' => true,
				'description' => __( 'Google Pay button label type.', 'woocommerce' ),
				'options'  => array(
					'buy' => 'Buy', 'checkout' => 'Checkout', 'donate' => 'Donate',
					'pay' => 'Pay', 'order' => 'Order', 'plain' => 'Plain', 'subscribe' => 'Subscribe',
				),
			),
			'button_locale' => array(
				'title'    => __( 'Button Locale', 'woocommerce' ),
				'type'     => 'select',
				'default'  => 'en',
				'desc_tip' => true,
				'description' => __( 'Language for the Google Pay button label.', 'woocommerce' ),
				'options'  => array(
					'ar' => 'Arabic', 'bg' => 'Bulgarian', 'ca' => 'Catalan', 'zh' => 'Chinese',
					'hr' => 'Croatian', 'cs' => 'Czech', 'da' => 'Danish', 'nl' => 'Dutch',
					'en' => 'English', 'et' => 'Estonian', 'fi' => 'Finnish', 'fr' => 'French',
					'de' => 'German', 'el' => 'Greek', 'id' => 'Indonesian', 'it' => 'Italian',
					'ja' => 'Japanese', 'ko' => 'Korean', 'ms' => 'Malay', 'no' => 'Norwegian',
					'pl' => 'Polish', 'pt' => 'Portuguese', 'ru' => 'Russian', 'sr' => 'Serbian',
					'sk' => 'Slovak', 'sl' => 'Slovenian', 'es' => 'Spanish', 'sv' => 'Swedish',
					'th' => 'Thai', 'tr' => 'Turkish', 'uk' => 'Ukrainian',
				),
			),

			/* ── Advanced ─────────────────────────────────────────────── */
			'section_advanced' => array( 'title' => __( 'Advanced', 'wc-ab-ae' ), 'type' => 'title' ),
			'card_networks' => array(
				'title'             => __( 'Card Networks', 'woocommerce' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select',
				'css'               => 'width: 450px;',
				'default'           => array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' ),
				'description'       => __( 'Accepted card networks.', 'woocommerce' ),
				'desc_tip'          => true,
				'options'           => array( 'AMEX' => 'AMEX', 'DISCOVER' => 'DISCOVER', 'INTERAC' => 'INTERAC', 'JCB' => 'JCB', 'MASTERCARD' => 'MASTERCARD', 'VISA' => 'VISA' ),
				'custom_attributes' => array( 'data-placeholder' => __( 'Select card networks', 'woocommerce' ) ),
			),
			'card_auth_methods' => array(
				'title'             => __( 'Auth Methods', 'woocommerce' ),
				'type'              => 'multiselect',
				'class'             => 'wc-enhanced-select',
				'css'               => 'width: 450px;',
				'default'           => array( 'PAN_ONLY' ),
				'description'       => __( 'Allowed card authentication methods.', 'woocommerce' ),
				'desc_tip'          => true,
				'options'           => array( 'PAN_ONLY' => 'PAN_ONLY', 'CRYPTOGRAM_3DS' => 'CRYPTOGRAM_3DS' ),
				'custom_attributes' => array( 'data-placeholder' => __( 'Select auth methods', 'woocommerce' ) ),
			),
			'google_pay_billing_address_required' => array(
				'title'   => __( 'Require Billing Address', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Request full billing address from Google Pay', 'woocommerce' ),
				'default' => 'no',
			),
			'google_pay_phone_number_required' => array(
				'title'   => __( 'Require Phone Number', 'woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Request phone number from Google Pay', 'woocommerce' ),
				'default' => 'no',
			),
			'order_review_enable' => array(
				'title'       => __( 'Order Review Page', 'woocommerce' ),
				'type'        => 'checkbox',
				'label'       => __( 'Redirect to an Order Review page after Google Pay authorisation', 'woocommerce' ),
				'description' => __( 'When enabled and no page is selected, a review page is created automatically.', 'woocommerce' ),
				'default'     => 'no',
			),
			'order_review_page' => array(
				'title'   => __( 'Review Page', 'woocommerce' ),
				'type'    => 'select',
				'description' => __( 'Page containing [acceptblue_googlepay_review_order] shortcode.', 'woocommerce' ),
				'default' => '',
				'options' => $page_list,
			),
		);
	}

	/* ================================================================== */
	/* C. Admin UI — tabbed settings matching the main gateway template   */
	/* ================================================================== */

	public function admin_enqueue_scripts( $hook ) {
		if ( 'woocommerce_page_wc-settings' !== $hook ) {
			return;
		}
		// The main gateway already enqueues acceptblue-v2-settings on this screen.
		// If it's disabled those handles won't be registered — enqueue them here.
		if ( ! wp_style_is( 'acceptblue-v2-settings', 'enqueued' ) ) {
			wp_enqueue_style(
				'acceptblue-v2-settings',
				plugins_url( 'assets/css/dist/acceptblue-settings.min.css', AB_V2_PLUGIN_FILE ),
				array(),
				AB_V2_VERSION
			);
		}
		if ( ! wp_script_is( 'acceptblue-v2-settings', 'enqueued' ) ) {
			wp_enqueue_script(
				'acceptblue-v2-settings',
				plugins_url( 'assets/js/dist/acceptblue-settings.min.js', AB_V2_PLUGIN_FILE ),
				array( 'jquery' ),
				AB_V2_VERSION,
				true
			);
		}
	}

	public function admin_options() {
		$tabs = array(
			'general'     => __( 'General',      'wc-ab-ae' ),
			'api'         => __( 'API Keys',      'wc-ab-ae' ),
			'credentials' => __( 'Google Pay',    'wc-ab-ae' ),
			'buttons'     => __( 'Buttons',       'wc-ab-ae' ),
			'advanced'    => __( 'Advanced',      'wc-ab-ae' ),
		);

		$tab_sections = array(
			'general'     => 'section_general',
			'api'         => 'section_api',
			'credentials' => 'section_credentials',
			'buttons'     => 'section_buttons',
			'advanced'    => 'section_advanced',
		);

		$settings    = $this->settings;
		$is_testmode = ( $settings['testmode'] ?? 'yes' ) === 'yes';
		$missing_api = $is_testmode
			? empty( $settings['test_api_key'] ?? '' )
			: empty( $settings['live_api_key'] ?? '' );
		// Missing is OK if main gateway key is set
		$main = $this->get_main_gateway();
		if ( $missing_api && $main ) {
			$main_key = $is_testmode ? $main->get_option('test_api_key','') : $main->get_option('live_api_key','');
			if ( ! empty( $main_key ) ) {
				$missing_api = false;
			}
		}
		?>
		<div id="acceptblue-ab-settings-wrap">

			<!-- Header -->
			<div class="acceptblue-ab-header">
				<div class="acceptblue-ab-header-left">
					<img src="<?php echo esc_url( plugins_url( 'assets/images/google_pay/google-pay-icon.svg', AB_V2_PLUGIN_FILE ) ); ?>"
					     alt="Google Pay" class="acceptblue-ab-header-logo" style="height:32px;width:auto;" />
					<div>
						<strong class="acceptblue-ab-header-title"><?php esc_html_e( 'Google Pay — accept.blue', 'wc-ab-ae' ); ?></strong>
						<span class="acceptblue-ab-header-version"><?php echo esc_html( AB_V2_VERSION ); ?></span>
					</div>
				</div>
				<div class="acceptblue-ab-header-actions">
					<a href="https://acceptblue.ryanplugins.net/blog/docs/accept-blue-version-2/"
					   target="_blank" rel="noopener" class="button button-secondary">
						<?php esc_html_e( '📖 Docs', 'wc-ab-ae' ); ?>
					</a>
					<a href="https://www.patreon.com/RyanPlugins/membership"
					   target="_blank" rel="noopener" class="button button-secondary">
						<?php esc_html_e( '❤️ Support', 'wc-ab-ae' ); ?>
					</a>
				</div>
			</div>

			<!-- Tab nav -->
			<div class="acceptblue-ab-nav-tabs" role="tablist">
				<?php foreach ( $tabs as $slug => $label ) : ?>
				<button type="button"
				        class="acceptblue-ab-nav-tab"
				        data-tab="<?php echo esc_attr( $slug ); ?>"
				        role="tab"
				        aria-selected="false"
				        aria-controls="acceptblue-ab-panel-<?php echo esc_attr( $slug ); ?>">
					<?php echo esc_html( $label ); ?>
					<?php if ( $slug === 'api' && $missing_api ) : ?>
					<span class="acceptblue-ab-tab-badge acceptblue-ab-tab-badge-warn"
					      title="<?php esc_attr_e( 'API key not set', 'wc-ab-ae' ); ?>">!</span>
					<?php endif; ?>
				</button>
				<?php endforeach; ?>
				<?php if ( $this->testmode ) : ?>
				<span class="acceptblue-ab-test-indicator">🧪 <?php esc_html_e( 'Test Mode', 'wc-ab-ae' ); ?></span>
				<?php endif; ?>
			</div>

			<!-- Tab panels -->
			<?php
			ob_start();
			$this->generate_settings_html();
			$html = ob_get_clean();

			// Split at section boundaries — IDs have the gateway prefix
			$gw_id   = str_replace( '-', '_', $this->id ); // acceptbluev2_googlepay_checkout
			$pattern = '/<\/table>[\s\S]*?<h3[^>]*id="woocommerce_' . preg_quote( $gw_id, '/' ) . '_(section_[^"]+)"[^>]*>[\s\S]*?<\/h3>[\s\S]*?<table[^>]*>/';
			$chunks  = preg_split( $pattern, $html, -1, PREG_SPLIT_DELIM_CAPTURE );

			$buckets = array_fill_keys( array_values( $tab_sections ), '' );
			$buckets['section_general'] = $chunks[0] ?? '';
			for ( $i = 1; $i + 1 < count( $chunks ); $i += 2 ) {
				$key = $chunks[ $i ];
				if ( isset( $buckets[ $key ] ) ) {
					$buckets[ $key ] = $chunks[ $i + 1 ];
				}
			}

			foreach ( $tab_sections as $tab => $section_key ) : ?>
			<div class="acceptblue-ab-tab-panel"
			     id="acceptblue-ab-panel-<?php echo esc_attr( $tab ); ?>"
			     role="tabpanel"
			     data-tab="<?php echo esc_attr( $tab ); ?>">
				<div class="acceptblue-ab-section-heading"><?php echo esc_html( $tabs[ $tab ] ); ?></div>
				<table class="form-table">
					<?php echo $buckets[ $section_key ]; // phpcs:ignore ?>
				</table>
			</div>
			<?php endforeach; ?>

		</div><!-- #acceptblue-ab-settings-wrap -->
		<?php
	}

	/* ================================================================== */
	/* D. Availability                                                     */
	/* ================================================================== */

	public function is_available() {
		// Standard WC enabled/cart checks
		if ( ! parent::is_available() ) {
			return false;
		}
		// Need at least one API key (own or inherited from main gateway option)
		if ( empty( $this->api_key ) ) {
			return false;
		}
		// Currency must be supported by accept.blue + Google Pay
		$supported = array(
			'USD','EUR','GBP','CAD','AUD','JPY','MXN','NZD',
			'SGD','HKD','NOK','SEK','DKK','CHF','PLN','BRL','PHP',
		);
		if ( ! in_array( get_woocommerce_currency(), $supported, true ) ) {
			return false;
		}
		// No dependency on the main acceptbluev2 gateway being enabled —
		// this gateway is fully standalone.
		return true;
	}

	/* ================================================================== */
	/* E. Payment fields                                                   */
	/* ================================================================== */

	public function payment_fields() {
		if ( $this->description ) {
			echo wp_kses_post( wpautop( wptexturize( $this->description ) ) );
		}
		$nonce = wp_create_nonce( 'acceptblue-gpay-checkout-nonce' );
		?>
		<div id="acceptblue-gpay-checkout-wrap">
			<input type="hidden" id="acceptbluev2_googlepay_checkout_token"
			       name="acceptbluev2_googlepay_checkout_token" value="" />
			<input type="hidden" id="acceptbluev2_googlepay_checkout_nonce"
			       name="acceptbluev2_googlepay_checkout_nonce" value="<?php echo esc_attr( $nonce ); ?>" />
			<div id="acceptblue-gpay-checkout-button"
			     class="acceptblue-gpay-checkout-button-wrap"
			     style="min-height:48px;"></div>
			<div id="acceptblue-gpay-checkout-status" style="display:none; margin-top:8px;"></div>
		</div>
		<?php if ( $this->testmode ) : ?>
			<p class="ab-gpay-test-notice">
				&#x26A0; <strong><?php esc_html_e( 'TEST MODE — Google Pay is in sandbox environment.', 'woocommerce' ); ?></strong>
			</p>
		<?php endif; ?>
		<?php
	}

	/* ================================================================== */
	/* F. Enqueue frontend scripts                                         */
	/* ================================================================== */

	public function enqueue_scripts() {
		if ( ! is_checkout() || is_checkout_pay_page() || ! $this->is_available() ) {
			return;
		}

		if ( ! wp_script_is( 'google-pay', 'enqueued' ) ) {
			wp_enqueue_script( 'google-pay', 'https://pay.google.com/gp/p/js/pay.js', array(), null, true );
		}

		wp_enqueue_script(
			'acceptblue-gpay-checkout-method',
			plugins_url( 'assets/js/src/acceptblue-google-pay-checkout-payment-method.js', AB_V2_PLUGIN_FILE ),
			array( 'jquery', 'google-pay' ),
			AB_V2_VERSION,
			true
		);

		// Build params directly from own settings — no dependency on the main
		// gateway being enabled or instantiated, so this works standalone.
		$settings = $this->settings;
		$merchant_id = preg_replace( '/[^0-9]/', '', $settings['google_merchant_id'] ?? '' );
		// Normalise multiselect arrays — WC may store them as assoc ['VISA'=>'VISA'].
		// JSON-encoding an assoc array produces an object {}, not an array [] in JS.
		$raw_networks = $settings['card_networks']    ?? array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' );
		$raw_auths    = $settings['card_auth_methods'] ?? array( 'PAN_ONLY' );
		$card_networks     = is_array( $raw_networks ) ? array_values( array_filter( array_map( 'strval', $raw_networks ) ) ) : array( 'AMEX', 'DISCOVER', 'INTERAC', 'JCB', 'MASTERCARD', 'VISA' );
		$card_auth_methods = is_array( $raw_auths )    ? array_values( array_filter( array_map( 'strval', $raw_auths ) ) )    : array( 'PAN_ONLY' );
		$country_code = WC()->countries ? WC()->countries->get_base_country() : 'US';
		$country_code = $country_code ?: 'US';

		$gpay_params = array(
			'google_pay_merchant_name'              => $settings['google_merchant_name'] ?? '',
			'google_pay_environment'                => $this->testmode ? 'TEST' : 'PRODUCTION',
			'google_pay_merchant_id'                => $merchant_id,
			'google_pay_country_code'               => $country_code,
			'gateway_merchant_id'                   => trim( $settings['gateway_merchant_id'] ?? '' ),
			'allowed_card_networks'                 => $card_networks,
			'allowed_card_auth_methods'             => $card_auth_methods,
			'button_color'                          => $settings['button_color']  ?? 'default',
			'button_type'                           => $settings['button_type']   ?? 'buy',
			'button_locale'                         => $settings['button_locale'] ?? 'en',
			'google_pay_billing_address_required'   => ( ( $settings['google_pay_billing_address_required'] ?? 'no' ) === 'yes' ) ? 1 : 0,
			'google_pay_phone_number_required'      => ( ( $settings['google_pay_phone_number_required']    ?? 'no' ) === 'yes' ) ? 1 : 0,
			'surcharge_card'                        => 'no',
			'is_user_logged_in'                     => is_user_logged_in() ? 1 : 0,
			'gateway_id'                            => $this->id,
			'currency_code'                         => get_woocommerce_currency(),
			'cart_total'                            => number_format( (float) WC()->cart->get_total( 'edit' ), 2, '.', '' ),
			'nonce'                                 => wp_create_nonce( 'acceptblue-gpay-checkout-nonce' ),
			'ajax_url'                              => admin_url( 'admin-ajax.php' ),
			'i18n'                                  => array(
				'gpay_not_ready' => __( 'Google Pay is not available on this device.', 'woocommerce' ),
				'payment_failed' => __( 'Google Pay payment failed. Please try again.', 'woocommerce' ),
				'complete_gpay'  => __( 'Please complete the Google Pay sheet to continue.', 'woocommerce' ),
				'token_stored'   => __( 'Google Pay authorised. Placing order...', 'woocommerce' ),
			),
		);

		wp_localize_script( 'acceptblue-gpay-checkout-method', 'acceptblue_gpay_checkout_params', $gpay_params );
		wp_add_inline_style( 'woocommerce-general', $this->get_checkout_css() );
	}

	/* ================================================================== */
	/* G. process_payment                                                  */
	/* ================================================================== */

	public function process_payment( $order_id ) {

		$raw_token = isset( $_POST['acceptbluev2_googlepay_checkout_token'] )
			? sanitize_text_field( wp_unslash( $_POST['acceptbluev2_googlepay_checkout_token'] ) ) : '';

		if ( empty( $raw_token ) ) {
			wc_add_notice( __( 'Google Pay payment token is missing. Please click the Google Pay button to authorise.', 'woocommerce' ), 'error' );
			return array( 'result' => 'fail' );
		}

		$gpay_nonce     = isset( $_POST['acceptbluev2_googlepay_checkout_nonce'] )
			? sanitize_text_field( wp_unslash( $_POST['acceptbluev2_googlepay_checkout_nonce'] ) ) : '';
		$is_block       = isset( $_POST['acceptbluev2_googlepay_block_checkout'] )
			&& sanitize_text_field( wp_unslash( $_POST['acceptbluev2_googlepay_block_checkout'] ) ) === '1';

		if ( ! $is_block && ! wp_verify_nonce( $gpay_nonce, 'acceptblue-gpay-checkout-nonce' ) ) {
			wc_add_notice( __( 'Security check failed. Please refresh and try again.', 'woocommerce' ), 'error' );
			return array( 'result' => 'fail' );
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		$payment_token = base64_decode( $raw_token );
		if ( ! $payment_token ) {
			wc_add_notice( __( 'Invalid Google Pay token. Please try again.', 'woocommerce' ), 'error' );
			return array( 'result' => 'fail' );
		}

		if ( empty( $this->api_key ) ) {
			wc_add_notice( __( 'Google Pay is not configured. Please contact the shop owner.', 'woocommerce' ), 'error' );
			return array( 'result' => 'fail' );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wc_add_notice( __( 'Order not found. Please try again.', 'woocommerce' ), 'error' );
			return array( 'result' => 'fail' );
		}

		// Remove any surcharge fee that may have been added by the main gateway —
		// Google Pay does not pass a surcharge.
		$main = $this->get_main_gateway();
		if ( $main && method_exists( $main, 'custom_remove_specific_fee_from_order' ) ) {
			$main->custom_remove_specific_fee_from_order( $order_id );
		}

		$order->update_meta_data( 'payment_token', $payment_token );
		$order->set_payment_method( $this->id );
		$order->set_payment_method_title( $this->title );
		$order->save();

		// Billing / shipping
		$billing_info = array(
			'first_name' => $order->get_billing_first_name(),
			'last_name'  => $order->get_billing_last_name(),
			'street'     => $order->get_billing_address_1(),
			'street2'    => $order->get_billing_address_2(),
			'city'       => $order->get_billing_city(),
			'state'      => $order->get_billing_state(),
			'zip'        => $order->get_billing_postcode(),
			'country'    => $order->get_billing_country(),
			'phone'      => $order->get_billing_phone(),
		);
		$shipping_info = array(
			'first_name' => $order->get_shipping_first_name() ?: $order->get_billing_first_name(),
			'last_name'  => $order->get_shipping_last_name()  ?: $order->get_billing_last_name(),
			'street'     => $order->get_shipping_address_1()  ?: $order->get_billing_address_1(),
			'street2'    => $order->get_shipping_address_2()  ?: $order->get_billing_address_2(),
			'city'       => $order->get_shipping_city()       ?: $order->get_billing_city(),
			'state'      => $order->get_shipping_state()      ?: $order->get_billing_state(),
			'zip'        => $order->get_shipping_postcode()   ?: $order->get_billing_postcode(),
			'country'    => $order->get_shipping_country()    ?: $order->get_billing_country(),
			'phone'      => $order->get_billing_phone(),
		);
		$transaction_details = array(
			'description'    => sprintf( '%s - ORDER No. #%s', ucwords( get_bloginfo( 'name' ) ), $order->get_order_number() ),
			'client_ip'      => WC_Geolocation::get_ip_address(),
			'order_number'   => $order->get_order_number(),
			'invoice_number' => $order->get_order_number(),
			'terminal'       => $this->title,
		);

		// Google Pay does not apply a surcharge fee.
		$order->calculate_totals();
		$order->save();
		$charge_amount = (float) $order->get_total();

		// Level-3
		$level3 = ( $main && method_exists( $main, 'level3_data_line_items' ) )
			? (array) $main->level3_data_line_items( $order->get_id() )
			: array();

		// Force capture
		$force_capture = $main ? (bool) $main->force_capture : true;

		$params = array_merge( array(
			'amount'              => (double) $charge_amount,
			'source'              => 'googlepay',
			'token'               => $payment_token,
			'billing_info'        => $billing_info,
			'shipping_info'       => $shipping_info,
			'avs_zip'             => $order->get_billing_postcode(),
			'avs_address'         => trim( $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() ),
			'transaction_details' => $transaction_details,
			'amount_details'      => array( 'tax' => 0.0, 'shipping' => 0.0, 'discount' => 0.0 ),
			'capture'             => $force_capture,
		), $level3 );

		// Use own request_api (own keys, own URL)
		$result = $this->request_api( $params, 'transactions/charge' );

		if (
			! empty( $result['response_code'] )
			&& $result['response_code'] === 200
			&& ! empty( $result['response_body'] )
		) {
			$data = (array) $result['response_body'];
			if ( isset( $data['status'] ) && $data['status'] === 'Approved' ) {

				$ref_num = sanitize_text_field( $data['reference_number'] ?? '' );

				// Determine target status
				$default_status = $main ? $main->default_status : 'default';
				if ( $default_status === 'default' || $default_status === '' ) {
					$order->payment_complete( $ref_num );
				} else {
					$order->set_transaction_id( $ref_num );
					$order->update_status( $default_status );
				}

				$main_id = $main ? $main->id : 'acceptbluev2';
				$order->update_meta_data( '_' . $main_id . '_refnum', $ref_num );

				if ( ! $force_capture ) {
					$auth_amount = isset( $data['auth_amount'] ) ? (float) $data['auth_amount'] : $charge_amount;
					if ( $auth_amount > 0 ) {
						$order->update_meta_data( '_acceptblue_authorized_amount', $auth_amount );
					}
				}

				$order->add_order_note( sprintf(
					__( 'Google Pay (accept.blue) payment completed. Transaction ID: %s', 'woocommerce' ),
					$ref_num
				) );
				$order->save();

				WC()->cart->empty_cart();
				WC()->session->delete_session( 'acceptblue_v2_surcharge_info' );

				return array( 'result' => 'success', 'redirect' => $order->get_checkout_order_received_url() );

			} else {
				$err = sanitize_text_field( $data['error_message'] ?? __( 'Payment declined.', 'woocommerce' ) );
				$order->add_order_note( sprintf( __( 'Google Pay declined: %s', 'woocommerce' ), $err ) );
				wc_add_notice( $err, 'error' );
				return array( 'result' => 'fail' );
			}
		}

		$api_msg = ! empty( $result['message'] ) ? $result['message'] : __( 'Payment request failed. Please try again.', 'woocommerce' );
		$order->add_order_note( sprintf( __( 'Google Pay API error: %s', 'woocommerce' ), $api_msg ) );
		wc_add_notice( $api_msg, 'error' );
		return array( 'result' => 'fail' );
	}

	/* ================================================================== */
	/* H. Own request_api — uses own keys, own URL                        */
	/* ================================================================== */

	public function request_api( array $params, string $action, string $method = 'POST' ) {
		$body = json_encode( $params, JSON_PRESERVE_ZERO_FRACTION );

		$response = wp_remote_request(
			$this->api_url . $action,
			array(
				'method'     => $method,
				'headers'    => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Basic ' . base64_encode( $this->api_key . ':' . $this->api_pin ),
				),
				'body'       => $body,
				'timeout'    => 90,
				'sslverify'  => true,
				'user-agent' => 'accept.blue Google Pay for WooCommerce ' . AB_V2_VERSION,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'code' => false, 'message' => $response->get_error_message() );
		}

		$decoded = json_decode( $response['body'] );
		return array(
			'code'             => true,
			'response_code'    => $response['response']['code'],
			'response_message' => $response['response']['message'],
			'response_body'    => $decoded,
		);
	}

	/* ================================================================== */
	/* I. Admin notices                                                    */
	/* ================================================================== */

	public function admin_notices() {
		$this->admin_notice_gpay_disabled();
		$this->admin_notice_gpay_api_key();
		$this->admin_notice_gpay_merchant_id();
		$this->admin_notice_gpay_country_code();
		$this->admin_notice_review_page();
	}

	private function admin_notice_gpay_disabled() {
		if ( ! $this->is_gpay_settings_screen() ) return;
		if ( $this->enabled === 'yes' ) return;
		?>
		<div class="notice notice-info is-dismissible">
			<p><strong>accept.blue Google Pay</strong> — <?php esc_html_e( 'Google Pay is currently disabled. Enable it on the General tab.', 'woocommerce' ); ?></p>
		</div>
		<?php
	}

	private function admin_notice_gpay_api_key() {
		if ( ! $this->is_gpay_settings_screen() ) return;
		if ( $this->enabled !== 'yes' ) return;
		if ( ! empty( $this->api_key ) ) return;
		?>
		<div class="notice notice-error">
			<p><strong>accept.blue Google Pay</strong> — <?php esc_html_e( 'No API key is configured. Enter API keys on the API Keys tab, or enable and configure the main accept.blue gateway as a fallback.', 'woocommerce' ); ?></p>
		</div>
		<?php
	}

	private function admin_notice_gpay_merchant_id() {
		if ( ! $this->is_gpay_settings_screen() ) return;
		if ( $this->enabled !== 'yes' ) return;

		// Gateway Merchant ID is required for ALL environments — empty value
		// causes OR_BIBED_11 from Google Pay and buttons will not render.
		$gateway_mid = trim( $this->get_option( 'gateway_merchant_id', '' ) );
		if ( empty( $gateway_mid ) ) {
			?>
			<div class="notice notice-error">
				<p>
					<strong>accept.blue Google Pay</strong> —
					<?php esc_html_e( 'Gateway Merchant ID is required. Without it, the Google Pay button will not appear and payments will fail with OR_BIBED_11. Enter your accept.blue Gateway Merchant ID on the Google Pay Credentials tab.', 'woocommerce' ); ?>
				</p>
			</div>
			<?php
		}

		// Google Merchant ID required in production only
		$google_mid = trim( $this->get_option( 'google_merchant_id', '' ) );
		if ( ! $this->testmode && empty( $google_mid ) ) {
			?>
			<div class="notice notice-error">
				<p><strong>accept.blue Google Pay</strong> — <?php esc_html_e( 'A Google Merchant ID is required for production. Set it on the Google Pay Credentials tab.', 'woocommerce' ); ?></p>
			</div>
			<?php
		}
	}

	private function admin_notice_gpay_country_code() {
		if ( ! $this->is_gpay_settings_screen() ) return;
		if ( $this->enabled !== 'yes' ) return;
		if ( empty( WC()->countries->get_base_country() ) ) {
			?>
			<div class="notice notice-warning">
				<p><strong>accept.blue Google Pay</strong> — <?php esc_html_e( 'Your WooCommerce store country is not set. Google Pay requires a country code — configure it under WooCommerce → Settings → General.', 'woocommerce' ); ?></p>
			</div>
			<?php
		}
	}

	public function admin_notice_review_page() {
		if ( $err = get_transient( 'ab_gpay_review_page_error' ) ) {
			delete_transient( 'ab_gpay_review_page_error' );
			echo '<div class="notice notice-error"><p>';
			printf( esc_html__( 'Google Pay: failed to auto-create Order Review page — %s', 'woocommerce' ), esc_html( $err ) );
			echo '</p></div>';
		}
		if ( $info = get_transient( 'ab_gpay_review_page_created' ) ) {
			delete_transient( 'ab_gpay_review_page_created' );
			echo '<div class="notice notice-success is-dismissible"><p>';
			printf(
				wp_kses( __( 'Google Pay: <strong>Order Review page created</strong>. <a href="%1$s" target="_blank">View</a> — <a href="%2$s">Edit</a>', 'woocommerce' ), array( 'strong' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ),
				esc_url( $info['page_url'] ),
				esc_url( $info['edit_url'] )
			);
			echo '</p></div>';
		}
	}

	/* ================================================================== */
	/* J. Order review page auto-create                                   */
	/* ================================================================== */

	public function maybe_create_order_review_page() {
		$settings = get_option( self::OPTION_KEY, array() );
		if ( empty( $settings['order_review_enable'] ) || $settings['order_review_enable'] !== 'yes' ) return;
		if ( ! empty( $settings['order_review_page'] ) ) {
			$existing = get_post( (int) $settings['order_review_page'] );
			if ( $existing && $existing->post_status === 'publish' ) return;
		}
		$found = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => 'acceptblue_googlepay_review_order', 'posts_per_page' => 1, 'fields' => 'ids' ) );
		if ( ! empty( $found ) ) {
			$page_id = $found[0];
		} else {
			$page_id = wp_insert_post( array(
				'post_title'   => __( 'Google Pay Order Review', 'woocommerce' ),
				'post_content' => '[acceptblue_googlepay_review_order]',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_author'  => get_current_user_id(),
			), true );
			if ( is_wp_error( $page_id ) ) {
				set_transient( 'ab_gpay_review_page_error', $page_id->get_error_message(), 60 );
				return;
			}
		}
		$settings['order_review_page'] = (string) $page_id;
		update_option( self::OPTION_KEY, $settings );
		set_transient( 'ab_gpay_review_page_created', array(
			'page_id'  => $page_id,
			'page_url' => get_permalink( $page_id ),
			'edit_url' => get_edit_post_link( $page_id ),
		), 60 );
	}

	/* ================================================================== */
	/* K. Helpers                                                          */
	/* ================================================================== */

	private function is_gpay_settings_screen(): bool {
		if ( ! is_admin() ) return false;
		$screen = get_current_screen();
		if ( ! $screen ) return false;
		return $screen->id === 'woocommerce_page_wc-settings'
			&& ( $_GET['tab'] ?? '' ) === 'checkout'
			&& ( $_GET['section'] ?? '' ) === $this->id;
	}

	private function get_main_gateway(): ?WC_Gateway_AcceptBlue_v2 {
		if ( $this->main_gw !== null ) return $this->main_gw;
		if ( ! function_exists( 'WC' ) ) return null;
		$wc = WC();
		if ( ! $wc || ! is_callable( array( $wc, 'payment_gateways' ) ) ) return null;
		$registry = $wc->payment_gateways();
		if ( ! $registry || ! is_callable( array( $registry, 'payment_gateways' ) ) ) return null;
		$gateways      = $registry->payment_gateways();
		$this->main_gw = $gateways['acceptbluev2'] ?? null;
		return $this->main_gw;
	}

	private function get_checkout_css(): string {
		return '
		/* Gateway icon in payment radio label */
		.payment_method_acceptbluev2_googlepay_checkout > label img,
		.wc_payment_method.payment_method_acceptbluev2_googlepay_checkout img {
		    height: 28px; width: auto; vertical-align: middle;
		    border: 1.5px solid #dadce0; border-radius: 6px;
		    padding: 3px 8px; background: #fff;
		    box-shadow: 0 1px 2px rgba(0,0,0,.08); margin-left: 6px;
		}
		/* Container */
		#acceptblue-gpay-checkout-wrap { margin: 0; padding: 0; }
		/* Description spacing */
		.payment_method_acceptbluev2_googlepay_checkout .payment_box p { margin-bottom: 14px; }
		/* Button */
		.acceptblue-gpay-checkout-button-wrap { width: 100%; max-width: 400px; margin-top: 12px; }
		.acceptblue-gpay-checkout-button-wrap .gpay-button-fill,
		.acceptblue-gpay-checkout-button-wrap > button,
		.acceptblue-gpay-checkout-button-wrap gpay-button { width: 100% !important; min-height: 48px !important; }
		/* Status messages */
		.acceptblue-gpay-checkout-status-success { color: #15803d; font-size: .875em; padding: 8px 0 0; }
		.acceptblue-gpay-checkout-status-error   { color: #dc2626; font-size: .875em; padding: 8px 0 0; }
		/* Test mode notice */
		#acceptblue-gpay-checkout-wrap .ab-gpay-test-notice { margin-top: 10px; font-size: .8em; color: #d97706; }
		/* Hide Place Order when GPay is active */
		body.acceptblue-gpay-active #payment #place_order { display: none !important; }
		';
	}
}
